package com.maha.agri.dept_cropsap;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.squareup.picasso.Picasso;

public class DepartmentCropSapActivity extends AppCompatActivity{

    private TextView dept_district_tv,dept_taluka_tv,dept_village_tv,dept_seasonname_tv,dept_cropname_tv,dept_survey_no_tv,dept_comment_tv,dept_farmer_fullname;
    private String id,name,districtname,talukaname,cropname,villagename,seasonname,filename,survey_no,comment;
    private ImageView dept_cropsap_iv;
    View parentLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_crop_sap);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Farmer CropSap Details");

        parentLayout = findViewById(android.R.id.content);
        if(isNetworkAvailable()){
            init();
            default_config();
            setCropSapValue();

        }else{
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        }

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }



    private void init(){

        dept_district_tv = (TextView) findViewById(R.id.department_district_tv);
        dept_taluka_tv = (TextView) findViewById(R.id.department_taluka_tv);
        dept_village_tv = (TextView) findViewById(R.id.department_village_tv);

        dept_seasonname_tv = (TextView) findViewById(R.id.department_season_name_tv);
        dept_cropname_tv = (TextView) findViewById(R.id.department_crop_name_tv);
        dept_survey_no_tv = (TextView) findViewById(R.id.txt_vw_survey_no_group_no_dept);
        dept_farmer_fullname = (TextView) findViewById(R.id.txt_vw_full_name_of_farmer_dept);
        dept_comment_tv = (TextView) findViewById(R.id.department_comment_tv);
        dept_cropsap_iv = (ImageView) findViewById(R.id.department_cropsap_iv);

    }

    private void default_config(){

        Intent intent = getIntent();
        id = intent.getStringExtra("farmer_id");
        name = intent.getStringExtra("farmer_name");
        survey_no = intent.getStringExtra("survey_no");
        comment = intent.getStringExtra("comment");
        filename = intent.getStringExtra("filename");

        districtname = intent.getStringExtra("district_name");
        talukaname = intent.getStringExtra("taluka_name");
        villagename = intent.getStringExtra("village_name");
        seasonname = intent.getStringExtra("season_name");
        cropname = intent.getStringExtra("crop_name");

    }

    private void setCropSapValue(){

        dept_farmer_fullname.setText(name);
        dept_survey_no_tv.setText(survey_no);
        dept_comment_tv.setText(comment);
        dept_farmer_fullname.setText(name);
        dept_survey_no_tv.setText(survey_no);
        dept_comment_tv.setText(comment);
        dept_district_tv.setText(districtname);
        dept_taluka_tv.setText(talukaname);
        dept_village_tv.setText(villagename);
        dept_seasonname_tv.setText(seasonname);
        dept_cropname_tv.setText(cropname);


        Picasso.get()
                .load(Uri.parse(filename))
                .resize(200, 300)
                .centerCrop()
                .into(dept_cropsap_iv);
    }


}
