package com.maha.agri.cropsowingreport;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.task_manager.NonSchemeListActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateFarmerWiseReportActivity extends AppCompatActivity implements ApiCallbackCode {

    //private TextView total_affected_crop_count, total_affected_area_count;
    private Button farmerwise_report_submit_btn, farmerwise_report_cancel_btn;
    private String survey_no,mobile_number,multi_consolreport_data,farmer_first="",farmer_middle="",farmer_last="";
    private int divison_id = 0,district_id = 0, taluka_id = 0, sajja_id = 0,village_id=0,scheme_id=0,farmer_id=0,year_plt_id=0,crop_type_id,horti_type_id,season_id;
    private RecyclerView generate_farmerwise_report_add_more_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray multiple_crop_field_add = new JSONArray();
    JSONArray village_wise_crop_data = new JSONArray();
    private String current_date = "",current_week="",last_week="";
    private String cureent_day = "";
    private SweetAlertDialog sweetAlertDialog;
    private ExpandableListView farmer_wise_report_expandableListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_farmer_wise_report);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Generate Farmer Wise Report");
        preferenceManager = new PreferenceManager(GenerateFarmerWiseReportActivity.this);
        sharedPref = new SharedPref(GenerateFarmerWiseReportActivity.this);
        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_id = intent.getIntExtra("sajja_id", 0);
        village_id = intent.getIntExtra("village_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        year_plt_id = intent.getIntExtra("year_plt_id",0);
        scheme_id = intent.getIntExtra("scheme_id",0);
        //farmer_id = intent.getIntExtra("farmer_id",0);
        farmer_first = intent.getStringExtra("farmer_first");
        farmer_middle = intent.getStringExtra("farmer_middle");
        farmer_last = intent.getStringExtra("farmer_last");
        survey_no = intent.getStringExtra("survey_no");
        mobile_number = intent.getStringExtra("mobile_number");
        current_week = intent.getStringExtra("current_week");
        last_week = intent.getStringExtra("last_week");
        multi_consolreport_data = intent.getStringExtra("multi_consolreport_data");

        init();
        default_config();
    }

    private void default_config() {
        try {
            multiple_crop_field_add = new JSONArray(multi_consolreport_data);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        generate_farmerwise_report_add_more_rv.setLayoutManager(new LinearLayoutManager(GenerateFarmerWiseReportActivity.this));
        GenerateFarmerWiseReportAdapter generateFarmerWiseReportAdapter = new GenerateFarmerWiseReportAdapter(preferenceManager, multiple_crop_field_add, GenerateFarmerWiseReportActivity.this);
        generate_farmerwise_report_add_more_rv.setAdapter(generateFarmerWiseReportAdapter);
        generateFarmerWiseReportAdapter.notifyDataSetChanged();

    }

    private void init() {
        generate_farmerwise_report_add_more_rv = (RecyclerView)findViewById(R.id.generate_farmerwise_report_add_more_rv);
        //farmer_wise_report_expandableListView = (ExpandableListView) findViewById(R.id.farmer_wise_report_expandableListView);
        farmerwise_report_submit_btn = (Button) findViewById(R.id.farmerwise_report_submit_btn);
        farmerwise_report_cancel_btn = (Button) findViewById(R.id.farmerwise_report_cancel_btn);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        current_date = df.format(c);
        cureent_day = sdf.format(d);

        farmerwise_report_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               farmerwiseReportSave();
            }
        });

        farmerwise_report_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /*private void Village_wise_crop_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("village_wise_c_data", multiple_crop_field_add);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.primary_report_village_wise_crop_data(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }*/

    private void farmerwiseReportSave() {
        if(multi_consolreport_data.length()==0) {
            Toast.makeText(this,"Select above fields",Toast.LENGTH_SHORT).show();
        }
        else {

            JSONObject jsonObject = new JSONObject();

            try {
                jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                jsonObject.put("division_id", divison_id);
                jsonObject.put("district_id", district_id);
                jsonObject.put("taluka_id", taluka_id);
                jsonObject.put("sajja_id", sajja_id);
                jsonObject.put("village_id", village_id);
                jsonObject.put("crop_type_id", crop_type_id);
                jsonObject.put("horti_type_id", horti_type_id);
                jsonObject.put("year_plt_id", year_plt_id);
                jsonObject.put("scheme_id", scheme_id);
                //jsonObject.put("farmer_id", farmer_id);
                jsonObject.put("f_name",farmer_first);
                jsonObject.put("m_name",farmer_middle);
                jsonObject.put("l_name",farmer_last);
                jsonObject.put("survey_no",survey_no);
                jsonObject.put("mobile_number",mobile_number);
                jsonObject.put("current_week",current_week);
                jsonObject.put("last_week",last_week);
                jsonObject.put("current_date",current_date);
                jsonObject.put("current_day",cureent_day);
                jsonObject.put("multiple_data", multiple_crop_field_add);
                jsonObject.put("weeksNo", "");
                jsonObject.put("monthsVal", "");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.csr_farmerwise_report_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {

                /*if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_wise_crop_data = jsonObject.getJSONArray("data");
                            FarmerWiseExpandableAdapter farmerwiseexpandableadapter = new FarmerWiseExpandableAdapter(GenerateFarmerWiseReportActivity.this,village_wise_crop_data);
                            farmer_wise_report_expandableListView.destroyDrawingCache();
                            farmer_wise_report_expandableListView.setAdapter(farmerwiseexpandableadapter);
                            farmerwiseexpandableadapter.notifyDataSetChanged();
                        }
                    }
                }*/


                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                    sweetAlertDialog.setTitleText("Farmer Wise Report Submitted Successfully");
                                    sweetAlertDialog.setCancelable(false);
                                    sweetAlertDialog.setConfirmText("Ok");
                                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Intent intent =new Intent(GenerateFarmerWiseReportActivity.this, NonSchemeListActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    });
                                    sweetAlertDialog.show();


                        }
                    }
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
