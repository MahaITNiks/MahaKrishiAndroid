package com.maha.agri.ffs.host_gusest_farmer;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.ffs.D_F_FFSActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;


public class D_F_GuestFarmerRegisrationActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {

    private PreferenceManager preferenceManager;
    private String reg_type;
    private String schemeID;
    private int planId;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 222;
    private AppLocationManager locationManager;

//    private TextView village_name_tv;
//    private int villageID;
//    private JSONArray village_list = new JSONArray();

//    private TextView planTextView;
//    private TextView planValueTextView;
//    private int planID;
//    private JSONArray host_farmer_list = new JSONArray();

    private EditText first_name_edt;
    private EditText middle_name_edt;
    private EditText last_name_edt;
    private EditText mobile_edt;
    private RadioGroup gender_radio_group;
    private int genderID = 0;
    private Button submit_btn;
    private double lat;
    private double lang;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_guest_farmer_regisration);
        getSupportActionBar().setTitle("Guest Farmer");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        preferenceManager = new PreferenceManager(D_F_GuestFarmerRegisrationActivity.this);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        init();
        defaultConfig();

    }

    private void init() {

        // village_name_tv = (TextView) findViewById(R.id.village_name_tv);
        // planTextView = (TextView) findViewById(R.id.planTextView);
        // planValueTextView = (TextView) findViewById(R.id.planValueTextView);
        first_name_edt = (EditText) findViewById(R.id.first_name_edt);
        middle_name_edt = (EditText) findViewById(R.id.middle_name_edt);
        last_name_edt = (EditText) findViewById(R.id.last_name_edt);
        mobile_edt = (EditText) findViewById(R.id.mobile_edt);

        gender_radio_group = (RadioGroup) findViewById(R.id.gender_radio_group);
        submit_btn = (Button)findViewById(R.id.submit_btn);

        /*if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
            planValueTextView.setHint("Select Demo Plan");
        }else {
            planValueTextView.setHint("Select FFS Plan");
        }*/

        planId = getIntent().getIntExtra("plan_id",0);

        locationManager = new AppLocationManager(this);

    }

    private void defaultConfig() {

        /*village_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (village_list.length()>0){
                    AppUtility.getInstance().showListDialogIndex(village_list, 1, "Select Village", "village_name", "village_id", D_F_GuestFarmerRegisrationActivity.this, D_F_GuestFarmerRegisrationActivity.this);
                }
            }
        });

        planValueTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (villageID == 0){
                    UIToastMessage.show(D_F_GuestFarmerRegisrationActivity.this,"Please select village");
                }else {
                    if (host_farmer_list.length()> 0 ) {
                        AppUtility.getInstance().showListDialogIndex(host_farmer_list, 2, "Select Host farmer", "name", "id", D_F_GuestFarmerRegisrationActivity.this, D_F_GuestFarmerRegisrationActivity.this);
                    } else {
                        getHostFarmerList(villageID);
                    }
                }
            }
        });
        */


        // For Gender
        gender_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                          @Override
                                                          public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                              if (checkedId == R.id.male_radio_btn) {
                                                                  genderID = 1;
                                                              } else if (checkedId == R.id.female_radio_btn) {
                                                                  genderID = 2;
                                                              } else {
                                                                  genderID = 3;
                                                              }
                                                          }
                                                      }
        );

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitBtnAction();
            }
        });

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        schemeID = preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_ID);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);


        if ((ContextCompat.checkSelfPermission(D_F_GuestFarmerRegisrationActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(D_F_GuestFarmerRegisrationActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();
        } else {
            String[] permissionRequest = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionRequest, LOCATION_PERMISSION_REQUEST_CODE);
            }
        }

       /* String data = AppSettings.getInstance().getValue(D_F_GuestFarmerRegisrationActivity.this, ApConstants.kLOGIN_DATA, "");
        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

        /*if (i == 1) {
            villageID = Integer.parseInt(s1);
            village_name_tv.setText(s);
            planID = 0;
            planValueTextView.setText("");
            getHostFarmerList(villageID);
        }

        if (i == 2) {
            planID = Integer.parseInt(s1);
            planValueTextView.setText(s);
        }*/

    }

    private void getHostFarmerList(int villageID) {

        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("village_id", villageID);
            jsonObject.put("crop_id", "");
            jsonObject.put("reg_type", reg_type);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.hostFarmerList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }




    private void clearFormData() {

//        village_name_tv.setText("");
//        villageID = 0;
//        planValueTextView.setText("");
//        planID = 0;

        first_name_edt.setText("");
        middle_name_edt.setText("");
        last_name_edt.setText("");
        mobile_edt.setText("");
        gender_radio_group.clearCheck();
    }


    public void addMoreAlert(String title, String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // alertDialogBuilder.setTitle(title);
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setNegativeButton("Add More Guest Farmer", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                first_name_edt.setFocusable(true);
                first_name_edt.requestFocus();
            }
        });


        alertDialogBuilder.setPositiveButton("Finish", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                Intent host_farmer_reg = new Intent(D_F_GuestFarmerRegisrationActivity.this, D_F_FFSActivity.class);
                startActivity(host_farmer_reg);
                finish();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE ){
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();
        }
    }


    private void submitBtnAction() {
        String fName = first_name_edt.getText().toString().trim();
        String mName = middle_name_edt.getText().toString().trim();
        String lName = last_name_edt.getText().toString().trim();
        String mobile = mobile_edt.getText().toString().trim();

        /*if (planID == 0) {
            UIToastMessage.show(this, "Select host farmer");
        } else*/ if (fName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter first name");
        } else if (mName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter middle name");
        } else if (lName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter last name");
        } else if (genderID == 0) {
            UIToastMessage.show(this, "Select gender");
        }else if (mobile.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter mobile number");
        } else if (!AppUtility.getInstance().isValidPhoneNumber(mobile)) {
            UIToastMessage.show(this, "Enter valid mobile number");
        }else {

//            clearFormData();
//            addMoreAlert("Add More","Guest farmer added successfully");

            try {

                JSONObject jsonObject = new JSONObject();

                jsonObject.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
                jsonObject.put("created_by", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                jsonObject.put("plan_id", planId);
                jsonObject.put("first_name", fName);
                jsonObject.put("middle_name", mName);
                jsonObject.put("last_name", lName);
                jsonObject.put("gender", genderID);
                jsonObject.put("mobile", mobile);
                jsonObject.put("reg_type", reg_type);

                jsonObject.put("lat", lat);
                jsonObject.put("lon", lang);

                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.registerGuestFarmer(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 1);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            clearFormData();
                            addMoreAlert("Add More",responseModel.getMsg());
                            // UIToastMessage.show(this,responseModel.getMsg());
                        }else {
                            UIToastMessage.show(this,responseModel.getMsg());
                        }
                    }
                }

                /*if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            host_farmer_list = responseModel.getData();
                        }else {
                            UIToastMessage.show(this,responseModel.getMsg());
                        }
                    }else {
                        UIToastMessage.show(this,jsonObject.getString("response"));
                    }
                }*/


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
