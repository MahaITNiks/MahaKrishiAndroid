package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class ProtectiveCultivationActivity extends AppCompatActivity {
    private TextView mb_farm_pond;
    private Button mb_farm_pond_next;
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    private JSONArray farm_pond_list;
    private int farm_pond_id = 0;
    private String farm_pond_name = "",farmer_name="",response="";
    private int  district_id,taluka_id,village_id,farmer_id;

    private Button green_house1_part1_btn,green_house1_part2_btn,green_house2_btn,onion_str1_part1_btn,onion_str1_part2_btn,onion_str2_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_protective_cultivation);
        getSupportActionBar().setTitle("Protective Cultivation");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(ProtectiveCultivationActivity.this);

        ids();
        functions();
    }

    private void ids() {
        green_house1_part1_btn = (Button) findViewById(R.id.green_house1_part1_btn);
        green_house2_btn = (Button) findViewById(R.id.green_house2_btn);
        onion_str1_part1_btn = (Button) findViewById(R.id.onion_str1_part1_btn);
        onion_str2_btn = (Button) findViewById(R.id.onion_str2_btn);
    }

    private void functions() {

        green_house1_part1_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProtectiveCultivationActivity.this,GreenHouseActivity.class);
                startActivity(intent);
            }
        });

        green_house2_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProtectiveCultivationActivity.this,GreenHouseLastActivity.class);
                startActivity(intent);
            }
        });

        onion_str1_part1_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProtectiveCultivationActivity.this,OnionStorageFirstPhysicalActivity1.class);
                startActivity(intent);
            }
        });

        onion_str2_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProtectiveCultivationActivity.this,OnionStorageLastPhysicalActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
