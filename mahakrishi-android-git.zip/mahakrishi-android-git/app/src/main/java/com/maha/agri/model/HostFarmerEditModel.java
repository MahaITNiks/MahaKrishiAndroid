/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class HostFarmerEditModel {

    private int host_farmer_id;
    private String last_name;
    private String middle_name;
    private String first_name;
    private String gender;
    private int age;
    private String mobile;
    private String survey_number;
    private String area_8a;
    private int social_category_id;
    private String social_category_name;
    private int physically_challenged;
    private int plot_id;
    private String plot;
    private int cropping_system_id;
    private int crop_id;
    private String crop_name;
    private int inter_crop_id;
    private String inter_crop_name;
    private String area_under_crop;
    private int irrigation_id;
    private String irrigation_name;
    private int soil_type_id;
    private String soil_type_name;
    private String control_plot_farmer_name;
    private int control_plot_cropping_system_id;
    private int control_plot_crop_id;
    private String control_plot_crop_name;
    private int control_plot_inter_crop_id;
    private String control_plot_inter_crop_name;
    private String control_plot_area_under_crop;
    private int village_id;
    private String village_name;
    private int taluka_id;
    private String taluka_name;
    private int subdivision_id;
    private String subdivision_name;
    private String name;
    private int id;

    private JSONObject jsonObject;

    public HostFarmerEditModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getHost_farmer_id() {
        host_farmer_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "host_farmer_id");
        return host_farmer_id;
    }

    public String getLast_name() {
        last_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "last_name");
        return last_name;
    }

    public String getMiddle_name() {
        middle_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "middle_name");
        return middle_name;
    }

    public String getFirst_name() {
        first_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "first_name");
        return first_name;
    }

    public String getGender() {
        gender = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "gender");
        return gender;
    }

    public int getAge() {
        age = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "age");
        return age;
    }

    public String getMobile() {
        mobile = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "mobile");
        return mobile;
    }

    public String getSurvey_number() {
        survey_number = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "survey_number");
        return survey_number;
    }

    public String getArea_8a() {
        area_8a = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "area_8a");
        return area_8a;
    }

    public int getSocial_category_id() {
        social_category_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "social_category_id");
        return social_category_id;
    }

    public String getSocial_category_name() {
        social_category_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "social_category_name");
        return social_category_name;
    }

    public int getPhysically_challenged() {
        physically_challenged = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "physically_challenged");
        return physically_challenged;
    }

    public int getPlot_id() {
        plot_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "plot_id");
        return plot_id;
    }

    public String getPlot() {
        plot = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "plot");
        return plot;
    }

    public int getCropping_system_id() {
        cropping_system_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "cropping_system_id");
        return cropping_system_id;
    }

    public int getCrop_id() {
        crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "crop_id");
        return crop_id;
    }

    public String getCrop_name() {
        crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "crop_name");
        return crop_name;
    }

    public int getInter_crop_id() {
        inter_crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "inter_crop_id");
        return inter_crop_id;
    }

    public String getInter_crop_name() {
        inter_crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "inter_crop_name");
        return inter_crop_name;
    }

    public String getArea_under_crop() {
        area_under_crop = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "area_under_crop");
        return area_under_crop;
    }

    public int getIrrigation_id() {
        irrigation_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "irrigation_id");
        return irrigation_id;
    }

    public int getSoil_type_id() {
        soil_type_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "soil_type_id");
        return soil_type_id;
    }

    public String getControl_plot_farmer_name() {
        control_plot_farmer_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "control_plot_farmer_name");
        return control_plot_farmer_name;
    }

    public int getControl_plot_cropping_system_id() {
        control_plot_cropping_system_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "control_plot_cropping_system_id");
        return control_plot_cropping_system_id;
    }

    public int getControl_plot_crop_id() {
        control_plot_crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "control_plot_crop_id");
        return control_plot_crop_id;
    }

    public String getControl_plot_crop_name() {
        control_plot_crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "control_plot_crop_name");
        return control_plot_crop_name;
    }

    public int getControl_plot_inter_crop_id() {
        control_plot_inter_crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "control_plot_inter_crop_id");
        return control_plot_inter_crop_id;
    }

    public String getControl_plot_inter_crop_name() {
        control_plot_inter_crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "control_plot_inter_crop_name");
        return control_plot_inter_crop_name;
    }

    public String getControl_plot_area_under_crop() {
        control_plot_area_under_crop = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "control_plot_area_under_crop");
        return control_plot_area_under_crop;
    }

    public int getVillage_id() {
        village_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "village_id");
        return village_id;
    }

    public String getVillage_name() {
        village_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "village_name");
        return village_name;
    }

    public int getTaluka_id() {
        taluka_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "taluka_id");
        return taluka_id;
    }

    public String getTaluka_name() {
        taluka_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "taluka_name");
        return taluka_name;
    }

    public int getSubdivision_id() {
        subdivision_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "subdivision_id");
        return subdivision_id;
    }

    public String getSubdivision_name() {
        subdivision_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "subdivision_name");
        return subdivision_name;
    }

    public String getIrrigation_name() {
        irrigation_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "irrigation_name");
        return irrigation_name;
    }

    public String getSoil_type_name() {
        soil_type_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "soil_type_name");
        return soil_type_name;
    }

    public String getName() {
        name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "name");
        return name;
    }

    public int getId() {
        id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "id");
        return id;
    }
}
