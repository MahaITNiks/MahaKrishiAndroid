package com.maha.agri.ffs;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.AppDelegate;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ffs.adaptor.CommonAdapter;
import com.maha.agri.ffs.adaptor.CommonDeleteRowAdapter;
import com.maha.agri.ffs.adaptor.DiseaseSeverityAdapter;
import com.maha.agri.ffs.ffs_db.FfsDatabase;
import com.maha.agri.ffs.ffs_db.M_DefenderEY;
import com.maha.agri.ffs.ffs_db.M_DiseaseSeverityEY;
import com.maha.agri.ffs.ffs_db.M_DiseaseTypeEY;
import com.maha.agri.ffs.ffs_db.M_IrrigationMethodEY;
import com.maha.agri.ffs.ffs_db.M_MethodOfSowingEY;
import com.maha.agri.ffs.ffs_db.M_PestEY;
import com.maha.agri.ffs.ffs_db.M_RainfallConditionEY;
import com.maha.agri.ffs.ffs_db.M_RodentDamageEY;
import com.maha.agri.ffs.ffs_db.M_SoilConditionEY;
import com.maha.agri.ffs.ffs_db.M_VarietyEY;
import com.maha.agri.ffs.ffs_db.M_WeatherConditionEY;
import com.maha.agri.ffs.ffs_db.M_WeedsTypeIntensityEY;
import com.maha.agri.ffs.ffs_db.M_WindCondEY;
import com.maha.agri.ffs.ffs_db.T_DefenderEY;
import com.maha.agri.ffs.ffs_db.T_DiseaseTypeEY;
import com.maha.agri.ffs.ffs_db.T_PestEY;
import com.maha.agri.ffs.model.CommonModel;
import com.maha.agri.ffs.model.OffDiseaseTypeModel;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.model.VisitDetailModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppHelper;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.DatePickerRequestListener;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FFSObservationActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener, DatePickerRequestListener, OnMultiRecyclerItemClickListener {

    private PreferenceManager preferenceManager;
    private AppLocationManager appLocationManager;
    private DBHandler dbHandler;
    private String schemeID;
    private String userID;
    private String reg_type;
    private String villageId;
    private String activityID;


    // For Image upload
    private ManagePermission managePermissions;
    private File photoFile = null;
    private Transformation transformation;
    private int imgNumber = 0;
    private String currentImglatLong = "";
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;

    String currentTime;
    private File imgFile = null;
    private double lat1;
    private double lang1;

    private File imgFile2 = null;
    private double lat2;
    private double lang2;

    private TextView headerTextView;
    private TextView dateTextView;
    private TextView daysAfterSowingTextView;
    private TextView methodDropTextView;
    private EditText varietyEditText;
    private EditText heightEditText;
    private EditText canopyEditText;
    private EditText branchesEditText;
    private EditText damageEditText;
    private EditText sqrBranchesEditText;
    private EditText sqrDamageEditText;
    private EditText budBranchesEditText;
    private EditText budDamageEditText;
    private EditText flowerBranchesEditText;
    private EditText flowerDamageEditText;
    private EditText fruitBranchesEditText;
    private EditText fruitDamageEditText;
    private EditText podBranchesEditText;
    private EditText podDamageEditText;
    private EditText bollBranchesEditText;
    private EditText bollDamageEditText;
    private EditText grainBranchesEditText;
    private EditText grainDamageEditText;
    private TextView pestDropTextView;
    private TextView defenderDropTextView;
    private EditText soilCondEditText;
    private EditText weatherCondEditText;
    private EditText diseasesTypeEditText;
    private EditText weedsTypeEditText;
    private EditText rodentDamageEditText;
    private EditText insectPestsEditText;
    private EditText naturalDefendersEditText;
    private EditText pdRatioEditText;

    private TextView varietyDropTextView;
    private TextView rodentDropTextView;
    private TextView soilCondDropTextView;
    private TextView weatherCondDropTextView;
    private TextView rainfallDropTextView;
    private TextView diseasesTypeDropTextView;
    private TextView diseasesSeverityDropTextView;
    private TextView weedsTypeDropTextView;
    private TextView irrigationMethodDropTextView;
    private TextView windCondDropTextView;

    private ImageView attch1ImageView;
    private ImageView attch2ImageView;

    private ImageView dateImageView;
    private ImageView methodImageView;
    private ImageView varietyImageView;
    private ImageView irrigationMethodDropImageView;
    private ImageView weatherCondDropImageView;
    private ImageView windCondDropImageView;
    private ImageView rainfallDropImageView;

    private RecyclerView pestRecyclerView;
    private RecyclerView defenderRecyclerView;
    private RecyclerView diseaseRecyclerView;

    private String methodSowingID = "";
    private int pestsID = 0;
    private int defendersID = 0;

    private JSONArray varietyJSONArray;
    private JSONArray soilJSONArray;
    private JSONArray weatherJSONArray;
    private JSONArray rainfallJSONArray;
    private JSONArray diseaseTypeJSONArray;
    private JSONArray diseaseSeverityJSONArray;
    private JSONArray weedsTypeJSONArray;
    private JSONArray irrigationMethodJSONArray;
    private JSONArray windCondJSONArray;
    private JSONArray rodentDamageJSONArray;

    private AppSession session;

    private JSONArray methodSowingJSONArray;
    private JSONArray pestsJSONArray;
    private JSONArray defendersJSONArray;

    private JSONArray dbPestsJSONArray;
    private JSONArray dbDefendersJSONArray;
    private JSONArray dbDiseaseJSONArray;

    private String cropCondition = "";

    private int crop_id = -1;
    private String daysSowing;
    private String dateOfSowingServer = "";

    private int varietyId = 0;
    private int soilCondId = 0;
    private int weatherCondId = 0;
    private int rainfallCondId = 0;
    private int diseaseId = 0;
    private int diseaseSeverityId = 0;
    private int weedsTypeId = 0;
    private int irrigationMethodId = 0;
    private int windCondition = 0;
    private int rodentDamageId = 0;
    private int update_visit = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_observation);
        appLocationManager = new AppLocationManager(this);

        preferenceManager = new PreferenceManager(FFSObservationActivity.this);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        headerTextView = findViewById(R.id.headerTextView);
        dateTextView = findViewById(R.id.dateTextView);
        daysAfterSowingTextView = findViewById(R.id.daysAfterSowingTextView);
        methodDropTextView = findViewById(R.id.methodDropTextView);

        varietyEditText = findViewById(R.id.varietyEditText);
        heightEditText = findViewById(R.id.heightEditText);
        canopyEditText = findViewById(R.id.canopyEditText);
        branchesEditText = findViewById(R.id.branchesEditText);
        damageEditText = findViewById(R.id.damageEditText);

        sqrBranchesEditText = findViewById(R.id.sqrBranchesEditText);
        sqrDamageEditText = findViewById(R.id.sqrDamageEditText);
        budBranchesEditText = findViewById(R.id.budBranchesEditText);
        budDamageEditText = findViewById(R.id.budDamageEditText);
        flowerBranchesEditText = findViewById(R.id.flowerBranchesEditText);
        flowerDamageEditText = findViewById(R.id.flowerDamageEditText);

        fruitBranchesEditText = findViewById(R.id.fruitBranchesEditText);
        fruitDamageEditText = findViewById(R.id.fruitDamageEditText);
        podBranchesEditText = findViewById(R.id.podBranchesEditText);
        podDamageEditText = findViewById(R.id.podDamageEditText);
        bollBranchesEditText = findViewById(R.id.bollBranchesEditText);
        bollDamageEditText = findViewById(R.id.bollDamageEditText);
        grainBranchesEditText = findViewById(R.id.grainBranchesEditText);
        grainDamageEditText = findViewById(R.id.grainDamageEditText);

        pestDropTextView = findViewById(R.id.pestDropTextView);
        defenderDropTextView = findViewById(R.id.defenderDropTextView);

        soilCondEditText = findViewById(R.id.soilCondEditText);
        weatherCondEditText = findViewById(R.id.weatherCondEditText);
        diseasesTypeEditText = findViewById(R.id.diseasesTypeEditText);
        weedsTypeEditText = findViewById(R.id.weedsTypeEditText);
        rodentDamageEditText = findViewById(R.id.rodentDamageEditText);
        insectPestsEditText = findViewById(R.id.insectPestsEditText);
        naturalDefendersEditText = findViewById(R.id.naturalDefendersEditText);
        pdRatioEditText = findViewById(R.id.pdRatioEditText);

        attch1ImageView = findViewById(R.id.attch1ImageView);
        attch2ImageView = findViewById(R.id.attch2ImageView);

        varietyDropTextView = findViewById(R.id.varietyDropTextView);
        rodentDropTextView = findViewById(R.id.rodentDropTextView);
        soilCondDropTextView = findViewById(R.id.soilCondDropTextView);
        weatherCondDropTextView = findViewById(R.id.weatherCondDropTextView);
        rainfallDropTextView = findViewById(R.id.rainfallDropTextView);
        diseasesTypeDropTextView = findViewById(R.id.diseasesTypeDropTextView);
        diseasesSeverityDropTextView = findViewById(R.id.diseasesSeverityDropTextView);
        weedsTypeDropTextView = findViewById(R.id.weedsTypeDropTextView);
        irrigationMethodDropTextView = findViewById(R.id.irrigationMethodDropTextView);
        windCondDropTextView = findViewById(R.id.windCondDropTextView);

        pestRecyclerView = findViewById(R.id.pestRecyclerView);
        defenderRecyclerView = findViewById(R.id.defenderRecyclerView);
        diseaseRecyclerView = findViewById(R.id.diseaseRecyclerView);

        dateImageView = findViewById(R.id.dateImageView);
        methodImageView = findViewById(R.id.methodImageView);
        varietyImageView = findViewById(R.id.varietyImageView);

        irrigationMethodDropImageView = findViewById(R.id.irrigationMethodDropImageView);
        weatherCondDropImageView = findViewById(R.id.weatherCondDropImageView);
        windCondDropImageView = findViewById(R.id.windCondDropImageView);
        rainfallDropImageView = findViewById(R.id.rainfallDropImageView);


        if (getIntent() != null && getIntent().hasExtra("update_visit")) {
            update_visit = getIntent().getIntExtra("update_visit", 0);
        }

        DebugLog.getInstance().d("update_visit="+update_visit);

        if (update_visit == 1) {
            findViewById(R.id.headingTextView).setVisibility(View.GONE);
            findViewById(R.id.imgLinearLayout).setVisibility(View.GONE);
        } else {
            findViewById(R.id.headingTextView).setVisibility(View.VISIBLE);
            findViewById(R.id.imgLinearLayout).setVisibility(View.VISIBLE);
        }


        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        pestRecyclerView.setLayoutManager(layoutManager);
        pestRecyclerView.setHasFixedSize(true);
        pestRecyclerView.setItemAnimator(new DefaultItemAnimator());

        LinearLayoutManager layoutManager2 = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        defenderRecyclerView.setLayoutManager(layoutManager2);
        defenderRecyclerView.setHasFixedSize(true);
        defenderRecyclerView.setItemAnimator(new DefaultItemAnimator());

        LinearLayoutManager layoutManager3 = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        diseaseRecyclerView.setLayoutManager(layoutManager3);
        diseaseRecyclerView.setHasFixedSize(true);
        diseaseRecyclerView.setItemAnimator(new DefaultItemAnimator());

        insectPestsEditText.setEnabled(false);
        naturalDefendersEditText.setEnabled(false);


        session = new AppSession(this);

        setTitle(getResources().getString(R.string.visit_observations));

        //Showing details will shown when user filled once
        updateShowingDetails();

        dateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //AppUtility.getInstance().showDisabledFutureDatePicker(FFSObservationActivity.this,new Date(), 1, FFSObservationActivity.this);
                AppUtility.getInstance().showPastDatePicker(FFSObservationActivity.this,new Date(), 1, FFSObservationActivity.this);

            }
        });


        String major = getResources().getString(R.string.ffs_plot_major_crop)+" - "+session.getCropName();
        headerTextView.setText(major);


        methodDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                methodOfSowing();
            }
        });

        pestDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pestsDropdown();
            }
        });

        defenderDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pestsID == 0) {
                    UIToastMessage.show(FFSObservationActivity.this, "Please select pest");
                } else {
                    defendersDropdown();
                }
            }
        });


        insectPestsEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String ipests = insectPestsEditText.getText().toString();
                String ndefender = naturalDefendersEditText.getText().toString();

                if (!ipests.isEmpty() && !ndefender.isEmpty()) {
                    String ratio = ipests+":"+ndefender;
                    pdRatioEditText.setText(ratio);
                }
            }
        });

        naturalDefendersEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String ipests = insectPestsEditText.getText().toString();
                String ndefender = naturalDefendersEditText.getText().toString();

                if (!ipests.isEmpty() && !ndefender.isEmpty()) {
                    String ratio = ipests+":"+ndefender;
                    pdRatioEditText.setText(ratio);
                }
            }
        });


        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                  @Override
                                                  public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                      if (checkedId == R.id.bNormalRadioButton) {
                                                          cropCondition = ApConstants.kOBS_CROP_B_NORMAL;

                                                      } else if (checkedId == R.id.normalRadioButton) {
                                                          cropCondition = ApConstants.kOBS_CROP_NORMAL;

                                                      } else if (checkedId == R.id.goodRadioButton) {
                                                          cropCondition = ApConstants.kOBS_CROP_GOOD;

                                                      }  else if (checkedId == R.id.excellentRadioButton) {
                                                          cropCondition = ApConstants.kOBS_CROP_EXCELLENT;
                                                      }
                                                  }
                                              }
        );



        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitButtonAction();
            }
        });


        attch1ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgNumber = 1;
                //if ((ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                if ((ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        attch2ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgNumber = 2;
                //if ((ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                if ((ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSObservationActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    //String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });


        varietyDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCropVariety();
            }
        });

        soilCondDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSoilCondition();
            }
        });

        weatherCondDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showWeatherCondition();
            }
        });

        rainfallDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRainfallCondition();
            }
        });

        diseasesTypeDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDiseaseType();
            }
        });

        diseasesSeverityDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (diseaseId == 0) {
                    UIToastMessage.show(FFSObservationActivity.this, "Please select disease");
                } else {
                    showDiseaseSeverity();
                }
            }
        });

        weedsTypeDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showWeedsType();
            }
        });

        rodentDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRodentDamage();
            }
        });

        irrigationMethodDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showIrrigationMethod();
            }
        });

        windCondDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showWindCondition();
            }
        });



        crop_id = getIntent().getIntExtra("crop_id", -1);
        DebugLog.getInstance().d("getCropId=" +session.getCropId());

        cleanUpDatabaseData();

        fetchMethodOfSowingMasterData();
        fetchPestsMasterData();
        fetchCropVariety();
        fetchSoilCondition();
        fetchRainfallCondition();
        fetchWeatherCondition();
        fetchDisease();
        fetchDiseaseSeverity();
        fetchWeedsType();
        fetchIrrigationMethod();
        fetchWindCondition();
        fetchRodentDamage();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }


    private void updateShowingDetails() {

        if (getIntent() != null) {
            String schedule_details = getIntent().getStringExtra("schedule_details");

            try {
                JSONObject jsonObject = new JSONObject(schedule_details);

                VisitDetailModel dataModel = new VisitDetailModel(jsonObject);

                if (!dataModel.getSowing_method().equalsIgnoreCase("")) {
                    methodDropTextView.setEnabled(false);
                    methodSowingID = dataModel.getSowing_method();
                    methodDropTextView.setText(dataModel.getSowing_method());
                    methodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                    methodImageView.setVisibility(View.INVISIBLE);
                }

                if (dataModel.getCrop_variety_id() > 0) {
                    varietyDropTextView.setEnabled(false);
                    varietyId = dataModel.getCrop_variety_id();
                    varietyDropTextView.setText(dataModel.getVariety_name());
                    varietyDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                    varietyImageView.setVisibility(View.INVISIBLE);
                }

                if (dataModel.getSowing_date() > 0 ) {

                    dateTextView.setEnabled(false);
                    dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getSowing_date()));

                    daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getSowing_date()));
                    String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                    daysAfterSowingTextView.setText(formattedDate);
                    dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getSowing_date());
                    dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                    dateImageView.setVisibility(View.INVISIBLE);

                }

                if (dataModel.getSowing_date() > 0 ) {

                    dateTextView.setEnabled(false);
                    dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getSowing_date()));

                    daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getSowing_date()));
                    String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                    daysAfterSowingTextView.setText(formattedDate);
                    dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getSowing_date());
                    dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                    dateImageView.setVisibility(View.INVISIBLE);
                }


               /* if (dataModel.getIrrigation_method_id() > 0) {
                    irrigationMethodDropTextView.setEnabled(false);
                    irrigationMethodId = dataModel.getIrrigation_method_id();
                    irrigationMethodDropTextView.setText(dataModel.getIrrigation_method_name());
                    irrigationMethodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                    irrigationMethodDropImageView.setVisibility(View.INVISIBLE);
                }*/


               /* if (ffsControlPlot == 1) { // FFS Plot

                    if (dataModel.getMethod_of_sowing_id() > 0) {
                        methodDropTextView.setEnabled(false);
                        methodSowingID = dataModel.getMethod_of_sowing_id();
                        methodDropTextView.setText(dataModel.getSowing_method());
                        methodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        methodImageView.setVisibility(View.INVISIBLE);
                    }

                    if (dataModel.getCrop_variety_id() > 0) {
                        varietyDropTextView.setEnabled(false);
                        varietyId = dataModel.getCrop_variety_id();
                        varietyDropTextView.setText(dataModel.getCrop_variety_name());
                        varietyDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        varietyImageView.setVisibility(View.INVISIBLE);

                    }

                    if (dataModel.getDate_of_sowing() > 0 ) {

                        dateTextView.setEnabled(false);
                        dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));

                        daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));
                        String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                        daysAfterSowingTextView.setText(formattedDate);
                        dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getDate_of_sowing());
                        dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        dateImageView.setVisibility(View.INVISIBLE);

                    }

                    if (dataModel.getDate_of_sowing() > 0 ) {

                        dateTextView.setEnabled(false);
                        dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));

                        daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));
                        String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                        daysAfterSowingTextView.setText(formattedDate);
                        dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getDate_of_sowing());
                        dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        dateImageView.setVisibility(View.INVISIBLE);
                    }


                    if (dataModel.getIrrigation_method_id() > 0) {
                        irrigationMethodDropTextView.setEnabled(false);
                        irrigationMethodId = dataModel.getIrrigation_method_id();
                        irrigationMethodDropTextView.setText(dataModel.getIrrigation_method_name());
                        irrigationMethodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        irrigationMethodDropImageView.setVisibility(View.INVISIBLE);
                    }

                } else { // Control Plot

                    if (dataModel.getControl_method_of_sowing_id() > 0) {
                        methodDropTextView.setEnabled(false);
                        methodSowingID = dataModel.getMethod_of_sowing_id();
                        methodDropTextView.setText(dataModel.getSowing_method());
                        methodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        methodImageView.setVisibility(View.INVISIBLE);
                    }


                    if (dataModel.getControl_crop_variety_id() > 0) {
                        varietyDropTextView.setEnabled(false);
                        varietyId = dataModel.getCrop_variety_id();
                        varietyDropTextView.setText(dataModel.getCrop_variety_name());
                        varietyDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        varietyImageView.setVisibility(View.INVISIBLE);

                    }

                    if (dataModel.getControl_date_of_sowing() > 0) {

                        dateTextView.setEnabled(false);
                        dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));

                        daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));
                        String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                        daysAfterSowingTextView.setText(formattedDate);
                        dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getDate_of_sowing());
                        dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        dateImageView.setVisibility(View.INVISIBLE);

                    }

                    if (dataModel.getControl_date_of_sowing() > 0) {

                        dateTextView.setEnabled(false);
                        dateTextView.setText(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));

                        daysSowing = AppHelper.getInstance().getDaysFromTwoDates(AppHelper.getInstance().getTimeStampDDMMYYYY(dataModel.getDate_of_sowing()));
                        String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing + " Day" : daysSowing + " Days";
                        daysAfterSowingTextView.setText(formattedDate);
                        dateOfSowingServer = AppHelper.getInstance().getTimeStampYYYYMMDD(dataModel.getDate_of_sowing());
                        dateTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        dateImageView.setVisibility(View.INVISIBLE);

                    }

                    if (dataModel.getControl_irrigation_method_id() > 0) {
                        irrigationMethodDropTextView.setEnabled(false);
                        irrigationMethodId = dataModel.getControl_irrigation_method_id();
                        irrigationMethodDropTextView.setText(dataModel.getControl_irrigation_method_name());
                        irrigationMethodDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
                        irrigationMethodDropImageView.setVisibility(View.INVISIBLE);
                    }
                }*/

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        if (session.getObsWeatherName().length() > 0) {
            weatherCondDropTextView.setEnabled(false);
            weatherCondId = session.getObsWeatherId();
            weatherCondDropTextView.setText(session.getObsWeatherName());
            weatherCondDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
            weatherCondDropImageView.setVisibility(View.INVISIBLE);
        }

        if (session.getObsWindName().length() > 0) {
            windCondDropTextView.setEnabled(false);
            windCondition = session.getObsWindId();
            windCondDropTextView.setText(session.getObsWindName());
            windCondDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
            windCondDropImageView.setVisibility(View.INVISIBLE);
        }

        if (session.getObsRainfallName().length() > 0) {
            rainfallDropTextView.setEnabled(false);
            rainfallCondId = session.getObsRainfallId();
            rainfallDropTextView.setText(session.getObsRainfallName());
            rainfallDropTextView.setBackgroundResource(R.drawable.drop_down_disable);
            rainfallDropImageView.setVisibility(View.INVISIBLE);
        }
    }


    private void cleanUpDatabaseData() {
        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();
                //Delete all transaction data
                db.tPestDAO().deleteAll();
                db.tDefenderDAO().deleteAll();
                db.tDiseaseTypeDAO().deleteAll();
                db.close();

            }
        }).start();
    }



    private void fetchDatabaseData() {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();
                List<M_MethodOfSowingEY> mDataArray = db.methodOfSowingDAO().getAll();
                methodSowingJSONArray = new JSONArray();

                for(M_MethodOfSowingEY data : mDataArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        methodSowingJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }



                pestsJSONArray = new JSONArray();
                List<M_PestEY> mPestArray = db.pestDAO().getCropPest(crop_id);

                if (mPestArray.size() == 0) {
                    List<M_PestEY> mPestArrayAll = db.pestDAO().getAll();

                    for(M_PestEY data : mPestArrayAll) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());

                            pestsJSONArray.put(jsonObject);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                } else {

                    for(M_PestEY data : mPestArray) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());

                            pestsJSONArray.put(jsonObject);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }


                varietyJSONArray = new JSONArray();
                List<M_VarietyEY> varietyArray = db.varietyDAO().getCropVarietyAll(crop_id);

                for (M_VarietyEY data : varietyArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());
                        jsonObject.put("crop_id", data.getCrop_id());

                        varietyJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                soilJSONArray = new JSONArray();
                List<M_SoilConditionEY> soilConArray = db.soilConditionDAO().getAll();

                for (M_SoilConditionEY data : soilConArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        soilJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                weatherJSONArray = new JSONArray();
                List<M_WeatherConditionEY> weatherConArray = db.weatherConditionDAO().getAll();

                for (M_WeatherConditionEY data : weatherConArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        weatherJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                rainfallJSONArray = new JSONArray();
                List<M_RainfallConditionEY> rainfallConArray = db.rainfallConditionDAO().getAll();

                for (M_RainfallConditionEY data : rainfallConArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        rainfallJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                diseaseTypeJSONArray = new JSONArray();
                List<M_DiseaseTypeEY> diseaseTypeArray = db.diseaseTypeDAO().getCropDiseaseAll(crop_id);

                for (M_DiseaseTypeEY data : diseaseTypeArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());
                        jsonObject.put("crop_id", data.getCrop_id());

                        diseaseTypeJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                diseaseSeverityJSONArray = new JSONArray();
                List<M_DiseaseSeverityEY> diseaseSeverityArray = db.diseaseSeverityDAO().getAll();

                for (M_DiseaseSeverityEY data : diseaseSeverityArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        diseaseSeverityJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                weedsTypeJSONArray = new JSONArray();
                List<M_WeedsTypeIntensityEY> weedsTypeArray = db.weedsTypeIntensityDAO().getAll();

                for (M_WeedsTypeIntensityEY data : weedsTypeArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        weedsTypeJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                irrigationMethodJSONArray = new JSONArray();
                List<M_IrrigationMethodEY> irrigationMethodArray = db.irrigationMethodDAO().getAll();

                for (M_IrrigationMethodEY data : irrigationMethodArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        irrigationMethodJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                windCondJSONArray = new JSONArray();
                List<M_WindCondEY> windCondArray = db.windCondDAO().getAll();

                for (M_WindCondEY data : windCondArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        windCondJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                rodentDamageJSONArray = new JSONArray();
                List<M_RodentDamageEY> rodentDamageArray = db.rodentDamageDAO().getAll();

                for (M_RodentDamageEY data : rodentDamageArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        rodentDamageJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                db.close();


            }
        }).start();
    }

    private void fetchDefendersMasterFromDatabase() {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                defendersJSONArray = new JSONArray();
                List<M_DefenderEY> mDataArray = db.mDefenderDAO().getDefenders(pestsID);

                for(M_DefenderEY data : mDataArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        defendersJSONArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                db.close();

            }
        }).start();
    }



    private void addPestInDatabase(final int cropping_system_id ,final int id, final  String name) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                List<T_PestEY> mDataExistArray = db.tPestDAO().checkIdExists(id, crop_id);

                if (mDataExistArray.size() == 0) {
                    T_PestEY pestEY = new T_PestEY();
                    pestEY.setUid(id);
                    pestEY.setName(name);
                    pestEY.setCrop_id(crop_id);
                   //  pestEY.setPlot_obs(ffsControlPlot);
                    pestEY.setCropping_system(cropping_system_id);
                    db.tPestDAO().insertOnlySingle(pestEY);
                }

                List<T_PestEY> mDataArray = db.tPestDAO().getTypePest(cropping_system_id, crop_id);

                if (cropping_system_id == 1) {

                    dbPestsJSONArray = new JSONArray();

                    for(T_PestEY data : mDataArray) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("crop_id", data.getCrop_id());
                            dbPestsJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }

                db.close();

                FFSObservationActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateViews(1, cropping_system_id);
                    }
                });

            }
        }).start();
    }


    private void addDefenderInDatabase(final int cropping_system_id, final int id, final  String name) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                List<T_DefenderEY> mDataExistArray = db.tDefenderDAO().checkIdExists(id, crop_id);

                if (mDataExistArray.size() == 0) {
                    T_DefenderEY defenderEY = new T_DefenderEY();
                    defenderEY.setUid(id);
                    defenderEY.setName(name);
                    defenderEY.setCrop_id(crop_id);
                    // defenderEY.setPlot_obs(ffsControlPlot);
                    defenderEY.setCropping_system(cropping_system_id);
                    db.tDefenderDAO().insertOnlySingle(defenderEY);
                }


                List<T_DefenderEY> mDataArray = db.tDefenderDAO().getDefenderType(cropping_system_id, crop_id);


                if (cropping_system_id == 1) {

                    dbDefendersJSONArray = new JSONArray();

                    for(T_DefenderEY data : mDataArray) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("crop_id", data.getCrop_id());
                            dbDefendersJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }

                db.close();

                FFSObservationActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateViews(2, cropping_system_id);
                    }
                });

            }
        }).start();
    }


    private void deleteData(final int request, final int pest_id) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                //major crop section

                if (request == 1) {
                    db.tDefenderDAO().deleteByPestId(pest_id, 2, crop_id);
                    db.tPestDAO().deleteByPestId(pest_id, 1, crop_id);

                    List<T_PestEY> mDataArray1 = db.tPestDAO().getTypePest(1, crop_id); //major pest
                    dbPestsJSONArray = new JSONArray();

                    for (T_PestEY data : mDataArray1) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("crop_id", data.getCrop_id());
                            dbPestsJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    List<T_DefenderEY> mDataArray2 = db.tDefenderDAO().getDefenderType(2, crop_id); //major defender
                    dbDefendersJSONArray = new JSONArray();

                    for (T_DefenderEY data : mDataArray2) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("crop_id", data.getCrop_id());
                            dbDefendersJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                    FFSObservationActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Major crop section
                            updateViews(1, 1);
                            updateViews(2, 2);

                        }
                    });

                }


            }
        }).start();
    }



    private void updateViews(int type, int cropping_system_id) {

        if (type == 1) {//Pest

            if (dbPestsJSONArray != null && dbPestsJSONArray.length() > 0) {
                pestRecyclerView.setVisibility(View.VISIBLE);
            } else {
                pestsID = 0;
                pestDropTextView.setHint("Select Pest");
                pestDropTextView.setText("");
                pestRecyclerView.setVisibility(View.GONE);
            }

            CommonDeleteRowAdapter commonAdapter = new CommonDeleteRowAdapter(this, 1, this, dbPestsJSONArray);
            pestRecyclerView.setAdapter(commonAdapter);

            insectPestsEditText.setText(String.valueOf(dbPestsJSONArray.length()));

            String ipests = insectPestsEditText.getText().toString();
            String ndefender = naturalDefendersEditText.getText().toString();

            if (!ipests.isEmpty() && !ndefender.isEmpty()) {
                String ratio = ipests+":"+ndefender;
                pdRatioEditText.setText(ratio);
            }
        }

        if (type == 2) {

            if (dbDefendersJSONArray != null && dbDefendersJSONArray.length() > 0) {
                defenderRecyclerView.setVisibility(View.VISIBLE);
            } else {
                defendersID = 0;
                defenderDropTextView.setHint("Select Defender");
                defenderDropTextView.setText("");
                defenderRecyclerView.setVisibility(View.GONE);
            }

            CommonAdapter commonAdapter = new CommonAdapter(this, 2, this, dbDefendersJSONArray);
            defenderRecyclerView.setAdapter(commonAdapter);

            naturalDefendersEditText.setText(String.valueOf(dbDefendersJSONArray.length()));

            String ipests = insectPestsEditText.getText().toString();
            String ndefender = naturalDefendersEditText.getText().toString();

            if (!ipests.isEmpty() && !ndefender.isEmpty()) {
                String ratio = ipests+":"+ndefender;
                pdRatioEditText.setText(ratio);
            }
        }


        if (type == 6) {

            if (dbDiseaseJSONArray != null && dbDiseaseJSONArray.length() > 0) {
                diseaseRecyclerView.setVisibility(View.VISIBLE);
            } else {
                diseaseId = 0;
                diseasesTypeDropTextView.setHint("Select disease type");
                diseasesTypeDropTextView.setText("");
                diseaseRecyclerView.setVisibility(View.GONE);
            }

            DiseaseSeverityAdapter diseaseSeverityAdapter = new DiseaseSeverityAdapter(this, 6, this, dbDiseaseJSONArray);
            diseaseRecyclerView.setAdapter(diseaseSeverityAdapter);

        }

    }



    private void addDiseaseInDatabase(final int cropping_system_id, final int id, final  String name) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                List<T_DiseaseTypeEY> mDataExistArray = db.tDiseaseTypeDAO().checkIdExists(id, crop_id);

                if (mDataExistArray.size() == 0) {
                    T_DiseaseTypeEY tDiseaseTypeEY = new T_DiseaseTypeEY();
                    tDiseaseTypeEY.setUid(id);
                    tDiseaseTypeEY.setName(name);
                    tDiseaseTypeEY.setCrop_id(crop_id);
                    tDiseaseTypeEY.setPlot_obs(0);
                    tDiseaseTypeEY.setCropping_system(cropping_system_id);
                    tDiseaseTypeEY.setIs_severity(0);
                    db.tDiseaseTypeDAO().insertOnlySingle(tDiseaseTypeEY);
                }


                List<T_DiseaseTypeEY> mDataArray = db.tDiseaseTypeDAO().getDiseaseType(cropping_system_id, crop_id);


                if (cropping_system_id == 1) {

                    dbDiseaseJSONArray = new JSONArray();

                    for(T_DiseaseTypeEY data : mDataArray) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("is_severity", data.getIs_severity());
                            dbDiseaseJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }

                db.close();

                FFSObservationActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateViews(6, cropping_system_id);
                    }
                });

            }
        }).start();
    }


    private void deleteDiseaseData(final int request, final int disease_id) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                //major crop section

                if (request == 6) {
                    db.tDiseaseTypeDAO().deleteByDiseaseId(disease_id, 1, crop_id);

                    List<T_DiseaseTypeEY> mDataArray1 = db.tDiseaseTypeDAO().getDiseaseType(1, crop_id);
                    dbDiseaseJSONArray = new JSONArray();

                    for (T_DiseaseTypeEY data : mDataArray1) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("is_severity", data.getIs_severity());
                            dbDiseaseJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                    FFSObservationActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Major crop section
                            updateViews(6, 1);

                        }
                    });

                }


                // Delete all data except no disease
                if (request == 8) {

                    db.tDiseaseTypeDAO().deleteAllDataExceptNoDisease(disease_id, 1, crop_id);

                    List<T_DiseaseTypeEY> mDataArray1 = db.tDiseaseTypeDAO().getDiseaseType(1, crop_id);
                    dbDiseaseJSONArray = new JSONArray();

                    for (T_DiseaseTypeEY data : mDataArray1) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("is_severity", data.getIs_severity());
                            dbDiseaseJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        }).start();
    }


    private void updateDiseaseData(final int request, final int disease_id, final int severity_id) {

        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getFfsDatabase();

                //major crop section

                if (request == 66) {

                    db.tDiseaseTypeDAO().updateByDiseaseSeverity(severity_id, disease_id, 1, crop_id);
                    List<T_DiseaseTypeEY> mDataArray1 = db.tDiseaseTypeDAO().getDiseaseType(1, crop_id);
                    dbDiseaseJSONArray = new JSONArray();

                    for (T_DiseaseTypeEY data : mDataArray1) {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id", data.getUid());
                            jsonObject.put("name", data.getName());
                            jsonObject.put("value", data.getValue());
                            jsonObject.put("is_severity", data.getIs_severity());
                            dbDiseaseJSONArray.put(jsonObject);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                    FFSObservationActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Major crop section
                            updateViews(6, 1);

                        }
                    });

                }


                db.close();

            }
        }).start();
    }



    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject) o;
        CommonModel commonModel = new CommonModel(jsonObject);

        if (i == 1) {
            deleteData(1, commonModel.getId());
        }

        if (i == 6) {
            /*if (commonModel.getName().equalsIgnoreCase(AppConstants.kOTHER)) {
                diseasesTypeEditText.setVisibility(View.GONE);
                diseasesTypeEditText.setText("");
            }*/

            deleteDiseaseData(6, commonModel.getId());
        }

       /* if (i == 66) {

            OffDiseaseTypeModel offDiseaseTypeModel = new OffDiseaseTypeModel(jsonObject);

            if (offDiseaseTypeModel.getIs_severity() > 0) {
                updateDiseaseData(i, offDiseaseTypeModel.getId(), offDiseaseTypeModel.getIs_severity());
            }
        }*/

    }



    @Override
    public void onDateSelected(int i, int i1, int i2, int i3) {
        DebugLog.getInstance().d("");

        String month = String.format(Locale.getDefault(),"%02d", i2);
        String day = String.format(Locale.getDefault(),"%02d", i1);

        String dateOfSowing = day+"-"+month+"-"+i3;

        dateOfSowingServer = i3+"-"+month+"-"+day;


        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        try {
            Date date = dateFormat.parse(dateOfSowing);
            Timestamp dateOfSowingTimestamp = new Timestamp(date,null);
            DebugLog.getInstance().d("dateOfSowingTimestamp="+dateOfSowingTimestamp);

        } catch (ParseException e) {
            e.printStackTrace();
        }


        dateTextView.setText(dateOfSowing);

        daysSowing = AppHelper.getInstance().getDaysFromTwoDates(dateOfSowing);
        String formattedDate = Integer.parseInt(daysSowing) == 1 ? daysSowing+" Day" : daysSowing+" Days";

        daysAfterSowingTextView.setText(formattedDate);


    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            methodSowingID = s;
            methodDropTextView.setText(s);
        }

        if (i == 2) {
            pestsID = Integer.parseInt(s1);
            pestDropTextView.setText(s);

            addPestInDatabase(1, pestsID, s);

            defendersID = 0;
            defenderDropTextView.setHint("Select Defender");
            defenderDropTextView.setText("");

            fetchDefendersMasterData();
        }

        if (i == 3) {
            defendersID = Integer.parseInt(s1);
            defenderDropTextView.setText(s);

            addDefenderInDatabase(1,defendersID,s);
        }

        if (i == 6) {
            varietyId = Integer.parseInt(s1);
            varietyDropTextView.setText(s);

            if (s.equalsIgnoreCase("other")) {
                varietyEditText.setVisibility(View.VISIBLE);
            } else {
                varietyEditText.setVisibility(View.GONE);
            }
        }

        if (i == 7) {
            soilCondId = Integer.parseInt(s1);
            soilCondDropTextView.setText(s);
        }

        if (i == 8) {
            rainfallCondId = Integer.parseInt(s1);
            rainfallDropTextView.setText(s);
            AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_RAINFALL_ID, rainfallCondId);
            AppSettings.getInstance().setValue(this, ApConstants.kOBS_RAINFALL_NAME, s);
        }


        if (i == 9) {
            weatherCondId = Integer.parseInt(s1);
            weatherCondDropTextView.setText(s);
            AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_WEATHER_ID, weatherCondId);
            AppSettings.getInstance().setValue(this, ApConstants.kOBS_WEATHER_NAME, s);
        }


        if (i == 10) {
            diseaseId = Integer.parseInt(s1);
            diseasesTypeDropTextView.setText(s);

            if (s.equalsIgnoreCase(ApConstants.kNO_DISEASE)) {
                deleteDiseaseData(8, diseaseId);
            }
            addDiseaseInDatabase(1, diseaseId, s);


            /*if (s.equalsIgnoreCase("other")) {
                diseasesTypeEditText.setVisibility(View.VISIBLE);
            } else {
                diseasesTypeEditText.setVisibility(View.GONE);
            }*/
        }


        if (i == 11) {
            weedsTypeId = Integer.parseInt(s1);
            weedsTypeDropTextView.setText(s);
        }

        if (i == 12) {
            irrigationMethodId = Integer.parseInt(s1);
            irrigationMethodDropTextView.setText(s);
        }

        if (i == 13) {
            diseaseSeverityId = Integer.parseInt(s1);
            diseasesSeverityDropTextView.setText(s);
        }

        if (i == 14) {
            windCondition = Integer.parseInt(s1);
            windCondDropTextView.setText(s);
            AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_WIND_ID, windCondition);
            AppSettings.getInstance().setValue(this, ApConstants.kOBS_WIND_NAME, s);
        }

        if (i == 23) {
            rodentDamageId = Integer.parseInt(s1);
            rodentDropTextView.setText(s);
        }
    }


    private void methodOfSowing() {

        if (methodSowingJSONArray == null) {
            fetchMethodOfSowingMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(methodSowingJSONArray, 1, "Select Method Of Sowing", "method_name", "id", this, this);
        }
    }

    private void pestsDropdown() {

        if (pestsJSONArray == null) {
            fetchPestsMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(pestsJSONArray, 2, "Select Pests", "pest_eng_name", "id", this, this);
        }
    }


    private void defendersDropdown() {
        if (defendersJSONArray == null) {
            fetchDefendersMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(defendersJSONArray, 3, "Select Defenders", "name", "id", this, this);
        }
    }


    private void showCropVariety() {
        if (varietyJSONArray == null) {
            fetchCropVariety();
        } else {
            AppUtility.getInstance().showListDialogIndex(varietyJSONArray, 6, "Select Crop Variety", "variety_name_marathi", "crop_name_id", this, this);
        }
    }

    private void showSoilCondition() {

        if (soilJSONArray == null) {
            fetchSoilCondition();
        } else {
            AppUtility.getInstance().showListDialogIndex(soilJSONArray, 7, "Select Soil Condition ", "name", "id", this, this);
        }
    }


    private void showRainfallCondition() {

        if (rainfallJSONArray == null) {
            fetchRainfallCondition();
        } else {
            AppUtility.getInstance().showListDialogIndex(rainfallJSONArray, 8, "Select Rainfall Condition ", "name", "id", this, this);
        }
    }


    private void showWeatherCondition() {
        if (weatherJSONArray == null) {
            fetchWeatherCondition();
        } else {
            AppUtility.getInstance().showListDialogIndex(weatherJSONArray, 9, "Select Weather Condition ", "name", "id", this, this);
        }
    }



    private void showDiseaseType() {
        if (diseaseTypeJSONArray == null) {
            fetchDisease();
        } else {
            AppUtility.getInstance().showListDialogIndex(diseaseTypeJSONArray, 10, "Select Disease Type", "name", "id", this, this);
        }
    }


    private void showWeedsType() {

        if (weedsTypeJSONArray == null) {
            fetchWeedsType();
        } else {
            AppUtility.getInstance().showListDialogIndex(weedsTypeJSONArray, 11, "Select Weeds Type & Intensity ", "name", "id", this, this);
        }
    }


    private void showIrrigationMethod() {

        if (irrigationMethodJSONArray == null) {
            fetchIrrigationMethod();
        } else {
            AppUtility.getInstance().showListDialogIndex(irrigationMethodJSONArray, 12, "Select Irrigation Method", "irrigation_name_eng", "irrigation_id", this, this);
        }
    }


    private void showDiseaseSeverity() {

        if (diseaseSeverityJSONArray == null) {
            fetchDiseaseSeverity();
        } else {
            AppUtility.getInstance().showListDialogIndex(diseaseSeverityJSONArray, 13, "Select Severity", "name", "id", this, this);
        }
    }


    private void showWindCondition() {
        if (windCondJSONArray == null) {
            fetchWindCondition();
        } else {
            AppUtility.getInstance().showListDialogIndex(windCondJSONArray, 14, "Select Wind Condition", "name", "id", this, this);
        }
    }

    private void showRodentDamage() {
        if (rodentDamageJSONArray == null) {
            fetchRodentDamage();
        } else {
            AppUtility.getInstance().showListDialogIndex(rodentDamageJSONArray, 23, "Select Rodent Damage", "name", "id", this, this);

        }
    }


    private boolean isDiseaseSeveritySelected() {

        boolean isAll = false;

        String disease = diseasesTypeDropTextView.getText().toString();

        if (disease.equalsIgnoreCase(ApConstants.kNO_DISEASE)) {
            isAll = true;

        } else {
            JSONArray jsonArray = new JSONArray();

            int k = 0;

            while (k< dbDiseaseJSONArray.length()) {
                try {
                    JSONObject jsonObject = dbDiseaseJSONArray.getJSONObject(k);
                    OffDiseaseTypeModel model = new OffDiseaseTypeModel(jsonObject);
                    if (model.getIs_severity() > 0) {
                        jsonArray.put(jsonObject);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                k++;
            }

            if (jsonArray.length() == dbDiseaseJSONArray.length()) {
                isAll = true;
            }
        }

        return isAll;
    }



    //TODO Submit button Action
    private void submitButtonAction() {
        if (update_visit == 1) {
            validateRequestWithoutImg();
        } else {
            validateRequest();
        }
    }

    private void validateRequest() {
        try {

            String variety = varietyEditText.getText().toString();
            String height = heightEditText.getText().toString();
            String canopy = canopyEditText.getText().toString();

            String branches = branchesEditText.getText().toString();
            String damage = damageEditText.getText().toString();
            String sqrBranches= sqrBranchesEditText.getText().toString();
            String sqrDamage= sqrDamageEditText.getText().toString();
            String budBranches= budBranchesEditText.getText().toString();
            String budDamage= budDamageEditText.getText().toString();
            String flowerBranches= flowerBranchesEditText.getText().toString();
            String flowerDamage= flowerDamageEditText.getText().toString();
            String fruitBranches=fruitBranchesEditText.getText().toString();
            String fruitDamage= fruitDamageEditText.getText().toString();
            String podBranches =podBranchesEditText.getText().toString();
            String podDamage=podDamageEditText.getText().toString();
            String bollBranches=bollBranchesEditText.getText().toString();
            String bollDamage=bollDamageEditText.getText().toString();
            String grainBranches= grainBranchesEditText.getText().toString();
            String grainDamage = grainDamageEditText.getText().toString();

            String npests = insectPestsEditText.getText().toString();
            String ndefenders = naturalDefendersEditText.getText().toString();
            String pdRatio = pdRatioEditText.getText().toString();

            String soil = soilCondEditText.getText().toString();
            String weather = weatherCondEditText.getText().toString();
            String diseases = diseasesTypeEditText.getText().toString();
            String weeds = weedsTypeEditText.getText().toString();
            String rodent = rodentDamageEditText.getText().toString();




            if (dateOfSowingServer.isEmpty()) {
                UIToastMessage.show(this, "Please select date of sowing");

            } else if (methodSowingID.equalsIgnoreCase("")) {
                UIToastMessage.show(this, "Please select method of sowing");

            } else if (varietyId == 0) {
                UIToastMessage.show(this, "Please select variety");

            } else if (varietyEditText.getVisibility() == View.VISIBLE && variety.isEmpty()) {
                UIToastMessage.show(this, "Please enter variety");

            } else if (irrigationMethodId == 0) {
                UIToastMessage.show(this, "Please select irrigation method");

            } else if (height.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_height_err));

            } else if (canopy.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_canopy_err));

            } else if (branches.isEmpty()) {
                UIToastMessage.show(this, "Please enter branches total");

            } else if (damage.isEmpty()) {
                UIToastMessage.show(this, "Please enter damage branches");

            } else if (sqrBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter square branches number");

            } else if (sqrDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter square of which damaged");

            } else if (budBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter bud branches number");

            } else if (budDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter bud of which damaged");

            } else if (flowerBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter flowers branches number");

            } else if (flowerDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter flowers of which damaged");

            } else if (fruitBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter fruit branches number");

            } else if (fruitDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter fruit of which damaged");

            } else if (podBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter pod branches number");

            } else if (podDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter pod of which damaged");

            } else if (bollBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter boll branches number");

            } else if (bollDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter boll of which damaged");

            } else if (grainBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter ear heads branches number");

            } else if (grainDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter ear heads of which damaged");

            } else if (pestsID == 0) {
                UIToastMessage.show(this, "Please select pests");

            } else if (npests.isEmpty()) {
                UIToastMessage.show(this, "Please enter no of pests insects");

            } else if (defendersID == 0) {
                UIToastMessage.show(this, "Please select defenders");

            } else if (ndefenders.isEmpty()) {
                UIToastMessage.show(this, "Please enter number of natural defenders");

            } else if (diseaseId == 0) {
                UIToastMessage.show(this, "Please select diseases types");

            } else if (!isDiseaseSeveritySelected()) {
                UIToastMessage.show(this, "Please select disease severity");

            }else if (diseaseSeverityId == 0) {
                UIToastMessage.show(this, "Please select severity");

            } else if (weedsTypeId == 0) {
                UIToastMessage.show(this, "Please select weeds types & intensity");

            } else if (rodentDamageId == 0) {
                UIToastMessage.show(this, "Please select rodent damage");

            } else if (soilCondId == 0) {
                UIToastMessage.show(this, "Please select soil condition");

            } else if (weatherCondId == 0) {
                UIToastMessage.show(this, "Please select weather condition");

            } else if (windCondition == 0) {
                UIToastMessage.show(this, "Please select wind condition");

            } else if (rainfallCondId == 0) {
                UIToastMessage.show(this, "Please select rainfall condition");

            } else if (diseasesTypeEditText.getVisibility() == View.VISIBLE && diseases.isEmpty()) {
                UIToastMessage.show(this, "Please enter diseases types");

            }else if (cropCondition.isEmpty()) {
                UIToastMessage.show(this, "Please select crop condition by eye observation");

            } else if (imgFile == null) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_attach_photo));

            } else if (imgFile2 == null) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_attach_photo_chart));

            } else {

                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("id", 0);
                jsonObject1.put("value", dateOfSowingServer);
                jsonObject1.put("name", "Date Of Sowing : "+dateOfSowingServer);

                JSONObject jsonObject2 = new JSONObject();
                jsonObject2.put("id", 1);
                jsonObject2.put("value", daysSowing);
                jsonObject2.put("name", "Days After Sowing : "+daysSowing);

                JSONObject jsonObject3 = new JSONObject();
                jsonObject3.put("id", 2);
                jsonObject3.put("value", methodSowingID);
                jsonObject3.put("name", "Method Of Sowing : "+methodSowingID);

                JSONObject jsonObject4 = new JSONObject();
                jsonObject4.put("id", 3);
                jsonObject4.put("value", varietyId);
                jsonObject4.put("name", "Variety : "+varietyId);

                JSONObject jsonObject34 = new JSONObject();
                jsonObject34.put("id", 33);
                jsonObject34.put("value", variety);
                jsonObject34.put("name", "Variety Other : "+variety);


                JSONObject jsonObject5 = new JSONObject();
                jsonObject5.put("id", 4);
                jsonObject5.put("value", height);
                jsonObject5.put("name", "Height : "+height);

                JSONObject jsonObject6 = new JSONObject();
                jsonObject6.put("id", 5);
                jsonObject6.put("value", canopy);
                jsonObject6.put("name", "Canopy : "+canopy);

                JSONObject jsonObject7 = new JSONObject();
                jsonObject7.put("id", 6);
                jsonObject7.put("value", branches);
                jsonObject7.put("name", "Branches Total : "+branches);

                JSONObject jsonObject8 = new JSONObject();
                jsonObject8.put("id", 7);
                jsonObject8.put("value", damage);
                jsonObject8.put("name", "Branches Damage : "+damage);

                JSONObject jsonObject9 = new JSONObject();
                jsonObject9.put("id", 8);
                jsonObject9.put("value", sqrBranches);
                jsonObject9.put("name", "Square Total : "+sqrBranches);

                JSONObject jsonObject10 = new JSONObject();
                jsonObject10.put("id", 9);
                jsonObject10.put("value", sqrDamage);
                jsonObject10.put("name", "Square Damage : "+sqrDamage);

                JSONObject jsonObject11 = new JSONObject();
                jsonObject11.put("id", 10);
                jsonObject11.put("value", budBranches);
                jsonObject11.put("name", "Bud Total : "+budBranches);

                JSONObject jsonObject12 = new JSONObject();
                jsonObject12.put("id", 11);
                jsonObject12.put("value", budDamage);
                jsonObject12.put("name", "Bud Damage : "+budDamage);

                JSONObject jsonObject13 = new JSONObject();
                jsonObject13.put("id", 12);
                jsonObject13.put("value", flowerBranches);
                jsonObject13.put("name", "Flowers Total : "+flowerBranches);

                JSONObject jsonObject14 = new JSONObject();
                jsonObject14.put("id", 13);
                jsonObject14.put("value", flowerDamage);
                jsonObject14.put("name", "Flowers Damage : "+flowerDamage);


                JSONObject jsonObject15 = new JSONObject();
                jsonObject15.put("id", 14);
                jsonObject15.put("value", fruitBranches);
                jsonObject15.put("name", "Fruit Total : "+fruitBranches);

                JSONObject jsonObject16 = new JSONObject();
                jsonObject16.put("id", 15);
                jsonObject16.put("value", fruitDamage);
                jsonObject16.put("name", "Fruit Damage : "+fruitDamage);

                JSONObject jsonObject17 = new JSONObject();
                jsonObject17.put("id", 16);
                jsonObject17.put("value", podBranches);
                jsonObject17.put("name", "Pod Total : "+podBranches);

                JSONObject jsonObject18 = new JSONObject();
                jsonObject18.put("id", 17);
                jsonObject18.put("value", podDamage);
                jsonObject18.put("name", "Pod Damage : "+podDamage);

                JSONObject jsonObject19 = new JSONObject();
                jsonObject19.put("id", 18);
                jsonObject19.put("value", bollBranches);
                jsonObject19.put("name", "Boll Total : "+bollBranches);

                JSONObject jsonObject20 = new JSONObject();
                jsonObject20.put("id", 19);
                jsonObject20.put("value", bollDamage);
                jsonObject20.put("name", "Boll Damage : "+bollDamage);

                JSONObject jsonObject21 = new JSONObject();
                jsonObject21.put("id", 20);
                jsonObject21.put("value", grainBranches);
                jsonObject21.put("name", "Grain Total : "+grainBranches);

                JSONObject jsonObject22 = new JSONObject();
                jsonObject22.put("id", 21);
                jsonObject22.put("value", grainDamage);
                jsonObject22.put("name", "Grain Damage : "+grainDamage);

                JSONObject jsonObject23 = new JSONObject();
                jsonObject23.put("id", 22);
                //jsonObject23.put("value", pestsID);
                jsonObject23.put("value", dbPestsJSONArray.toString());
                jsonObject23.put("name", "Pests : "+pestDropTextView.getText().toString());

                JSONObject jsonObject24 = new JSONObject();
                jsonObject24.put("id", 23);
                //jsonObject24.put("value", defendersID);
                jsonObject24.put("value", dbDefendersJSONArray.toString());
                jsonObject24.put("name", "Defenders : "+defenderDropTextView.getText().toString());

                JSONObject jsonObject25 = new JSONObject();
                jsonObject25.put("id", 24);
                jsonObject25.put("value", npests);
                jsonObject25.put("name", "No Of Insect Pests : "+npests);

                JSONObject jsonObject26 = new JSONObject();
                jsonObject26.put("id", 25);
                jsonObject26.put("value", ndefenders);
                jsonObject26.put("name", "No Of Natural Defenders : "+ndefenders);

                JSONObject jsonObject27 = new JSONObject();
                jsonObject27.put("id", 26);
                jsonObject27.put("value", pdRatio);
                jsonObject27.put("name", "PD Ratio : "+pdRatio);

                JSONObject jsonObject28 = new JSONObject();
                jsonObject28.put("id", 27);
                jsonObject28.put("value", soilCondId);
                jsonObject28.put("name", "Soil Condition : "+soilCondId);

                JSONObject jsonObject29 = new JSONObject();
                jsonObject29.put("id", 28);
                jsonObject29.put("value", weatherCondId);
                jsonObject29.put("name", "Weather Condition : "+weatherCondId);

                JSONObject jsonObject30 = new JSONObject();
                jsonObject30.put("id", 29);
                //jsonObject30.put("value", diseaseId);
                jsonObject30.put("value", dbDiseaseJSONArray.toString());
                //jsonObject30.put("name", "Diseases Types : "+diseaseId);
                jsonObject30.put("name", "Diseases Types : "+diseasesTypeDropTextView.getText().toString());


                //Passing empty data as of now (Disease type other) 05/07/2019
                JSONObject jsonObject35 = new JSONObject();
                jsonObject35.put("id", 34);
                jsonObject35.put("value", "");
                jsonObject35.put("name", "Diseases Types Other : ");

                JSONObject jsonObject36 = new JSONObject();
                jsonObject36.put("id", 35);
                jsonObject36.put("value", diseaseSeverityId);
                jsonObject36.put("name", "Disease Severity : "+diseaseSeverityId);

                JSONObject jsonObject31 = new JSONObject();
                jsonObject31.put("id", 30);
                jsonObject31.put("value", weedsTypeId);
                jsonObject31.put("name", "Weed Types & Intensity : "+weedsTypeId);

                JSONObject jsonObject32 = new JSONObject();
                jsonObject32.put("id", 31);
                jsonObject32.put("value", rodentDamageId);
                jsonObject32.put("name", "Rodent Damage : "+rodentDropTextView.getText().toString());


                JSONObject jsonObject33 = new JSONObject();
                jsonObject33.put("id", 32);
                jsonObject33.put("value", cropCondition);
                jsonObject33.put("name", "Crop Conditions : "+cropCondition);


                JSONObject jsonObject37 = new JSONObject();
                jsonObject37.put("id", 36);
                jsonObject37.put("value", windCondition);
                jsonObject37.put("name", "Wind Conditions : "+windCondDropTextView.getText().toString());

                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject1);
                jsonArray.put(jsonObject2);
                jsonArray.put(jsonObject3);
                jsonArray.put(jsonObject4);
                jsonArray.put(jsonObject5);
                jsonArray.put(jsonObject6);
                jsonArray.put(jsonObject7);
                jsonArray.put(jsonObject8);
                jsonArray.put(jsonObject9);
                jsonArray.put(jsonObject10);
                jsonArray.put(jsonObject11);
                jsonArray.put(jsonObject12);
                jsonArray.put(jsonObject13);
                jsonArray.put(jsonObject14);
                jsonArray.put(jsonObject15);
                jsonArray.put(jsonObject16);
                jsonArray.put(jsonObject17);
                jsonArray.put(jsonObject18);
                jsonArray.put(jsonObject19);
                jsonArray.put(jsonObject20);
                jsonArray.put(jsonObject21);
                jsonArray.put(jsonObject22);
                jsonArray.put(jsonObject23);
                jsonArray.put(jsonObject24);
                jsonArray.put(jsonObject25);
                jsonArray.put(jsonObject26);
                jsonArray.put(jsonObject27);
                jsonArray.put(jsonObject28);
                jsonArray.put(jsonObject29);
                jsonArray.put(jsonObject37);
                jsonArray.put(jsonObject30);
                jsonArray.put(jsonObject31);
                jsonArray.put(jsonObject32);
                jsonArray.put(jsonObject33);
                jsonArray.put(jsonObject34);
                //jsonArray.put(jsonObject35);
                jsonArray.put(jsonObject36);

                AppSettings.getInstance().setLongValue(this, ApConstants.kOBS_DATE_SOWING, AppHelper.getInstance().getYYYYMMDDDateTimestamp(dateOfSowingServer));
                AppSettings.getInstance().setValue(this, ApConstants.kOBS_METHOD_SOWING, methodSowingID);
                AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_CROP_VARIETY, varietyId);
                AppSettings.getInstance().setValue(this, ApConstants.kOBSERVATIONS, jsonArray.toString());
                AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_IRRIGATION_METHOD, irrigationMethodId);
                EventBus.getDefault().post(new EventModel("update_3"));
                finish();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void validateRequestWithoutImg() {
        try {

            String variety = varietyEditText.getText().toString();
            String height = heightEditText.getText().toString();
            String canopy = canopyEditText.getText().toString();

            String branches = branchesEditText.getText().toString();
            String damage = damageEditText.getText().toString();
            String sqrBranches= sqrBranchesEditText.getText().toString();
            String sqrDamage= sqrDamageEditText.getText().toString();
            String budBranches= budBranchesEditText.getText().toString();
            String budDamage= budDamageEditText.getText().toString();
            String flowerBranches= flowerBranchesEditText.getText().toString();
            String flowerDamage= flowerDamageEditText.getText().toString();
            String fruitBranches=fruitBranchesEditText.getText().toString();
            String fruitDamage= fruitDamageEditText.getText().toString();
            String podBranches =podBranchesEditText.getText().toString();
            String podDamage=podDamageEditText.getText().toString();
            String bollBranches=bollBranchesEditText.getText().toString();
            String bollDamage=bollDamageEditText.getText().toString();
            String grainBranches= grainBranchesEditText.getText().toString();
            String grainDamage = grainDamageEditText.getText().toString();

            String npests = insectPestsEditText.getText().toString();
            String ndefenders = naturalDefendersEditText.getText().toString();
            String pdRatio = pdRatioEditText.getText().toString();

            String soil = soilCondEditText.getText().toString();
            String weather = weatherCondEditText.getText().toString();
            String diseases = diseasesTypeEditText.getText().toString();
            String weeds = weedsTypeEditText.getText().toString();
            String rodent = rodentDamageEditText.getText().toString();


            if (dateOfSowingServer.isEmpty()) {
                UIToastMessage.show(this, "Please select date of sowing");

            } else if (methodSowingID.equalsIgnoreCase("")) {
                UIToastMessage.show(this, "Please select method of sowing");

            } else if (varietyId == 0) {
                UIToastMessage.show(this, "Please select variety");

            } else if (varietyEditText.getVisibility() == View.VISIBLE && variety.isEmpty()) {
                UIToastMessage.show(this, "Please enter variety");

            } else if (irrigationMethodId == 0) {
                UIToastMessage.show(this, "Please select irrigation method");

            } else if (height.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_height_err));

            } else if (canopy.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.obs_canopy_err));

            } else if (branches.isEmpty()) {
                UIToastMessage.show(this, "Please enter branches total");

            } else if (damage.isEmpty()) {
                UIToastMessage.show(this, "Please enter damage branches");

            } else if (sqrBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter square branches number");

            } else if (sqrDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter square of which damaged");

            } else if (budBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter bud branches number");

            } else if (budDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter bud of which damaged");

            } else if (flowerBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter flowers branches number");

            } else if (flowerDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter flowers of which damaged");

            } else if (fruitBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter fruit branches number");

            } else if (fruitDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter fruit of which damaged");

            } else if (podBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter pod branches number");

            } else if (podDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter pod of which damaged");

            } else if (bollBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter boll branches number");

            } else if (bollDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter boll of which damaged");

            } else if (grainBranches.isEmpty()) {
                UIToastMessage.show(this, "Please enter ear heads branches number");

            } else if (grainDamage.isEmpty()) {
                UIToastMessage.show(this, "Please enter ear heads of which damaged");

            } else if (pestsID == 0) {
                UIToastMessage.show(this, "Please select pests");

            } else if (npests.isEmpty()) {
                UIToastMessage.show(this, "Please enter no of pests insects");

            } else if (defendersID == 0) {
                UIToastMessage.show(this, "Please select defenders");

            } else if (ndefenders.isEmpty()) {
                UIToastMessage.show(this, "Please enter number of natural defenders");

            } else if (diseaseId == 0) {
                UIToastMessage.show(this, "Please select diseases types");

            } else if (!isDiseaseSeveritySelected()) {
                UIToastMessage.show(this, "Please select disease severity");

            }else if (diseaseSeverityId == 0) {
                UIToastMessage.show(this, "Please select severity");

            } else if (weedsTypeId == 0) {
                UIToastMessage.show(this, "Please select weeds types & intensity");

            } else if (rodentDamageId == 0) {
                UIToastMessage.show(this, "Please select rodent damage");

            } else if (soilCondId == 0) {
                UIToastMessage.show(this, "Please select soil condition");

            } else if (weatherCondId == 0) {
                UIToastMessage.show(this, "Please select weather condition");

            } else if (windCondition == 0) {
                UIToastMessage.show(this, "Please select wind condition");

            } else if (rainfallCondId == 0) {
                UIToastMessage.show(this, "Please select rainfall condition");

            } else if (diseasesTypeEditText.getVisibility() == View.VISIBLE && diseases.isEmpty()) {
                UIToastMessage.show(this, "Please enter diseases types");

            }else if (cropCondition.isEmpty()) {
                UIToastMessage.show(this, "Please select crop condition by eye observation");

            } else {

                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("id", 0);
                jsonObject1.put("value", dateOfSowingServer);
                jsonObject1.put("name", "Date Of Sowing : "+dateOfSowingServer);

                JSONObject jsonObject2 = new JSONObject();
                jsonObject2.put("id", 1);
                jsonObject2.put("value", daysSowing);
                jsonObject2.put("name", "Days After Sowing : "+daysSowing);

                JSONObject jsonObject3 = new JSONObject();
                jsonObject3.put("id", 2);
                jsonObject3.put("value", methodSowingID);
                jsonObject3.put("name", "Method Of Sowing : "+methodSowingID);

                JSONObject jsonObject4 = new JSONObject();
                jsonObject4.put("id", 3);
                jsonObject4.put("value", varietyId);
                jsonObject4.put("name", "Variety : "+varietyId);

                JSONObject jsonObject34 = new JSONObject();
                jsonObject34.put("id", 33);
                jsonObject34.put("value", variety);
                jsonObject34.put("name", "Variety Other : "+variety);

                JSONObject jsonObject5 = new JSONObject();
                jsonObject5.put("id", 4);
                jsonObject5.put("value", height);
                jsonObject5.put("name", "Height : "+height);

                JSONObject jsonObject6 = new JSONObject();
                jsonObject6.put("id", 5);
                jsonObject6.put("value", canopy);
                jsonObject6.put("name", "Canopy : "+canopy);

                JSONObject jsonObject7 = new JSONObject();
                jsonObject7.put("id", 6);
                jsonObject7.put("value", branches);
                jsonObject7.put("name", "Branches Total : "+branches);

                JSONObject jsonObject8 = new JSONObject();
                jsonObject8.put("id", 7);
                jsonObject8.put("value", damage);
                jsonObject8.put("name", "Branches Damage : "+damage);

                JSONObject jsonObject9 = new JSONObject();
                jsonObject9.put("id", 8);
                jsonObject9.put("value", sqrBranches);
                jsonObject9.put("name", "Square Total : "+sqrBranches);

                JSONObject jsonObject10 = new JSONObject();
                jsonObject10.put("id", 9);
                jsonObject10.put("value", sqrDamage);
                jsonObject10.put("name", "Square Damage : "+sqrDamage);

                JSONObject jsonObject11 = new JSONObject();
                jsonObject11.put("id", 10);
                jsonObject11.put("value", budBranches);
                jsonObject11.put("name", "Bud Total : "+budBranches);

                JSONObject jsonObject12 = new JSONObject();
                jsonObject12.put("id", 11);
                jsonObject12.put("value", budDamage);
                jsonObject12.put("name", "Bud Damage : "+budDamage);

                JSONObject jsonObject13 = new JSONObject();
                jsonObject13.put("id", 12);
                jsonObject13.put("value", flowerBranches);
                jsonObject13.put("name", "Flowers Total : "+flowerBranches);

                JSONObject jsonObject14 = new JSONObject();
                jsonObject14.put("id", 13);
                jsonObject14.put("value", flowerDamage);
                jsonObject14.put("name", "Flowers Damage : "+flowerDamage);


                JSONObject jsonObject15 = new JSONObject();
                jsonObject15.put("id", 14);
                jsonObject15.put("value", fruitBranches);
                jsonObject15.put("name", "Fruit Total : "+fruitBranches);

                JSONObject jsonObject16 = new JSONObject();
                jsonObject16.put("id", 15);
                jsonObject16.put("value", fruitDamage);
                jsonObject16.put("name", "Fruit Damage : "+fruitDamage);

                JSONObject jsonObject17 = new JSONObject();
                jsonObject17.put("id", 16);
                jsonObject17.put("value", podBranches);
                jsonObject17.put("name", "Pod Total : "+podBranches);

                JSONObject jsonObject18 = new JSONObject();
                jsonObject18.put("id", 17);
                jsonObject18.put("value", podDamage);
                jsonObject18.put("name", "Pod Damage : "+podDamage);

                JSONObject jsonObject19 = new JSONObject();
                jsonObject19.put("id", 18);
                jsonObject19.put("value", bollBranches);
                jsonObject19.put("name", "Boll Total : "+bollBranches);

                JSONObject jsonObject20 = new JSONObject();
                jsonObject20.put("id", 19);
                jsonObject20.put("value", bollDamage);
                jsonObject20.put("name", "Boll Damage : "+bollDamage);

                JSONObject jsonObject21 = new JSONObject();
                jsonObject21.put("id", 20);
                jsonObject21.put("value", grainBranches);
                jsonObject21.put("name", "Grain Total : "+grainBranches);

                JSONObject jsonObject22 = new JSONObject();
                jsonObject22.put("id", 21);
                jsonObject22.put("value", grainDamage);
                jsonObject22.put("name", "Grain Damage : "+grainDamage);

                JSONObject jsonObject23 = new JSONObject();
                jsonObject23.put("id", 22);
                //jsonObject23.put("value", pestsID);
                jsonObject23.put("value", dbPestsJSONArray.toString());
                jsonObject23.put("name", "Pests : "+pestDropTextView.getText().toString());

                JSONObject jsonObject24 = new JSONObject();
                jsonObject24.put("id", 23);
                //jsonObject24.put("value", defendersID);
                jsonObject24.put("value", dbDefendersJSONArray.toString());
                jsonObject24.put("name", "Defenders : "+defenderDropTextView.getText().toString());

                JSONObject jsonObject25 = new JSONObject();
                jsonObject25.put("id", 24);
                jsonObject25.put("value", npests);
                jsonObject25.put("name", "No Of Insect Pests : "+npests);

                JSONObject jsonObject26 = new JSONObject();
                jsonObject26.put("id", 25);
                jsonObject26.put("value", ndefenders);
                jsonObject26.put("name", "No Of Natural Defenders : "+ndefenders);

                JSONObject jsonObject27 = new JSONObject();
                jsonObject27.put("id", 26);
                jsonObject27.put("value", pdRatio);
                jsonObject27.put("name", "PD Ratio : "+pdRatio);

                JSONObject jsonObject28 = new JSONObject();
                jsonObject28.put("id", 27);
                jsonObject28.put("value", soilCondId);
                jsonObject28.put("name", "Soil Condition : "+soilCondId);

                JSONObject jsonObject29 = new JSONObject();
                jsonObject29.put("id", 28);
                jsonObject29.put("value", weatherCondId);
                jsonObject29.put("name", "Weather Condition : "+weatherCondId);

                JSONObject jsonObject30 = new JSONObject();
                jsonObject30.put("id", 29);
                //jsonObject30.put("value", diseaseId);
                jsonObject30.put("value", dbDiseaseJSONArray.toString());
                //jsonObject30.put("name", "Diseases Types : "+diseaseId);
                jsonObject30.put("name", "Diseases Types : "+diseasesTypeDropTextView.getText().toString());


                //Passing empty data as of now (Disease type other) 05/07/2019
                JSONObject jsonObject35 = new JSONObject();
                jsonObject35.put("id", 34);
                jsonObject35.put("value", "");
                jsonObject35.put("name", "Diseases Types Other : ");

                JSONObject jsonObject36 = new JSONObject();
                jsonObject36.put("id", 35);
                jsonObject36.put("value", diseaseSeverityId);
                jsonObject36.put("name", "Disease Severity : "+diseaseSeverityId);

                JSONObject jsonObject31 = new JSONObject();
                jsonObject31.put("id", 30);
                jsonObject31.put("value", weedsTypeId);
                jsonObject31.put("name", "Weed Types & Intensity : "+weedsTypeId);

                JSONObject jsonObject32 = new JSONObject();
                jsonObject32.put("id", 31);
                jsonObject32.put("value", rodentDamageId);
                jsonObject32.put("name", "Rodent Damage : "+rodentDropTextView.getText().toString());


                JSONObject jsonObject33 = new JSONObject();
                jsonObject33.put("id", 32);
                jsonObject33.put("value", cropCondition);
                jsonObject33.put("name", "Crop Conditions : "+cropCondition);


                JSONObject jsonObject37 = new JSONObject();
                jsonObject37.put("id", 36);
                jsonObject37.put("value", windCondition);
                jsonObject37.put("name", "Wind Conditions : "+windCondDropTextView.getText().toString());

                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject1);
                jsonArray.put(jsonObject2);
                jsonArray.put(jsonObject3);
                jsonArray.put(jsonObject4);
                jsonArray.put(jsonObject5);
                jsonArray.put(jsonObject6);
                jsonArray.put(jsonObject7);
                jsonArray.put(jsonObject8);
                jsonArray.put(jsonObject9);
                jsonArray.put(jsonObject10);
                jsonArray.put(jsonObject11);
                jsonArray.put(jsonObject12);
                jsonArray.put(jsonObject13);
                jsonArray.put(jsonObject14);
                jsonArray.put(jsonObject15);
                jsonArray.put(jsonObject16);
                jsonArray.put(jsonObject17);
                jsonArray.put(jsonObject18);
                jsonArray.put(jsonObject19);
                jsonArray.put(jsonObject20);
                jsonArray.put(jsonObject21);
                jsonArray.put(jsonObject22);
                jsonArray.put(jsonObject23);
                jsonArray.put(jsonObject24);
                jsonArray.put(jsonObject25);
                jsonArray.put(jsonObject26);
                jsonArray.put(jsonObject27);
                jsonArray.put(jsonObject28);
                jsonArray.put(jsonObject29);
                jsonArray.put(jsonObject37);
                jsonArray.put(jsonObject30);
                jsonArray.put(jsonObject31);
                jsonArray.put(jsonObject32);
                jsonArray.put(jsonObject33);
                jsonArray.put(jsonObject34);
                //jsonArray.put(jsonObject35);
                jsonArray.put(jsonObject36);

                AppSettings.getInstance().setLongValue(this, ApConstants.kOBS_DATE_SOWING, AppHelper.getInstance().getYYYYMMDDDateTimestamp(dateOfSowingServer));
                AppSettings.getInstance().setValue(this, ApConstants.kOBS_METHOD_SOWING, methodSowingID);
                AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_CROP_VARIETY, varietyId);
                AppSettings.getInstance().setValue(this, ApConstants.kOBSERVATIONS, jsonArray.toString());
                AppSettings.getInstance().setIntValue(this, ApConstants.kOBS_IRRIGATION_METHOD, irrigationMethodId);
                EventBus.getDefault().post(new EventModel("update_3"));
                finish();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }




    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userID + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (imgNumber == 1){
                            imgFile = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            // lat1 = locationManager.getLatitude();
                            // lang1 = locationManager.getLatitude();
                        }else if (imgNumber == 2){
                            imgFile2 = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            // lat2 = locationManager.getLatitude();
                            // lang2 = locationManager.getLatitude();
                        }
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(FFSObservationActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {

            currentImglatLong = appLocationManager.getLatitude()+ "_" + appLocationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("crop_id", String.valueOf(crop_id));
            params.put("ima_sr_no", String.valueOf(imgNumber));

            //creating a file
            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("image_name", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.visit_image_upload(partBody, params);
            api.postRequest(responseCall, this, 33);

            DebugLog.getInstance().d("technology_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("technology_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }




   /* private void imageUploadRequest() {
        try {


            AppSession session = new AppSession(this);

            int visit_number = session.getVisitNumber();
            int scheduleId = session.getScheduleId();

            MultipartBody.Part partBody = null;

            DebugLog.getInstance().d("imgName=" + imgFile);


            Map<String, RequestBody> params = new HashMap<>();
            String userId = String.valueOf(session.getUserId());
            params.put("timestamp", AppinventorApi.toRequestBody(session.getTimeStamp()));
            params.put("facilitator_id", AppinventorApi.toRequestBody(userId));
            params.put("image_type", AppinventorApi.toRequestBody(ImageUploadType.OBSERVATION.id()));
            params.put("visit_number", AppinventorApi.toRequestBody(String.valueOf(visit_number)));
            params.put("schedule_visit_id", AppinventorApi.toRequestBody(String.valueOf(scheduleId)));
            params.put("token", AppinventorApi.toRequestBody(session.getToken()));

            //creating a file
            File file;

            if (imgNumber == 1) {
                file = new File(imgFile.getPath());
            } else {
                file = new File(imgFile2.getPath());
            }

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();

            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.uploadImagesRequest(partBody, params);
            api.postRequest(responseCall, this, 33);


            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }


    }*/


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if ( i == 33 && jsonObject != null) {

                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {

                    JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                    String imgUrl = jsonObject1.getString("file_url");

                    if (imgNumber == 1) {
                        AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE1, jsonObject1.toString());
                        if (currentImglatLong.equalsIgnoreCase("")){
                            AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE1_LOC, currentImglatLong);
                        }else {
                            AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE1_LOC, ApConstants.kOBS_FILE1_LOC);
                        }
                        if (imgUrl != null){
                            Picasso.get()
                                    .load(imgUrl)
                                    .transform(transformation)
                                    .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                    .centerCrop()
                                    .into(attch1ImageView);
                        }

                    } else {
                        AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE2, jsonObject1.toString());
                        if (currentImglatLong.equalsIgnoreCase("")){
                            AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE2_LOC, currentImglatLong);
                        }else {
                            AppSettings.getInstance().setValue(this, ApConstants.kOBS_FILE2_LOC, ApConstants.kOBS_FILE2_LOC);
                        }
                        if (imgUrl != null){
                            Picasso.get()
                                    .load(imgUrl)
                                    .transform(transformation)
                                    .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                    .centerCrop()
                                    .into(attch2ImageView);
                        }
                    }
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 1) {

                if (jsonObject != null) {

                    DebugLog.getInstance().d("onResponse=" + jsonObject);
                    ResponseModel response = new ResponseModel(jsonObject);

                    if (response.isStatus()) {
                        methodSowingJSONArray = response.getData();
                    } else {
                        UIToastMessage.show(FFSObservationActivity.this, response.getMsg());
                    }
                }
            }


            if (i == 2 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    pestsJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

            if (i == 3 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    defendersJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 5 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    varietyJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 6 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    soilJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 7 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    rainfallJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 8 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    weatherJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 9 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    diseaseTypeJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

            if (i == 10 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    weedsTypeJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 11 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    irrigationMethodJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

            if (i == 12 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    diseaseSeverityJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.toString());
                }
            }

            if (i == 13 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    windCondJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.toString());
                }
            }

            if (i == 14 && jsonObject != null) {
                DebugLog.getInstance().d("onResponse="+jsonObject.toString());
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    rodentDamageJSONArray = response.getData();
                } else {
                    UIToastMessage.show(this, response.toString());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }





    private void fetchMethodOfSowingMasterData() {

        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("crop_id", crop_id);
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchShowingList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        /*String url = APIServices.kMethodOfSowingMaster;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                methodSowingJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(FFSObservationActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);*/
    }




    private void fetchPestsMasterData() {

        try {

            JSONObject jsonObject = new JSONObject();

            DebugLog.getInstance().d("getCropId=" +crop_id);

            jsonObject.put("crop_id", crop_id);
            jsonObject.put("pest_id", "");

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }




    private void fetchDefendersMasterData() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("pest_id", pestsID);
            // jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchDefenderList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 3);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }



    private void fetchCropVariety() {

        /*try {
            AppSession session = new AppSession(this);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_id", crop_id);
            // jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchCropVerityList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_name_id", crop_id);
            // jsonObject.put("activity_id", activityID);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MASTER_API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchCropVerityById(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchSoilCondition() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchSoilConditionList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 6);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchRainfallCondition() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchRainConditionList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 7);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchWeatherCondition() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchWeatherList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 8);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchDisease() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            // jsonObject.put("crop_id", crop_id);
            jsonObject.put("", "");
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchDisaesList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 9);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }



    private void fetchWeedsType() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchWeedTypeList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 10);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void fetchIrrigationMethod() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_id", crop_id);
            // jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropIrrigation(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 11);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchDiseaseSeverity() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchDiesesSeverityList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 12);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchWindCondition() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchWindConditionList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 13);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void fetchRodentDamage() {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL,"", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchDamageList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 14);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
