package com.maha.agri.history;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DepartmentHistoryActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button dept_cropsap_history,dept_punchnama_history,dept_primary_report_history;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_history);
        getSupportActionBar().setTitle("History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DepartmentHistoryActivity.this);
        sharedPref = new SharedPref(DepartmentHistoryActivity.this);
        init();
        getCropsapCount();
        getPunchnamaCount();
        default_config();
    }

    private void init(){
        dept_cropsap_history = (Button) findViewById(R.id.dept_cropsap_history);
        dept_punchnama_history = (Button) findViewById(R.id.dept_punchnama_history);
        dept_primary_report_history = (Button) findViewById(R.id.dept_primary_report_history);
    }

    private void default_config(){
    }

    private void getCropsapCount() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_cropsap_history_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    private void getPunchnamaCount() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_panchnama_total_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dept_cropsap_history.setVisibility(View.VISIBLE);
                            String cropsap_count = jsonObject.getString("data");
                            dept_cropsap_history.setText("Cropsap(Self Observation Recorded)" + " (" + cropsap_count + ")");

                            dept_cropsap_history.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(DepartmentHistoryActivity.this,DepartmentCropSapCropCountActivity.class);
                                    startActivity(intent);

                                }
                            });

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dept_punchnama_history.setVisibility(View.VISIBLE);
                            String punchnama_count = jsonObject.getString("data");
                            dept_punchnama_history.setText("Panchnama" + " (" + punchnama_count + ")");

                            dept_punchnama_history.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(DepartmentHistoryActivity.this,DepartmentPunchnamaCropCountActivity.class);
                                    startActivity(intent);

                                }
                            });

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
