/*
 * Copyright (c) 2019. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/1/19 1:00 PM
 */

package com.maha.agri.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.TypedValue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class AIImageLoadingUtils {


    private Context mContext;
//    public Bitmap icon;

    public AIImageLoadingUtils(Context mContext) {
        this.mContext = mContext;
//        icon = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.ic_launcher);
    }

    private int convertDipToPixels(float dips) {
        Resources r = mContext.getResources();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dips, r.getDisplayMetrics());
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;

        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }

        return inSampleSize;
    }

    public Bitmap decodeBitmapFromPath(String filePath) {
        Bitmap scaledBitmap = null;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        scaledBitmap = BitmapFactory.decodeFile(filePath, options);

        options.inSampleSize = calculateInSampleSize(options, convertDipToPixels(150), convertDipToPixels(200));
        options.inDither = false;
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inJustDecodeBounds = false;

        scaledBitmap = BitmapFactory.decodeFile(filePath, options);
        return scaledBitmap;
    }

    public float getFileIMGWidth(Uri uri) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri.getPath()).getAbsolutePath(), options);
        float imageWidth = options.outWidth;
        return imageWidth;
    }

    public float getFileIMGHeight(Uri uri) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri.getPath()).getAbsolutePath(), options);
        float imageHeight = options.outHeight;
        return imageHeight;
    }

    public File createImageFile(String imageType) throws IOException {

        /*String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
//		File storageDir = getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        File storageDir = getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(
                imageFileName,  *//* prefix *//*
                ".jpg",         *//* suffix *//*
                storageDir      *//* directory *//*
        );

        // Save a file: path for use with ACTION_VIEW intents
//		mCurrentPhotoPath = "file:" + image.getAbsolutePath();

        return image;*/

//        File storageDir = new File(Environment.getExternalStorageDirectory().getPath(), ApConstants.kDIR+"/"+ApConstants.kVISITS_DIR+"/"+ApConstants.kVISITS_ONLINE_DIR);
        AppSession session = new AppSession(mContext);

        File storageDir;

        if (session.isOfflineMode()) {
            storageDir = session.getOfflineStorageDir();
            if (!storageDir.exists()) {
                storageDir.mkdirs();
            }
        } else {
            storageDir = session.getOnlineStorageDir();
            if (!storageDir.exists()) {
                storageDir.mkdirs();
            }
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = imageType+"_"+ timeStamp + "_";

        File image = File.createTempFile(
                imageFileName,  //* prefix *//*
                ".jpg",   //* suffix *//*
                 storageDir     //* directory *//*
        );

        return image;
    }

}
