package com.maha.agri.ochard_mapping.model;

import org.json.JSONException;
import org.json.JSONObject;

public class CropType {

    private int id;
    private String croptype;

    public CropType(int id, String croptype) {
        this.id = id;
        this.croptype = croptype;
    }

    public JSONObject getJSONObject() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("id", id);
            obj.put("croptype", croptype);
        } catch (JSONException e) {
        }
        return obj;
    }
}
