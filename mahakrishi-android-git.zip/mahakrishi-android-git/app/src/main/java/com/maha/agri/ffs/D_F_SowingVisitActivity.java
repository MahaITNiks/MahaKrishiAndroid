package com.maha.agri.ffs;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppHelper;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.DatePickerCallbackListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_SowingVisitActivity extends AppCompatActivity implements DatePickerCallbackListener, AlertListEventListener, ApiCallbackCode {

    private PreferenceManager preferenceManager;
    private String schemeID;
    private String userID;
    private String reg_type;
    private String villageId;
    private String planId;
    private String cropID;
    private String cropVerityID;

    private TextView sowingDate_tv;
    private String showingDate = "";
    private TextView showingMethodTV;
    private String showingName = "";
    private String showingID = "";

    private EditText nFertilizerDoseET;
    private EditText pFertilizerDoseET;
    private EditText kFertilizerDoseET;

    private EditText sulphurMN_ET;
    private EditText zincMN_ET;
    private EditText boronMN_ET;

    private Button showingSubmit_btn;
    private boolean isDataAvailable = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_sowing_visit);

        getSupportActionBar().setTitle("Sowing Visit");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(D_F_SowingVisitActivity.this);
        schemeID = preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_ID);
        userID = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        villageId = AppSettings.getInstance().getValue(this, ApConstants.kVILLAGE_ID_DEMO_FFS, ApConstants.kVILLAGE_ID_DEMO_FFS);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);
        cropID = AppSettings.getInstance().getValue(this, ApConstants.kCROP_ID_DEMO_FFS, ApConstants.kCROP_ID_DEMO_FFS);
        cropVerityID = AppSettings.getInstance().getValue(this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, ApConstants.kCROP_VERITY_ID_DEMO_FFS);

        init();
        defaultConfig();

    }

    private void init() {

        sowingDate_tv = (TextView) findViewById(R.id.sowingDate_tv);
        showingMethodTV = (TextView) findViewById(R.id.showingMethodTV);
        nFertilizerDoseET = (EditText) findViewById(R.id.nFertilizerDoseET);
        pFertilizerDoseET = (EditText) findViewById(R.id.pFertilizerDoseET);
        kFertilizerDoseET = (EditText) findViewById(R.id.kFertilizerDoseET);
        sulphurMN_ET = (EditText) findViewById(R.id.sulphurMN_ET);
        zincMN_ET = (EditText) findViewById(R.id.zincMN_ET);
        boronMN_ET = (EditText) findViewById(R.id.boronMN_ET);
        showingSubmit_btn = (Button) findViewById(R.id.showingSubmit_btn);

    }


    private void defaultConfig() {

        sowingDate_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppUtility.getInstance().showFutureDatePicker(D_F_SowingVisitActivity.this,new Date(), sowingDate_tv, D_F_SowingVisitActivity.this);
            }
        });

        showingMethodTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JSONArray showingArray = AppHelper.getInstance().getShowingMethod();
                AppUtility.getInstance().showListDialogIndex(showingArray, 1, "Select Showing Mathod", "name", "id", D_F_SowingVisitActivity.this, D_F_SowingVisitActivity.this);
            }
        });

        showingSubmit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showingSubmit_btnAction();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getShowingVisitDetail();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onDateSelected(TextView textView, int i, int i1, int i2) {
        if (textView == sowingDate_tv){
            showingDate = String.valueOf(i2) + "-" + String.valueOf(i1) + "-" + String.valueOf(i);
        }
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i==1){
            showingID = String.valueOf(s1);
            showingName = s;
            showingMethodTV.setText(s);
        }
    }


    private void getShowingVisitDetail() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", userID);
            param.put("village_id", villageId);
            param.put("crop_id", cropID);
            param.put("vareity_id", cropVerityID);
            param.put("plan_id", planId);
            param.put("reg_type", reg_type);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.getShowingVisitDetail(requestBody);

        DebugLog.getInstance().d("get_Showing Detail=" + responseCall.request().toString());
        DebugLog.getInstance().d("get_Showing Detail=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    private void setShowingDetail(JSONArray showingDataArray) {
        try {
            JSONObject jsonObject = showingDataArray.getJSONObject(0);
            showingDate = jsonObject.getString("sowing_date");
            sowingDate_tv.setText(ApUtil.getDateByTimeStamp(showingDate));
            showingName = jsonObject.getString("sowing_method");
            showingMethodTV.setText(jsonObject.getString("sowing_method"));
            nFertilizerDoseET.setText(jsonObject.getString("n"));
            pFertilizerDoseET.setText(jsonObject.getString("p"));
            kFertilizerDoseET.setText(jsonObject.getString("k"));
            sulphurMN_ET.setText(jsonObject.getString("sulphur"));
            zincMN_ET.setText(jsonObject.getString("zinc"));
            boronMN_ET.setText(jsonObject.getString("boron"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (isDataAvailable){
            sowingDate_tv.setEnabled(false);
            showingMethodTV.setEnabled(false);
            nFertilizerDoseET.setEnabled(false);
            pFertilizerDoseET.setEnabled(false);
            kFertilizerDoseET.setEnabled(false);
            sulphurMN_ET.setEnabled(false);
            zincMN_ET.setEnabled(false);
            boronMN_ET.setEnabled(false);
            // showingSubmit_btn.setVisibility(View.VISIBLE);
            showingSubmit_btn.setVisibility(View.GONE);
        }else {
            sowingDate_tv.setEnabled(true);
            showingMethodTV.setEnabled(true);
            nFertilizerDoseET.setEnabled(true);
            pFertilizerDoseET.setEnabled(true);
            kFertilizerDoseET.setEnabled(true);
            sulphurMN_ET.setEnabled(true);
            zincMN_ET.setEnabled(true);
            boronMN_ET.setEnabled(true);
            showingSubmit_btn.setVisibility(View.VISIBLE);
        }
    }


    private void showingSubmit_btnAction() {

        String n = nFertilizerDoseET.getText().toString().trim();
        String p = pFertilizerDoseET.getText().toString().trim();
        String k = kFertilizerDoseET.getText().toString().trim();
        String sulphur = sulphurMN_ET.getText().toString().trim();
        String zinc = zincMN_ET.getText().toString().trim();
        String boron = boronMN_ET.getText().toString().trim();

        if (showingDate.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Select showing date");
        } else if (showingID.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Select showing method");
        } else if (n.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Fertilizer N dose");
        }else if (n.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Fertilizer N dose should not be 0");
        } else if (p.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Fertilizer P dose");
        }else if (p.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Fertilizer P dose should not be 0");
        } else if (k.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Fertilizer K dose");
        }else if (k.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Fertilizer K dose should not be 0");
        } else if (sulphur.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Micro-Nutrient sulphur dose");
        }else if (sulphur.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Micro-Nutrient sulphur dose should not be 0");
        } else if (zinc.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Micro-Nutrient Zinc dose");
        }else if (zinc.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Micro-Nutrient Zinc dose should not be 0");
        } else if (boron.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Micro-Nutrient Boron dose");
        }else if (boron.equalsIgnoreCase("0")) {
            UIToastMessage.show(this, "Micro-Nutrient Boron dose should not be 0");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", userID);
                param.put("village_id", villageId);
                param.put("crop_id", cropID);
                param.put("vareity_id", cropVerityID);
                param.put("plan_id", planId);
                param.put("sowing_date", showingDate);
                param.put("sowing_method", showingName);
                param.put("n", n);
                param.put("p", p);
                param.put("k", k);
                param.put("sulphur", sulphur);
                param.put("zinc", zinc);
                param.put("boron", boron);
                param.put("reg_type", reg_type);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.insertShowingDetail(requestBody);

            DebugLog.getInstance().d("inset_Showing Detail=" + responseCall.request().toString());
            DebugLog.getInstance().d("inset_Showing Detail=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            if (i == 1) {

                ResponseModel responseModel = new ResponseModel(jsonObject);
                if (responseModel.isStatus()) {
                    UIToastMessage.show(this,responseModel.getMsg());
                    finish();
                }else {
                    UIToastMessage.show(this,responseModel.getMsg());
                }
            }


            if (i == 2) {

                ResponseModel responseModel = new ResponseModel(jsonObject);
                if (responseModel.isStatus()) {
                    JSONArray showingDetailArray = responseModel.getData();
                    if (showingDetailArray.length()>0){
                        isDataAvailable = true;
                        setShowingDetail(showingDetailArray);
                    }
                }
            }
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
