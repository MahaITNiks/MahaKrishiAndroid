package com.maha.agri.activity.task_manager;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SchemeListTypeAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ffs.D_F_FFSActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.spot_verification.DripAndSprinklerActivity;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SchemeActListActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;
    HashMap<String, List<String>> expandableListDetail;
    private boolean haschild;
    private JSONArray schemeListTypes;
    private RecyclerView scheme_List_types_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private int schemeListpos;
    private JSONObject jsonObject;
    private DBHandler dbHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_act_list);
        getSupportActionBar().setTitle("Scheme Activity List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SchemeActListActivity.this);
        sharedPref = new SharedPref(SchemeActListActivity.this);
        dbHandler = new DBHandler(this);
        /*String jsonArray = getIntent().getStringExtra("schemeList");
        dbHandler = new DBHandler(this);

        try {
            JSONArray array = new JSONArray(jsonArray);
            schemeListpos = getIntent().getIntExtra("position", 0);
            jsonObject = array.getJSONObject(schemeListpos);
            String schemeId = jsonObject.getString("id");
            String schemeName = jsonObject.getString("name");
            preferenceManager.putPreferenceValues(Preference_Constant.SCHEME_ID, schemeId);
            preferenceManager.putPreferenceValues(Preference_Constant.SCHEME_NAME, schemeName);

        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        init();
        default_confiq();

        if (isNetworkAvailable()) {
            getSchemeListActivityWebservice();
        } else {
            getOfflineSchemeListActivity();
        }

    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.offline_sync, menu);
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            /*case R.id.offline_sync:
                Intent intent = new Intent(SchemeActListActivity.this, SyncOfflineDataActivity.class);
                startActivity(intent);*/

            default:
                return super.onOptionsItemSelected(item);
        }
    }



    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void init() {
        scheme_List_types_rv = (RecyclerView) findViewById(R.id.scheme_List_type_recyclerView);
        scheme_List_types_rv.setLayoutManager(new LinearLayoutManager(this));
        scheme_List_types_rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void default_confiq() {
        scheme_List_types_rv.addOnItemTouchListener(new SchemeListTypeAdapter.RecyclerTouchListener(this, scheme_List_types_rv, new SchemeListTypeAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                switch (position) {

                    case 12:
                        Intent dripandsprinkler = new Intent(SchemeActListActivity.this, DripAndSprinklerActivity.class);
                        startActivity(dripandsprinkler);
                        break;

                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }



    private void getOfflineSchemeListActivity() {
        //  schemeListTypes = dbHandler.getSchemeActivity(jsonObject.getString("typeId"), "0");
        schemeListTypes = dbHandler.getSchemeActivity("1", "0");
        scheme_List_types_rv.setAdapter(new SchemeListTypeAdapter(this, schemeListTypes, preferenceManager,SchemeActListActivity.this));
    }


    private void getSchemeListActivityWebservice() {
        JSONObject param = new JSONObject();
        try {
            param.put("typeId", preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_TYPE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeListTypes(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

        if (i == 1) {
            AppSettings.getInstance().setValue(SchemeActListActivity.this,ApConstants.kFARMER_REG_TYPE,ApConstants.kFARMER_FFS_REG);
            Intent schedule_visit = new Intent(this, D_F_FFSActivity.class);
            startActivity(schedule_visit);
        }

        if (i == 2) {
            AppSettings.getInstance().setValue(SchemeActListActivity.this,ApConstants.kFARMER_REG_TYPE,ApConstants.kFARMER_DEMO_REG);
            Intent schedule_visit = new Intent(this, D_F_FFSActivity.class);
            startActivity(schedule_visit);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            schemeListTypes = jsonObject.getJSONArray("data");
                            scheme_List_types_rv.setAdapter(new SchemeListTypeAdapter(this, schemeListTypes, preferenceManager, SchemeActListActivity.this));
                            //UIToastMessage.show(this, jsonObject.getString("response"));
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }



}
