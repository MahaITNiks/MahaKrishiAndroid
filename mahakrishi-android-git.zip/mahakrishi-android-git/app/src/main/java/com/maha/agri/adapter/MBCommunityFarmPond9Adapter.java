package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.cropsowingreport.ConsolidateReportAreaYearAdapter;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

public class MBCommunityFarmPond9Adapter extends RecyclerView.Adapter<MBCommunityFarmPond9Adapter.MyViewHolder>{

    private JSONArray add_more_list;
    private JSONObject jsonObject;
    private Context context;
    private PreferenceManager preferencemanager;
    HashMap<Integer,String> crop_map = new HashMap<Integer, String>();

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView mb_pond8_crop_type,mb_pond8_crop_name,mb_pond8_crop_area;
        private ImageView cr_row_delete_iv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.mb_pond8_crop_type = itemView.findViewById(R.id.cr_cropname_tv);
            this.mb_pond8_crop_name = itemView.findViewById(R.id.cr_0_1_year);
            this.mb_pond8_crop_area = itemView.findViewById(R.id.cr_1_3_year);
            this.cr_row_delete_iv = itemView.findViewById(R.id.cr_row_delete_iv);
        }
    }

    public MBCommunityFarmPond9Adapter(PreferenceManager preferenceManager, JSONArray add_more_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.add_more_list = add_more_list;
        this.context = context;
    }

    @NonNull
    @Override
    public MBCommunityFarmPond9Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.mb_community_farm_pond8_singleitem, viewGroup, false);

        MBCommunityFarmPond9Adapter.MyViewHolder myViewHolder = new MBCommunityFarmPond9Adapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MBCommunityFarmPond9Adapter.MyViewHolder holder, int listPosition) {

        try {
            jsonObject = add_more_list.getJSONObject(listPosition);
            holder.mb_pond8_crop_type.setText(jsonObject.getString("crop_type_name"));
            holder.mb_pond8_crop_name.setText(jsonObject.getString("crop_name"));
            holder.mb_pond8_crop_area.setText(jsonObject.getString("crop_area"));

            holder.cr_row_delete_iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    add_more_list.remove(listPosition);
                    notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ConsolidateReportAreaYearAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ConsolidateReportAreaYearAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
