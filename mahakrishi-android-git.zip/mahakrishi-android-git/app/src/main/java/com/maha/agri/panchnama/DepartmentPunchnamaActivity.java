package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DepartmentPunchnamaActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView sp_claims;
    private RecyclerView claims_rv;
    ArrayList<String> ClaimsName;
    HashMap<Integer,String> claims_map = new HashMap<Integer, String>();
    private String claimsname;
    private int claimsID = 0;
    private JSONArray claimsList,claims;
    private Button generate_final_report_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_punchnama);
        getSupportActionBar().setTitle("Panchnama");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        init();
        default_confiq();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void init(){

       sp_claims = (TextView) findViewById(R.id.sp_submit_punchnama);
       //ClaimsName = new ArrayList<>();
        claimsList = new JSONArray();
       claims = new JSONArray();
       PunchnamaClaimWebservice();

       sp_claims.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if (claims.length() > 0) {
                   AppUtility.getInstance().showListDialogIndex(claims, 1, "Select Claims", "name", "id", DepartmentPunchnamaActivity.this, DepartmentPunchnamaActivity.this);
               } else {
                   //PunchnamaClaimWebservice();
               }
           }
       });

        claims_rv = (RecyclerView)findViewById(R.id.dept_punchnama_claims_rv);
        generate_final_report_btn = (Button)findViewById(R.id.generate_final_report_btn);
        claims_rv.setLayoutManager(new LinearLayoutManager(this));

    }

    private void default_confiq(){

        claims_rv.addOnItemTouchListener(new DepartmentPunchnamaAdapter.RecyclerTouchListener(this, claims_rv, new DepartmentPunchnamaAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Intent intent = new Intent(DepartmentPunchnamaActivity.this, DepartmentPunchnamaDetailsActivity.class);
                intent.putExtra("punchanam_details",claimsList.toString());
                intent.putExtra("position",position);
                startActivity(intent);

            }



            @Override
            public void onLongClick(View view, int position) {

            }
        }));


        generate_final_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(claimsID == 0){
                    Toast.makeText(DepartmentPunchnamaActivity.this,"Select Claim",Toast.LENGTH_LONG).show();
                }else {
                    Intent intent = new Intent(DepartmentPunchnamaActivity.this, GenerateFinalReportActivity.class);
                    startActivity(intent);
                }
            }
        });

    }



    private void PunchnamaClaimWebservice(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_punchnama_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void PunchnamaClaimListWebservice(int claimsID){
        JSONObject param = new JSONObject();
        try {
            param.put("panchnama_type_id",claimsID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_punchnama_claims_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            claims = jsonObject.getJSONArray("data");
                            //ClaimsName.add("Submit Panchnama for");
                            /*final int numberOfItemsInResp = claimsList.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject claims_json_object = claimsList.getJSONObject(j);
                                claimsID = claims_json_object.getString("id");
                                claimsname = claims_json_object.getString("name");
                                ClaimsName.add(claimsname);
                                claims_map.put(j, claimsID);
                            }*/

                            generate_final_report_btn.setVisibility(View.VISIBLE);

                        }

                        /*ArrayAdapter<String> adapter = new ArrayAdapter<String>(DepartmentPunchnamaActivity.this, android.R.layout.simple_spinner_dropdown_item, ClaimsName);
                        sp_claims.setAdapter(adapter);*/
                    } else {
                        //UIToastMessage.show(this,jsonObject.getString("response"));
                        //Toast.makeText(this, jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            claimsList = jsonObject.getJSONArray("data");
                            claims_rv.setAdapter(new DepartmentPunchnamaAdapter(claimsList,this));
                        }

                    } else {
                        //UIToastMessage.show(this,"No claims received");
                        Toast toast= Toast.makeText(getApplicationContext(), jsonObject.getString("response"), Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                        toast.show();
                        claims_rv.setAdapter(null);

                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        claimsID = Integer.parseInt(s1);
        claimsname = s;
        sp_claims.setText(claimsname);
        PunchnamaClaimListWebservice(claimsID);
    }
}
