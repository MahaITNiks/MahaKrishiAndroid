package com.maha.agri.ffs;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class PlotHisVisitModel {
    private int id;
    private String visit_number;
    private String created_at_app;
    private JSONObject jsonObject;

    public PlotHisVisitModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getId() {
        id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "id");
        return id;
    }

    public String getVisit_number() {
        visit_number = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "visit_number");
        return visit_number;
    }

    public String getCreated_at_app() {
        created_at_app = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "created_at_app");
        return created_at_app;
    }
}
