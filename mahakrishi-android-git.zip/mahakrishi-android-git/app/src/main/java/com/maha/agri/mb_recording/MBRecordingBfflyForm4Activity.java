package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBRecordingBfflyForm4Activity extends AppCompatActivity implements ApiCallbackCode {
    private EditText mb_bffly4_total_gaps;
    private TextView mb_bffly4_subsidy_year2;
    private Button mb_bffly4_save;
    private SweetAlertDialog sweetAlertDialog;
    private PreferenceManager preferenceManager;
    private String farmer_id="",district_id="",taluka_id="",village_id="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_recording_bffly_form4);
        getSupportActionBar().setTitle("MB Recording BFFLY Form 4");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBRecordingBfflyForm4Activity.this);
        Intent intent = getIntent();
        farmer_id = intent.getStringExtra("farmer_id");
        district_id = intent.getStringExtra("district_id");
        taluka_id = intent.getStringExtra("taluka_id");
        village_id = intent.getStringExtra("village_id");

        ids();
        functions();
    }

    private void ids(){
        mb_bffly4_total_gaps = (EditText) findViewById(R.id.mb_bffly4_total_gaps);
        mb_bffly4_subsidy_year2 = (TextView) findViewById(R.id.mb_bffly4_subsidy_year2);
        mb_bffly4_save = (Button) findViewById(R.id.mb_bffly4_save);
    }

    private void functions(){
        mb_bffly4_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_bffly_form4_save_service();
            }
        });
    }

    private void mb_bffly_form4_save_service(){
        if(mb_bffly4_total_gaps.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter total gaps filled", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("total_gaps", mb_bffly4_total_gaps.getText().toString().trim());
                param.put("subsidy_year2", "0");
                param.put("is_completed", "1");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mbrecording_bffly_form4_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Recording by BFFLY Form 4");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }
            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
