package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface T_DiseaseTypeDAO {

    @Query("SELECT * FROM T_DiseaseTypeEY")
    List<T_DiseaseTypeEY> getAll();

    @Query("DELETE FROM T_DiseaseTypeEY")
    void deleteAll();

//    @Query("DELETE FROM T_DiseaseTypeEY WHERE uid = :diseaseId and cropping_system = :cropping_system and plot_obs = :plot_type")
//    void deleteByDiseaseId(int diseaseId, int cropping_system, int plot_type);

    @Query("DELETE FROM T_DiseaseTypeEY WHERE uid = :diseaseId and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteByDiseaseId(int diseaseId, int cropping_system, int crop_id);


//    @Query("DELETE FROM T_DiseaseTypeEY WHERE uid not in(uid = :diseaseId)  and cropping_system = :cropping_system and plot_obs = :plot_type")
//    void deleteAllDataExceptNoDisease(int diseaseId, int cropping_system, int plot_type);

    @Query("DELETE FROM T_DiseaseTypeEY WHERE uid not in(uid = :diseaseId)  and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteAllDataExceptNoDisease(int diseaseId, int cropping_system, int crop_id);

    @Query("SELECT * FROM T_DiseaseTypeEY WHERE crop_id = :crop_id")
    List<T_DiseaseTypeEY> getCropDisease(int crop_id);

//    @Query("SELECT * FROM T_DiseaseTypeEY WHERE uid = :id and plot_obs = :plot_type")
//    List<T_DiseaseTypeEY> checkIdExists(int id, int plot_type);

    @Query("SELECT * FROM T_DiseaseTypeEY WHERE uid = :id and crop_id = :crop_id")
    List<T_DiseaseTypeEY> checkIdExists(int id, int crop_id);

//    @Query("SELECT * FROM T_DiseaseTypeEY WHERE cropping_system = :cropping_system and plot_obs = :plot_type ORDER BY id DESC")
//    List<T_DiseaseTypeEY> getDiseaseType(int cropping_system, int plot_type);

    @Query("SELECT * FROM T_DiseaseTypeEY WHERE cropping_system = :cropping_system and crop_id = :crop_id ORDER BY id DESC")
    List<T_DiseaseTypeEY> getDiseaseType(int cropping_system, int crop_id);

    @Query("SELECT * FROM T_DiseaseTypeEY WHERE uid IN (:userIds)")
    List<T_DiseaseTypeEY> loadAllByIds(int[] userIds);

//    @Query("UPDATE T_DiseaseTypeEY set is_severity =:severit_id WHERE uid = :diseaseId and cropping_system = :cropping_system and plot_obs = :plot_type")
//    void updateByDiseaseSeverity(int severit_id, int diseaseId, int cropping_system, int plot_type);

    @Query("UPDATE T_DiseaseTypeEY set is_severity =:severit_id WHERE uid = :diseaseId and cropping_system = :cropping_system and crop_id = :crop_id")
    void updateByDiseaseSeverity(int severit_id, int diseaseId, int cropping_system, int crop_id);

    @Insert
    void insertAll(T_DiseaseTypeEY... diseaseTypeEYS);

    @Insert
    void insertOnlySingle(T_DiseaseTypeEY diseaseTypeEY);


}
