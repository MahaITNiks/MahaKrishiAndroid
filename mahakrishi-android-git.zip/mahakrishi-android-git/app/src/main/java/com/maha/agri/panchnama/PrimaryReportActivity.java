package com.maha.agri.panchnama;

import android.content.Intent;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.AddMoreAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class PrimaryReportActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    TextView district_primary_report_txtvw,taluka_primary_report_txtvw,pr_sajja_name_tv,primary_report_affected_village_tv;
    private TextView sp_crop_name,sp_season,pr_sp_horti_crop_type,pr_sp_crop_type,primary_report_other_crop_edt,primary_report_affected_village_reset_tv;
    private ImageView primary_report_affected_village_iv;
    Button btn_add_more_primary_report,generate_primary_report_btn;
    private EditText Total_affected_area_primary_report_edt;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray District_List,village_list,season_list,crop_list,crop_type_list,horti_crop_type_list;
    String season_name,selected_crop_name;
    private int season_id = 0,crop_type_id = 0, horti_crop_id = 0,selected_crop_id = 0;
    ArrayList<String> VillageName;
    ArrayList<String> SajjaName;
    ArrayList<String> SeasonName;
    ArrayList<String> add_more_list;
    HashMap<Integer,String> village_map = new HashMap<Integer, String>();
    HashMap<Integer,String> sajja_map = new HashMap<Integer, String>();
    HashMap<Integer,String> season_map = new HashMap<Integer, String>();
    private RecyclerView primary_report_add_more_rv;
    private LinearLayout season_ll,pr_crop_type_ll,pr_horti_type_ll,primary_report_other_crop_ll,pr_sajja_linear_layout,pr_village_list_linear_layout,pr_village_list_linear_layout_as,pr_sajja_list_linear_layout;
    private JSONArray affectedjsonarray = new JSONArray();
    private JSONArray village_wise_json_array = new JSONArray();
    private JSONArray assigned_location_list = new JSONArray();
    private JSONObject getVillageLocation;
    private String activityID = "",role_id = "",pr_villageID = "",pr_village_name = "",pr_sajaID = "",pr_saja_name = "";

    boolean isdeleteicon_clicked = false;

    //location variable
    private String divison_id_str = "",district_id_str = "",taluka_id_str = "",circle_id_str = "", sajja_id_str = "",
            divison_name = "", district_name = "", taluka_name = "",circle_name = "", sajja_name="",village_name="";
    private int divison_id = 0,district_id = 0, taluka_id = 0,circle_id = 0, sajja_id = 0,selected_village_id = 0;
    private int delete_pos = 0;
    AddMoreAdapter addMoreAdapter;
    private boolean isCropPresent = false;
    private int crop_id_stored = 0, village_id_stored = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drought_related_work);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Primary Report");
        preferenceManager = new PreferenceManager(PrimaryReportActivity.this);
        sharedPref = new SharedPref(PrimaryReportActivity.this);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);
        initialization();
        get_district_taluka();
        Seasons_Service();
        Crop_type_service();
        default_confiq();

    }

    private void initialization() {
        district_primary_report_txtvw = (TextView) findViewById(R.id.district_primary_report_txtvw);
        taluka_primary_report_txtvw = (TextView) findViewById(R.id.taluka_primary_report_txtvw);
        primary_report_affected_village_tv = (TextView)findViewById(R.id.primary_report_affected_village_tv);
        sp_season = (TextView) findViewById(R.id.sp_season);
        pr_sp_crop_type = (TextView) findViewById(R.id.pr_sp_crop_type);
        pr_sp_horti_crop_type = (TextView) findViewById(R.id.pr_sp_horti_crop_type);
        sp_crop_name = (TextView) findViewById(R.id.sp_crop_name);
        pr_sajja_name_tv = (TextView)findViewById(R.id.pr_sajja_name_tv);

        primary_report_affected_village_iv = (ImageView)findViewById(R.id.primary_report_affected_village_iv);

        primary_report_add_more_rv = (RecyclerView)findViewById(R.id.primary_report_add_more_rv);

        generate_primary_report_btn = (Button) findViewById(R.id.generate_primary_report_btn);
        btn_add_more_primary_report = (Button)findViewById(R.id.btn_add_more_primary_report);

        Total_affected_area_primary_report_edt = (EditText)findViewById(R.id.Total_affected_area_primary_report_edt);
        primary_report_other_crop_edt = (EditText) findViewById(R.id.primary_report_other_crop_edt);

        season_ll = (LinearLayout)findViewById(R.id.season_ll);
        pr_crop_type_ll = (LinearLayout)findViewById(R.id.pr_crop_type_ll);
        pr_horti_type_ll = (LinearLayout)findViewById(R.id.pr_horti_type_ll);
        primary_report_other_crop_ll = (LinearLayout)findViewById(R.id.primary_report_other_crop_ll);

        pr_sajja_linear_layout = (LinearLayout)findViewById(R.id.pr_sajja_linear_layout);
        pr_village_list_linear_layout = (LinearLayout)findViewById(R.id.pr_village_list_linear_layout);

        Total_affected_area_primary_report_edt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        SeasonName = new ArrayList<>();

        add_more_list = new ArrayList<>();
        season_list = new JSONArray();
        crop_type_list = new JSONArray();
        horti_crop_type_list = new JSONArray();
        crop_list = new JSONArray();

        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        Seasons_Service();

        sp_season.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(selected_village_id == 0){
                    Toast.makeText(PrimaryReportActivity.this,"Select Village",Toast.LENGTH_SHORT).show();
                } else if (season_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(season_list, 2, "Select Season", "name", "id", PrimaryReportActivity.this, PrimaryReportActivity.this);
                }else{
                    Seasons_Service();
                }
            }
        });

        pr_sp_crop_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(season_id == 0){
                    Toast.makeText(PrimaryReportActivity.this,"Select Season",Toast.LENGTH_SHORT).show();
                } else if (crop_type_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(crop_type_list, 4, "Select Crop Type", "name", "id", PrimaryReportActivity.this, PrimaryReportActivity.this);
                }else{
                    Crop_type_service();
                }
            }
        });

        pr_sp_horti_crop_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (horti_crop_type_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(horti_crop_type_list, 5, "Select Horticultural Crop Type", "crop_type", "id", PrimaryReportActivity.this, PrimaryReportActivity.this);
                }else{
                    Horti_crop_type_service(crop_type_id);
                }
            }
        });

        sp_crop_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_type_id == 0) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select Crop Type", Toast.LENGTH_SHORT);
                    toast.show();
                }
                if(crop_list.length()==0){
                    Toast.makeText(PrimaryReportActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();

                }else {
                    if (crop_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(crop_list, 3, "Select Crop", "crop_english", "id", PrimaryReportActivity.this, PrimaryReportActivity.this);
                    }
                }
            }
        });


        if(role_id.equalsIgnoreCase("1")){
            village_list = new JSONArray();
            primary_report_affected_village_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    village_web_service();
                    if(village_list.length()>0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 8, "Select Village", "village_name", "village_id", PrimaryReportActivity.this, PrimaryReportActivity.this);
                    }
                }
            });
        }

    }


    private void default_confiq(){

        btn_add_more_primary_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(selected_crop_id==0){
                    Toast.makeText(PrimaryReportActivity.this, "Please select crop", Toast.LENGTH_LONG).show();
                }else if(selected_crop_name.equalsIgnoreCase("OTHER")) {
                    if (primary_report_other_crop_edt.getText().toString().trim().equalsIgnoreCase("")) {
                        Toast.makeText(PrimaryReportActivity.this, "Please Enter crop name", Toast.LENGTH_LONG).show();
                    }else if(Total_affected_area_primary_report_edt.getText().toString().trim().equalsIgnoreCase("")){
                        Toast.makeText(PrimaryReportActivity.this, "Please Enter affected area", Toast.LENGTH_LONG).show();
                    } else {
                        selected_crop_name = primary_report_other_crop_edt.getText().toString().trim();
                        add_affected_array(selected_village_id, village_name, selected_crop_id, selected_crop_name, Total_affected_area_primary_report_edt.getText().toString().trim(),"OTHER");
                        selected_crop_id = 0;
                    }
                }else if (Total_affected_area_primary_report_edt.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(PrimaryReportActivity.this, "Please Enter affected area", Toast.LENGTH_LONG).show();
                }
                else {
                    add_affected_array(selected_village_id,village_name,selected_crop_id,selected_crop_name,Total_affected_area_primary_report_edt.getText().toString().trim(),"LIST");
                    selected_crop_id = 0;
                }
            }
        });

        generate_primary_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selected_village_id == 0) {
                    Toast.makeText(PrimaryReportActivity.this, "Select affected village", Toast.LENGTH_SHORT).show();
                } else if (season_id==0) {
                    Toast.makeText(PrimaryReportActivity.this, "Select season", Toast.LENGTH_SHORT).show();
                } else if (crop_type_id==0) {
                    Toast.makeText(PrimaryReportActivity.this, "Select crop type", Toast.LENGTH_SHORT).show();
                }else if (affectedjsonarray.length()==0) {
                    Toast.makeText(PrimaryReportActivity.this, "Select crop and enter affected area", Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(PrimaryReportActivity.this, GeneratePrimaryReportActivity.class);
                    intent.putExtra("affected_crop", affectedjsonarray.toString());
                    intent.putExtra("division_id", divison_id);
                    intent.putExtra("district_name", district_name);
                    intent.putExtra("district_id",district_id);
                    intent.putExtra("taluka_name", taluka_name);
                    intent.putExtra("taluka_id",taluka_id);
                    intent.putExtra("circle_id",circle_id);
                    intent.putExtra("sajja_name", sajja_name);
                    intent.putExtra("sajja_id",sajja_id);
                    intent.putExtra("season_name", season_name);
                    intent.putExtra("season_id",season_id);
                    intent.putExtra("crop_type_id",crop_type_id);
                    intent.putExtra("horti_type_id",horti_crop_id);
                    startActivity(intent);
                }
            }
        });
    }

    private void add_affected_array(int village_id,String village_name,int crop_id,String crop_name,String affected_area, String type){

        JSONObject affectedjson = new JSONObject();
        try {
            affectedjson.put("village_id",village_id);
            affectedjson.put("village_name",village_name);
            affectedjson.put("afftedcrop", crop_id);
            affectedjson.put("crop_name", crop_name);
            affectedjson.put("affectedArea", affected_area);
            affectedjson.put("type", type);

            isCropPresent = false;

            for (int i = 0; i < affectedjsonarray.length(); i++) {
                JSONObject multiple_data_json_object = affectedjsonarray.getJSONObject(i);
                crop_id_stored = Integer.parseInt(multiple_data_json_object.getString("afftedcrop"));
                village_id_stored = Integer.parseInt(multiple_data_json_object.getString("village_id"));
                String crop_name_stored = multiple_data_json_object.getString("crop_name");
                String crop_type = multiple_data_json_object.getString("type");

                String Crop_name = primary_report_other_crop_edt.getText().toString().trim();

                if(crop_type.equalsIgnoreCase("LIST")){
                    if (village_id_stored == selected_village_id && crop_id_stored == selected_crop_id) {
                        isCropPresent = true;
                        break;
                    }
                }else if(crop_type.equalsIgnoreCase("OTHER")){
                    if (village_id_stored == selected_village_id && crop_name_stored.equalsIgnoreCase(Crop_name)) {
                        isCropPresent = true;
                        break;
                    }
                }


            }
            if(isCropPresent!=true){
                affectedjsonarray.put(affectedjson);
            }else{
                Toast.makeText(PrimaryReportActivity.this, "Selected crop is already added in this village", Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(affectedjsonarray.length()>0) {
            primary_report_add_more_rv.setLayoutManager(new LinearLayoutManager(PrimaryReportActivity.this));
            addMoreAdapter = new AddMoreAdapter(preferenceManager, affectedjsonarray, PrimaryReportActivity.this);
            primary_report_add_more_rv.setAdapter(addMoreAdapter);
            addMoreAdapter.notifyDataSetChanged();
            Crop_Season_Service(season_id,crop_type_id,horti_crop_id);
            sp_crop_name.setText("Select");
            Total_affected_area_primary_report_edt.setText("");
            primary_report_other_crop_ll.setVisibility(View.GONE);
            primary_report_other_crop_edt.setText("");

        } else{
            final Toast toast = Toast.makeText(PrimaryReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);
        }

    }


    private void get_district_taluka(){
        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Seasons_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("panchnama_scheme_id", "");
            param.put("primary_report_id", "3");
        } catch (Exception e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void Crop_type_service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("season_id", "");
            param.put("primary_crop_id", "3");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropType(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Horti_crop_type_service(int crop_type_id){
        JSONObject param = new JSONObject();
        try {
            param.put("id",crop_type_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_crop_type_sown_sublist(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void Crop_Season_Service(int season_id,int crop_type_id,int horti_crop_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id", season_id);
            param.put("crop_type", crop_type_id);
            param.put("horti_crop_type_id", horti_crop_id);
            param.put("primary_report_id","3");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id","0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void getSajjaLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ASSIGNED_VILLAGE_BASE_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assignedLocationUrl(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);

    }

    private void village_web_service() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            District_List = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= District_List.length(); j++) {
                                JSONObject district_json_object = District_List.getJSONObject(j);
                                district_name = district_json_object.getString("district_name");
                                taluka_name = district_json_object.getString("taluka_name");
                                district_id_str = district_json_object.getString("district_id");
                                taluka_id_str = district_json_object.getString("taluka_id");

                                divison_id_str = district_json_object.getString("division_id");
                                divison_name = district_json_object.getString("division_name");
                                circle_id_str = district_json_object.getString("circle_id");
                                circle_name = district_json_object.getString("circle_name");
                                sajja_id_str = district_json_object.getString("sajja_id");
                                sajja_name = district_json_object.getString("sajja_name");

                                divison_id = Integer.valueOf(divison_id_str);
                                district_id = Integer.valueOf(district_id_str);
                                taluka_id = Integer.valueOf(taluka_id_str);
                                circle_id = Integer.valueOf(circle_id_str);
                                sajja_id = Integer.valueOf(sajja_id_str);

                                district_primary_report_txtvw.setText(district_name);
                                taluka_primary_report_txtvw.setText(taluka_name);
                                pr_sajja_name_tv.setText(sajja_name);

                                village_web_service();

                            }
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                //seasons
                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            season_list = jsonObject.getJSONArray("data");

                        }
                    }
                }else {

                }

                //crop
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            crop_list = jsonObject.getJSONArray("data");
                        }


                    }/*else {
                        Toast.makeText(PrimaryReportActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();
                    }*/
                }
                //crop type
                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            crop_type_list = jsonObject.getJSONArray("data");
                        }
                    }
                }else {

                }
                //horti type
                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            horti_crop_type_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 7) {

                    try {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                assigned_location_list = jsonObject.getJSONArray("data");
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                if (i == 8) {

                    try {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                village_list = jsonObject.getJSONArray("data");
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 2) {
            season_id = Integer.parseInt(s1);
            sp_season.setText(s);
            crop_type_list = new JSONArray();
            horti_crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            pr_sp_crop_type.setText("Select");
            pr_horti_type_ll.setVisibility(View.GONE);
            primary_report_other_crop_ll.setVisibility(View.GONE);
            primary_report_other_crop_edt.setText("");
            pr_sp_horti_crop_type.setText("Select");
            sp_crop_name.setText("Select");
            Total_affected_area_primary_report_edt.setText("");
        }

        if (i == 4) {
            crop_type_id = Integer.parseInt(s1);
            pr_sp_crop_type.setText(s);
            horti_crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            Crop_Season_Service(season_id,crop_type_id,horti_crop_id);
            pr_sp_horti_crop_type.setText("Select");
            sp_crop_name.setText("Select");
            primary_report_other_crop_ll.setVisibility(View.GONE);
            primary_report_other_crop_edt.setText("");
            Total_affected_area_primary_report_edt.setText("");
            horti_crop_id = 0;

            if(crop_type_id == 45){
                pr_horti_type_ll.setVisibility(View.VISIBLE);
                horti_crop_type_list = new JSONArray();
                crop_list = new JSONArray();
                Horti_crop_type_service(crop_type_id);
                Crop_Season_Service(season_id,crop_type_id,horti_crop_id);
                pr_sp_horti_crop_type.setText("Select");
                sp_crop_name.setText("Select");
                primary_report_other_crop_ll.setVisibility(View.GONE);
                primary_report_other_crop_edt.setText("");
            }else{
                pr_horti_type_ll.setVisibility(View.GONE);
                horti_crop_type_list = new JSONArray();
                crop_list = new JSONArray();
                Crop_Season_Service(season_id,crop_type_id,horti_crop_id);
                sp_crop_name.setText("Select");
                primary_report_other_crop_ll.setVisibility(View.GONE);
                primary_report_other_crop_edt.setText("");
                horti_crop_id = 0;
            }
        }

        if (i == 5) {
            horti_crop_id = Integer.parseInt(s1);
            pr_sp_horti_crop_type.setText(s);
            //horti_crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            Crop_Season_Service(season_id,crop_type_id,horti_crop_id);
            primary_report_other_crop_ll.setVisibility(View.GONE);
            primary_report_other_crop_edt.setText("");
            sp_crop_name.setText("Select");
        }

        if (i == 3) {
            selected_crop_id = Integer.parseInt(s1);
            selected_crop_name = s;
            sp_crop_name.setText(selected_crop_name);
            if(selected_crop_name.equalsIgnoreCase("OTHER")){
                primary_report_other_crop_ll.setVisibility(View.VISIBLE);
            }else {
                primary_report_other_crop_ll.setVisibility(View.GONE);
                primary_report_other_crop_edt.setText("");
            }
            Total_affected_area_primary_report_edt.setText("");
        }

        if (i == 8) {
            selected_village_id = Integer.parseInt(s1);
            village_name = s;
            primary_report_affected_village_tv.setText(village_name);
            sp_season.setText("Select");
            pr_sp_crop_type.setText("Select");
            pr_sp_horti_crop_type.setText("Select");
            sp_crop_name.setText("Select");

            /*primary_report_affected_village_tv.setEnabled(false);
            primary_report_affected_village_iv.setVisibility(View.INVISIBLE);
            primary_report_affected_village_reset_tv.setVisibility(View.VISIBLE);*/
        }
    }
}
