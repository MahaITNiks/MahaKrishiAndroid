package com.maha.agri.dept_cropsap;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSapSurveyDetails extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView cropsap_survey_recyclerView;
    private String village_name = "", farmer_name = "",village_id_str="";
    private int farmer_id = 0,district_id = 0,taluka_id=0,village_id =0;
    private JSONArray crop_data_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap_survey_details);

        getSupportActionBar().setTitle("Crop Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        village_id = intent.getIntExtra("village_id",0);
        village_id_str = String.valueOf(village_id);
        village_name = intent.getStringExtra("village_name");
        farmer_name = intent.getStringExtra("farmer_name");
        farmer_id = intent.getIntExtra("farmer_id", 0);
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        crop_survey_based_on_farmer();
        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        cropsap_survey_recyclerView = (RecyclerView) findViewById(R.id.cropsap_survey_recyclerView);
        crop_data_list = new JSONArray();
    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setElevation(0);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        GridLayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        cropsap_survey_recyclerView.setLayoutManager(mLayoutManager);
        cropsap_survey_recyclerView.setHasFixedSize(true);
        cropsap_survey_recyclerView.setItemAnimator(new DefaultItemAnimator());

        cropsap_survey_recyclerView.addOnItemTouchListener(new CropSapSurveyDetailsAdapter.RecyclerTouchListener(CropSapSurveyDetails.this, cropsap_survey_recyclerView, new CropSapSurveyDetailsAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                        Intent intent = new Intent(CropSapSurveyDetails.this, CropSapGeneralObsActivity.class);
                        intent.putExtra("crop_data_list",crop_data_list.toString());
                        intent.putExtra("type","survey_crops");
                        intent.putExtra("village_id",village_id_str);
                        intent.putExtra("farmer_id",farmer_id);
                        intent.putExtra("district_id",district_id);
                        intent.putExtra("taluka_id",taluka_id);
                        intent.putExtra("selected_pos",position);
                        startActivity(intent);
            }
            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            /*case R.id.add:
                Intent intent = new Intent(CropSapSurveyDetails.this,CropSapActivityNew.class);
                startActivity(intent);
                return true;*/
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void crop_survey_based_on_farmer() {
        JSONObject param = new JSONObject();
        try {
            param.put("village_id", village_id);
            param.put("farmer_id", farmer_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_get_farmer_crop_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            crop_data_list = jsonObject.getJSONArray("data");
                            CropSapSurveyDetailsAdapter cropSapSurveyDetailsAdapter = new CropSapSurveyDetailsAdapter( this, crop_data_list);
                            cropsap_survey_recyclerView.setAdapter(cropSapSurveyDetailsAdapter);
                        }
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    /*@Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

        Intent intent = new Intent(this, CropSapGeneralObsActivity.class);
        intent.putExtra("crop_data_list",crop_data_list.toString());
        intent.putExtra("village_id",village_id);
        intent.putExtra("farmer_id",farmer_id);
        intent.putExtra("selected_pos",i);
        startActivity(intent);

    }*/
}
