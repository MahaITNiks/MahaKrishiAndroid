package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerMechanizationActivity extends AppCompatActivity implements ApiCallbackCode {
    private EditText farmer_mech_scheme_name,farmer_mech_firstname_beneficiaryname,farmer_mech_middle_beneficiaryname,
            farmer_mech_last_beneficiaryname,farmer_mech_taluka,farmer_mech_district,farmer_mech_village,farmer_mech_mobileno,farmer_mech_chetranusar,
            farmer_mech_samajik,farmer_mech_aadharcard,farmer_mech_technicalname_bilanusar,farmer_mech_manufacturer_bilanusar,farmer_mech_toolseller_bilanusar,
            farmer_mech_modelno_lotno_bilanusar,farmer_mech_modelno_hp_bilanusar,farmer_mech_modelno_bilanusar,farmer_mech_modelno_pratyashat,
            farmer_mech_tractorhp_bilanusar,farmer_mech_table_no,farmer_mech_table_toolrealname,farmer_mech_table_billverf,farmer_mech_table_billno,
            farmer_mech_table_date,farmer_mech_table_GSTbill,farmer_mech_makeno_bilanusar,farmer_mech_makeno_pratyashat,farmer_mech_engineno_bilanusar,
            farmer_mech_engineno_pratyashat,farmer_mech_chasisno_bilanusar,farmer_mech_chasisno_pratyashat,farmer_mech_billno,farmer_mech_billamt,
            farmer_mech_parivahan_regno,farmer_mech_officername,farmer_mech_post;

    private TextView farmer_mech_observationdate,farmer_mech_tool_arrivaldate_bilanusar,farmer_mech_purchasedate_pratyashat,farm_mech_pre_letter,
            farm_mech_bill_doc,farmer_mech_billdate,farmer_mech_parivahan_regdate,farmer_mech_purchasedate_bilanusar,farmer_mech_tool_arrivaldate_pratyashat;

    private EditText farmer_mech_technicalname_pratyashat,farmer_mech_manufacturer_pratyashat,farmer_mech_toolseller_pratyashat,
            farmer_mech_modelno_lotno_pratyashat,farmer_mech_modelno_hp_pratyashat,farmer_mech_tractorhp_pratyashat,farmer_mech_table_giventotalrs,
            farmer_mech_finalpayment;

    private ImageView farmer_mech1ImageView,farmer_mech2ImageView,farmer_mech_purchasecalendarP,farmer_mech_arrivalcalendarB,farmer_mech_billdateiv,
            farmer_mech_purchasecalendarB,farmer_mech_regdateiv,farmer_mech_arrivalcalendarP;

    private RadioGroup farmer_mech_bab_rg,farmer_mech_paymewntbyfarmer_radio_group,farmer_mech_trialno_printed_radio_group,farmer_mech_verification_radio_group,
            farmer_mech_electronic_rg,farmer_mech_parivahan_rg;
    private RadioButton hiddenyes,hiddenno,yes1_radio_btn,no1_radio_btn,yes2_radio_btn,no2_radio_btn,yes_farmer_mech_electronic_rb,no_farmer_mech_electronic_rb,
            yes_farmer_mech_bab,no_farmer_mech_bab,other_farmer_mech_electronic_rb,yes_parivahan,no_parivahan;
    private LinearLayout hiddenll,parivahan_yes_ll,parivahan_no_ll;

    private Button submit;
    private int district_id,taluka_id,village_id,farmer_id;
    private int mYear, mMonth, mDay;
    private DatePickerDialog farmerdatePickerDialog,purchasePdialog,arrivalBdialog,billdateDialog,parivahanDateDialog,purchaseBdialog,arrivalPdialog;

    private String payment,trailno,verify,type,imageid_1,imageid_2,farmer_mech_date,purchaseP_date,arrivalB_date,electronic="",bab="",billdate="0",parivahan="",
            parivahan_date="0",purchaseB_date,arrivalP_date;

    private PreferenceManager preferenceManager;
    SharedPref sharedPref;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    static final Integer CAMERA = 0x5;
    String imagePath,currentTime;
    private Transformation transformation;

    private AppLocationManager locationManager;
    public double lat,lang;
    private String farmer_details = "";
    private int position = 0;
    private JSONArray farmer_details_list;
    String file_url1 = "",file_url2 = "",scheme_title_id= "";
    String application_no = "", scheme_name = "",  first_name = "", middle_name = "", last_name = "", add_district = "", add_taluka = "", add_village = "", farmer_mobile_number = "", khsetra_nusar = "", samajik_nushar = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_mechanization);

        getSupportActionBar().setTitle("Farmer Mechanization Form");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(FarmerMechanizationActivity.this);
        sharedPref = new SharedPref(FarmerMechanizationActivity.this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        scheme_title_id = intent.getStringExtra("scheme_title_id");
        //farmer_id = intent.getIntExtra("farmer_id",0);
        try {
            farmer_details = intent.getStringExtra("farmer_details");
            position = intent.getIntExtra("position",0);
            farmer_details_list = new JSONArray(farmer_details);
            JSONObject farmer_details_json_object = farmer_details_list.getJSONObject(position);
            application_no = farmer_details_json_object.getString("ApplicationNo");
            first_name = farmer_details_json_object.getString("FirstName");
            middle_name = farmer_details_json_object.getString("MiddleName");
            last_name = farmer_details_json_object.getString("LastName");
            farmer_mobile_number = farmer_details_json_object.getString("MobileNo");
            add_district = farmer_details_json_object.getString("AddrDistrict");
            add_taluka = farmer_details_json_object.getString("AddrTaluka");
            add_village = farmer_details_json_object.getString("AddrVillage");

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ids();
        initializations();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void ids(){
        farmer_mech_observationdate = (TextView) findViewById(R.id.farmer_mech_observationdate);
        farmer_mech_billdate = (TextView) findViewById(R.id.farmer_mech_billdate);
        farm_mech_bill_doc = (TextView) findViewById(R.id.farm_mech_bill_doc);
        farmer_mech_parivahan_regdate = (TextView) findViewById(R.id.farmer_mech_parivahan_regdate);
        farm_mech_pre_letter = (TextView) findViewById(R.id.farm_mech_pre_letter);
        farmer_mech_scheme_name = (EditText) findViewById(R.id.farmer_mech_scheme_name);
        farmer_mech_firstname_beneficiaryname = (EditText) findViewById(R.id.farmer_mech_firstname_beneficiaryname);
        farmer_mech_middle_beneficiaryname = (EditText) findViewById(R.id.farmer_mech_middle_beneficiaryname);
        farmer_mech_last_beneficiaryname = (EditText) findViewById(R.id.farmer_mech_last_beneficiaryname);
        farmer_mech_taluka = (EditText) findViewById(R.id.farmer_mech_taluka);
        farmer_mech_district = (EditText) findViewById(R.id.farmer_mech_district);
        farmer_mech_village = (EditText) findViewById(R.id.farmer_mech_village);
        farmer_mech_mobileno = (EditText) findViewById(R.id.farmer_mech_mobileno);
        farmer_mech_chetranusar = (EditText) findViewById(R.id.farmer_mech_chetranusar);
        farmer_mech_samajik = (EditText) findViewById(R.id.farmer_mech_samajik);
        //farmer_mech_aadharcard = (EditText) findViewById(R.id.farmer_mech_aadharcard);
        farmer_mech_technicalname_bilanusar = (EditText) findViewById(R.id.farmer_mech_technicalname_bilanusar);
        farmer_mech_manufacturer_bilanusar = (EditText) findViewById(R.id.farmer_mech_manufacturer_bilanusar);
        farmer_mech_toolseller_bilanusar = (EditText) findViewById(R.id.farmer_mech_toolseller_bilanusar);
        farmer_mech_modelno_bilanusar = (EditText) findViewById(R.id.farmer_mech_modelno_bilanusar);
        farmer_mech_modelno_pratyashat = (EditText) findViewById(R.id.farmer_mech_modelno_pratyashat);
        farmer_mech_makeno_pratyashat = (EditText) findViewById(R.id.farmer_mech_makeno_pratyashat);
        farmer_mech_makeno_bilanusar = (EditText) findViewById(R.id.farmer_mech_makeno_bilanusar);
        farmer_mech_modelno_lotno_bilanusar = (EditText) findViewById(R.id.farmer_mech_modelno_lotno_bilanusar);
        farmer_mech_modelno_hp_bilanusar = (EditText) findViewById(R.id.farmer_mech_modelno_hp_bilanusar);
        farmer_mech_purchasedate_bilanusar = (TextView) findViewById(R.id.farmer_mech_purchasedate_bilanusar);
        farmer_mech_tool_arrivaldate_bilanusar = (TextView) findViewById(R.id.farmer_mech_tool_arrivaldate_bilanusar);
        farmer_mech_tractorhp_bilanusar = (EditText) findViewById(R.id.farmer_mech_tractorhp_bilanusar);
        farmer_mech_engineno_bilanusar = (EditText) findViewById(R.id.farmer_mech_engineno_bilanusar);
        farmer_mech_engineno_pratyashat = (EditText) findViewById(R.id.farmer_mech_engineno_pratyashat);
        farmer_mech_chasisno_bilanusar = (EditText) findViewById(R.id.farmer_mech_chasisno_bilanusar);
        farmer_mech_chasisno_pratyashat = (EditText) findViewById(R.id.farmer_mech_chasisno_pratyashat);
       /* farmer_mech_table_no = (TextView) findViewById(R.id.farmer_mech_table_no);
        farmer_mech_table_toolrealname = (TextView) findViewById(R.id.farmer_mech_table_toolrealname);
        farmer_mech_table_billverf = (TextView) findViewById(R.id.farmer_mech_table_billverf);
        farmer_mech_table_billno = (TextView) findViewById(R.id.farmer_mech_table_billno);
        farmer_mech_table_date = (TextView) findViewById(R.id.farmer_mech_table_date);
        farmer_mech_table_GSTbill = (TextView) findViewById(R.id.farmer_mech_table_GSTbill);*/
        farmer_mech_technicalname_pratyashat = (EditText) findViewById(R.id.farmer_mech_technicalname_pratyashat);
        farmer_mech_manufacturer_pratyashat = (EditText) findViewById(R.id.farmer_mech_manufacturer_pratyashat);
        farmer_mech_toolseller_pratyashat = (EditText) findViewById(R.id.farmer_mech_toolseller_pratyashat);
        farmer_mech_modelno_lotno_pratyashat = (EditText) findViewById(R.id.farmer_mech_modelno_lotno_pratyashat);
        farmer_mech_modelno_hp_pratyashat = (EditText) findViewById(R.id.farmer_mech_modelno_hp_pratyashat);
        farmer_mech_purchasedate_pratyashat = (TextView) findViewById(R.id.farmer_mech_purchasedate_pratyashat);
        farmer_mech_tool_arrivaldate_pratyashat = (TextView) findViewById(R.id.farmer_mech_tool_arrivaldate_pratyashat);
        farmer_mech_tractorhp_pratyashat = (EditText) findViewById(R.id.farmer_mech_tractorhp_pratyashat);
        farmer_mech_table_giventotalrs = (EditText) findViewById(R.id.farmer_mech_table_giventotalrs);
        farmer_mech_finalpayment = (EditText) findViewById(R.id.farmer_mech_finalpayment);
        farmer_mech_billamt = (EditText) findViewById(R.id.farmer_mech_billamt);
        farmer_mech_billno = (EditText) findViewById(R.id.farmer_mech_billno);
        farmer_mech_parivahan_regno = (EditText) findViewById(R.id.farmer_mech_parivahan_regno);
        farmer_mech_officername = (EditText) findViewById(R.id.farmer_mech_officername);
        farmer_mech_post = (EditText) findViewById(R.id.farmer_mech_post);

        farmer_mech1ImageView = (ImageView) findViewById(R.id.farmer_mech1ImageView);
        farmer_mech2ImageView = (ImageView) findViewById(R.id.farmer_mech2ImageView);
        //farmer_mech_calendar = (ImageView) findViewById(R.id.farmer_mech_calendar);
        farmer_mech_purchasecalendarB = (ImageView) findViewById(R.id.farmer_mech_purchasecalendarB);
        farmer_mech_purchasecalendarP = (ImageView) findViewById(R.id.farmer_mech_purchasecalendarP);
        farmer_mech_arrivalcalendarB = (ImageView) findViewById(R.id.farmer_mech_arrivalcalendarB);
        farmer_mech_arrivalcalendarP = (ImageView) findViewById(R.id.farmer_mech_arrivalcalendarP);
        farmer_mech_billdateiv = (ImageView) findViewById(R.id.farmer_mech_billdateiv);
        farmer_mech_regdateiv = (ImageView) findViewById(R.id.farmer_mech_regdateiv);

        farmer_mech_bab_rg = (RadioGroup) findViewById(R.id.farmer_mech_bab_rg);
        farmer_mech_paymewntbyfarmer_radio_group = (RadioGroup) findViewById(R.id.farmer_mech_paymewntbyfarmer_radio_group);
        farmer_mech_trialno_printed_radio_group = (RadioGroup) findViewById(R.id.farmer_mech_trialno_printed_radio_group);
        farmer_mech_verification_radio_group = (RadioGroup) findViewById(R.id.farmer_mech_verification_radio_group);
        farmer_mech_electronic_rg = (RadioGroup) findViewById(R.id.farmer_mech_electronic_rg);
        farmer_mech_parivahan_rg = (RadioGroup) findViewById(R.id.farmer_mech_parivahan_rg);

        yes_farmer_mech_bab = (RadioButton) findViewById(R.id.yes_farmer_mech_bab);
        no_farmer_mech_bab = (RadioButton) findViewById(R.id.no_farmer_mech_bab);
        hiddenyes = (RadioButton) findViewById(R.id.yes_radio_btn);
        hiddenno = (RadioButton) findViewById(R.id.no_radio_btn);
        yes1_radio_btn = (RadioButton) findViewById(R.id.yes1_radio_btn);
        no1_radio_btn = (RadioButton) findViewById(R.id.no1_radio_btn);
        yes2_radio_btn = (RadioButton) findViewById(R.id.yes2_radio_btn);
        no2_radio_btn = (RadioButton) findViewById(R.id.no2_radio_btn);
        yes_farmer_mech_electronic_rb = (RadioButton) findViewById(R.id.yes_farmer_mech_electronic_rb);
        no_farmer_mech_electronic_rb = (RadioButton) findViewById(R.id.no_farmer_mech_electronic_rb);
        other_farmer_mech_electronic_rb = (RadioButton) findViewById(R.id.other_farmer_mech_electronic_rb);
        yes_parivahan = (RadioButton) findViewById(R.id.yes_parivahan);
        no_parivahan = (RadioButton) findViewById(R.id.no_parivahan);

        hiddenll = (LinearLayout) findViewById(R.id.hiddenll);
        parivahan_yes_ll = (LinearLayout) findViewById(R.id.parivahan_yes_ll);
        parivahan_no_ll = (LinearLayout) findViewById(R.id.parivahan_no_ll);
        submit = (Button) findViewById(R.id.farmer_mech_submitBtn);

        farmer_mech_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        farmer_mech_observationdate.setText(farmer_mech_date);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
        locationManager = new AppLocationManager(this);

        farmer_mech_firstname_beneficiaryname.setText(first_name);
        farmer_mech_middle_beneficiaryname.setText(middle_name);
        farmer_mech_last_beneficiaryname.setText(last_name);
        farmer_mech_mobileno.setText(farmer_mobile_number);
        farmer_mech_district.setText(add_district);
        farmer_mech_taluka.setText(add_taluka);
        farmer_mech_village.setText(add_village);

    }


    private void initializations() {

        /*farmer_mech_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                farmer_mech_date_Picker();
            }
        });*/

        farmer_mech_purchasecalendarB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                purchaseB_date_picker();
            }
        });

        farmer_mech_purchasecalendarP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                purchaseP_date_picker();
            }
        });

        farmer_mech_arrivalcalendarB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrivalB_date_picker();
            }
        });

        farmer_mech_arrivalcalendarP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrivalP_date_picker();
            }
        });

        farmer_mech_billdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                billdate_date_picker();
            }
        });

        farmer_mech_regdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regdate_date_picker();
            }
        });

        farmer_mech_bab_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes_farmer_mech_bab:
                        yes_farmer_mech_bab.setChecked(true);
                        bab = "1";
                        break;

                    case R.id.no_farmer_mech_bab:
                        no_farmer_mech_bab.setChecked(true);
                        bab = "0";
                        break;

                }
            }
        });

        farmer_mech_paymewntbyfarmer_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes_radio_btn:
                        hiddenyes.setChecked(true);
                        hiddenll.setVisibility(View.VISIBLE);
                        payment = "1";
                        break;

                    case R.id.no_radio_btn:
                        hiddenno.setChecked(true);
                        hiddenll.setVisibility(View.GONE);
                        electronic = "";
                        payment = "0";
                        break;

                }
            }
        });

        farmer_mech_electronic_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes_farmer_mech_electronic_rb:
                        yes_farmer_mech_electronic_rb.setChecked(true);
                        electronic = "1";
                        break;

                    case R.id.no_farmer_mech_electronic_rb:
                        no_farmer_mech_electronic_rb.setChecked(true);
                        electronic = "0";
                        break;

                    case R.id.other_farmer_mech_electronic_rb:
                        other_farmer_mech_electronic_rb.setChecked(true);
                        electronic = "2";
                        break;

                }
            }
        });

        farmer_mech_trialno_printed_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes1_radio_btn:
                        yes1_radio_btn.setChecked(true);
                        trailno = "1";
                        break;

                    case R.id.no1_radio_btn:
                        no1_radio_btn.setChecked(true);
                        trailno = "0";
                        break;

                }
            }
        });

        farmer_mech_verification_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes2_radio_btn:
                        yes2_radio_btn.setChecked(true);
                        verify = "1";
                        break;

                    case R.id.no2_radio_btn:
                        no2_radio_btn.setChecked(true);
                        verify = "0";
                        break;

                }
            }
        });

        farmer_mech_parivahan_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.yes_parivahan:
                        yes_parivahan.setChecked(true);
                        parivahan_yes_ll.setVisibility(View.VISIBLE);
                        parivahan_no_ll.setVisibility(View.GONE);
                        parivahan_date = "0";
                        farmer_mech_parivahan_regdate.setText("dd/mm/yyyy");
                        parivahan = "1";
                        break;

                    case R.id.no_parivahan:
                        no_parivahan.setChecked(true);
                        parivahan_yes_ll.setVisibility(View.GONE);
                        parivahan_no_ll.setVisibility(View.VISIBLE);
                        farmer_mech_parivahan_regno.setText("");
                        parivahan = "0";
                        break;

                }
            }
        });

        farmer_mech1ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){

                    type ="1";
                    takeImage1FromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }

        });

        farmer_mech2ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerMechanizationActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){

                    type="2";
                    takeImage2FromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }

        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                farmermechsave();
                //uploadImage2OnServer(imagePath);
                //uploadImage1OnServer(imagePath);
            }
        });

    }

    private void farmer_mech_date_Picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        farmerdatePickerDialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        farmer_mech_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_observationdate.setText(farmer_mech_date);


                    }
                }, mYear, mMonth, mDay);

        farmerdatePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());

        farmerdatePickerDialog.show();
    }

    private void purchaseB_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        purchaseBdialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        purchaseB_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_purchasedate_bilanusar.setText(purchaseB_date);


                    }
                }, mYear, mMonth, mDay);

        purchaseBdialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        purchaseBdialog.show();
    }

    private void purchaseP_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        purchasePdialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        purchaseP_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_purchasedate_pratyashat.setText(purchaseP_date);
                    }
                }, mYear, mMonth, mDay);

        purchasePdialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        purchasePdialog.show();
    }

    private void arrivalB_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        arrivalBdialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        arrivalB_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_tool_arrivaldate_bilanusar.setText(arrivalB_date);


                    }
                }, mYear, mMonth, mDay);

        arrivalBdialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        arrivalBdialog.show();
    }

    private void billdate_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        billdateDialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        billdate = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_billdate.setText(billdate);


                    }
                }, mYear, mMonth, mDay);

        billdateDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        billdateDialog.show();
    }

    private void arrivalP_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        arrivalPdialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        arrivalP_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_tool_arrivaldate_pratyashat.setText(arrivalP_date);


                    }
                }, mYear, mMonth, mDay);

        arrivalPdialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        arrivalPdialog.show();
    }

    private void regdate_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        parivahanDateDialog = new DatePickerDialog(FarmerMechanizationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        parivahan_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_mech_parivahan_regdate.setText(parivahan_date);


                    }
                }, mYear, mMonth, mDay);

        parivahanDateDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        parivahanDateDialog.show();
    }

    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage2FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
            } else {
                photoURI = Uri.fromFile(photoFile2);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmer_mech1ImageView.getWidth(), farmer_mech1ImageView.getHeight())
                                    .centerCrop()
                                    .into(farmer_mech1ImageView);
                            uploadImage1OnServer(imagePath);

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {

        }

        if(photoFile2 != null){

            if (type.equalsIgnoreCase("2")){

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmer_mech2ImageView.getWidth(), farmer_mech2ImageView.getHeight())
                                    .centerCrop()
                                    .into(farmer_mech2ImageView);
                            uploadImage2OnServer(imagePath);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else{
            //Toast.makeText(D_F_AttendanceSheetForm.this, "Please click photo", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadImage1OnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("farmer_id", String.valueOf(farmer_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("image_id","1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mechanism_save_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImage2OnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("farmer_id", String.valueOf(farmer_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("image_id","2");

            File file = new File(photoFile2.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mechanism_save_image(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void farmermechsave(){

        String technical_nameP = farmer_mech_technicalname_pratyashat.getText().toString();
        String manufacturer_nameP = farmer_mech_manufacturer_pratyashat.getText().toString();
        String seller_nameP = farmer_mech_toolseller_pratyashat.getText().toString();
        String modelnoP = farmer_mech_modelno_pratyashat.getText().toString();
        String makenoP = farmer_mech_makeno_pratyashat.getText().toString();
        String modelno_lotnoP = farmer_mech_modelno_lotno_pratyashat.getText().toString();
        String modelno_hpP = farmer_mech_modelno_hp_pratyashat.getText().toString();
        String enginenoP = farmer_mech_engineno_pratyashat.getText().toString();
        String chasisnoP = farmer_mech_chasisno_pratyashat.getText().toString();
        String purchase_dateP = farmer_mech_purchasedate_pratyashat.getText().toString();
        String arrival_dateP = farmer_mech_tool_arrivaldate_pratyashat.getText().toString();
        String tractorhpP = farmer_mech_tractorhp_pratyashat.getText().toString();
        String finalpayment = farmer_mech_finalpayment.getText().toString();
        String billno = farmer_mech_billno.getText().toString();
        String billamt = farmer_mech_billamt.getText().toString();
        String officer_name = farmer_mech_officername.getText().toString();
        String officer_post = farmer_mech_post.getText().toString();

        if(technical_nameP.isEmpty()){
            UIToastMessage.show(this,"Please enter यंत्र/ औजाराचे तांत्रिक नाव");
        }
        else if(manufacturer_nameP.isEmpty()){
            UIToastMessage.show(this,"Please enter यंत्र/ औजाराचे उत्पादक कंपनीचे नाव");
        }
        else if(seller_nameP.isEmpty()){
            UIToastMessage.show(this,"Please enter यंत्र/ औजाराचे पुरवठादाराचे/ विक्रेत्याचे नाव");
        }
        /*else if(modelnoP.isEmpty()){
            UIToastMessage.show(this,"Please enter मॉडेल क्रमांक");
        }
        else if(makenoP.isEmpty()){
            UIToastMessage.show(this,"Please enter मेक क्रमांक");
        }
        else if(modelno_lotnoP.isEmpty()){
            UIToastMessage.show(this,"Please enter लॉट क्रमांक");
        }
        else if(modelno_hpP.isEmpty()){
            UIToastMessage.show(this,"Please enter यंत्र/ औजाराचे एच.पी.");
        }*/
        /*else if(enginenoP.isEmpty()){
            UIToastMessage.show(this,"Please enter इंजिने क्रमांक");
        }
        else if(chasisnoP.isEmpty()){
            UIToastMessage.show(this,"Please enter चेसिस क्रमांक");
        }*/
        else if(purchase_dateP.isEmpty()){
            UIToastMessage.show(this,"Please select यंत्र/ औजारे खरेदी दिनांक");
        }
        else if(arrival_dateP.isEmpty()){
            UIToastMessage.show(this,"Please select यंत्र/ औजारे प्रत्यक्ष प्राप्त दिनांक");
        }
        else if(billno.isEmpty()){
            UIToastMessage.show(this,"Please enter बिल क्रमांक");
        }
        else if(billdate.equalsIgnoreCase("0")){
            UIToastMessage.show(this,"Please select बिल दिनांक");
        }
        else if(billamt.isEmpty()){
            UIToastMessage.show(this,"Please enter बिलानुसार खरेदीची रक्कम");
        }
        /*else if(parivahan.equalsIgnoreCase("")){
            UIToastMessage.show(this,"Please select यंत्र /औजाराची परिवहन विभागाकडे नोंदणी करण्यात आली आहे काय?");
        }*/
        else if(finalpayment.isEmpty()){
            UIToastMessage.show(this,"Please enter amount of subsidies given");
        }
        else if(officer_name.isEmpty()){
            UIToastMessage.show(this,"Please enter तपासणी अधिकारी नाव");
        }
        else if(officer_post.isEmpty()){
            UIToastMessage.show(this,"Please enter पदनाम");
        }
        else if(photoFile1 == null){
            UIToastMessage.show(this,"Please click first photo");
        }
        else if(photoFile2 == null){
            UIToastMessage.show(this,"Please click second photo");
        }else {

            JSONObject param = new JSONObject();

            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("application_no", application_no);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("obs_date", farmer_mech_date);
                param.put("scheme_name", "SMAM");
                param.put("ben_first_name", farmer_mech_firstname_beneficiaryname.getText().toString().trim());
                param.put("ben_middle_name", farmer_mech_middle_beneficiaryname.getText().toString().trim());
                param.put("ben_last_name", farmer_mech_last_beneficiaryname.getText().toString().trim());
                param.put("district", farmer_mech_district.getText().toString().trim());
                param.put("taluka", farmer_mech_taluka.getText().toString().trim());
                param.put("village", farmer_mech_village.getText().toString().trim());
                param.put("mobile_no", farmer_mech_mobileno.getText().toString().trim());
                param.put("area_wise", farmer_mech_chetranusar.getText().toString().trim());
                param.put("social_category", farmer_mech_samajik.getText().toString().trim());
                param.put("bab", bab);
                param.put("aadhar_card", "");
                param.put("technical_nameB", farmer_mech_technicalname_bilanusar.getText().toString().trim());
                param.put("manufacturer_nameB", farmer_mech_manufacturer_bilanusar.getText().toString().trim());
                param.put("seller_nameB", farmer_mech_toolseller_bilanusar.getText().toString().trim());
                param.put("model_lotnoB", farmer_mech_modelno_lotno_bilanusar.getText().toString().trim());
                param.put("modelnoB", farmer_mech_modelno_bilanusar.getText().toString().trim());
                param.put("makenoB", farmer_mech_makeno_bilanusar.getText().toString().trim());
                param.put("model_hpB", farmer_mech_modelno_hp_bilanusar.getText().toString().trim());
                param.put("enginenoB", farmer_mech_engineno_bilanusar.getText().toString().trim());
                param.put("chasisnoB", farmer_mech_chasisno_bilanusar.getText().toString().trim());
                param.put("purchase_dateB", purchaseB_date);
                param.put("receiving_dateB", arrivalB_date);
                param.put("required_hpB", farmer_mech_tractorhp_bilanusar.getText().toString().trim());
                param.put("technical_nameP", farmer_mech_technicalname_pratyashat.getText().toString().trim());
                param.put("manufacturer_nameP", farmer_mech_manufacturer_pratyashat.getText().toString().trim());
                param.put("seller_nameP", farmer_mech_toolseller_pratyashat.getText().toString().trim());
                param.put("model_lotnoP", farmer_mech_modelno_lotno_pratyashat.getText().toString().trim());
                param.put("modelnoP", farmer_mech_modelno_pratyashat.getText().toString().trim());
                param.put("makenoP", farmer_mech_makeno_pratyashat.getText().toString().trim());
                param.put("model_hpP", farmer_mech_modelno_hp_pratyashat.getText().toString().trim());
                param.put("enginenoP", farmer_mech_engineno_pratyashat.getText().toString().trim());
                param.put("chasisnoP", farmer_mech_chasisno_pratyashat.getText().toString().trim());
                param.put("purchase_dateP", purchaseP_date);
                param.put("receiving_dateP", arrivalP_date);
                param.put("required_hpP", farmer_mech_tractorhp_pratyashat.getText().toString().trim());
                param.put("billno", farmer_mech_billno.getText().toString().trim());
                param.put("billdate", billdate);
                param.put("billamt", farmer_mech_billamt.getText().toString().trim());
                param.put("section_9", payment);
                param.put("payment_method", electronic);
                param.put("section_10", trailno);
                param.put("section_11", verify);
                param.put("parivahan", parivahan);
                param.put("parivahan_regno", farmer_mech_parivahan_regno.getText().toString().trim());
                param.put("parivahan_regdate", parivahan_date);
                param.put("officer_name", officer_name);
                param.put("officer_post", officer_post);
                param.put("given_rs", farmer_mech_finalpayment.getText().toString().trim());
                param.put("image_id1", imageid_1);
                param.put("image_id2", imageid_2);
                param.put("StatusID",6);
                param.put("scheme_title_id",scheme_title_id);

            } catch (Exception e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.mechanism_master_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("Farmer Mechanization")
                                .setContentText(jsonObject.getString("response"))
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        JSONObject datajsonobject = jsonObject.getJSONObject("data");
                        file_url1 = datajsonobject.getString("file_url");
                        imageid_1 = datajsonobject.getString("last_id");
                        //farmer_mech1ImageView.setImageResource(R.drawable.camera);
                    }
                }
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        JSONObject datajsonobject = jsonObject.getJSONObject("data");
                        file_url2 = datajsonobject.getString("file_url");
                        imageid_2 = datajsonobject.getString("last_id");
                        //farmer_mech2ImageView.setImageResource(R.drawable.camera);
                    }
                }

            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}

