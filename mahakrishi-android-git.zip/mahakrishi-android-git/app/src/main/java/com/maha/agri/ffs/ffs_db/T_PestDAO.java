package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface T_PestDAO {

    @Query("SELECT * FROM T_PestEY")
    List<T_PestEY> getAll();

    @Query("DELETE FROM T_PestEY")
    void deleteAll();

    @Query("DELETE FROM T_PestEY WHERE uid = :pestId and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteByPestId(int pestId, int cropping_system, int crop_id);

    @Query("DELETE FROM T_DefenderEY WHERE uid not in(uid = :pestId)  and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteAllDataExceptNoPest(int pestId, int cropping_system, int crop_id);

    @Query("SELECT * FROM T_PestEY WHERE crop_id = :crop_id")
    List<T_PestEY> getCropPest(int crop_id);

    @Query("SELECT * FROM T_PestEY WHERE uid = :id and crop_id = :crop_id")
    List<T_PestEY> checkIdExists(int id, int crop_id);

    @Query("SELECT * FROM T_PestEY WHERE cropping_system = :cropping_system and crop_id = :crop_id")
    List<T_PestEY> getTypePest(int cropping_system, int crop_id);

    @Query("SELECT * FROM T_PestEY WHERE uid IN (:userIds)")
    List<T_PestEY> loadAllByIds(int[] userIds);

    @Insert
    void insertAll(T_PestEY... m_pestEYS);

    @Insert
    void insertOnlySingle(T_PestEY m_pestEY);
}
