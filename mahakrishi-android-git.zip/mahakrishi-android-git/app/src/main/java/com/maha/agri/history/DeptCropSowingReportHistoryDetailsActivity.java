package com.maha.agri.history;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.eftimoff.viewpagertransformers.ForegroundToBackgroundTransformer;
import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DeptCropSowingReportHistoryDetailsActivity extends AppCompatActivity implements ApiCallbackCode {
    ViewPager dept_sowing_report_details_viewpager;
    private JSONArray dept_sowing_report_details_list;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    String village_list, week_number, village_id_str;
    int position = 0,village_id = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dept_crop_sowing_report_history_details);
        getSupportActionBar().setTitle("Crop Sowing Report Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DeptCropSowingReportHistoryDetailsActivity.this);
        sharedPref = new SharedPref(DeptCropSowingReportHistoryDetailsActivity.this);
        IdCalling();

        Intent intent = getIntent();
        week_number = intent.getStringExtra("week_number");
        village_list = intent.getStringExtra("village_list");
        position = intent.getIntExtra("position", 0);

        try {
            JSONArray village_json_array = new JSONArray(village_list);
            JSONObject village_json_object = village_json_array.getJSONObject(position);
            village_id_str = village_json_object.getString("village_id");
            village_id = Integer.valueOf(village_id_str);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (isNetworkAvailable()){
            getdept_village_list_list_details();

        }else {

        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        dept_sowing_report_details_viewpager = (ViewPager) findViewById(R.id.dept_sowing_report_details_viewpager);

    }

    private void getdept_village_list_list_details() {

        JSONObject param = new JSONObject();
        try{
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("village_id",village_id);
            param.put("week_number", week_number);

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_sowing_report_details(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dept_sowing_report_details_list = jsonObject.getJSONArray("data");
                            dept_sowing_report_details_viewpager.setAdapter(new DeptCropSowingReportHistoryDetailsPagerAdapter(preferenceManager,dept_sowing_report_details_list,this));
                            dept_sowing_report_details_viewpager.setPageTransformer(true,new ForegroundToBackgroundTransformer());

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
