package com.maha.agri.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;


public class ResponseModel {

    private boolean is_success;
    private String msg;
    private JSONObject jsonObject;


    public ResponseModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public JSONArray getData() {
        try {
            return this.jsonObject.getJSONArray("data");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isStatus() {
        JSONObject jsonObject = null;
        jsonObject = this.jsonObject;
        if (AppUtility.getInstance().sanitizeJSONObj(jsonObject, "status").equalsIgnoreCase("200")) {
            is_success = true;
        } else {
            is_success = false;
        }

        /*try {
            jsonObject = this.jsonObject.getJSONObject("meta");
            if (AppUtility.getInstance().sanitizeJSONObj(jsonObject, "status").equalsIgnoreCase("200")) {
                is_success = true;
            } else {
                is_success = false;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        return is_success;
    }

    public String getMsg() {
        JSONObject jsonObject = null;
        jsonObject = this.jsonObject;
        msg = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "response");

       /* try {
            jsonObject = this.jsonObject.getJSONObject("meta");
            msg = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "response");

        } catch (JSONException e) {
            e.printStackTrace();
        }*/
        return msg;
    }


}
