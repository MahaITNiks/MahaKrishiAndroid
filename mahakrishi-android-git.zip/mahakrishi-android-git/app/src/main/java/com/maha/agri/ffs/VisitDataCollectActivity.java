package com.maha.agri.ffs;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.maha.agri.R;

public class VisitDataCollectActivity extends AppCompatActivity /*implements OnMultiRecyclerItemClickListener, ApiCallbackCode*/ {


    /*private TextView headerTextView;

    private ImageView addAttendanceImageView;
    private RecyclerView attendanceRecyclerView;
    private TextView attendanceBlankTextView;

    private ImageView addTechImageView;
    private RecyclerView techRecyclerView;
    private TextView techBlankTextView;


    private CardView obsCardView;
    private ImageView addObservationImageView;
    private RecyclerView obsRecyclerView;
    private TextView obsBlankTextView;

    private CardView controlObsCardView;
    private ImageView addControlObservationImageView;
    private RecyclerView controlObsRecyclerView;
    private TextView controlObsBlankTextView;

    private EditText decisionEditText;
    private String plot_name;
    private String village_name;
    private int host_farmer_id;
    private int plot_id;
    private int crop_id;
    private int inter_crop_id;
    private int cropping_system_id = 0;
    private int visit_number;
    private int schedule_id;
    private AppString appString;
    private AppSession session;
    private OnlineOfflineMode onlineOfflineMode;
    private Boolean isObsAllowed = false;
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_data_collect);
        //initComponents();
        //setConfiguration();
    }

//    private void initComponents() {
//
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        if (getSupportActionBar() != null) {
//            getSupportActionBar().setElevation(0);
//            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        }
//
//        headerTextView = findViewById(R.id.headerTextView);
//
//        addAttendanceImageView = findViewById(R.id.addAttendanceImageView);
//        attendanceRecyclerView = findViewById(R.id.attendanceRecyclerView);
//        attendanceBlankTextView = findViewById(R.id.attendanceBlankTextView);
//
//
//        addTechImageView = findViewById(R.id.addTechImageView);
//        techRecyclerView = findViewById(R.id.techRecyclerView);
//        techBlankTextView = findViewById(R.id.techBlankTextView);
//
//
//        obsCardView = findViewById(R.id.obsCardView);
//        addObservationImageView = findViewById(R.id.addObservationImageView);
//        obsRecyclerView = findViewById(R.id.obsRecyclerView);
//        obsBlankTextView = findViewById(R.id.obsBlankTextView);
//
//
//        controlObsCardView = findViewById(R.id.controlObsCardView);
//        addControlObservationImageView = findViewById(R.id.addControlObservationImageView);
//        controlObsRecyclerView = findViewById(R.id.controlObsRecyclerView);
//        controlObsBlankTextView = findViewById(R.id.controlObsBlankTextView);
//
//        decisionEditText = findViewById(R.id.decisionEditText);
//    }
//
//
//    private void setConfiguration() {
//
//        session = new AppSession(this);
//        appString = new AppString(this);
//
//        EventBus.getDefault().register(this);
//
//        visit_number = getIntent().getIntExtra("visit", 0);
//        schedule_id = getIntent().getIntExtra("schedule_id", 0);
//        String visit = appString.getVisit() + " " + visit_number;
//        plot_name = getIntent().getStringExtra("plot_name");
//        village_name = getIntent().getStringExtra("village_name");
//
//        plot_id = getIntent().getIntExtra("plot_id", -1);
//        crop_id = getIntent().getIntExtra("crop_id", -1);
//        inter_crop_id = getIntent().getIntExtra("inter_crop_id", -1);
//
//        cropping_system_id = getIntent().getIntExtra("cropping_system_id", 0);
//
//
//
//
//        // Added on 15 June 2019
//        if (visit_number == 1) {
//            isObsAllowed = false;
//            obsCardView.setVisibility(View.GONE);
//            controlObsCardView.setVisibility(View.GONE);
//        } else {
//            isObsAllowed = true;
//            obsCardView.setVisibility(View.VISIBLE);
//            controlObsCardView.setVisibility(View.VISIBLE);
//        }
//
//
//
//
//        if (getIntent() != null) {
//            onlineOfflineMode = (OnlineOfflineMode) getIntent().getSerializableExtra("OnlineOfflineMode");
//        }
//
//        host_farmer_id = getIntent().getIntExtra("host_farmer_id", -1);
//
//
//        headerTextView.setText(visit);
//
//
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        attendanceRecyclerView.setLayoutManager(layoutManager);
//        attendanceRecyclerView.setHasFixedSize(true);
//        attendanceRecyclerView.setItemAnimator(new DefaultItemAnimator());
//
//
//        LinearLayoutManager layoutManagerTech = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        techRecyclerView.setLayoutManager(layoutManagerTech);
//        techRecyclerView.setHasFixedSize(true);
//        techRecyclerView.setItemAnimator(new DefaultItemAnimator());
//
//
//        LinearLayoutManager layoutManagerObs = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        obsRecyclerView.setLayoutManager(layoutManagerObs);
//        obsRecyclerView.setHasFixedSize(true);
//        obsRecyclerView.setItemAnimator(new DefaultItemAnimator());
//
//
//        LinearLayoutManager layoutManagerControlObs = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        controlObsRecyclerView.setLayoutManager(layoutManagerControlObs);
//        controlObsRecyclerView.setHasFixedSize(true);
//        controlObsRecyclerView.setItemAnimator(new DefaultItemAnimator());
//
//
//        final int finalUpdate_visit = getIntent().getIntExtra("update_visit", 0);
//
//
//
//        addAttendanceImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(VisitDataCollectActivity.this, FFSAttendanceActivity.class);
//
//
//                intent.putExtra("visit_number", visit_number);
//                if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                    intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                } else {
//                    String farmer_name = getIntent().getStringExtra("farmer_name");
//                    String host_farmer_mobile = getIntent().getStringExtra("host_farmer_mobile");
//                    intent.putExtra("farmer_name", farmer_name);
//                    intent.putExtra("host_farmer_mobile", host_farmer_mobile);
//                    intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//
//                }
//                intent.putExtra("update_visit", finalUpdate_visit);
//                startActivity(intent);
//            }
//        });
//
//        addTechImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(VisitDataCollectActivity.this, FFSTechActivity.class);
////                intent.putExtra("visit_number", visit_number);
//                if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                    intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                } else {
//                    intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                }
//                intent.putExtra("update_visit", finalUpdate_visit);
//                startActivity(intent);
//            }
//        });
//
//
//        addObservationImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                String schedule_details = getIntent().getStringExtra("schedule_details");
//
//                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//
//                    int visitNum = session.getVisitNumber();
//                    int majorCropCount = session.getVisitCount();
//                    int interCropCount = session.getInterVisitCropCount();
//
//                    if (( visitNum <= majorCropCount)   &&   (visitNum <= interCropCount)) {
//
//                        Intent intent = new Intent(VisitDataCollectActivity.this, FFSObservationIntercropActivity.class);
//                        intent.putExtra("crop_id", crop_id);
//                        intent.putExtra("inter_crop_id", inter_crop_id);
//                        intent.putExtra("schedule_details", schedule_details);
//                        intent.putExtra("cropping_system_id", cropping_system_id);
//                        if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                            intent.putExtra("PlotType", PlotType.FFS_PLOT);
//                        } else {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                            intent.putExtra("PlotType", PlotType.FFS_PLOT);
//                        }
//                        intent.putExtra("update_visit", finalUpdate_visit);
//                        startActivity(intent);
//
//
//                    } else {
//
//                        Intent intent = new Intent(VisitDataCollectActivity.this, ObservationMajorInterActivity.class);
//                        intent.putExtra("crop_id", crop_id);
//                        intent.putExtra("schedule_details", schedule_details);
//                        intent.putExtra("cropping_system_id", cropping_system_id);
//                        if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                            intent.putExtra("PlotType", PlotType.FFS_PLOT);
//                        } else {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                            intent.putExtra("PlotType", PlotType.FFS_PLOT);
//
//                        }
//                        intent.putExtra("update_visit", finalUpdate_visit);
//                        startActivity(intent);
//                    }
//
//                } else {
//                    Intent intent = new Intent(VisitDataCollectActivity.this, FFSObservationActivity.class);
//                    intent.putExtra("crop_id", crop_id);
//                    intent.putExtra("schedule_details", schedule_details);
//                    if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                        intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                        intent.putExtra("PlotType", PlotType.FFS_PLOT);
//                    } else {
//                        intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                        intent.putExtra("PlotType", PlotType.FFS_PLOT);
//                    }
//                    intent.putExtra("update_visit", finalUpdate_visit);
//                    startActivity(intent);
//                }
//
//            }
//        });
//
//
//        addControlObservationImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                String schedule_details = getIntent().getStringExtra("schedule_details");
//
//                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//
//                    int visitNum = session.getVisitNumber();
//                    int majorCropCount = session.getVisitCount();
//                    int interCropCount = session.getInterVisitCropCount();
//
//                    if (( visitNum <= majorCropCount)   &&   (visitNum <= interCropCount)) {
//
//                        Intent intent = new Intent(VisitDataCollectActivity.this, FFSObservationIntercropActivity.class);
//                        intent.putExtra("crop_id", crop_id);
//                        intent.putExtra("inter_crop_id", inter_crop_id);
//                        intent.putExtra("schedule_details", schedule_details);
//                        intent.putExtra("cropping_system_id", cropping_system_id);
//                        if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                            intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                        } else {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                            intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                        }
//                        intent.putExtra("update_visit", finalUpdate_visit);
//                        startActivity(intent);
//
//
//                    } else {
//
//                        Intent intent = new Intent(VisitDataCollectActivity.this, ObservationMajorInterActivity.class);
//                        intent.putExtra("crop_id", crop_id);
//                        intent.putExtra("schedule_details", schedule_details);
//                        intent.putExtra("cropping_system_id", cropping_system_id);
//                        if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                            intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                        } else {
//                            intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                            intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                        }
//                        intent.putExtra("update_visit", finalUpdate_visit);
//                        startActivity(intent);
//                    }
//
//                } else {
//                    Intent intent = new Intent(VisitDataCollectActivity.this, FFSObservationActivity.class);
//                    intent.putExtra("crop_id", crop_id);
//                    intent.putExtra("schedule_details", schedule_details);
//                    if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                        intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.ONLINE);
//                        intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                    } else {
//                        intent.putExtra("OnlineOfflineMode", OnlineOfflineMode.OFFLINE);
//                        intent.putExtra("PlotType", PlotType.CONTROL_PLOT);
//                    }
//                    intent.putExtra("update_visit", finalUpdate_visit);
//                    startActivity(intent);
//                }
//
//            }
//        });
//
//
//        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                submitRequest();
//            }
//        });
//
//        dataBind();
//
////        DebugLog.getInstance().d("lat " + String.valueOf(appLocationManager.location.getLatitude()));
////        DebugLog.getInstance().d("lang " + String.valueOf(appLocationManager.location.getLongitude()));
//
//
//    }
//
//    @Override
//    public void onBackPressed() {
////        super.onBackPressed();
//    }
//
//    private void dataBind() {
//        try {
//
//            AppSession session = new AppSession(this);
//
//            JSONArray jsonArray = session.getAttendance();
//
//            if (jsonArray.length() > 0) {
//                attendanceRecyclerView.setVisibility(View.VISIBLE);
//                attendanceBlankTextView.setVisibility(View.GONE);
//            } else {
//                attendanceRecyclerView.setVisibility(View.GONE);
//                attendanceBlankTextView.setVisibility(View.VISIBLE);
//            }
//            AttendanceVisitAdapter attendanceVisitAdapter = new AttendanceVisitAdapter(this, plot_name, this, jsonArray);
//            attendanceRecyclerView.setAdapter(attendanceVisitAdapter);
//
//
//            JSONArray jsonArray1 = session.getTechDemo();
//
//            if (jsonArray1.length() > 0) {
//                techRecyclerView.setVisibility(View.VISIBLE);
//                techBlankTextView.setVisibility(View.GONE);
//            } else {
//                techRecyclerView.setVisibility(View.GONE);
//                techBlankTextView.setVisibility(View.VISIBLE);
//            }
//
//            TechDemonstratedAdapter techDemonstratedAdapter = new TechDemonstratedAdapter(this, this, jsonArray1);
//            techRecyclerView.setAdapter(techDemonstratedAdapter);
//
//
//            JSONArray jsonArray2;
//
//            if (cropping_system_id == CroppingSystem.SOLE.id()) {
//                jsonArray2 = session.getObservations();
//            } else {
//                jsonArray2 = session.getObservationsIntercrop();
//            }
//
//
//            if (jsonArray2.length() > 0) {
//                obsRecyclerView.setVisibility(View.VISIBLE);
//                obsBlankTextView.setVisibility(View.GONE);
//            } else {
//                obsRecyclerView.setVisibility(View.GONE);
//                obsBlankTextView.setVisibility(View.VISIBLE);
//            }
//
//            ObservationsAdapter observationsAdapter = new ObservationsAdapter(this, this, jsonArray2);
//            obsRecyclerView.setAdapter(observationsAdapter);
//
//
//            //Control Plot
//            JSONArray jsonArray3;
//
//            if (cropping_system_id == CroppingSystem.SOLE.id()) {
//                jsonArray3 = session.getObservationsControl();
//            } else {
//                jsonArray3 = session.getObservationsIntercropControl();
//            }
//
//
//            if (jsonArray3.length() > 0) {
//                controlObsRecyclerView.setVisibility(View.VISIBLE);
//                controlObsBlankTextView.setVisibility(View.GONE);
//            } else {
//                controlObsRecyclerView.setVisibility(View.GONE);
//                controlObsBlankTextView.setVisibility(View.VISIBLE);
//            }
//
//            ObservationsAdapter observationsAdapterControl = new ObservationsAdapter(this, this, jsonArray3);
//            controlObsRecyclerView.setAdapter(observationsAdapterControl);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
//
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//
//                JSONArray jsonArray = session.getAttendance();
//                JSONArray techjsonArray = session.getTechDemo();
//                JSONArray obsjsonArray = session.getObservations();
//
//                if (jsonArray != null && jsonArray.length() > 0 ) {
//                    showDiscardAlertMessage();
//                } else if (techjsonArray != null && techjsonArray.length() > 0 ) {
//                    showDiscardAlertMessage();
//                } else if (obsjsonArray != null && obsjsonArray.length() > 0 ) {
//                    showDiscardAlertMessage();
//                } else {
//                    finish();
//                }
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }
//
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        EventBus.getDefault().unregister(this);
//    }
//
//
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void onEventFire(EventModel event) {
//
//        if (event != null) {
//
//            DebugLog.getInstance().d("onEventFire=" + event.getEvent());
//
//            //TODO Attendance
//            if (event.getEvent().equalsIgnoreCase("update_1")) {
//
//                dataBind();
//            }
//
//
//            //TODO TECH DEmo
//            if (event.getEvent().equalsIgnoreCase("update_2")) {
//
//                dataBind();
//            }
//
//
//            //TODO Observations
//            if (event.getEvent().equalsIgnoreCase("update_3")) {
//
//                dataBind();
//            }
//
//
//
//
//            //TODO Control Observations
//            if (event.getEvent().equalsIgnoreCase("update_4")) {
//
//                dataBind();
//            }
//
//        }
//    }
//
//    ;
//
//
//    private void submitRequest() {
//        validateDeltaPost();
//    }
//
//
//    @Override
//    public void onMultiRecyclerViewItemClick(int i, Object o) {
//
//    }
//
//
//    private void validateDeltaPost() {
//        try {
//
//
//            String attendance = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getAttendance(), "id");
//            String tech = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getTechDemo(), "id");
//
//            String decision = decisionEditText.getText().toString();
//
//            if (isObsAllowed) {
//                if (attendance.isEmpty()) {
//                    UIToastMessage.show(this, "Please mark attendance");
//
//                } else if (tech.isEmpty()) {
//                    UIToastMessage.show(this, "Please mark technology demonstrated");
//
//                } else if (session.getPostObservations(cropping_system_id).length() == 0) {
//                    UIToastMessage.show(this, "Please take observations");
//
//                } else if (session.getPostObservationsControl(cropping_system_id).length() == 0) {
//                    UIToastMessage.show(this, "Please take control plot observations");
//
//                } else if (decision.isEmpty()) {
//                    UIToastMessage.show(this, "Please enter decision taken by group farmers");
//
//                } else {
//                    showConfirmationAlertMessage(getResources().getString(R.string.visit_post));
//                }
//            } else {
//
//                if (attendance.isEmpty()) {
//                    UIToastMessage.show(this, "Please mark attendance");
//
//                } else if (tech.isEmpty()) {
//                    UIToastMessage.show(this, "Please mark technology demonstrated");
//
//                } else if (decision.isEmpty()) {
//                    UIToastMessage.show(this, "Please enter decision taken by group farmers");
//
//                } else {
//                    showConfirmationAlertMessage(getResources().getString(R.string.visit_post));
//                }
//            }
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    private void postData() {
//        try {
//
//
//            String attendance = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getAttendance(), "id");
//            String tech = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getTechDemo(), "id");
//
//
//            String decision = decisionEditText.getText().toString();
//
//
//            if (attendance.isEmpty()) {
//                UIToastMessage.show(this, getResources().getString(R.string.visit_attendance_err));
//
//            } else if (tech.isEmpty()) {
//                UIToastMessage.show(this, getResources().getString(R.string.visit_tech_err));
//
//            } else if (decision.isEmpty()) {
//                UIToastMessage.show(this, getResources().getString(R.string.visit_decision_err));
//
//            } else {
//
//                DebugLog.getInstance().d("attendance=" + attendance);
//                DebugLog.getInstance().d("tech=" + tech);
//
//
//                final JSONObject jsonObject = new JSONObject();
//
//                jsonObject.put("schedule_id", schedule_id);
//                jsonObject.put("facilitator_id", session.getUserId());
//                jsonObject.put("plot_id", plot_id);
//                jsonObject.put("crop_id", crop_id);
//                jsonObject.put("cropping_system_id", cropping_system_id);
//                jsonObject.put("visit_number", visit_number);
//                jsonObject.put("host_farmer_id", host_farmer_id);
//
//
//                //Offline Guest Farmer Registered
//                jsonObject.put("guest_farmers", session.getAttendance().toString());
////                jsonObject.put("offline_guest_farmers", session.getAttendance().toString());
//
//
//                jsonObject.put("tech_demonstrations", tech);
//
//                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("observations", session.getPostObservationsIntercrop().toString());
//                } else {
//                    jsonObject.put("observations", session.getPostServerObservations(CroppingSystem.SOLE.id()));
//                }
//
////                jsonObject.put("lat", String.valueOf(appLocationManager.getLatitude()));
////                jsonObject.put("lon", String.valueOf(appLocationManager.getLongitude()));
//                jsonObject.put("decision_taken", decision);
//
////                jsonObject.put("file_attendance", session.getAttendanceFileName());
////                jsonObject.put("file_attendance_list", session.getAttendanceListFileName());
//
////                jsonObject.put("file_tech_demo_1", session.getTechDemoFileName1());
////                jsonObject.put("file_tech_demo_2", session.getTechDemoFileName2());
//
////                jsonObject.put("file_observation_1", session.getObsFileName1());
////                jsonObject.put("file_observation_2", session.getObsFileName2());
////                jsonObject.put("file_observation_3", session.getObsFileName3());
////                jsonObject.put("file_observation_4", session.getObsFileName4());
//
////                jsonObject.put("control_file_obs1", session.getObsFileName1Control());
////                jsonObject.put("control_file_obs2", session.getObsFileName2Control());
////                jsonObject.put("control_file_obs3", session.getObsFileName3Control());
////                jsonObject.put("control_file_obs4", session.getObsFileName4Control());
//
//
////                jsonObject.put("latlong_attendance", session.getAttendanceFileLatLon());
////                jsonObject.put("latlong_attendance_list", session.getAttendanceListFileLatLon());
////
////                jsonObject.put("latlong_tech_demo_1", session.getTechDemo1FileLatLon());
////                jsonObject.put("latlong_tech_demo_2", session.getTechDemo2FileLatLon());
////
////                jsonObject.put("latlong_observation_1", session.getObs1FileLatLon());
////                jsonObject.put("latlong_observation_2", session.getObs2FileLatLon());
//
//                /*if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("latlong_observation_3", session.getObs3FileLatLon());
//                    jsonObject.put("latlong_observation_4", session.getObs4FileLatLon());
//
//                } else {
//                    jsonObject.put("latlong_observation_3", "0");
//                    jsonObject.put("latlong_observation_4", "0");
//
//                }*/
//
//                jsonObject.put("date_of_sowing", session.getDateSowing());
//                jsonObject.put("method_of_sowing", session.getMethodSowing());
//                jsonObject.put("crop_variety", session.getCropVariety());
//                jsonObject.put("irrigation_method", session.getIrrigationMethod());
//
//
//                jsonObject.put("control_date_of_sowing", session.getControlDateSowing());
//                jsonObject.put("control_method_of_sowing", session.getControlMethodSowing());
//                jsonObject.put("control_crop_variety", session.getControlCropVariety());
//                jsonObject.put("control_irrigation_method", session.getControlIrrigationMethod());
//
//
////                jsonObject.put("control_latlong_obs1", session.getObs1FileLatLonControl());
////                jsonObject.put("control_latlong_obs2", session.getObs2FileLatLonControl());
//
//                /*if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("control_latlong_obs3", session.getObs3FileLatLonControl());
//                    jsonObject.put("control_latlong_obs4", session.getObs4FileLatLonControl());
//                } else {
//                    jsonObject.put("control_latlong_obs3", "0");
//                    jsonObject.put("control_latlong_obs4", "0");
//                }*/
//
//                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("control_observations", session.getPostObservationsIntercropControl().toString());
//                } else {
//                    jsonObject.put("control_observations", session.getPostServerObservationsControl(CroppingSystem.SOLE.id()));
//                }
//                jsonObject.put("created_at_app", session.getTimeStamp());
//
//                DebugLog.getInstance().d("param=" + jsonObject.toString());
//
//                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
//
//                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
//                Retrofit retrofit = api.getRetrofitInstance();
//                APIRequest apiRequest = retrofit.create(APIRequest.class);
//                Call<JsonObject> responseCall = apiRequest.postVisitsRequest(requestBody);
//
//                DebugLog.getInstance().d("param=" + responseCall.request().toString());
//                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
//
//                api.postRequest(responseCall, this, 1);
//
//
//
//
//
//                   /* final Context mContext = this;
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            FfsDatabase db = AppDelegate.getInstance(mContext).getAppDatabase();
//
//                            OffVisitDataModel model = new OffVisitDataModel(jsonObject);
//
//                            OfflineVisitsEY offlineVisitsEY = new OfflineVisitsEY();
//                            offlineVisitsEY.setFacilitator_id(model.getFacilitator_id());
//                            offlineVisitsEY.setPlot_id(model.getPlot_id());
//                            offlineVisitsEY.setVisit_number(model.getVisit_number());
//                            offlineVisitsEY.setHost_farmer_id(model.getFarmer_id());
//                            offlineVisitsEY.setGuest_farmers(model.getGuest_farmers());
//                            offlineVisitsEY.setTech_demonstrations(model.getTech_demonstrations());
//                            offlineVisitsEY.setObservations(model.getObservations());
//                            offlineVisitsEY.setDecision_taken(model.getDecision_taken());
//                            offlineVisitsEY.setCrop_id(model.getCrop_id());
//                            offlineVisitsEY.setSchedule_id(model.getSchedule_id());
//                            offlineVisitsEY.setCropping_system_id(model.getCropping_system_id());
////                            offlineVisitsEY.setFile_attendance(session.getAttendanceFilePath());
////                            offlineVisitsEY.setFile_attendance_list(session.getAttendanceListFilePath());
////                            offlineVisitsEY.setFile_tech_demo_1(session.getTechDemoFilePATH1());
////                            offlineVisitsEY.setFile_tech_demo_2(session.getTechDemoFilePATH2());
////                            offlineVisitsEY.setFile_observation_1(session.getObsFilePATH1());
////                            offlineVisitsEY.setFile_observation_2(session.getObsFilePATH2());
////                            offlineVisitsEY.setFile_observation_3(session.getObsFilePATH3());
////                            offlineVisitsEY.setFile_observation_4(session.getObsFilePATH4());
////                            offlineVisitsEY.setLatlong_attendance(model.getLatlong_attendance());
////                            offlineVisitsEY.setLatlong_attendance_list(model.getLatlong_attendance_list());
////                            offlineVisitsEY.setLatlong_tech_demo_1(model.getLatlong_tech_demo_1());
////                            offlineVisitsEY.setLatlong_tech_demo_2(model.getLatlong_tech_demo_2());
////                            offlineVisitsEY.setLatlong_observation_1(model.getLatlong_observation_1());
////                            offlineVisitsEY.setLatlong_observation_2(model.getLatlong_observation_2());
////                            offlineVisitsEY.setLatlong_observation_3(model.getLatlong_observation_3());
////                            offlineVisitsEY.setLatlong_observation_4(model.getLatlong_observation_4());
//                            offlineVisitsEY.setCreated_at(model.getCreated_at());
//                            offlineVisitsEY.setCreated_at_app(model.getCreated_at_app());
//                            offlineVisitsEY.setLat(model.getLat());
//                            offlineVisitsEY.setLon(model.getLon());
//                            offlineVisitsEY.setVillage_name(village_name);
//                            offlineVisitsEY.setPlot_name(plot_name);
//
////                            offlineVisitsEY.setControl_file_obs1(session.getObsFilePATH1Control());
////                            offlineVisitsEY.setControl_file_obs2(session.getObsFilePATH2Control());
////                            offlineVisitsEY.setControl_file_obs3(session.getObsFilePATH3Control());
////                            offlineVisitsEY.setControl_file_obs4(session.getObsFilePATH4Control());
//
//                            offlineVisitsEY.setDate_of_sowing(model.getDate_of_sowing());
//                            offlineVisitsEY.setMethod_of_sowing(model.getMethod_of_sowing());
//                            offlineVisitsEY.setCrop_variety(model.getCrop_variety());
//
//                            offlineVisitsEY.setControl_date_of_sowing(model.getControl_date_of_sowing());
//                            offlineVisitsEY.setControl_method_of_sowing(model.getControl_method_of_sowing());
//                            offlineVisitsEY.setControl_crop_variety(model.getControl_crop_variety());
//
////                            offlineVisitsEY.setControl_latlong_obs1(model.getControl_latlong_obs1());
////                            offlineVisitsEY.setControl_latlong_obs2(model.getControl_latlong_obs2());
////                            offlineVisitsEY.setControl_latlong_obs3(model.getControl_latlong_obs3());
////                            offlineVisitsEY.setControl_latlong_obs4(model.getControl_latlong_obs4());
//
//                            offlineVisitsEY.setControl_observations(model.getControl_observations());
//
//                            offlineVisitsEY.setIs_online(0); //O means offline mode
//
//                            db.offlineVisitsDAO().insertOnlySingle(offlineVisitsEY);
//
//                            db.facilitatorSchedulesDAO().update(1, model.getSchedule_id());
//
//                            db.close();
//
//                            VisitDataCollectActivity.this.runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    showAlertMessage("Your visit completed successfully.\nData saved on offline mode.\n Please sync it once you have internet");
//                                }
//                            });
//
//                        }
//                    }).start();
//
//*/
//
//            }
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    private void showDiscardAlertMessage() {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage("Are you sure you want to discard the captured data?");
//
//        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                    }
//                });
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                        session.clearDataForScheduleVisits();
//                        dataBind();
//                        finish();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    private void showConfirmationAlertMessage(String msg) {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(msg);
//
//
//        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                    }
//                });
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        postData();
//                        dialog.cancel();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    @Override
//    public void onResponse(JSONObject jsonObject, int i) {
//        try {
//            if (jsonObject != null) {
//                ResponseModel response = new ResponseModel(jsonObject);
//
//                if (response.getStatus()) {
//                    showAlertMessage(response.getResponse());
//                    AppUtility.getInstance().deleteAllFileFromDirectory(session.getOnlineStorageDir());
//
//                } else {
//                    UIToastMessage.show(this, response.getResponse());
//                }
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    @Override
//    public void onFailure(Object o, Throwable throwable, int i) {
//
//    }
//
//
//    private void showAlertMessage(String msg) {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(msg);
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        showDashboard();
//                        dialog.cancel();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    private void showDashboard() {
//        Intent intent = new Intent(this, DashboardActivity.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }

}
