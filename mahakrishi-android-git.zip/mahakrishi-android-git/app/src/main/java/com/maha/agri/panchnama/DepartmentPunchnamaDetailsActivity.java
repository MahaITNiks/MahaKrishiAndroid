package com.maha.agri.panchnama;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.abdeveloper.library.MultiSelectDialog;
import com.abdeveloper.library.MultiSelectModel;
import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;

import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;

import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DepartmentPunchnamaDetailsActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private RadioGroup dept_edit_farmer_crop_insurance_rg,dept_edit_farmer_sheticha_prakar_radio_group,dept_edit_farmer_neshirg_apati_rg;
    private RadioButton dept_edit_farmer_crop_insu_yes_radio_btn,dept_edit_farmer_crop_insu_no_radio_btn,dept_edit_farmer_bagyati_radio_btn,
            dept_edit_farmer_jirayati_radio_btn,dept_edit_farmer_neshirg_apati_yes_radio_btn,dept_edit_farmer_neshirg_apati_no_radio_btn;
    private EditText dept_edit_farmer_lagwadi_ekkar_edt,dept_edit_farmer_lagwadi_guntha_edt,dept_edit_farmer_pikvima_ekkar_edt,dept_edit_farmer_pikvima_guntha_edt,
            dept_edit_farmer_andajeet_ekkar_edt,dept_edit_farmer_andajeet_guntha_edt,dept_edit_farmer_edt_survey_no_group_no,dept_edit_farmer_txt_vw_Specify_disease,
            dept_edit_farmer_txt_vw_Specify_Pest,dept_edit_farmer_nuksanicha_takkewari_edt,dept_edit_farmer_total_lagwadi,dept_edit_farmer_total_pikvima,
            dept_edit_farmer_total_baghadheet,dept_edit_farmer_crop_name_edt;
    private Button dept_edit_farmer_submit_btn;
    private LinearLayout dept_edit_farmer_panchnama_photo_ll,dept_edit_farmer_yojna_ll,dept_edit_farmer_pikache_prakar_ll,dept_edit_farmer_pik_vima_saranjheet_ll,
            dept_edit_farmer_neshirg_apati_ll,dept_edit_farmer_damage_reason_ll,dept_edit_farmer_rogache_naav_ll,dept_edit_farmer_keedicha_naav_ll,
            dept_edit_farmer_crop_name_ll,dept_edit_farmer_horti_type_ll;
    private ImageView farmer_panchnama_photo,dept_edit_farmer_nuksanicha_dinaak_iv,nuksanicha_notice_dinaak_iv,dept_edit_farmer_panchnama_photo_1,
            dept_edit_farmer_punchnama_photo_2;
    private String crop_insurance_name;

    private JSONArray year_list,district_list,taluka_list,village_list,farm_type_list,crop_list,damage_reason_list,damage_type_list,scheme_list,
            season_list,crop_type_list,
    horti_type_list;
    BottomSheetDialog mBottomSheetDialog;

    private String yearname,district_name,taluka_name,village_name,farm_type_name,crop_list_name,damage_reason_name,damage_type_name,scheme_name,
            season_name,croptypename,farmer_year_name_str,punchanam_details_str,farmer_mobile_number,farmer_punchanama_type_id, neshirg_apti_id = "";
    private String crop_insurance_ID,farmID,Damage_reason_id="0",damage_name;
    private int yearID=0,districtID=0,talukaID=0,villageID=0,croplistID=0,damageReasonID=0,damageTypeID=0,seasonID=0,croptypeID=0,lagwadi_ekkar_str = 0,
            lagwadi_guntha_str =0,pikvima_ekkar_str = 0,pikvima_guntha_str= 0,andajeet_ekkar_str = 0,andajeet_guntha_str = 0,schemeID = 0,
            horti_crop_id = 0;
    private String district_list_str,taluka_list_str,village_list_str,farmer_last_name,farmer_middle_name,farmer_first_name,edt_survey_no_group_no_str,
            farmer_fullname,currentTime,imagePath,imagePath1;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    static final Integer CAMERA1 = 0x6;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private File photoFile1 = null;
    private Transformation transformation;
    private int responseID;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String activityID = "",farmer_id="";

    private int mYear, mMonth, mDay;
    private String nuksanicha_dinaak;
    private DatePickerDialog nuksanidatePickerDialog;

    private int one_ekkar = 100;
    private String total_lagwadi_str,total_pikvima_str="0",total_baghadheet_str,nuksanicka_takkewari_str,lagwadi_ekkar_value="0",lagwadi_guntha_value="0",
            pikvima_ekkar_value="0",pikvima_guntha_value="0",andajeet_ekkar_value="0",andajeet_guntha_value = "0",Damage_reason_name="";
    private int total_lagwadi_int,total_pikvima_int,total_baghadheet_int;
    private View parentLayout;
    private int position,nuksanicha_int;
    private JSONObject jsonObject;
    ArrayList<MultiSelectModel> list_of_damage= new ArrayList<>();
    private ArrayList<Integer> damage_id;
    private SweetAlertDialog sweetAlertDialog;
    private ArrayList<Integer> damage_reason_selectedIds;
    private ArrayList<String> damage_reason_selectedNames;
    private AppLocationManager appLocationManager;
    public double lat,lang;

    //Farmer Data
    private String year,district,taluka,village,farmer_name,gut_no,sheticha_prakar,hangam,yojna,pikache_prakar,pikache_naav,
            lagwadi_guntha,pika_vima_ekkar="0",pik_vima_guntha="0", andajeet_ekkar,andajeet_guntha,nuksanicha_prakar,nuksanicha_karan,rogache_naav,
            keedache_naav,nuksani_per,nuksani_date,nuksani_notice_date,total_baghdheet,img_one_url = "", img_two_url = "",horti_crop_name="",damage_reason_id="";

    private TextView dept_edit_farmer_txt_vw_full_name_of_farmer,dept_edit_farmer_year_tv,dept_edit_farmer_district_tv,dept_edit_farmer_taluka_tv,
            dept_edit_farmer_village_tv,dept_edit_farmer_horti_crop_type_tv,
            dept_edit_farmer_scheme_name_tv,dept_edit_farmer_season_tv,dept_edit_farmer_pikache_prakar_tv,dept_edit_farmer_pikache_naav_tv,
            dept_edit_farmer_nuksanicha_prakar_tv,dept_edit_farmer_nuksanicha_karan_tv,dept_edit_farmer_nuksanicha_dinaak_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_punchnama_details);
        getSupportActionBar().setTitle("Farmer Panchnama Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DepartmentPunchnamaDetailsActivity.this);
        sharedPref = new SharedPref(DepartmentPunchnamaDetailsActivity.this);
        parentLayout = findViewById(android.R.id.content);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();

        if(isNetworkAvailable()){
            initialiazation();
            default_confiq();
            field_calulation();
        }else{
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.call_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.call:
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:"+ farmer_mobile_number));
                startActivity(callIntent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initialiazation() {

        Intent intent = getIntent();
        punchanam_details_str = intent.getStringExtra("punchanam_details");

        try {
            JSONArray array = new JSONArray(punchanam_details_str);
            position = intent.getIntExtra("position", 0);
            jsonObject = array.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        year_list = new JSONArray();
        district_list = new JSONArray();
        taluka_list = new JSONArray();
        village_list = new JSONArray();
        season_list = new JSONArray();
        scheme_list = new JSONArray();
        crop_type_list = new JSONArray();
        crop_list = new JSONArray();
        damage_type_list = new JSONArray();
        damage_reason_list = new JSONArray();
        //TextView
        dept_edit_farmer_txt_vw_full_name_of_farmer = (TextView) findViewById(R.id.dept_edit_farmer_txt_vw_full_name_of_farmer);
        dept_edit_farmer_year_tv = (TextView)findViewById(R.id.dept_edit_farmer_year_tv);
        dept_edit_farmer_district_tv = (TextView)findViewById(R.id. dept_edit_farmer_district_tv);
        dept_edit_farmer_taluka_tv = (TextView)findViewById(R.id.dept_edit_farmer_taluka_tv);
        dept_edit_farmer_village_tv = (TextView)findViewById(R.id.dept_edit_farmer_village_tv);
        dept_edit_farmer_scheme_name_tv = (TextView)findViewById(R.id.dept_edit_farmer_scheme_name_tv);
        dept_edit_farmer_season_tv = (TextView)findViewById(R.id.dept_edit_farmer_season_tv);
        dept_edit_farmer_pikache_prakar_tv = (TextView)findViewById(R.id.dept_edit_farmer_pikache_prakar_tv);
        dept_edit_farmer_horti_crop_type_tv = (TextView)findViewById(R.id.dept_edit_farmer_horti_crop_type_tv);
        dept_edit_farmer_pikache_naav_tv = (TextView)findViewById(R.id.dept_edit_farmer_pikache_naav_tv);
        dept_edit_farmer_pikache_naav_tv = (TextView)findViewById(R.id.dept_edit_farmer_pikache_naav_tv);
        dept_edit_farmer_nuksanicha_prakar_tv = (TextView)findViewById(R.id.dept_edit_farmer_nuksanicha_prakar_tv);
        dept_edit_farmer_nuksanicha_karan_tv = (TextView)findViewById(R.id.dept_edit_farmer_nuksanicha_karan_tv);
        dept_edit_farmer_nuksanicha_dinaak_tv = (TextView)findViewById(R.id.dept_edit_farmer_nuksanicha_dinaak_tv);

        //Edit Text
        dept_edit_farmer_crop_name_edt = (EditText) findViewById(R.id.dept_edit_farmer_crop_name_edt);
        dept_edit_farmer_edt_survey_no_group_no = (EditText) findViewById(R.id.dept_edit_farmer_edt_survey_no_group_no);
        dept_edit_farmer_lagwadi_ekkar_edt = (EditText) findViewById(R.id.dept_edit_farmer_lagwadi_ekkar_edt);
        dept_edit_farmer_lagwadi_guntha_edt = (EditText) findViewById(R.id.dept_edit_farmer_lagwadi_guntha_edt);
        dept_edit_farmer_pikvima_ekkar_edt = (EditText) findViewById(R.id.dept_edit_farmer_pikvima_ekkar_edt);
        dept_edit_farmer_pikvima_guntha_edt = (EditText) findViewById(R.id.dept_edit_farmer_pikvima_guntha_edt);
        dept_edit_farmer_andajeet_ekkar_edt = (EditText) findViewById(R.id.dept_edit_farmer_andajeet_ekkar_edt);
        dept_edit_farmer_andajeet_guntha_edt = (EditText) findViewById(R.id.dept_edit_farmer_andajeet_guntha_edt);
        dept_edit_farmer_txt_vw_Specify_disease = (EditText) findViewById(R.id.dept_edit_farmer_txt_vw_Specify_disease);
        dept_edit_farmer_txt_vw_Specify_Pest = (EditText) findViewById(R.id.dept_edit_farmer_txt_vw_Specify_Pest);
        dept_edit_farmer_nuksanicha_takkewari_edt = (EditText)findViewById(R.id.dept_edit_farmer_nuksanicha_takkewari_edt);
        dept_edit_farmer_total_lagwadi = (EditText)findViewById(R.id.dept_edit_farmer_total_lagwadi);
        dept_edit_farmer_total_pikvima = (EditText)findViewById(R.id.dept_edit_farmer_total_pikvima);
        dept_edit_farmer_total_baghadheet = (EditText)findViewById(R.id.dept_edit_farmer_total_baghadheet);
        dept_edit_farmer_nuksanicha_dinaak_tv = (TextView)findViewById(R.id.dept_edit_farmer_nuksanicha_dinaak_tv);;
        //nuksanicha_suchna_dilecha_dinaak_tv = (TextView)findViewById(R.id.nuksanicha_suchna_dilecha_dinaak_tv);

        //RadioGroup and RadioButton
        dept_edit_farmer_crop_insurance_rg = (RadioGroup) findViewById(R.id.dept_edit_farmer_crop_insurance_rg);
        dept_edit_farmer_sheticha_prakar_radio_group = (RadioGroup)findViewById(R.id.dept_edit_farmer_sheticha_prakar_radio_group);
        dept_edit_farmer_neshirg_apati_rg = (RadioGroup)findViewById(R.id.dept_edit_farmer_neshirg_apati_rg);
        dept_edit_farmer_neshirg_apati_yes_radio_btn = (RadioButton)findViewById(R.id.dept_edit_farmer_neshirg_apati_yes_radio_btn) ;
        dept_edit_farmer_neshirg_apati_no_radio_btn = (RadioButton)findViewById(R.id.dept_edit_farmer_neshirg_apati_no_radio_btn);
        dept_edit_farmer_crop_insu_yes_radio_btn = (RadioButton) findViewById(R.id.dept_edit_farmer_crop_insu_yes_radio_btn);
        dept_edit_farmer_crop_insu_no_radio_btn = (RadioButton) findViewById(R.id.dept_edit_farmer_crop_insu_no_radio_btn);
        dept_edit_farmer_bagyati_radio_btn = (RadioButton)findViewById(R.id.dept_edit_farmer_bagyati_radio_btn);
        dept_edit_farmer_jirayati_radio_btn = (RadioButton)findViewById(R.id.dept_edit_farmer_jirayati_radio_btn);
        dept_edit_farmer_year_tv.setEnabled(false);

        //Layout
        dept_edit_farmer_yojna_ll = (LinearLayout) findViewById(R.id.dept_edit_farmer_yojna_ll);
        dept_edit_farmer_pikache_prakar_ll = (LinearLayout) findViewById(R.id.dept_edit_farmer_pikache_prakar_ll);
        dept_edit_farmer_pik_vima_saranjheet_ll = (LinearLayout) findViewById(R.id.dept_edit_farmer_pik_vima_saranjheet_ll);
        dept_edit_farmer_neshirg_apati_ll = (LinearLayout) findViewById(R.id.dept_edit_farmer_neshirg_apati_ll);
        dept_edit_farmer_rogache_naav_ll = (LinearLayout)findViewById(R.id.dept_edit_farmer_rogache_naav_ll);
        dept_edit_farmer_keedicha_naav_ll = (LinearLayout)findViewById(R.id.dept_edit_farmer_keedicha_naav_ll);
        dept_edit_farmer_damage_reason_ll = (LinearLayout)findViewById(R.id.dept_edit_farmer_damage_reason_ll);
        dept_edit_farmer_panchnama_photo_ll = (LinearLayout) findViewById(R.id.dept_edit_farmer_panchnama_photo_ll);
        dept_edit_farmer_crop_name_ll = (LinearLayout)findViewById(R.id.dept_edit_farmer_crop_name_ll);
        dept_edit_farmer_horti_type_ll = (LinearLayout)findViewById(R.id.dept_edit_farmer_horti_type_ll);

        //Button
        dept_edit_farmer_submit_btn = (Button) findViewById(R.id.dept_edit_farmer_submit_btn);
        dept_edit_farmer_nuksanicha_dinaak_iv = (ImageView)findViewById(R.id.dept_edit_farmer_nuksanicha_dinaak_iv);
        dept_edit_farmer_panchnama_photo_1 = (ImageView)findViewById(R.id.dept_edit_farmer_panchnama_photo_1);
        dept_edit_farmer_punchnama_photo_2 = (ImageView) findViewById(R.id.dept_edit_farmer_punchnama_photo_2);
        //nuksanicha_notice_dinaak_iv = (ImageView)findViewById(R.id.nuksanicha_notice_dinaak_iv);

        /*farmer_last_name = preferenceManager.getPreferenceValues(Preference_Constant.LAST_NAME);
        farmer_middle_name = preferenceManager.getPreferenceValues(Preference_Constant.MIDDLE_NAME);
        farmer_first_name = preferenceManager.getPreferenceValues(Preference_Constant.FIRST_NAME);
        farmer_fullname = farmer_first_name + "  " + farmer_middle_name + "  " + farmer_last_name;*/

        currentTime = ApUtil.getCurrentTimeStamp();

        PunchnamaYearWebservice();
        District_Service();
        Farm_type_Service();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

    }
    private void default_confiq(){

        farmer_panchanam_data_service();

            dept_edit_farmer_year_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (year_list.length()>0) {
                        AppUtility.getInstance().showListDialogIndex(year_list, 1,"Select Year", "name", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                    } else {
                        PunchnamaYearWebservice();
                    }
                }
            });

            dept_edit_farmer_district_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(district_list == null) {
                        District_Service();
                    }else{
                        AppUtility.getInstance().showListDialogIndex(district_list, 2, "Select District", "district_name", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                    }
                }
            });

            dept_edit_farmer_taluka_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(taluka_list == null) {
                        Taluka_Service(districtID);
                    }else{
                        AppUtility.getInstance().showListDialogIndex(taluka_list, 3, "Select Taluka", "taluka_name", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                    }
                }
            });

            dept_edit_farmer_village_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(village_list == null){
                        Village_Service(talukaID);
                    }else{
                        AppUtility.getInstance().showListDialogIndex(village_list, 4, "Select Village", "village_name", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                    }
                }
            });

            dept_edit_farmer_scheme_name_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(scheme_list.length()>0) {
                        AppUtility.getInstance().showListDialogIndex(scheme_list, 6, "Select Scheme", "name_mr", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                    }else{
                        Scheme_Service();
                    }
                }
            });

            dept_edit_farmer_season_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (crop_insurance_ID.equalsIgnoreCase("")) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select crop insurance is available or not", Toast.LENGTH_SHORT).show();
                    } else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select scheme", Toast.LENGTH_SHORT).show();
                    } else {
                        if (season_list.length() > 0) {
                            AppUtility.getInstance().showListDialogIndex(season_list, 7, "Select Season", "name_mr", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                        } else {
                            Season_Service(crop_insurance_ID, schemeID);
                        }
                    }
                }
            });

            dept_edit_farmer_pikache_prakar_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(seasonID==0){
                        Toast toast= Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
                        toast.show();
                    }else {
                        if (crop_type_list.length() > 0) {
                            AppUtility.getInstance().showListDialogIndex(crop_type_list, 8, "Select Crop type", "name_mr", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                        } else {
                            CropType_Service(seasonID);
                        }
                    }
                }
            });

            dept_edit_farmer_horti_crop_type_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(croptypeID==0){
                        Toast toast= Toast.makeText(getApplicationContext(), "Select crop type", Toast.LENGTH_SHORT);
                        toast.show();
                    }else {
                        if (horti_type_list.length() > 0) {
                            AppUtility.getInstance().showListDialogIndex(horti_type_list, 15, "Select Horticulture type", "name_marathi", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                        } else {
                            Horti_crop_type_service(croptypeID);
                        }
                    }
                }
            });

            dept_edit_farmer_pikache_naav_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (crop_insurance_ID.equalsIgnoreCase("")) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select crop insurance is available or not", Toast.LENGTH_SHORT).show();
                    }else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select scheme", Toast.LENGTH_SHORT).show();
                    }else if (seasonID == 0) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select season", Toast.LENGTH_SHORT).show();
                    }else if (crop_insurance_ID.equalsIgnoreCase("0") && croptypeID == 0) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select crop type", Toast.LENGTH_SHORT).show();
                    }else if(crop_list.length()==0){
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();
                    } else {
                        if (crop_list.length() > 0) {
                            AppUtility.getInstance().showListDialogIndex(crop_list, 9, "Select Crop", "crop_marathi", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                        } else {
                            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);

                        }
                    }
                }
            });

            dept_edit_farmer_nuksanicha_prakar_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (crop_insurance_ID.equalsIgnoreCase("")) {
                        Toast.makeText(DepartmentPunchnamaDetailsActivity.this, "Select crop insurance is available or not", Toast.LENGTH_SHORT).show();
                    } else {
                        if (damage_type_list.length() > 0) {
                            AppUtility.getInstance().showListDialogIndex(damage_type_list, 11, "Select Damage type", "name_mr", "id", DepartmentPunchnamaDetailsActivity.this, DepartmentPunchnamaDetailsActivity.this);
                        } else {
                            Damage_Type(crop_insurance_ID);
                        }
                    }
                }
            });

        dept_edit_farmer_nuksanicha_dinaak_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nuk_sani_date_Picker();
            }
        });

            dept_edit_farmer_nuksanicha_karan_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    MultiSelectDialog multiSelectDialog = new MultiSelectDialog()
                            .title("Select")
                            .titleSize(25)
                            .positiveText("Done")
                            .negativeText("Cancel")
                            .setMinSelectionLimit(1)
                            .setMaxSelectionLimit(list_of_damage.size())
                            .multiSelectList(list_of_damage)
                            .onSubmit(new MultiSelectDialog.SubmitCallbackListener() {
                                @Override
                                public void onSelected(ArrayList<Integer> selectedIds, ArrayList<String> selectedNames, String dataString) {
                                    damage_reason_selectedIds = selectedIds;
                                    damage_reason_id = String.valueOf(damage_reason_selectedIds);
                                    damage_reason_selectedNames = selectedNames;
                                    Damage_reason_name = dataString;
                                    dept_edit_farmer_nuksanicha_karan_tv.setText(dataString);
                                    if(selectedNames.contains("किडीचा प्रादुर्भाव") & selectedNames.contains("रोगाचा प्रादुर्भाव")){
                                        dept_edit_farmer_rogache_naav_ll.setVisibility(View.VISIBLE);
                                        dept_edit_farmer_keedicha_naav_ll.setVisibility(View.VISIBLE);
                                        dept_edit_farmer_txt_vw_Specify_Pest.setText("");
                                        dept_edit_farmer_txt_vw_Specify_disease.setText("");
                                    }else if (selectedNames.contains("रोगाचा प्रादुर्भाव")){
                                        dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                                        dept_edit_farmer_rogache_naav_ll.setVisibility(View.VISIBLE);
                                        dept_edit_farmer_txt_vw_Specify_Pest.setText("");
                                        dept_edit_farmer_txt_vw_Specify_disease.setText("");
                                    }else if(selectedNames.contains("किडीचा प्रादुर्भाव")){
                                        dept_edit_farmer_keedicha_naav_ll.setVisibility(View.VISIBLE);
                                        dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                                        dept_edit_farmer_txt_vw_Specify_Pest.setText("");
                                        dept_edit_farmer_txt_vw_Specify_disease.setText("");
                                    } else {
                                        dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                                        dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                                        dept_edit_farmer_txt_vw_Specify_Pest.setText("");
                                        dept_edit_farmer_txt_vw_Specify_disease.setText("");
                                    }
                                }
                                @Override
                                public void onCancel() {

                                }
                            });

                    multiSelectDialog.show(getSupportFragmentManager(), "multiSelectDialog");
                }
            });



            dept_edit_farmer_crop_insurance_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch(checkedId) {
                        case R.id.dept_edit_farmer_crop_insu_yes_radio_btn:
                            dept_edit_farmer_crop_insu_yes_radio_btn.setChecked(true);
                            dept_edit_farmer_neshirg_apati_yes_radio_btn.setChecked(false);
                            dept_edit_farmer_neshirg_apati_no_radio_btn.setChecked(false);
                            crop_insurance_name = dept_edit_farmer_crop_insu_yes_radio_btn.getText().toString();
                            crop_insurance_ID = "1";
                            dept_edit_farmer_yojna_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_pik_vima_saranjheet_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_neshirg_apati_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_pikache_prakar_ll.setVisibility(View.GONE);
                            dept_edit_farmer_horti_type_ll.setVisibility(View.GONE);
                            dept_edit_farmer_damage_reason_ll.setVisibility(View.GONE);
                            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
                            //dept_edit_farmer_scheme_name_tv.setText(scheme_name);
                            //croptypeID = 0;
                            Scheme_Service();
                            Damage_Type(crop_insurance_ID);
                            Damage_Reason();
                            clear_data();
                            break;

                        case R.id.dept_edit_farmer_crop_insu_no_radio_btn:
                            dept_edit_farmer_crop_insu_no_radio_btn.setChecked(true);
                            dept_edit_farmer_neshirg_apati_yes_radio_btn.setChecked(true);
                            dept_edit_farmer_neshirg_apati_no_radio_btn.setChecked(true);
                            crop_insurance_name = dept_edit_farmer_crop_insu_no_radio_btn.getText().toString();
                            crop_insurance_ID = "0";
                            neshirg_apti_id = "";
                            dept_edit_farmer_yojna_ll.setVisibility(View.GONE);
                            dept_edit_farmer_pik_vima_saranjheet_ll.setVisibility(View.GONE);
                            dept_edit_farmer_neshirg_apati_ll.setVisibility(View.GONE);
                            dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_horti_type_ll.setVisibility(View.GONE);
                            dept_edit_farmer_pikache_prakar_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
                            clear_data();
                            schemeID = 0;
                            //Scheme_Service();
                            Season_Service(crop_insurance_ID,schemeID);
                            Damage_Type(crop_insurance_ID);
                            CropType_Service(seasonID);
                            Damage_Reason();
                            break;


                    }
                }
            });

            dept_edit_farmer_sheticha_prakar_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch(checkedId) {
                        case R.id.dept_edit_farmer_bagyati_radio_btn:
                            dept_edit_farmer_bagyati_radio_btn.setChecked(true);
                            farmID = "1";
                            break;

                        case R.id.dept_edit_farmer_jirayati_radio_btn:
                            dept_edit_farmer_jirayati_radio_btn.setChecked(true);
                            farmID = "2";
                            break;
                    }
                }
            });

            dept_edit_farmer_neshirg_apati_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch(checkedId) {
                        case R.id.dept_edit_farmer_neshirg_apati_yes_radio_btn:
                            dept_edit_farmer_neshirg_apati_yes_radio_btn.setChecked(true);
                            neshirg_apti_id = "1";
                            dept_edit_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                            dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_nuksanicha_karan_tv.setText("Select");
                            break;

                        case R.id.dept_edit_farmer_neshirg_apati_no_radio_btn:
                            dept_edit_farmer_neshirg_apati_no_radio_btn.setChecked(true);
                            neshirg_apti_id = "0";
                            dept_edit_farmer_damage_reason_ll.setVisibility(View.GONE);
                            dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
                            dept_edit_farmer_nuksanicha_karan_tv.setText("Select");
                            break;


                    }
                }
            });

            dept_edit_farmer_panchnama_photo_1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if((ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                        takeImageFromCameraUri();
                    } else{
                        String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                        }
                    }
                }
            });

            dept_edit_farmer_punchnama_photo_2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if((ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(DepartmentPunchnamaDetailsActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                        takeImageFromCameraUri1();
                    } else{
                        String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                        }
                    }
                }
            });


            dept_edit_farmer_submit_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PunchnamaSave();
                }
            });
    }

    private void nuk_sani_date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        nuksanidatePickerDialog = new DatePickerDialog(DepartmentPunchnamaDetailsActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        nuksanicha_dinaak = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        dept_edit_farmer_nuksanicha_dinaak_tv.setText(nuksanicha_dinaak);
                    }
                }, mYear, mMonth, mDay);

        nuksanidatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        nuksanidatePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        nuksanidatePickerDialog.show();
    }

    private void farmer_panchanam_data_service(){
        try {
            farmer_punchanama_type_id = jsonObject.getString("id");
            //yearID = jsonObject.getString("id");
            year = jsonObject.getString("year_name");
            district = jsonObject.getString("district_name");
            taluka = jsonObject.getString("taluka_name");
            village = jsonObject.getString("village_name");
            farmer_name = jsonObject.getString("farmer_name");
            farmer_id = jsonObject.getString("user_id");
            sheticha_prakar = jsonObject.getString("farm_type_name");
            hangam = jsonObject.getString("season_name");
            yojna = jsonObject.getString("scheme_name_mr");
            pikache_naav = jsonObject.getString("crop_name_mr");
            gut_no = jsonObject.getString("survey_no");
            pikache_prakar = jsonObject.getString("crop_type_mr");
            crop_insurance_name = jsonObject.getString("crop_insurance_name");
            lagwadi_ekkar_value = jsonObject.getString("area_under_crop_acre");
            lagwadi_guntha_value = jsonObject.getString("area_under_crop_guntha");
            pikvima_ekkar_value = jsonObject.getString("insured_area_under_crop_acre");
            pikvima_guntha_value = jsonObject.getString("insured_area_under_crop_guntha");
            andajeet_ekkar_value = jsonObject.getString("approxmate_area_acre");
            andajeet_guntha_value = jsonObject.getString("approxmate_area_guntha");
            nuksanicha_prakar = jsonObject.getString("damage_type_name");
            //nuksanicha_karan = jsonObject.getString("damage_reason_name");
            rogache_naav = jsonObject.getString("disease_name");
            keedache_naav = jsonObject.getString("pest_name");
            districtID = Integer.parseInt(jsonObject.getString("district_id"));
            talukaID = Integer.parseInt(jsonObject.getString("taluka_id"));
            villageID = Integer.parseInt(jsonObject.getString("village_id"));
            crop_insurance_ID = jsonObject.getString("crop_insurance");
            farmID = jsonObject.getString("farm_type_id");
            schemeID = Integer.parseInt(jsonObject.getString("scheme_id"));
            seasonID = Integer.parseInt(jsonObject.getString("season_id"));
            croptypeID = Integer.parseInt(jsonObject.getString("crop_type_id"));
            horti_crop_name = jsonObject.getString("horti_name_mr");
            croplistID = Integer.parseInt(jsonObject.getString("crop_id"));
            damageTypeID = Integer.parseInt(jsonObject.getString("damage_type_id"));
            //damage_id = bundle.getIntegerArrayList("damage_reason_id");
            damage_reason_id = jsonObject.getString("damage_reason_id");
            neshirg_apti_id = jsonObject.getString("neshirg_apti_id");
            Damage_reason_name = jsonObject.getString("dmg_reason_name");
            nuksanicka_takkewari_str = jsonObject.getString("nuksani_per");
            nuksanicha_dinaak = jsonObject.getString("nuksani_date");
            //nuksani_notice_date = jsonObject.getString("nuksani_notice_date");
            farmer_mobile_number = jsonObject.getString("mobile");
            total_lagwadi_str = jsonObject.getString("total_lagwadi");
            total_pikvima_str = jsonObject.getString("total_pikvima");
            total_baghadheet_str = jsonObject.getString("total_baghadeet");
            img_one_url = jsonObject.getString("file_name_one");
            img_two_url = jsonObject.getString("file_name_two");
            //sp_dept_edit_farmer_year.setTitle(year);
            dept_edit_farmer_txt_vw_full_name_of_farmer.setText(farmer_name);
            dept_edit_farmer_year_tv.setText("2019-2020");
            dept_edit_farmer_year_tv.setEnabled(false);
            dept_edit_farmer_district_tv.setText(district);
            dept_edit_farmer_taluka_tv.setText(taluka);
            dept_edit_farmer_village_tv.setText(village);
            dept_edit_farmer_season_tv.setText(hangam);
            dept_edit_farmer_pikache_prakar_tv.setText(pikache_prakar);
            dept_edit_farmer_pikache_naav_tv.setText(pikache_naav);
            dept_edit_farmer_nuksanicha_prakar_tv.setText(nuksanicha_prakar);
            dept_edit_farmer_nuksanicha_karan_tv.setText(Damage_reason_name);

            dept_edit_farmer_edt_survey_no_group_no.setText(gut_no);
            dept_edit_farmer_lagwadi_ekkar_edt.setText(lagwadi_ekkar_value);
            dept_edit_farmer_lagwadi_guntha_edt.setText(lagwadi_guntha_value);
            dept_edit_farmer_andajeet_ekkar_edt.setText(andajeet_ekkar_value);
            dept_edit_farmer_andajeet_guntha_edt.setText(andajeet_guntha_value);
            dept_edit_farmer_nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str);
            dept_edit_farmer_nuksanicha_dinaak_tv.setText(nuksanicha_dinaak);
            //dept_punchnama_nuksanicha_notice_dinaak_edt.setText(nuksani_notice_date);
            dept_edit_farmer_total_lagwadi.setText(total_lagwadi_str);
            dept_edit_farmer_total_pikvima.setText(total_pikvima_str);
            dept_edit_farmer_total_baghadheet.setText(total_baghadheet_str);

            if (!img_one_url.equalsIgnoreCase("")) {
                Picasso.get()
                        .load(img_one_url)
                        .transform(transformation)
                        .into(dept_edit_farmer_panchnama_photo_1);
            } else {

            }

            if (!img_two_url.equalsIgnoreCase("")) {
                Picasso.get()
                        .load(img_two_url)
                        .transform(transformation)
                        .into(dept_edit_farmer_punchnama_photo_2);
            } else {

            }

            if (!total_pikvima_str.equalsIgnoreCase("")) {
                if (!total_pikvima_str.equalsIgnoreCase("0")) {
                    dept_edit_farmer_pik_vima_saranjheet_ll.setVisibility(View.VISIBLE);
                    dept_edit_farmer_pikvima_ekkar_edt.setText(pikvima_ekkar_value);
                    dept_edit_farmer_pikvima_guntha_edt.setText(pikvima_guntha_value);
                }
            }
            if (!rogache_naav.equalsIgnoreCase("")) {
                dept_edit_farmer_rogache_naav_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_txt_vw_Specify_disease.setText(rogache_naav);
            }
            if (!keedache_naav.equalsIgnoreCase("")) {
                dept_edit_farmer_keedicha_naav_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_txt_vw_Specify_Pest.setText(keedache_naav);
            }
            if (yojna.equalsIgnoreCase("null")) {
                dept_edit_farmer_yojna_ll.setVisibility(View.GONE);
            } else {
                dept_edit_farmer_yojna_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_scheme_name_tv.setText(yojna);
            }

            if (crop_insurance_ID.equalsIgnoreCase("1")) {
                dept_edit_farmer_crop_insu_yes_radio_btn.setChecked(true);
            } else {
                dept_edit_farmer_crop_insu_yes_radio_btn.setChecked(false);
            }

            if (crop_insurance_ID.equalsIgnoreCase("0")) {
                dept_edit_farmer_crop_insu_no_radio_btn.setChecked(true);
                dept_edit_farmer_neshirg_apati_ll.setVisibility(View.GONE);
            } else {
                dept_edit_farmer_crop_insu_no_radio_btn.setChecked(false);
                dept_edit_farmer_neshirg_apati_ll.setVisibility(View.VISIBLE);
            }

            if (farmID.equalsIgnoreCase("1")) {
                dept_edit_farmer_bagyati_radio_btn.setChecked(true);
                dept_edit_farmer_jirayati_radio_btn.setChecked(false);
            } else {
                dept_edit_farmer_bagyati_radio_btn.setChecked(false);
                dept_edit_farmer_jirayati_radio_btn.setChecked(true);
            }

            if (croptypeID != 0) {
                dept_edit_farmer_pikache_prakar_ll.setVisibility(View.VISIBLE);
            } else {
                dept_edit_farmer_pikache_prakar_ll.setVisibility(View.GONE);
            }

            if (croptypeID == 45) {
                dept_edit_farmer_horti_type_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_horti_crop_type_tv.setText(horti_crop_name);
            } else {
                dept_edit_farmer_horti_type_ll.setVisibility(View.GONE);
                dept_edit_farmer_horti_crop_type_tv.setText("Select");
            }

            if (neshirg_apti_id.equalsIgnoreCase("1")) {
                dept_edit_farmer_neshirg_apati_yes_radio_btn.setChecked(true);
                dept_edit_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
            } else {
                dept_edit_farmer_neshirg_apati_no_radio_btn.setChecked(true);
                dept_edit_farmer_damage_reason_ll.setVisibility(View.GONE);
            }

            if (!Damage_reason_name.equalsIgnoreCase("")) {
                dept_edit_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_nuksanicha_karan_tv.setText(Damage_reason_name);
            } else {
                dept_edit_farmer_damage_reason_ll.setVisibility(View.GONE);
                dept_edit_farmer_nuksanicha_karan_tv.setText("");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void clear_data() {

        season_list = new JSONArray();
        seasonID = 0;
        scheme_list = new JSONArray();
        schemeID = 0;
        crop_type_list = new JSONArray();
        croptypeID = 0;
        horti_type_list = new JSONArray();
        horti_crop_id = 0;
        crop_list = new JSONArray();
        croplistID = 0;
        damage_type_list = new JSONArray();
        damageTypeID = 0;
        damage_reason_list = new JSONArray();
        damageReasonID = 0;

        dept_edit_farmer_scheme_name_tv.setText("Select");
        dept_edit_farmer_season_tv.setText("Select");
        dept_edit_farmer_pikache_prakar_tv.setText("Select");
        dept_edit_farmer_pikache_naav_tv.setText("Select");
        dept_edit_farmer_nuksanicha_prakar_tv.setText("Select");
        dept_edit_farmer_nuksanicha_karan_tv.setText("Select");
        dept_edit_farmer_horti_crop_type_tv.setText("Select");
        dept_edit_farmer_lagwadi_ekkar_edt.setText("");
        dept_edit_farmer_lagwadi_guntha_edt.setText("");
        dept_edit_farmer_total_lagwadi.setText("");
        dept_edit_farmer_pikvima_ekkar_edt.setText("");
        dept_edit_farmer_pikvima_guntha_edt.setText("");
        dept_edit_farmer_total_pikvima.setText("");
        dept_edit_farmer_andajeet_ekkar_edt.setText("");
        dept_edit_farmer_andajeet_guntha_edt.setText("");
        dept_edit_farmer_total_baghadheet.setText("");
        dept_edit_farmer_nuksanicha_takkewari_edt.setText("");
        dept_edit_farmer_crop_name_edt.setText("");
        dept_edit_farmer_txt_vw_Specify_disease.setText("");
        dept_edit_farmer_txt_vw_Specify_Pest.setText("");
        dept_edit_farmer_nuksanicha_dinaak_tv.setText("dd-mm-yyyy");
        dept_edit_farmer_panchnama_photo_1.setImageResource(R.drawable.camera);
        dept_edit_farmer_punchnama_photo_2.setImageResource(R.drawable.camera);
        photoFile = null;
        photoFile1 = null;
        imagePath = "";
        imagePath1 = "";
        img_one_url= "";
        img_two_url= "";
    }

    private void field_calulation(){

        dept_edit_farmer_lagwadi_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                lagwadi_ekkar_value = dept_edit_farmer_lagwadi_ekkar_edt.getText().toString().trim();
                if(!lagwadi_ekkar_value.equalsIgnoreCase("")){
                    lagwadi_ekkar_str = Integer.parseInt(s.toString());
                    total_lagwadi_str = String.valueOf(lagwadi_ekkar_str * one_ekkar + lagwadi_guntha_str);
                    total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                    dept_edit_farmer_total_lagwadi.setText(total_lagwadi_str);

                }else {
                    dept_edit_farmer_total_lagwadi.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dept_edit_farmer_lagwadi_guntha_edt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                lagwadi_guntha_value = dept_edit_farmer_lagwadi_guntha_edt.getText().toString();
                    if (!lagwadi_guntha_value.equalsIgnoreCase("")) {
                        lagwadi_guntha_str = Integer.valueOf(s.toString());
                        if (lagwadi_guntha_str < 100) {
                            total_lagwadi_str = String.valueOf(lagwadi_ekkar_str * one_ekkar + lagwadi_guntha_str);
                            dept_edit_farmer_total_lagwadi.setText(total_lagwadi_str);
                            total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                        } else {
                            sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    dept_edit_farmer_lagwadi_guntha_edt.setText("");
                                    dept_edit_farmer_total_lagwadi.setText("");
                                }
                            })
                                    .show();
                        }
                    }
                        else {
                        dept_edit_farmer_total_lagwadi.setText("");
                        }
                }
        });

        dept_edit_farmer_pikvima_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                pikvima_ekkar_value = dept_edit_farmer_pikvima_ekkar_edt.getText().toString().trim();

                if(!pikvima_ekkar_value.equalsIgnoreCase("")){
                    pikvima_ekkar_str = Integer.parseInt(pikvima_ekkar_value);
                    total_pikvima_str = String.valueOf(pikvima_ekkar_str * one_ekkar + pikvima_guntha_str);
                    total_pikvima_int = Integer.valueOf(total_pikvima_str);
                    if (total_pikvima_int > total_lagwadi_int) {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता कामा नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                dept_edit_farmer_total_pikvima.setText("");
                                dept_edit_farmer_pikvima_ekkar_edt.setText("");
                                pikvima_ekkar_str=0;
                            }
                        }).show();

                    } else {
                        pikvima_ekkar_str = Integer.parseInt(s.toString());
                        dept_edit_farmer_total_pikvima.setText(total_pikvima_str);
                    }

                }else {
                    dept_edit_farmer_total_pikvima.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dept_edit_farmer_pikvima_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                pikvima_guntha_value = dept_edit_farmer_pikvima_guntha_edt.getText().toString();
                    if (!pikvima_guntha_value.equalsIgnoreCase("")) {

                        pikvima_guntha_str = Integer.parseInt(pikvima_guntha_value);

                        if (pikvima_guntha_str < 100) {
                            total_pikvima_str = String.valueOf(pikvima_ekkar_str * one_ekkar + pikvima_guntha_str);
                            total_pikvima_int = Integer.valueOf(total_pikvima_str);

                            if (total_pikvima_int > total_lagwadi_int) {
                                sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                                sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता कामा नये");
                                sweetAlertDialog.setConfirmText("ठीक आहे");
                                sweetAlertDialog.setCanceledOnTouchOutside(false);
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        dept_edit_farmer_total_pikvima.setText("");
                                        total_pikvima_int=0;
                                        dept_edit_farmer_pikvima_guntha_edt.setText("");
                                        pikvima_guntha_str=0;
                                    }
                                }).show();

                            } else {
                                dept_edit_farmer_total_pikvima.setText(total_pikvima_str);
                            }
                        } else {
                            dept_edit_farmer_total_pikvima.setText("");
                            sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    dept_edit_farmer_total_pikvima.setText("");
                                    dept_edit_farmer_pikvima_guntha_edt.setText("");
                                    pikvima_guntha_str=0;
                                }
                            }).show();
                        }
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        dept_edit_farmer_andajeet_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                andajeet_ekkar_value = dept_edit_farmer_andajeet_ekkar_edt.getText().toString().trim();
                if(!andajeet_ekkar_value.equalsIgnoreCase("")){
                    andajeet_ekkar_str = Integer.parseInt(andajeet_ekkar_value);
                    total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                    total_baghadheet_int = Integer.valueOf(total_baghadheet_str);
                    if (total_baghadheet_int > total_lagwadi_int) {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा बाधित क्षेत्र अधिक असता कामा नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                dept_edit_farmer_total_baghadheet.setText("");
                                dept_edit_farmer_andajeet_ekkar_edt.setText("");
                                andajeet_ekkar_str=0;
                            }
                        }).show();

                    } else {
                        //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                        //dept_edit_farmer_nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");
                        dept_edit_farmer_total_baghadheet.setText(total_baghadheet_str);

                    }
                }else{
                    dept_edit_farmer_total_baghadheet.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dept_edit_farmer_andajeet_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                andajeet_guntha_value = dept_edit_farmer_andajeet_guntha_edt.getText().toString();


                    if (!andajeet_guntha_value.equalsIgnoreCase("")) {
                        andajeet_guntha_str = Integer.parseInt(andajeet_guntha_value);
                        if (andajeet_guntha_str < 100) {
                            total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                            total_baghadheet_int = Integer.valueOf(total_baghadheet_str);

                            if (total_baghadheet_int > total_lagwadi_int) {
                                sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                                sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा बाधित क्षेत्र अधिक असता कामा नये");
                                sweetAlertDialog.setConfirmText("ठीक आहे");
                                sweetAlertDialog.setCanceledOnTouchOutside(false);
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        dept_edit_farmer_total_baghadheet.setText("");
                                        total_baghadheet_int=0;
                                        dept_edit_farmer_andajeet_guntha_edt.setText("");
                                        andajeet_guntha_str=0;

                                    }
                                }).show();

                                //dept_edit_farmer_nuksanicha_takkewari_edt.setText("");
                            } else {
                                dept_edit_farmer_total_baghadheet.setText(total_baghadheet_str);
                                //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                                //dept_edit_farmer_nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");

                            }
                        } else {
                            sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    dept_edit_farmer_total_baghadheet.setText("");
                                    dept_edit_farmer_andajeet_guntha_edt.setText("");
                                    andajeet_guntha_str=0;
                                    //nuksanicha_takkewari_edt.setText("");
                                }
                            }).show();
                        }
                    }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        dept_edit_farmer_nuksanicha_takkewari_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                nuksanicka_takkewari_str = dept_edit_farmer_nuksanicha_takkewari_edt.getText().toString().trim();
                if (!nuksanicka_takkewari_str.equalsIgnoreCase("")) {
                    nuksanicha_int = Integer.valueOf(nuksanicka_takkewari_str);
                    if(nuksanicha_int > 100){
                        sweetAlertDialog = new SweetAlertDialog(DepartmentPunchnamaDetailsActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("नुकसानीची टक्केवारी १००% पेक्षा कमी असली पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismiss();
                                dept_edit_farmer_nuksanicha_takkewari_edt.setText("");
                            }
                        }).show();
                    }
                }
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImageFromCameraUri1() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA1);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }else  if (requestCode == CAMERA1) {
                onCameraActivityResult1();
            }
        }else{
            photoFile = null;
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile!=null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(dept_edit_farmer_panchnama_photo_1.getWidth(), dept_edit_farmer_panchnama_photo_1.getHeight())
                                .centerCrop()
                                .into(dept_edit_farmer_panchnama_photo_1);
                        uploadImageOnServer(imagePath);
                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void onCameraActivityResult1() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile1!=null) {

            if (photoFile1.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath1 = "file://" + photoFile1;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath1)
                                .transform(transformation)
                                .resize(dept_edit_farmer_punchnama_photo_2.getWidth(), dept_edit_farmer_punchnama_photo_2.getHeight())
                                .centerCrop()
                                .into(dept_edit_farmer_punchnama_photo_2);
                        uploadImageOnServer1(imagePath1);
                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile1);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private void PunchnamaYearWebservice(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_year_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void District_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_district_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void Taluka_Service(int districtID){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",districtID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_taluka_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void Village_Service(int talukaID){
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id",talukaID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Farm_type_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_farm_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void Scheme_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_scheme_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    private void Season_Service(String crop_insurance_ID,int schemeID){
        String crop_Iid;
        if(schemeID ==0){
            crop_Iid = "";
        }else {
            crop_Iid = String.valueOf(schemeID);
        }
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("crop_insurance", crop_insurance_ID);
            param.put("panchnama_scheme_id", crop_Iid);
            param.put("primary_report_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);
    }

    private void CropType_Service(int seasonID) {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id",activityID);
            param.put("season_id", "");
            param.put("primary_crop_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropType(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);
    }

    private void Horti_crop_type_service(int croptypeID){
        JSONObject param = new JSONObject();
        try {
            param.put("id",croptypeID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_crop_type_sown_sublist(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 15);
    }

    private void Crop_list(int croptypeID,int schemeID,int seasonID,int horti_crop_id) {
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id", seasonID);
            param.put("crop_type", croptypeID);
            param.put("horti_crop_type_id", horti_crop_id);
            param.put("primary_report_id","");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id",schemeID);

        } catch (Exception e) {

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 9);
    }

    private void Damage_Reason(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_reason_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 10);
    }

    private void Damage_Type(String crop_insurance_ID){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_insurance",crop_insurance_ID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 11);
    }

    private void PunchnamaSave(){

       /* if(districtID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select district",Toast.LENGTH_SHORT).show();
        }else if(talukaID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select taluka",Toast.LENGTH_SHORT).show();
        }else if(villageID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select village",Toast.LENGTH_SHORT).show();
        }else if(dept_edit_farmer_edt_survey_no_group_no.getText().toString().isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Enter survey or gut number",Toast.LENGTH_SHORT).show();
        }else if(crop_insurance_ID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select insurance",Toast.LENGTH_SHORT).show();
        }else if(seasonID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select season",Toast.LENGTH_SHORT).show();
        }else if(croplistID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select crop",Toast.LENGTH_SHORT).show();
        }else if(dept_edit_farmer_lagwadi_ekkar_edt.getText().toString().trim().isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Enter acre value",Toast.LENGTH_SHORT).show();
        }else if(dept_edit_farmer_andajeet_ekkar_edt.getText().toString().trim().isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Enter acre value",Toast.LENGTH_SHORT).show();
        }else if(damageTypeID.isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"select damage type",Toast.LENGTH_SHORT).show();
        }else if(nuksanicha_dinaak.equalsIgnoreCase("")){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Enter damage date",Toast.LENGTH_SHORT).show();
        }else if(dept_edit_farmer_nuksanicha_takkewari_edt.getText().toString().trim().isEmpty()){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Enter damage percentage",Toast.LENGTH_SHORT).show();
        }else if(photoFile==null){
            Toast.makeText(DepartmentPunchnamaDetailsActivity.this,"Capture Photo",Toast.LENGTH_SHORT).show();
        }else {
*/
            JSONObject param = new JSONObject();
            try {
                param.put("farmer_panchnama_id",farmer_punchanama_type_id);
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("year_id", yearID);
                param.put("district_id", districtID);
                param.put("taluka_id", talukaID);
                param.put("farmer_name", farmer_name);
                param.put("farmer_id", farmer_id);
                param.put("village_id", villageID);
                param.put("crop_insurance", crop_insurance_ID);
                param.put("scheme_id", schemeID);
                param.put("season_id", seasonID);
                param.put("crop_type_id", croptypeID);
                param.put("crop_id", croplistID);
                param.put("farm_type_id", farmID);
                param.put("survey_no", dept_edit_farmer_edt_survey_no_group_no.getText().toString());
                param.put("area_under_crop_acre", lagwadi_ekkar_value);
                param.put("area_under_crop_guntha", lagwadi_guntha_value);
                param.put("insured_area_under_crop_acre", pikvima_ekkar_value);
                param.put("insured_area_under_crop_guntha", pikvima_guntha_value);
                param.put("approxmate_area_acre", andajeet_ekkar_value);
                param.put("approxmate_area_guntha", andajeet_guntha_value);
                param.put("damage_type_id", damageTypeID);
                param.put("damage_reason_id", damage_reason_id);
                param.put("dmg_reason_name", Damage_reason_name);
                param.put("disease_name", dept_edit_farmer_txt_vw_Specify_disease.getText().toString().trim());
                param.put("pest_name", dept_edit_farmer_txt_vw_Specify_Pest.getText().toString().trim());
                param.put("nuksani_per",nuksanicka_takkewari_str);
                param.put("nuksani_date", nuksanicha_dinaak);
                param.put("neshirg_apti", neshirg_apti_id);
                param.put("nuksani_notice_date", "00-00-0000");
                param.put("total_lagwadi",total_lagwadi_str);
                param.put("total_pikvima",total_pikvima_str);
                param.put("total_baghadeet",total_baghadheet_str);
                param.put("first_img_url",img_one_url);
                param.put("second_img_url",img_two_url);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_punchnama_form_submit_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 12);

    }

    private void uploadImageOnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("lat", String.valueOf(lat));
            params.put("long",String.valueOf(lang));
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));

            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_punchnama_save_image_url(partBody, params);
            api.postRequest(responseCall, this, 13);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImageOnServer1(String imagePath1) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("lat", String.valueOf(lat));
            params.put("long",String.valueOf(lang));
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_punchnama_save_image_url(partBody, params);
            api.postRequest(responseCall, this, 14);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //year
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_list = jsonObject.getJSONArray("data");
                        }

                    } else {

                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                        }

                    } else {

                    }
                } else
                    //taluka
                    if (i == 3) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                taluka_list = jsonObject.getJSONArray("data");
                            }
                        } else {

                        }
                    }else
                        //Village
                        if (i == 4) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    village_list = jsonObject.getJSONArray("data");
                                }

                            } else {

                            }

                        }

                        else
                            //Farm Type
                            if (i == 5) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        farm_type_list = jsonObject.getJSONArray("data");
                                        final int numberOfItemsInResp = farm_type_list.length();
                                        for (int j = 0; j < numberOfItemsInResp; j++) {
                                            JSONObject farm_type_json_object = farm_type_list.getJSONObject(j);
                                            farmID = farm_type_json_object.getString("id");
                                            farm_type_name = farm_type_json_object.getString("name_mr");
                                            if(farmID.equalsIgnoreCase("1")){
                                                dept_edit_farmer_bagyati_radio_btn.setText(farm_type_name);
                                            } else if(farmID.equalsIgnoreCase("2")){
                                                dept_edit_farmer_jirayati_radio_btn.setText(farm_type_name);
                                            }
                                            farmID = "0";

                                        }

                                    }

                                } else {

                                }
                            }
                            else
                                //Scheme Type
                                if (i == 6) {

                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                        if (responseModel.isStatus()) {
                                            scheme_list = jsonObject.getJSONArray("data");

                                        }

                                    } else {

                                    }
                                }

                                else
                                    //Season
                                    if (i == 7) {

                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                            if (responseModel.isStatus()) {
                                                season_list = jsonObject.getJSONArray("data");
                                            }

                                        } else {

                                        }
                                    }

                                    else
                                        //Crop Type
                                        if (i == 8) {

                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                if (responseModel.isStatus()) {
                                                    crop_type_list = jsonObject.getJSONArray("data");
                                                }
                                            } else {

                                            }
                                        }

                if (i == 15) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            horti_type_list = jsonObject.getJSONArray("data");
                        }
                    } else {

                    }
                }


                                        else
                                        if (i == 9) {

                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                if (responseModel.isStatus()) {
                                                    crop_list = jsonObject.getJSONArray("data");
                                                }
                                            } else {

                                            }
                                        }

                                        else
                                            //Damage Reason
                                            if (i == 10) {

                                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                                    if (responseModel.isStatus()) {
                                                        damage_reason_list = jsonObject.getJSONArray("data");
                                                        final int numberOfItemsInResp = damage_reason_list.length();
                                                        for (int j = 0; j < numberOfItemsInResp; j++) {
                                                            JSONObject damage_json_object = damage_reason_list.getJSONObject(j);
                                                            Damage_reason_id = damage_json_object.getString("id");
                                                            damage_name = damage_json_object.getString("name_mr");
                                                            list_of_damage.add(new MultiSelectModel(Integer.valueOf(Damage_reason_id),damage_name));
                                                        }
                                                    }
                                                } else {

                                                }
                                            }

                                            else
                                                //Damage Type
                                                if (i == 11) {

                                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                                        if (responseModel.isStatus()) {
                                                            damage_type_list = jsonObject.getJSONArray("data");
                                                        }
                                                    } else {

                                                    }
                                                }

                                                else
                                                    //Save Punchnama
                                                    if (i == 12) {

                                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                                            if (responseModel.isStatus()) {
                                                                responseID = jsonObject.getInt("data");
                                                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                                                        sweetAlertDialog.setContentText(jsonObject.getString("response"));
                                                                        sweetAlertDialog.setConfirmText("Ok");
                                                                        sweetAlertDialog.setCancelable(false);
                                                                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                                            @Override
                                                                            public void onClick(SweetAlertDialog sDialog) {
                                                                                finish();
                                                                            }
                                                                        });
                                                                        sweetAlertDialog.show();
                                                            }

                                                        } else {

                                                        }
                                                    }

                                                    else
                                                        //Save Punchnama image
                                                        if (i == 13) {

                                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                                if (responseModel.isStatus()) {
                                                                    JSONObject data = jsonObject.getJSONObject("data");
                                                                    img_one_url = data.getString("file_url");
                                                                }

                                                            }
                                                        }

                                                        else
                                                            //Save Punchnama image
                                                            if (i == 14) {

                                                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                                                    if (responseModel.isStatus()) {
                                                                        JSONObject data = jsonObject.getJSONObject("data");
                                                                        img_two_url = data.getString("file_url");
                                                                    }

                                                                }
                                                            }

            }
            catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    /*private void DeptPunchnamaSave(){

        JSONObject param = new JSONObject();
        try {
            param.put("farmer_panchnama_id",Integer.valueOf(farmer_punchanama_type_id));
            param.put("user_id",Integer.valueOf(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)));
            param.put("year_id",Integer.valueOf(yearID));
            param.put("district_id",Integer.valueOf(districtID));
            param.put("taluka_id",Integer.valueOf(talukaID));
            param.put("village_id",Integer.valueOf(villageID));
            param.put("crop_insurance",Integer.valueOf(crop_insurance_ID));
            param.put("scheme_id",Integer.valueOf(schemeID));
            param.put("season_id",Integer.valueOf(seasonID));
            param.put("crop_type_id",Integer.valueOf(croptypeID));
            param.put("crop_id",Integer.valueOf(croplistID));
            param.put("survey_no",gut_no);
            param.put("farm_type_id",Integer.valueOf(farmID));
            param.put("area_under_crop_acre",lagwadi_ekkar_value);
            param.put("area_under_crop_guntha",lagwadi_guntha_value);
            param.put("insured_area_under_crop_acre",pikvima_ekkar_value);
            param.put("insured_area_under_crop_guntha",pikvima_guntha_value);
            param.put("approxmate_area_acre",andajeet_ekkar_value);
            param.put("approxmate_area_guntha",andajeet_guntha_value);
            param.put("damage_type_id",Integer.valueOf(damageTypeID));
            param.put("damage_reason_id",Integer.valueOf(damageReasonID));
            param.put("disease_name",txt_vw_Specify_disease.getText().toString().trim());
            param.put("pest_name",txt_vw_Specify_Pest.getText().toString().trim());
            param.put("nuksani_per", nuksanicka_takkewari_str);
            param.put("nuksani_date", nuksani_date);
            param.put("nuksani_notice_date", "00-00-0000");
            param.put("total_lagwadi",total_lagwadi_str);
            param.put("total_pikvima",total_pikvima_str);
            param.put("total_baghadeet",total_baghadheet_str);



        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_punchnama_form_submit_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Panchnama")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }*/

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            yearID = Integer.parseInt(s1);
            dept_edit_farmer_year_tv.setText(s);
        }

        if (i == 2) {
            districtID = Integer.parseInt(s1);
            dept_edit_farmer_district_tv.setText(s);
            dept_edit_farmer_taluka_tv.setText("Select");
            dept_edit_farmer_village_tv.setText("Select");
            village_list = new JSONArray();
            Taluka_Service(districtID);
        }

        if (i == 3) {
            talukaID = Integer.parseInt(s1);
            dept_edit_farmer_taluka_tv.setText(s);
            dept_edit_farmer_village_tv.setText("Select");
            Village_Service(talukaID);
        }


        if (i == 4) {
            villageID = Integer.parseInt(s1);
            dept_edit_farmer_village_tv.setText(s);
        }

        if (i == 6) {
            schemeID = Integer.parseInt(s1);
            dept_edit_farmer_scheme_name_tv.setText(s);
            horti_type_list = new JSONArray();
            crop_list = new JSONArray();
            Season_Service(crop_insurance_ID,schemeID);
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            dept_edit_farmer_season_tv.setText("Select");
            dept_edit_farmer_pikache_naav_tv.setText("Select");
            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
            dept_edit_farmer_crop_name_edt.setText("");
        }

        if (i == 7) {
            seasonID = Integer.parseInt(s1);
            dept_edit_farmer_season_tv.setText(s);
            crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            CropType_Service(seasonID);
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            dept_edit_farmer_pikache_prakar_tv.setText("Select");
            dept_edit_farmer_pikache_naav_tv.setText("Select");
            dept_edit_farmer_horti_crop_type_tv.setText("Select");
            dept_edit_farmer_horti_type_ll.setVisibility(View.GONE);
            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
            dept_edit_farmer_crop_name_edt.setText("");
        }

        if (i == 8) {
            croptypeID = Integer.parseInt(s1);
            dept_edit_farmer_pikache_prakar_tv.setText(s);
            crop_list = new JSONArray();
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            dept_edit_farmer_pikache_naav_tv.setText("Select");
            dept_edit_farmer_horti_crop_type_tv.setText("Select");
            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
            dept_edit_farmer_crop_name_edt.setText("");
            horti_crop_id = 0;

            if(croptypeID == 45){
                dept_edit_farmer_horti_type_ll.setVisibility(View.VISIBLE);
                horti_type_list = new JSONArray();
                crop_list = new JSONArray();
                Horti_crop_type_service(croptypeID);
                Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
                dept_edit_farmer_horti_crop_type_tv.setText("Select");
                dept_edit_farmer_pikache_naav_tv.setText("Select");
                dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
                dept_edit_farmer_crop_name_edt.setText("");
            }else {
                dept_edit_farmer_horti_type_ll.setVisibility(View.GONE);
                horti_type_list = new JSONArray();
                crop_list = new JSONArray();
                Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
                dept_edit_farmer_pikache_naav_tv.setText("Select");
                dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
                dept_edit_farmer_crop_name_edt.setText("");
                horti_crop_id = 0;
            }
        }

        if (i == 9) {
            croplistID = Integer.parseInt(s1);
            dept_edit_farmer_pikache_naav_tv.setText(s);
            if(s.equalsIgnoreCase("इतर")){
                dept_edit_farmer_crop_name_ll.setVisibility(View.VISIBLE);
            }else {
                dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
                dept_edit_farmer_crop_name_edt.setText("");
            }
        }

        if (i == 10) {
            damageReasonID = Integer.parseInt(s1);
            dept_edit_farmer_nuksanicha_karan_tv.setText(s);
            /*if(damageReasonID==3){
                dept_edit_farmer_rogache_naav_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_keedicha_naav_ll.setVisibility(View.GONE);
            } else if(damageReasonID==4){
                dept_edit_farmer_keedicha_naav_ll.setVisibility(View.VISIBLE);
                dept_edit_farmer_rogache_naav_ll.setVisibility(View.GONE);
            }*/
        }

        if (i == 11) {
            damageTypeID = Integer.parseInt(s1);
            nuksanicha_prakar = s;
            dept_edit_farmer_nuksanicha_prakar_tv.setText(nuksanicha_prakar);
        }
        if (i == 15) {
            horti_crop_id = Integer.parseInt(s1);
            horti_crop_name = s;
            dept_edit_farmer_horti_crop_type_tv.setText(horti_crop_name);
            crop_list = new JSONArray();
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            dept_edit_farmer_crop_name_ll.setVisibility(View.GONE);
            dept_edit_farmer_pikache_naav_tv.setText("Select");
            dept_edit_farmer_crop_name_edt.setText("");
        }

    }
}
