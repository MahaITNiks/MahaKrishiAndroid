package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DripFormActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView drip_name_of_the_beneficiary,drip_application_number,drip_social_categroy_of_the_beneficiary,drip_name_of_the_component,
            drip_name_of_the_scheme,drip_crop_name_app,drip_manufacturer,drip_dealer,drip_area_as_per_application, drip_bill_invoice_no,drip_bill_invoice_date,
            drip_bill_invoice_amount,drip_GSTN, drip_date_of_presanction,drip_date_of_spot_verification, drip_bill_invoice_date_actual_edt,drip_spacing_app,
            drip_system_type,drip_spacing_actual;

    private EditText drip_crop_name_actual,drip_area_of_application_actual_edt,drip_area_benefitted_in_last_7_years,drip_bill_invoice_no_actual_edt,
            drip_bill_invoice_amount_actual_edt,drip_GSTN_actual_edt;

    private ImageView drip_bill_invoice_date_actual_iv;
    private String drip_bill_invoice_date_actual = "",drip_system_name="",drip_spacing_name="",drip_manufacturers_name="",drip_dealers_name="";

    private String drip_name_of_the_beneficiary_str,drip_application_number_str,drip_social_categroy_of_the_beneficiary_str,drip_name_of_the_component_str,
            drip_specification_of_the_component_str,drip_name_of_the_scheme_str,drip_crop_name_str,drip_manufacturer_str,drip_dealer_str,drip_area_as_per_application_str,
            drip_area_benefitted_in_last_7_years_str,drip_bill_invoice_no_str,drip_bill_invoice_date_str,drip_bill_invoice_amount_str,drip_GSTN_str,
            drip_date_of_presanction_str,drip_date_of_spot_verification_str;

    private int mYear, mMonth, mDay;
    private DatePickerDialog datePickerDialog;
    private PreferenceManager preferenceManager;

    private int  district_id = 0,taluka_id = 0,village_id = 0,farmer_id = 0,drip_system_id = 0,drip_spacing_id = 0,drip_manuf_id = 0,drip_dealers_id = 0,scheme_id = 0;
    private JSONArray drip_field_data,drip_system_type_list,drip_spacing_list,drip_manufacturers_list,drip_dealers_list;
    private Button dripsave_btn;

    private int manufacture_id = 0;
    private String form_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drip_form);
        getSupportActionBar().setTitle("Drip");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DripFormActivity.this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        form_id = intent.getStringExtra("form_id");
        scheme_id = intent.getIntExtra("scheme_id",0);
        ids();
        default_confiq();
    }

    private void ids(){

        drip_name_of_the_beneficiary = (TextView) findViewById(R.id.drip_name_of_the_beneficiary);
        drip_application_number = (TextView) findViewById(R.id.drip_application_number);
        drip_social_categroy_of_the_beneficiary = (TextView) findViewById(R.id.drip_social_categroy_of_the_beneficiary);
        drip_name_of_the_scheme = (TextView) findViewById(R.id.drip_name_of_the_scheme);
        drip_crop_name_app = (TextView) findViewById(R.id.drip_crop_name_app);
        drip_system_type = (TextView) findViewById(R.id.drip_system_type);
        drip_spacing_app = (TextView) findViewById(R.id.drip_spacing_app);
        drip_spacing_actual = (TextView) findViewById(R.id.drip_spacing_actual);
        drip_manufacturer = (TextView) findViewById(R.id.drip_manufacturer);
        drip_dealer = (TextView) findViewById(R.id.drip_dealer);
        drip_area_as_per_application = (TextView) findViewById(R.id.drip_area_as_per_application);
        drip_name_of_the_component = (TextView) findViewById(R.id.drip_name_of_the_component);
        drip_bill_invoice_no = (TextView) findViewById(R.id.drip_bill_invoice_no);
        drip_bill_invoice_date = (TextView) findViewById(R.id.drip_bill_invoice_date);
        drip_bill_invoice_amount = (TextView) findViewById(R.id.drip_bill_invoice_amount);
        drip_GSTN = (TextView) findViewById(R.id.drip_GSTN);
        drip_date_of_presanction = (TextView) findViewById(R.id.drip_date_of_presanction);
        drip_date_of_spot_verification = (TextView) findViewById(R.id.drip_date_of_spot_verification);
        drip_bill_invoice_date_actual_edt = (TextView) findViewById(R.id.drip_bill_invoice_date_actual_edt);
        //Edittext
        drip_crop_name_actual = (EditText) findViewById(R.id.drip_crop_name_actual);
        drip_area_of_application_actual_edt = (EditText) findViewById(R.id.drip_area_of_application_actual_edt);
        drip_area_benefitted_in_last_7_years = (EditText) findViewById(R.id.drip_area_benefitted_in_last_7_years);
        drip_bill_invoice_no_actual_edt = (EditText) findViewById(R.id.drip_bill_invoice_no_actual_edt);
        drip_bill_invoice_amount_actual_edt = (EditText) findViewById(R.id.drip_bill_invoice_amount_actual_edt);
        drip_GSTN_actual_edt = (EditText) findViewById(R.id.drip_GSTN_actual_edt);

        drip_bill_invoice_date_actual_iv = (ImageView) findViewById(R.id.drip_bill_invoice_date_actual_iv);
        dripsave_btn = (Button) findViewById(R.id.btn_save_drip_wf);

        drip_date_of_spot_verification_str = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        drip_date_of_spot_verification.setText(drip_date_of_spot_verification_str);
        drip_field_data = new JSONArray();
        drip_system_type_list = new JSONArray();
        drip_spacing_list = new JSONArray();
        drip_manufacturers_list= new JSONArray();
        drip_dealers_list = new JSONArray();
        get_field_drip_data();
        drip_system_service();
        drip_spacing_service();
        drip_manufacturers_service();
    }

    private void default_confiq(){

        dripsave_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //drip_save_service();
                Intent intent = new Intent(DripFormActivity.this, SpotVerificationActivity.class);
                intent.putExtra("form_id",form_id);
                intent.putExtra("manuf_code",drip_manuf_id);
                intent.putExtra("scheme_id",scheme_id);
                intent.putExtra("district_id",district_id);
                intent.putExtra("takula_id",taluka_id);
                intent.putExtra("village_id",village_id);
                startActivity(intent);
                finish();
            }
        });

        drip_system_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drip_system_type_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(drip_system_type_list, 2, "Select drip system type", "name", "id", DripFormActivity.this, DripFormActivity.this);
                }
            }
        });

        drip_spacing_actual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drip_spacing_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(drip_spacing_list, 3, "Select drip spacing type", "spacing_value", "id", DripFormActivity.this, DripFormActivity.this);
                }
            }
        });

        drip_manufacturer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drip_manufacturers_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(drip_manufacturers_list, 4, "Select manufacturer", "manuf_name", "manuf_code", DripFormActivity.this, DripFormActivity.this);
                }
            }
        });

        drip_dealer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drip_dealers_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(drip_dealers_list, 5, "Select dealer", "dealer_name", "id", DripFormActivity.this, DripFormActivity.this);
                }
            }
        });

        drip_bill_invoice_date_actual_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date_Picker();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void get_field_drip_data() {

        JSONObject param = new JSONObject();
        try {
            param.put("village_id",village_id);
            param.put("farmer_id",farmer_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.fetch_spot_verification_drip_data(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void drip_system_service(){
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.drip_system_type();
        api.postRequest(responseCall, this, 2);
    }

    private void drip_spacing_service(){
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.drip_spacing();
        api.postRequest(responseCall, this,3);
    }

    private void drip_manufacturers_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_manufacture_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void drip_dealers_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("manuf_id",drip_manuf_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_dealer_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void drip_save_service(){
        if(drip_crop_name_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter name of the crop(actual)",Toast.LENGTH_LONG).show();
        }else if(drip_system_name.equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Select drip system type",Toast.LENGTH_LONG).show();
        }else if(drip_spacing_name.equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Select drip spacing m X m(Actual)",Toast.LENGTH_LONG).show();
        }else if(drip_manufacturer_str.equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Select manufacturer",Toast.LENGTH_LONG).show();
        }else if(drip_dealer_str.equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Select dealer",Toast.LENGTH_LONG).show();
        }else if(drip_area_of_application_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter area in HA(Actual)",Toast.LENGTH_LONG).show();
        }else if(drip_area_benefitted_in_last_7_years.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter area benefited in last 7 years",Toast.LENGTH_LONG).show();
        }else if(drip_bill_invoice_no_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter bill invoice no(Actual)",Toast.LENGTH_LONG).show();
        }else if(drip_bill_invoice_date_actual.equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Select bill invoice date",Toast.LENGTH_LONG).show();
        }else if(drip_bill_invoice_amount_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter bill invoice amount(Rs.)(Actual)",Toast.LENGTH_LONG).show();
        }else if(drip_GSTN_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormActivity.this,"Enter GSTN(Actual)",Toast.LENGTH_LONG).show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("village_id", village_id);
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("date_spot",drip_date_of_spot_verification_str);
                //param.put("name", drip_name_of_the_beneficiary_str);
                param.put("app_no", drip_application_number_str);
                param.put("social_cat", drip_social_categroy_of_the_beneficiary_str);
                param.put("name_comp", drip_name_of_the_component_str);
                param.put("scheme_name", drip_name_of_the_scheme_str);
                param.put("crop_name_app", drip_crop_name_str);
                param.put("crop_name_actual", drip_crop_name_actual.getText().toString().trim());
                param.put("drip_system_id", drip_system_id);
                param.put("spacing_app", drip_spacing_app.getText().toString().trim());
                param.put("spacing_actual", drip_spacing_id);
                param.put("manufacturer_id", drip_manuf_id);
                param.put("dealer_id", drip_dealers_id);
                param.put("area_app", drip_area_as_per_application_str);
                param.put("area_actual", drip_area_of_application_actual_edt.getText().toString().trim());
                param.put("area_seven_years", drip_area_benefitted_in_last_7_years.getText().toString().trim());
                param.put("bill_invoice_no_app", drip_bill_invoice_no_str);
                param.put("bill_invoice_no_actual", drip_bill_invoice_no_actual_edt.getText().toString().trim());
                param.put("bill_invoice_date_app", drip_bill_invoice_date_str);
                param.put("bill_invoice_date_actual", drip_bill_invoice_date_actual);
                param.put("bill_invoice_amt_app", drip_bill_invoice_amount_str);
                param.put("bill_invoice_amt_actual", drip_bill_invoice_amount_actual_edt.getText().toString().trim());
                param.put("bill_invoice_doc", drip_bill_invoice_date_str);
                param.put("gstn_app", drip_GSTN_str);
                param.put("gstn_actual", drip_GSTN_actual_edt.getText().toString().trim());
                param.put("date_pre_sanction", drip_date_of_presanction_str);
                param.put("pre_letter_doc", drip_date_of_presanction_str);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.drip_form_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 6);

        }
    }

    private void date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        c.add(Calendar.DAY_OF_YEAR, -730);
        Date newDate = c.getTime();

        datePickerDialog = new DatePickerDialog(DripFormActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        drip_bill_invoice_date_actual = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                        drip_bill_invoice_date_actual_edt.setText(drip_bill_invoice_date_actual);
                    }
                }, mYear, mMonth, mDay);

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        datePickerDialog.show();
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_field_data = jsonObject.getJSONArray("data");
                            for (int j = 0; j < drip_field_data.length(); j++) {
                                JSONObject drip_field_data_json_object = drip_field_data.getJSONObject(j);
                                String id = drip_field_data_json_object.getString("id");
                                drip_name_of_the_beneficiary_str = drip_field_data_json_object.getString("drip_name_of_the_beneficiary_str");
                                drip_application_number_str = drip_field_data_json_object.getString("drip_application_number_str");
                                drip_social_categroy_of_the_beneficiary_str = drip_field_data_json_object.getString("drip_social_categroy_of_the_beneficiary_str");
                                drip_name_of_the_component_str = drip_field_data_json_object.getString("drip_name_of_the_component_str");
                                drip_specification_of_the_component_str = drip_field_data_json_object.getString("drip_specification_of_the_component_str");
                                drip_name_of_the_scheme_str = drip_field_data_json_object.getString("drip_name_of_the_scheme_str");
                                drip_crop_name_str = drip_field_data_json_object.getString("drip_crop_name_str");
                                drip_manufacturer_str = drip_field_data_json_object.getString("drip_manufacturer_str");
                                drip_dealer_str = drip_field_data_json_object.getString("drip_dealer_str");
                                drip_area_as_per_application_str = drip_field_data_json_object.getString("drip_area_as_per_application_str");
                                drip_area_benefitted_in_last_7_years_str = drip_field_data_json_object.getString("drip_area_benefitted_in_last_7_years_str");
                                drip_bill_invoice_no_str = drip_field_data_json_object.getString("drip_bill_invoice_no_str");
                                drip_bill_invoice_date_str = drip_field_data_json_object.getString("drip_bill_invoice_date_str");
                                drip_bill_invoice_amount_str = drip_field_data_json_object.getString("drip_bill_invoice_amount_str");
                                drip_GSTN_str = drip_field_data_json_object.getString("drip_GSTN_str");
                                drip_date_of_presanction_str = drip_field_data_json_object.getString("drip_date_of_presanction_str");
                                drip_date_of_spot_verification_str = drip_field_data_json_object.getString("drip_date_of_spot_verification_str");

                                drip_name_of_the_beneficiary.setText(drip_name_of_the_beneficiary_str);
                                drip_application_number.setText(drip_application_number_str);
                                drip_social_categroy_of_the_beneficiary.setText(drip_social_categroy_of_the_beneficiary_str);
                                //drip_specification_of_the_component.setText(drip_specification_of_the_component_str);
                                drip_name_of_the_scheme.setText(drip_name_of_the_scheme_str);
                                drip_crop_name_app.setText(drip_crop_name_str);
                                //drip_manufacturer.setText(drip_manufacturer_str);
                                //drip_dealer.setText(drip_dealer_str);
                                drip_area_as_per_application.setText(drip_area_as_per_application_str);
                                drip_name_of_the_component.setText(drip_name_of_the_component_str);
                                //drip_area_benefitted_in_last_7_years.setText(drip_area_benefitted_in_last_7_years_str);
                                drip_bill_invoice_no.setText(drip_bill_invoice_no_str);
                                drip_bill_invoice_date.setText(drip_bill_invoice_date_str);
                                drip_bill_invoice_amount.setText(drip_bill_invoice_amount_str);
                                drip_GSTN.setText(drip_GSTN_str);
                                drip_date_of_presanction.setText(drip_date_of_presanction_str);
                                //drip_date_of_spot_verification.setText(drip_date_of_spot_verification_str);

                            }

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_system_type_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_spacing_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_manufacturers_list = jsonObject.getJSONArray("data");
                            for(int j=0;j<drip_manufacturers_list.length();j++){
                                JSONObject manufacture_data = drip_manufacturers_list.getJSONObject(j);
                                String manufacture_id_str =  manufacture_data.getString("manuf_code");
                                manufacture_id = Integer.parseInt(manufacture_id_str);
                            }
                        }
                    }else{
                        Toast.makeText(DripFormActivity.this,"No manufacturer present in this district",Toast.LENGTH_LONG).show();
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_dealers_list = jsonObject.getJSONArray("data");
                        }
                    }else{
                        Toast.makeText(DripFormActivity.this,"No dealers present against this manufacturer",Toast.LENGTH_LONG).show();
                    }
                }

                if (i == 6) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("Submitted successfully")
                                .setContentText(jsonObject.getString("response"))
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                         Intent intent = new Intent(DripFormActivity.this, SpotVerificationActivity.class);
                                         startActivity(intent);
                                         finish();
                                    }
                                })
                                .show();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 2) {
            drip_system_id = Integer.parseInt(s1);
            drip_system_name = s;
            drip_system_type.setText(drip_system_name);

        }

        if (i == 3) {
            drip_spacing_id = Integer.parseInt(s1);
            drip_spacing_name = s;
            drip_spacing_actual.setText(drip_spacing_name);

        }

        if (i == 4) {
            drip_manuf_id = Integer.parseInt(s1);
            drip_manufacturers_name = s;
            drip_manufacturer.setText(drip_manufacturers_name);
            drip_dealers_service();
            drip_dealers_list = new JSONArray();
            drip_dealer.setText("Select");

        }

        if (i == 5) {
            drip_dealers_id = Integer.parseInt(s1);
            drip_dealers_name = s;
            drip_dealer.setText(drip_dealers_name);

        }
    }
}
