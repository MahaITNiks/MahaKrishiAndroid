/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.host_gusest_farmer;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.TaskManagerReport.SchemeListReportActivity;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.GuestFarmerEditModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.widget.UIToastMessage;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class EditGuestFarmerActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {


    private EditText lNameEditText;
    private EditText fNameEditText;
    private EditText mNameEditText;
    private EditText ageEditText;
    private EditText mobEditText;
    private RadioButton maleRadioButton;
    private RadioButton femaleRadioButton;
    private RadioButton transgenderRadioButton;

    private RadioButton yesRadioButton;
    private RadioButton noRadioButton;


    private TextView socialCatDropTextView;

    private int socialCatId = 0;
    private JSONArray mDataArray;
    private AppSession session;


    private int genderId = -1;
    private int physicallyId = -1;
    private AppString appString;
    private GuestFarmerEditModel model;
    private boolean isUpdated = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_edit_guest_farmer);

        initComponents();
        setConfiguration();

    }



    private void initComponents() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        lNameEditText = findViewById(R.id.lNameEditText);
        fNameEditText = findViewById(R.id.fNameEditText);
        mNameEditText = findViewById(R.id.mNameEditText);
        ageEditText = findViewById(R.id.ageEditText);
        mobEditText = findViewById(R.id.mobEditText);

        maleRadioButton = findViewById(R.id.maleRadioButton);
        femaleRadioButton = findViewById(R.id.femaleRadioButton);
        transgenderRadioButton = findViewById(R.id.transgenderRadioButton);

        yesRadioButton = findViewById(R.id.yesRadioButton);
        noRadioButton = findViewById(R.id.noRadioButton);


//        talukaDropTextView = findViewById(R.id.talukaDropTextView);
//        villDropTextView = findViewById(R.id.villDropTextView);
//        plotDropTextView = findViewById(R.id.plotDropTextView);
        socialCatDropTextView = findViewById(R.id.socialCatDropTextView);

        appString = new AppString(this);
        session = new AppSession(this);
    }

    private void setConfiguration() {


        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                  @Override
                                                  public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                      if (checkedId == R.id.maleRadioButton) {
                                                          genderId = 1;
                                                      } else if (checkedId == R.id.femaleRadioButton) {
                                                          genderId = 2;
                                                      } else {
                                                          genderId = 3;
                                                      }
                                                  }
                                              }
        );

        RadioGroup physicallyRadioGroup = findViewById(R.id.physicallyRadioGroup);
        physicallyRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                            @Override
                                                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                                if (checkedId == R.id.yesRadioButton) {
                                                                    physicallyId = 1;
                                                                } else if (checkedId == R.id.noRadioButton) {
                                                                    physicallyId = 0;
                                                                }
                                                            }
                                                        }
        );

        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isUpdated) {
                    EventBus.getDefault().post(new EventModel("update_1"));
                }
                finish();
            }
        });


        socialCatDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSocialCategory();
            }
        });

        findViewById(R.id.updateButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validatePostRequest();
            }
        });

        fetchSocialCategoryMasterData();


        String data = null;
        if (getIntent().getStringExtra("mDetails") != null) {
            data = getIntent().getStringExtra("mDetails");
        }
        try {
            JSONObject jsonObject = new JSONObject(data);
            model = new GuestFarmerEditModel(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        lNameEditText.setText(model.getLast_name());
        fNameEditText.setText(model.getFirst_name());
        mNameEditText.setText(model.getMiddle_name());

        if (model.getGender() == 1) {
            RadioButton maleRadioButton = findViewById(R.id.maleRadioButton);
            maleRadioButton.setChecked(true);
        }

        if (model.getGender() == 2) {
            RadioButton femaleRadioButton = findViewById(R.id.femaleRadioButton);
            femaleRadioButton.setChecked(true);
        }

        if (model.getGender() == 3) {
            RadioButton transgenderRadioButton = findViewById(R.id.transgenderRadioButton);
            transgenderRadioButton.setChecked(true);
        }

        ageEditText.setText(model.getAge());
        mobEditText.setText(model.getMobile());
        socialCatDropTextView.setText(model.getSocial_category_name());
        socialCatId = model.getSocial_category_id();

        if (model.getPhysically_challenged() == 1) {
            RadioButton pYesRadioButton = findViewById(R.id.yesRadioButton);
            pYesRadioButton.setChecked(true);
        }

        if (model.getPhysically_challenged() == 0) {
            RadioButton pNoRadioButton = findViewById(R.id.noRadioButton);
            pNoRadioButton.setChecked(true);
        }

        physicallyId = model.getPhysically_challenged();



    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (isUpdated) {
                    EventBus.getDefault().post(new EventModel("update_1"));
                }
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void onHomeButtonAction() {

        Intent intent = new Intent(this, SchemeListReportActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();

    }

    private void askUserPermission() {
        AppString appString = new AppString(this);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage(appString.getHomeAlertMsg());
        alertDialogBuilder.setPositiveButton(appString.getNO(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setNegativeButton(appString.getYES(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        onHomeButtonAction();
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    private void navigateActivity() {
        finish();
    }



    private void showSocialCategory() {
        if (mDataArray == null) {
            fetchSocialCategoryMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(mDataArray, 4, "Select Social Category", "name", "id", this, this);
        }
    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

/*
        if (i == 1) {
            getVillageAgainstTaluka(s1);
            talukaID = Integer.parseInt(s1);
            talukaDropTextView.setText(s);

            villageID = 0;
            villDropTextView.setText("");
            villDropTextView.setHint(getResources().getString(R.string.ffs_village_select_village));

            plotID = 0;
            plotDropTextView.setText("");
            plotDropTextView.setHint(getResources().getString(R.string.ffs_village_select_plot));

        }

        if (i == 2) {
            getPlotAgainstVillage(s1);
            villageID = Integer.parseInt(s1);
            villDropTextView.setText(s);

            plotID = 0;
            plotDropTextView.setText("");
            plotDropTextView.setHint(getResources().getString(R.string.ffs_village_select_plot));

        }

        if (i == 3) {
            plotID = Integer.parseInt(s1);
            plotDropTextView.setText(s);
        }*/


        if (i == 4) {
            socialCatId = Integer.parseInt(s1);
            socialCatDropTextView.setText(s);
        }

    }


    private void fetchSocialCategoryMasterData() {

        String url = APIServices.kSocialCat;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                mDataArray = response.getData();
                            } else {
                                UIToastMessage.show(EditGuestFarmerActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    private void validatePostRequest() {

        try {

            String lName = lNameEditText.getText().toString();
            String fName = fNameEditText.getText().toString();
            String mName = mNameEditText.getText().toString();
            String age = ageEditText.getText().toString();
            String mob = mobEditText.getText().toString();


            if (lName.isEmpty()) {
                UIToastMessage.show(this, "Please enter last name");

            } else if (fName.isEmpty()) {
                UIToastMessage.show(this, "Please enter first name");

            } else if (mName.isEmpty()) {
                UIToastMessage.show(this, "Please enter middle name");

            } else if (genderId == -1) {
                UIToastMessage.show(this, "Please select gender");

            } else if (age.isEmpty()) {
                UIToastMessage.show(this, "Please enter gae");

            } else if (age.length() < 2) {
                UIToastMessage.show(this, "Please enter valid age");

            } else if (Integer.parseInt(age) < 15) {
                UIToastMessage.show(this, "Your age should be greater than 15 year");

            } else if (mob.isEmpty()) {
                UIToastMessage.show(this, "Please enter mobile number");

            } else if (!AppUtility.getInstance().isValidPhoneNumber(mob)) {
                UIToastMessage.show(this, "Please enter valid mobile number");

            } else if (socialCatId == 0) {
                UIToastMessage.show(this, "Please select social category");

            } else if (physicallyId == -1) {
                UIToastMessage.show(this, "Please select physically challenged");

            } else {


                JSONObject jsonObject = new JSONObject();


                jsonObject.put("farmer_id", model.getGuest_farmer_id());
                jsonObject.put("last_name", lName);
                jsonObject.put("first_name", fName);
                jsonObject.put("middle_name", mName);
                jsonObject.put("gender", genderId);
                jsonObject.put("age", age);
                jsonObject.put("mobile", mob);

                jsonObject.put("social_category_id", socialCatId);
                jsonObject.put("physically_challenged", physicallyId);

                jsonObject.put("lat", "");
                jsonObject.put("lon", "")

                /*jsonObject.put("lat", String.valueOf(appLocationManager.getLatitude()));
                jsonObject.put("lon", String.valueOf(appLocationManager.getLongitude()))*/;


                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.updateGuestFarmer(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 2);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void clearSelected() {

        lNameEditText.setText("");
        fNameEditText.setText("");
        mNameEditText.setText("");
        ageEditText.setText("");
        mobEditText.setText("");
        socialCatDropTextView.setText("");
        socialCatId = 0;

        maleRadioButton.setChecked(false);
        femaleRadioButton.setChecked(false);
        transgenderRadioButton.setChecked(false);

        yesRadioButton.setChecked(false);
        noRadioButton.setChecked(false);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (i == 2) {
                if (jsonObject != null) {
                    ResponseModel response = new ResponseModel(jsonObject);

                    if (response.isStatus()) {
                        isUpdated = true;
                        UIToastMessage.show(this, response.getMsg());
                        clearSelected();

                    } else {
                        UIToastMessage.show(this, response.getMsg());
                    }
                }

            }



        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
