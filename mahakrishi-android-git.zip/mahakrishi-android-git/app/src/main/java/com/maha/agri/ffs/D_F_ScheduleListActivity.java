package com.maha.agri.ffs;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_ScheduleListActivity extends AppCompatActivity implements ApiCallbackCode {

    private PreferenceManager preferenceManager;
    private String planId;
    private String userID;
    private String villageId;
    private Button preSowing, sowingVisit, visitsScheduledButton;
    private String reg_type;
    private String cropID = "";
    private String cropVerityID = "";
    private String crop1Id;
    private String crop1VerityId;
    private String crop2Id;
    private String crop2VerityId;
    private RadioGroup cropRadioGroup;
    private RadioButton crop1RadioButton;
    private RadioButton crop2RadioButton;

    private boolean isPreShowingComplete = false;
    private boolean isShowingComplete = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_schedule_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(D_F_ScheduleListActivity.this);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);
        villageId = AppSettings.getInstance().getValue(this, ApConstants.kVILLAGE_ID_DEMO_FFS, ApConstants.kVILLAGE_ID_DEMO_FFS);
        userID = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            getSupportActionBar().setTitle("Demonstration visits");
        } else {
            getSupportActionBar().setTitle("FFS visits");
        }

        init();
        defaultConfig();
    }

    @Override
    protected void onResume() {
        super.onResume();

        String planData = getIntent().getStringExtra("cropDetail");
        try {
            JSONObject cropJSON = new JSONObject(planData);
            String cropDetail = cropJSON.getString("crop_data");
            JSONArray cropArray = new JSONArray(cropDetail);

            if (cropArray.length() > 1) {
                cropRadioGroup.setVisibility(View.VISIBLE);
                JSONObject crop1_data = cropArray.getJSONObject(0);

                crop1Id = crop1_data.getString("crop_id");
                crop1VerityId = crop1_data.getString("crop_verity_id");
                String crop1Name = crop1_data.getString("crop_name");
                crop1RadioButton.setText(crop1Name);

                JSONObject crop2_data = cropArray.getJSONObject(1);
                crop2Id = crop2_data.getString("crop_id");
                crop2VerityId = crop1_data.getString("crop_verity_id");
                String crop2Name = crop2_data.getString("crop_name");
                crop2RadioButton.setText(crop2Name);

            } else {
                cropRadioGroup.setVisibility(View.GONE);
                JSONObject crop_data = cropArray.getJSONObject(0);
                cropID = crop_data.getString("crop_id");
                cropVerityID = crop_data.getString("crop_verity_id");
                getPreShowingVisit();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void init() {
        cropRadioGroup = (RadioGroup) findViewById(R.id.cropRadioGroup);
        preSowing = (Button) findViewById(R.id.demo_pre_sowing_visits);
        sowingVisit = (Button) findViewById(R.id.demo_sowing_visit);
        visitsScheduledButton = (Button) findViewById(R.id.visitsScheduledButton);
        crop1RadioButton = (RadioButton) findViewById(R.id.crop1RadioButton);
        crop2RadioButton = (RadioButton) findViewById(R.id.crop2RadioButton);
    }

    private void defaultConfig() {

        cropRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.crop1RadioButton) {
                    cropID = crop1Id;
                    cropVerityID = crop1VerityId;
                }
                if (i == R.id.crop2RadioButton) {
                    cropID = crop2Id;
                    cropVerityID = crop2VerityId;
                }
                getPreShowingVisit();
            }
        });


        preSowing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!cropID.equalsIgnoreCase("")) {
                    AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_ID_DEMO_FFS, cropID);
                    AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, cropVerityID);
                    Intent intent = new Intent(D_F_ScheduleListActivity.this, D_F_PreSowingVisitListActivity.class);
                    startActivity(intent);
                } else {
                    UIToastMessage.show(D_F_ScheduleListActivity.this, "Please select crop");
                }
            }
        });

        sowingVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!cropID.equalsIgnoreCase("")) {
                    if (!isPreShowingComplete) {
                        UIToastMessage.show(D_F_ScheduleListActivity.this, "Please complete Pre Showing Visit");
                    } else{
                        AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_ID_DEMO_FFS, String.valueOf(cropID));
                        AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, cropVerityID);
                        Intent intent = new Intent(D_F_ScheduleListActivity.this, D_F_SowingVisitActivity.class);
                        startActivity(intent);
                    }

                } else {
                    UIToastMessage.show(D_F_ScheduleListActivity.this, "Please select crop");
                }
            }
        });

        visitsScheduledButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isPreShowingComplete) {
                    UIToastMessage.show(D_F_ScheduleListActivity.this, "Please complete Pre Showing Visit");
                } else if (!isShowingComplete) {
                    UIToastMessage.show(D_F_ScheduleListActivity.this, "Please complete Showing Visit");
                } else {
                    if (!cropID.equalsIgnoreCase("")) {
                        AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_ID_DEMO_FFS, String.valueOf(cropID));
                        AppSettings.getInstance().setValue(D_F_ScheduleListActivity.this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, cropVerityID);
                        Intent intent = new Intent(D_F_ScheduleListActivity.this, D_F_VisitScheduleActivity.class);
                        startActivity(intent);
                    } else {
                        UIToastMessage.show(D_F_ScheduleListActivity.this, "Please select crop");
                    }
                }
            }
        });
    }


    private void getPreShowingVisit() {
        JSONObject param = new JSONObject();
        try {
            param.put("plan_id", planId);
            param.put("crop_id", cropID);
            param.put("vareity_id", cropVerityID);
            param.put("reg_type", reg_type);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.getPreShowingList(requestBody);
        DebugLog.getInstance().d("get_pre_showing_list=" + responseCall.request().toString());
        DebugLog.getInstance().d("get_pre_showing_list=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void getShowingVisitDetail() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", userID);
            param.put("village_id", villageId);
            param.put("crop_id", cropID);
            param.put("vareity_id", cropVerityID);
            param.put("plan_id", planId);
            param.put("reg_type", reg_type);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.getShowingVisitDetail(requestBody);

        DebugLog.getInstance().d("get_Showing Detail=" + responseCall.request().toString());
        DebugLog.getInstance().d("get_Showing Detail=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {
            if (jsonObject != null) {

                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        JSONArray preShowing_data = jsonObject.getJSONArray("data");
                        if (preShowing_data.length() > 0) {
                            for (int d = 0; d < preShowing_data.length(); d++) {
                                JSONObject pDataJSON = preShowing_data.getJSONObject(d);
                                JSONArray jsonArray = pDataJSON.getJSONArray("activities");
                                if (jsonArray.length() > 0) {
                                    for (int a = 0; a < jsonArray.length(); a++) {
                                        JSONObject actJSON = jsonArray.getJSONObject(a);
                                        String isCompleted = actJSON.getString("is_submitted");
                                        if (isCompleted.equalsIgnoreCase("0") || isCompleted.equalsIgnoreCase("null")) {
                                            isPreShowingComplete = false;
                                            break;
                                        } else {
                                            isPreShowingComplete = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    getShowingVisitDetail();
                }


                if (i == 2) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        JSONArray showing_data = jsonObject.getJSONArray("data");
                        if (showing_data.length() > 0) {
                            isShowingComplete = true;
                        } else {
                            isShowingComplete = false;
                        }
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
