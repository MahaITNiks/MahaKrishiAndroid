package com.maha.agri.dept_cropsap;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class SoyabeanCropPheromoneActivity extends AppCompatActivity {

    EditText edt_trap1_Spodoptera_soyabeanP, edt_trap2_Spodoptera_soyabeanP, edt_trap1_Helicoverpa_soyabeanP, edt_trap2_Helicoverpa_soyabeanP;
    private Button soybeanP_savecontinue;
    private SweetAlertDialog sweetAlertDialog;
    private String str_trap1_Spodoptera_soyabeanP="",str_trap2_Spodoptera_soyabeanP="",str_trap1_Helicoverpa_soyabeanP="",str_trap2_Helicoverpa_soyabeanP="";
    private int district_id = 0, taluka_id = 0, village_id = 0, farmer_id = 0;
    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soyabean_crop_pheromone);
        getSupportActionBar().setTitle("Soybean Pheromone");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SoyabeanCropPheromoneActivity.this);
        sharedPref = new SharedPref(SoyabeanCropPheromoneActivity.this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        village_id = intent.getIntExtra("village_id", 0);

        initView();
        setListners();

    }

    private void initView(){
        edt_trap1_Spodoptera_soyabeanP = (EditText) findViewById(R.id.edt_trap1_Spodoptera_soyabeanP);
        edt_trap2_Spodoptera_soyabeanP = (EditText)findViewById(R.id.edt_trap2_Spodoptera_soyabeanP);
        edt_trap1_Helicoverpa_soyabeanP = (EditText)findViewById(R.id.edt_trap1_Helicoverpa_soyabeanP);
        edt_trap2_Helicoverpa_soyabeanP = (EditText)findViewById(R.id.edt_trap2_Helicoverpa_soyabeanP);
        soybeanP_savecontinue = (Button)findViewById(R.id.soybeanP_savecontinue);
    }

    private void setListners(){

        soybeanP_savecontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_trap1_Spodoptera_soyabeanP = edt_trap1_Spodoptera_soyabeanP.getText().toString().trim();
                str_trap2_Spodoptera_soyabeanP = edt_trap2_Spodoptera_soyabeanP.getText().toString().trim();
                str_trap1_Helicoverpa_soyabeanP = edt_trap1_Helicoverpa_soyabeanP.getText().toString().trim();
                str_trap2_Helicoverpa_soyabeanP = edt_trap2_Helicoverpa_soyabeanP.getText().toString().trim();

                if (str_trap1_Spodoptera_soyabeanP.equalsIgnoreCase("")) {
                    Toast.makeText(SoyabeanCropPheromoneActivity.this, "Enter no. of adults/trap in Spodoptera trap1 ", Toast.LENGTH_SHORT).show();
                } else if (str_trap2_Spodoptera_soyabeanP.equalsIgnoreCase("")) {
                    Toast.makeText(SoyabeanCropPheromoneActivity.this, "Enter no. of adults/trap in Spodoptera trap2", Toast.LENGTH_SHORT).show();
                } else if (str_trap1_Helicoverpa_soyabeanP.equalsIgnoreCase("")) {
                    Toast.makeText(SoyabeanCropPheromoneActivity.this, "Enter no. of adults/trap in Helicoverpa trap1", Toast.LENGTH_SHORT).show();
                } else if (str_trap2_Helicoverpa_soyabeanP.equalsIgnoreCase("")) {
                    Toast.makeText(SoyabeanCropPheromoneActivity.this, "Enter no. of adults/trap in Helicoverpa trap2", Toast.LENGTH_SHORT).show();
                } else {
                    sweetAlertDialog = new SweetAlertDialog(SoyabeanCropPheromoneActivity.this, SweetAlertDialog.SUCCESS_TYPE);
                    sweetAlertDialog.setTitleText("Soybean Pheromone");
                    sweetAlertDialog.setContentText("Data saved successfully");
                    sweetAlertDialog.setConfirmText("Ok");
                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            Intent intent = new Intent(SoyabeanCropPheromoneActivity.this,SoyabeanOtherWorkActivity.class);
                            intent.putExtra("district_id",district_id);
                            intent.putExtra("taluka_id",taluka_id);
                            intent.putExtra("village_id",village_id);
                            intent.putExtra("trap1_spodoptera",str_trap1_Spodoptera_soyabeanP);
                            intent.putExtra("trap2_spodoptera",str_trap2_Spodoptera_soyabeanP);
                            intent.putExtra("trap1_helicoverpa",str_trap1_Helicoverpa_soyabeanP);
                            intent.putExtra("trap2_helicoverpa",str_trap2_Helicoverpa_soyabeanP);
                            startActivity(intent);
                            finish();
                        }
                    });
                    sweetAlertDialog.show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
