package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SorghumOtherWorkActivity extends AppCompatActivity implements ApiCallbackCode {

    private EditText tradename_insecticide_sorghumOW,quantity_used_acre_insecticide_sorghumOW,tradename_fungicide_sorghumOW,quantity_used_acre_fungicide_sorghumOW,
            tradename_weedicide_sorghumOW,quantity_used_acre_weedicide_sorghumOW,fertilizer_sorghumOW_N,fertilizer_sorghumOW_P,fertilizer_sorghumOW_K,fertilizername_sorghumOW,quantity_used_acre_fertilizer_sorghumOW;

    private ImageView pest_sorghumOW_photo,crop_growth_sorghumOW_photo;

    private Button btn_sorghumOW_submit;

    private Spinner sp_technicalname_insecticide_sorghumOW,sp_technicalname_fungicide_sorghumOW,sp_weedicide_technicalname_sorghumOW,
            sp_irrigation_given_sorghumOW;

    private RadioGroup insecticide_radio_group_sorghumOW,fungicide_radio_group_sorghumOW,weedicide_radio_group_sorghumOW,
            fertilizer_radio_group_sorghumOW, radio_group_intercultural_sorghumOW, radio_group_irrigation_field_sorghumOW;

    private RadioButton insecticide_sorghumOW_yes,insecticide_sorghumOW_no,fungicide_sorghumOW_yes,fungicide_sorghumOW_no,
            weedicide_sorghumOW_yes,weedicide_sorghumOW_no,fertilizer_sorghumOW_yes,fertilizer_sorghumOW_no,
            weeding_sorghumOW_rb,hoeing_sorghumOW_rb,detopping_sorghumOW_rb,none_sorghumOW_rb,irrigation_sorghumOW_yes,
            irrigation_sorghumOW_no;

    private LinearLayout ll_insecticide_layout_sorghumOW,ll_fungicide_layout_sorghumOW,ll_weedicide_layout_sorghumOW,
            ll_fertilizer_layout_sorghumOW;

    private RelativeLayout irrigation_layout_sorghumOW;

    private String insecticide,fungicide,weedicide,fertilizer,irrigation,intercultural;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    private int district_id=0, taluka_id=0, village_id=0, farmer_id=0;
    private String fall_trap1="",fall_trap2="",fall_trap1_photo="",fall_trap2_photo="";

    //Image
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private String imagePath1="", imagePath2="",type="";
    private String image_1_file_name="",image_2_file_name="";
    public double lat,lang;
    private AppLocationManager locationManager;

    private String insec_tech_name="",fungi_tech_name="",weedi_tech_name="",irrigation_name="";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sorghum_other_work);
        getSupportActionBar().setTitle("Other Works");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SorghumOtherWorkActivity.this);
        sharedPref = new SharedPref(SorghumOtherWorkActivity.this);
        locationManager = new AppLocationManager(this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        fall_trap1 = intent.getStringExtra("fall_armyworm_trap1");
        fall_trap2 = intent.getStringExtra("fall_armyworm_trap2");
        fall_trap1_photo = intent.getStringExtra("fall_armyworm_trap1_photo");
        fall_trap2_photo = intent.getStringExtra("fall_armyworm_trap2_photo");

        initView();
        setListners();
    }

    private void initView() {


        //Spinner
        sp_technicalname_insecticide_sorghumOW = (Spinner)findViewById(R.id.sp_technicalname_insecticide_sorghumOW);
        sp_technicalname_fungicide_sorghumOW = (Spinner)findViewById(R.id.sp_technicalname_fungicide_sorghumOW);
        sp_weedicide_technicalname_sorghumOW = (Spinner)findViewById(R.id.sp_weedicide_technicalname_sorghumOW);
        sp_irrigation_given_sorghumOW = (Spinner)findViewById(R.id.sp_irrigation_given_sorghumOW);

        // EDIT TEXT
        tradename_insecticide_sorghumOW = (EditText)findViewById(R.id.tradename_insecticide_sorghumOW);
        quantity_used_acre_insecticide_sorghumOW = (EditText)findViewById(R.id.quantity_used_acre_insecticide_sorghumOW);
        tradename_fungicide_sorghumOW = (EditText)findViewById(R.id.tradename_fungicide_sorghumOW);
        quantity_used_acre_fungicide_sorghumOW = (EditText)findViewById(R.id.quantity_used_acre_fungicide_sorghumOW);
        tradename_weedicide_sorghumOW = (EditText)findViewById(R.id.tradename_weedicide_sorghumOW);
        quantity_used_acre_weedicide_sorghumOW = (EditText)findViewById(R.id.quantity_used_acre_weedicide_sorghumOW);
        fertilizer_sorghumOW_N = (EditText)findViewById(R.id.fertilizer_sorghumOW_N);
        fertilizer_sorghumOW_P = (EditText)findViewById(R.id.fertilizer_sorghumOW_P);
        fertilizer_sorghumOW_K = (EditText)findViewById(R.id.fertilizer_sorghumOW_K);
        fertilizername_sorghumOW = (EditText)findViewById(R.id.fertilizername_sorghumOW);
        quantity_used_acre_fertilizer_sorghumOW = (EditText)findViewById(R.id.quantity_used_acre_fertilizer_sorghumOW);

        //Imageview
        //pest_sorghumOW_photo = (ImageView) findViewById(R.id.pest_sorghumOW_photo);
        crop_growth_sorghumOW_photo = (ImageView) findViewById(R.id.crop_growth_sorghumOW_photo);

        //Radiogroup
        insecticide_radio_group_sorghumOW = (RadioGroup) findViewById(R.id.insecticide_radio_group_sorghumOW);
        fungicide_radio_group_sorghumOW = (RadioGroup) findViewById(R.id.fungicide_radio_group_sorghumOW);
        weedicide_radio_group_sorghumOW = (RadioGroup) findViewById(R.id.weedicide_radio_group_sorghumOW);
        fertilizer_radio_group_sorghumOW = (RadioGroup) findViewById(R.id.fertilizer_radio_group_sorghumOW);
        radio_group_intercultural_sorghumOW = (RadioGroup) findViewById(R.id.radio_group_intercultural_sorghumOW);
        radio_group_irrigation_field_sorghumOW = (RadioGroup) findViewById(R.id.radio_group_irrigation_field_sorghumOW);

        //Radiobutton
        insecticide_sorghumOW_yes = (RadioButton) findViewById(R.id.insecticide_sorghumOW_yes);
        insecticide_sorghumOW_no = (RadioButton) findViewById(R.id.insecticide_sorghumOW_no);
        fungicide_sorghumOW_yes = (RadioButton) findViewById(R.id.fungicide_sorghumOW_yes);
        fungicide_sorghumOW_no = (RadioButton) findViewById(R.id.fungicide_sorghumOW_no);
        weedicide_sorghumOW_yes = (RadioButton) findViewById(R.id.weedicide_sorghumOW_yes);
        weedicide_sorghumOW_no = (RadioButton) findViewById(R.id.weedicide_sorghumOW_no);
        fertilizer_sorghumOW_yes = (RadioButton) findViewById(R.id.fertilizer_sorghumOW_yes);
        fertilizer_sorghumOW_no = (RadioButton) findViewById(R.id.fertilizer_sorghumOW_no);
        weeding_sorghumOW_rb = (RadioButton) findViewById(R.id.weeding_sorghumOW_rb);
        hoeing_sorghumOW_rb = (RadioButton) findViewById(R.id.hoeing_sorghumOW_rb);
        detopping_sorghumOW_rb = (RadioButton) findViewById(R.id.detopping_sorghumOW_rb);
        none_sorghumOW_rb = (RadioButton) findViewById(R.id.none_sorghumOW_rb);
        irrigation_sorghumOW_yes = (RadioButton) findViewById(R.id.irrigation_sorghumOW_yes);
        irrigation_sorghumOW_no = (RadioButton) findViewById(R.id.irrigation_sorghumOW_no);

        //Linear Layout
        ll_insecticide_layout_sorghumOW = (LinearLayout)findViewById(R.id.ll_insecticide_layout_sorghumOW);
        ll_fungicide_layout_sorghumOW = (LinearLayout)findViewById(R.id.ll_fungicide_layout_sorghumOW);
        ll_weedicide_layout_sorghumOW = (LinearLayout)findViewById(R.id.ll_weedicide_layout_sorghumOW);
        ll_fertilizer_layout_sorghumOW = (LinearLayout)findViewById(R.id.ll_fertilizer_layout_sorghumOW);
        irrigation_layout_sorghumOW = (RelativeLayout) findViewById(R.id.irrigation_layout_sorghumOW);

        //Button
        btn_sorghumOW_submit = (Button)findViewById(R.id.btn_sorghumOW_submit);

    }

    private void setListners() {

        insecticide_radio_group_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.insecticide_sorghumOW_yes:
                        insecticide_sorghumOW_yes.setChecked(true);
                        ll_insecticide_layout_sorghumOW.setVisibility(View.VISIBLE);
                        insecticide = insecticide_sorghumOW_yes.getText().toString();
                        break;

                    case R.id.insecticide_sorghumOW_no:
                        insecticide_sorghumOW_no.setChecked(true);
                        ll_insecticide_layout_sorghumOW.setVisibility(View.GONE);
                        insecticide = insecticide_sorghumOW_yes.getText().toString();
                        break;
                }
            }
        });

        fungicide_radio_group_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fungicide_sorghumOW_yes:
                        fungicide_sorghumOW_yes.setChecked(true);
                        ll_fungicide_layout_sorghumOW.setVisibility(View.VISIBLE);
                        fungicide = fungicide_sorghumOW_yes.getText().toString();
                        break;

                    case R.id.fungicide_sorghumOW_no:
                        fungicide_sorghumOW_no.setChecked(true);
                        ll_fungicide_layout_sorghumOW.setVisibility(View.GONE);
                        fungicide = fungicide_sorghumOW_yes.getText().toString();
                        break;
                }
            }
        });

        weedicide_radio_group_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.weedicide_sorghumOW_yes:
                        weedicide_sorghumOW_yes.setChecked(true);
                        ll_weedicide_layout_sorghumOW.setVisibility(View.VISIBLE);
                        weedicide = weedicide_sorghumOW_yes.getText().toString();
                        break;

                    case R.id.weedicide_sorghumOW_no:
                        weedicide_sorghumOW_no.setChecked(true);
                        ll_weedicide_layout_sorghumOW.setVisibility(View.GONE);
                        weedicide = weedicide_sorghumOW_yes.getText().toString();
                        break;
                }
            }
        });

        fertilizer_radio_group_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fertilizer_sorghumOW_yes:
                        fertilizer_sorghumOW_yes.setChecked(true);
                        ll_fertilizer_layout_sorghumOW.setVisibility(View.VISIBLE);
                        fertilizer = fertilizer_sorghumOW_yes.getText().toString();
                        break;

                    case R.id.fertilizer_sorghumOW_no:
                        fertilizer_sorghumOW_no.setChecked(true);
                        ll_fertilizer_layout_sorghumOW.setVisibility(View.GONE);
                        fertilizer = fertilizer_sorghumOW_yes.getText().toString();
                        break;
                }
            }
        });

        radio_group_intercultural_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.weeding_sorghumOW_rb:
                        weeding_sorghumOW_rb.setChecked(true);
                        intercultural = weeding_sorghumOW_rb.getText().toString();
                        break;

                    case R.id.hoeing_sorghumOW_rb:
                        hoeing_sorghumOW_rb.setChecked(true);
                        intercultural = hoeing_sorghumOW_rb.getText().toString();
                        break;

                    case R.id.detopping_sorghumOW_rb:
                        detopping_sorghumOW_rb.setChecked(true);
                        intercultural = detopping_sorghumOW_rb.getText().toString();
                        break;

                    case R.id.none_sorghumOW_rb:
                        none_sorghumOW_rb.setChecked(true);
                        intercultural = none_sorghumOW_rb.getText().toString();
                        break;
                }
            }
        });

        radio_group_irrigation_field_sorghumOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.irrigation_sorghumOW_yes:
                        irrigation_sorghumOW_yes.setChecked(true);
                        irrigation_layout_sorghumOW.setVisibility(View.VISIBLE);
                        irrigation = irrigation_sorghumOW_yes.getText().toString();
                        break;

                    case R.id.irrigation_sorghumOW_no:
                        irrigation_sorghumOW_no.setChecked(true);
                        irrigation_layout_sorghumOW.setVisibility(View.GONE);
                        irrigation = irrigation_sorghumOW_yes.getText().toString();
                        break;
                }
            }
        });



        sp_technicalname_insecticide_sorghumOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?>arg0, View view, int arg2, long arg3) {

                insec_tech_name = sp_technicalname_insecticide_sorghumOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        sp_weedicide_technicalname_sorghumOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?>arg0, View view, int arg2, long arg3) {

                fungi_tech_name = sp_weedicide_technicalname_sorghumOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        sp_technicalname_fungicide_sorghumOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?>arg0, View view, int arg2, long arg3) {

                fungi_tech_name = sp_technicalname_fungicide_sorghumOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });

        sp_irrigation_given_sorghumOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?>arg0, View view, int arg2, long arg3) {

                irrigation_name = sp_irrigation_given_sorghumOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        /*pest_sorghumOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });*/

        crop_growth_sorghumOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SorghumOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_sorghumOW_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cropsap_sorghumOW_pheromone_save();
            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            /*if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else*/ if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            //photoFile1=null;
            photoFile2=null;
        }
    }


    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        /*if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pest_sorghumOW_photo.getWidth(), pest_sorghumOW_photo.getHeight())
                                    .centerCrop()
                                    .into(pest_sorghumOW_photo);

                            uploadImage1OnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else */if(type.equalsIgnoreCase("2")) {


            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(crop_growth_sorghumOW_photo.getWidth(), crop_growth_sorghumOW_photo.getHeight())
                                    .centerCrop()
                                    .into(crop_growth_sorghumOW_photo);

                            uploadImage2OnServer(imagePath2);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /*private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));


            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_new_crop_sorghum_last_form_save_img(partBody, params);
            api.postRequest(responseCall, this, 1);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    private void uploadImage2OnServer(String imagePath2) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath2);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_new_crop_sorghum_last_form_save_img(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void cropsap_sorghumOW_pheromone_save(){
        if( (insecticide_radio_group_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select insecticide", Toast.LENGTH_SHORT).show();
        }else if( (fungicide_radio_group_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select fungicide", Toast.LENGTH_SHORT).show();
        }else if( (weedicide_radio_group_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select weedicide", Toast.LENGTH_SHORT).show();
        }else if( (fertilizer_radio_group_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select fertilizer", Toast.LENGTH_SHORT).show();
        }else if( (radio_group_intercultural_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select intercultural operations", Toast.LENGTH_SHORT).show();
        }else if( (radio_group_irrigation_field_sorghumOW.getCheckedRadioButtonId() == -1)){
            Toast.makeText(SorghumOtherWorkActivity.this, "Select irrigation", Toast.LENGTH_SHORT).show();
        }/*else if (photoFile1 == null) {
            Toast.makeText(SorghumOtherWorkActivity.this, "Click photo of pest", Toast.LENGTH_SHORT).show();
        }*/else if (photoFile2 == null) {
            Toast.makeText(SorghumOtherWorkActivity.this, "Click photo of crop growth stage", Toast.LENGTH_SHORT).show();
        }
        else{
            JSONObject param = new JSONObject();
            try {
                param.put("last_id","1");
                param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id",district_id);
                param.put("taluka_id",taluka_id);
                param.put("village_id",village_id);
                param.put("et_sorghum_trap_one",fall_trap1);
                param.put("et_sorghum_trap_two",fall_trap2);
                param.put("insecticide",insecticide);
                param.put("insec_tech_name",insec_tech_name);
                param.put("insec_trade_name",tradename_insecticide_sorghumOW.getText().toString().trim());
                param.put("insec_qnty",quantity_used_acre_insecticide_sorghumOW.getText().toString().trim());
                param.put("fungicide",fungicide);
                param.put("fungi_tech_name",fungi_tech_name);
                param.put("fungi_trade_name",tradename_fungicide_sorghumOW.getText().toString().trim());
                param.put("fungi_qnty",quantity_used_acre_fungicide_sorghumOW.getText().toString().trim());
                param.put("weedicide",weedicide);
                param.put("weedi_tech_name",weedi_tech_name);
                param.put("weedi_trade_name",tradename_weedicide_sorghumOW.getText().toString().trim());
                param.put("weedi_qnty",quantity_used_acre_weedicide_sorghumOW.getText().toString().trim());
                param.put("fertilizers",fertilizer);
                param.put("ferti_n_per",fertilizer_sorghumOW_N.getText().toString().trim());
                param.put("ferti_p_per",fertilizer_sorghumOW_P.getText().toString().trim());
                param.put("ferti_k_per",fertilizer_sorghumOW_K.getText().toString().trim());
                param.put("ferti_name",fertilizername_sorghumOW.getText().toString().trim());
                param.put("ferti_qnty",quantity_used_acre_fertilizer_sorghumOW.getText().toString().trim());
                param.put("inter_cul_oper",intercultural);
                param.put("irrigation",irrigation);
                param.put("other_pest","");
                param.put("irrigation_name",irrigation_name);
                param.put("img_file_1",fall_trap1_photo);
                param.put("img_file_2",fall_trap2_photo);
                param.put("img_file_3","1");
                param.put("img_file_4",image_2_file_name);


            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_crop_sorghum_last_form_save_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {

                /*if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");

                        }
                    }
                }*/

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            JSONObject data = jsonObject.getJSONObject("data");
                            image_2_file_name = data.getString("file_name");
                        }
                    }
                }

                /*if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_3_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_4_file_name = data.getString("file_name");
                        }
                    }
                }*/

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Sorghum Other Works Completed")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    }).show();
                        }
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(SorghumOtherWorkActivity.this,SorghumGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
