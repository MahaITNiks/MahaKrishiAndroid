package com.maha.agri.activity.user_dashboard.farmer;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.farmer.FarmerCategoriesActivity;
import com.maha.agri.farmer.FarmerCropSapActivity;
import com.maha.agri.farmer.FarmerPunchnamaActivity;
import com.maha.agri.activity.common.LoginActivity;
import com.maha.agri.adapter.FarmerDashboardAdapter;
import com.maha.agri.farmer.FarmerMagazineAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.history.FarmerHistoryActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIAlertView;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerDashboardActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView farmer_dashboard_rv,farmer_month_rv;
    private JSONArray farmer_dashboard_list,farmer_magazine_list;;
    private int[] farmer_dashboard_backy = {R.drawable.dash_attendance,R.drawable.dash_task,R.drawable.dash_assigned_villages,R.drawable.dash_task_report};
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String month_Filter,year,month_id;
    private DBHandler dbHandler;
    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_dashboard);

        preferenceManager = new PreferenceManager(FarmerDashboardActivity.this);
        sharedPref = new SharedPref(FarmerDashboardActivity.this);

        dbHandler = new DBHandler(this);

        IdCalling();
        default_Config();
        getTaskManagerListWebservie();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.history:
                Intent history_intent = new Intent(FarmerDashboardActivity.this, FarmerHistoryActivity.class);
                startActivity(history_intent);
                return true;

            case R.id.app_log_out:
                logout();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void IdCalling(){
        farmer_dashboard_rv = (RecyclerView)findViewById(R.id.farmer_dashboard_rv);
        farmer_dashboard_rv.setLayoutManager(new LinearLayoutManager(this));
        //month_id = preferenceManager.getPreferenceValues(Preference_Constant.FARMER_MAGAZINE_MONTH_ID);
        Calendar calander = Calendar.getInstance();
        year = String.valueOf(calander.get(Calendar.YEAR));


    }

    private void logout() {

        new FancyAlertDialog.Builder(this)
                .setTitle("बाहेर पडणे")
                .setBackgroundColor(Color.parseColor("#d50000"))  //Don't pass R.color.colorvalue
                .setMessage("आपण खरोखर लॉग आउट करू इच्छिता ? ")
                .setNegativeBtnText("नाही")
                .setIcon(R.drawable.ic_error_outline_black_24dp, Icon.Visible)
                .setPositiveBtnBackground(Color.parseColor("#9b0000"))  //Don't pass R.color.colorvalue
                .setPositiveBtnText("होय")
                .setNegativeBtnBackground(Color.parseColor("#FFA9A7A8"))  //Don't pass R.color.colorvalue
                .setAnimation(Animation.POP)
                .isCancellable(true)
                .OnPositiveClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {
                        preferenceManager.clearSharedPreferance();
                        //AppSettings.getInstance().setValue(AADashboardActivity.this,ApConstants.kLOGIN_DATA,ApConstants.kLOGIN_DATA);
                        Intent log_out_Intent = new Intent(FarmerDashboardActivity.this, LoginActivity.class);
                        log_out_Intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(log_out_Intent);
                        finishAffinity();
                    }
                })
                .OnNegativeClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {


                    }
                })
                .build();
    }

    @Override
    public void onBackPressed() {
        UIAlertView.getOurInstance().exitFromApplicationMessage(this,"तुम्हाला बाहेर पडायचे आहे का ?");
    }

    private void default_Config() {

        farmer_dashboard_rv.addOnItemTouchListener(new FarmerDashboardAdapter.RecyclerTouchListener(this, farmer_dashboard_rv, new FarmerDashboardAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                switch (position) {
                    case 0:
                        UIToastMessage.show(FarmerDashboardActivity.this,"Coming soon");
                        break;

                    case 1:
                        Intent farmer_cropsap = new Intent(FarmerDashboardActivity.this, FarmerCropSapActivity.class);
                        startActivity(farmer_cropsap);
                        break;

                    case 2:
                        Intent farmer_punchnama = new Intent(FarmerDashboardActivity.this, FarmerPunchnamaActivity.class);
                        startActivity(farmer_punchnama);
                        break;

                   /* case 3:
                        Intent intentMaz = new Intent(FarmerDashboardActivity.this, FarmerMagazineActivity.class);
                        intentMaz.putExtra("magazine_title","farmer");
                        startActivity(intentMaz);
                        break;*/
                    case 3:
                        Intent intentMazCat = new Intent(FarmerDashboardActivity.this, FarmerCategoriesActivity.class);
                        intentMazCat.putExtra("magazine_title","farmer");
                        startActivity(intentMazCat);
                        break;
                }
            }



            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }


   /* private void getOfflineTaskManager() {
        task_manager_types_list = dbHandler.getTaskType();
        farmer_dashboard_rv.setAdapter(new TaskManagerAdapter(preferenceManager,task_manager_types_list,task_manager_backy,this));
    }*/


    private void getTaskManagerListWebservie() {

        JSONObject param = new JSONObject();

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.farmer_dashboard_url(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_dashboard_list = jsonObject.getJSONArray("data");
                            farmer_dashboard_rv.setAdapter(new FarmerDashboardAdapter(preferenceManager,farmer_dashboard_list,farmer_dashboard_backy,this));

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_magazine_list = jsonObject.getJSONArray("data");
                            farmer_month_rv.setAdapter(new FarmerMagazineAdapter(preferenceManager,farmer_magazine_list,this));
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_magazine_list = jsonObject.getJSONArray("data");
                            for(int j = 0; j < farmer_magazine_list .length(); j++) {
                                JSONObject pdf_json_object = farmer_magazine_list.getJSONObject(j);
                                String pdf_file = pdf_json_object.getString("pdf_file");
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(pdf_file));
                                startActivity(browserIntent);
                            }

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
