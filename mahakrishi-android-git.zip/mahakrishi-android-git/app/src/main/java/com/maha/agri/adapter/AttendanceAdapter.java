package com.maha.agri.adapter;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.maha.agri.R;
import com.maha.agri.activity.attendance.AttendanceListDetailActivity;
import com.maha.agri.model.AttendDetailModel;
import com.maha.agri.util.ApUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.CustomViewHolder> {

    private Context context;
    private String[] count;
    private String[] hcount;
    private String[] meeting;
    private String[] checkin;
    private String[] checkout;
    private JSONArray attendanceList;

    public AttendanceAdapter(Context context, JSONArray attendanceList) {
        this.context = context;
        this.attendanceList = attendanceList;

    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private TextView count, hcount, meeting, checkin, checkout, absent_count,holiday_count,normal_count,holiday_tv;
        private RelativeLayout absent_rl, present_rl,holiday_rl,normal_rl;


        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

            count = mView.findViewById(R.id.dayssingle_count);
            hcount = mView.findViewById(R.id.dayssingle_hcount);
            meeting = mView.findViewById(R.id.meetingsingletv);
            checkin = mView.findViewById(R.id.checkinsingletv);
            checkout = mView.findViewById(R.id.checkoutsingletv);
            holiday_tv = mView.findViewById(R.id.holiday_tv);
            absent_rl = mView.findViewById(R.id.absent_rl);
            present_rl = mView.findViewById(R.id.present_rl);
            holiday_rl = mView.findViewById(R.id.holiday_rl);
            normal_rl = mView.findViewById(R.id.normal_rl);
            holiday_count = mView.findViewById(R.id.dayssingle_holiday_count);
            normal_count = mView.findViewById(R.id.dayssingle_normal_count);
            absent_count = mView.findViewById(R.id.dayssingle_absent_count);



        }
    }

    @Override
    public AttendanceAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.attendance_single, parent, false);
        return new AttendanceAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AttendanceAdapter.CustomViewHolder holder, int position) {

        try {
            final JSONObject jsonObject = attendanceList.getJSONObject(position);


            AttendDetailModel aDModel = new AttendDetailModel(jsonObject);

            holder.checkin.setText(aDModel.getDate());

            if (jsonObject.getString("is_present").equalsIgnoreCase("1")) {

                int workHour = Integer.valueOf(jsonObject.getString("hours"));
                if (workHour>1.45){
                    holder.present_rl.setBackground(context.getResources().getDrawable(R.drawable.attendance_present_backy));
                }else {
                    holder.present_rl.setBackground(context.getResources().getDrawable(R.drawable.attendance_present_less_time_back));
                }

                holder.present_rl.setVisibility(View.VISIBLE);
                holder.absent_rl.setVisibility(View.GONE);
                holder.normal_rl.setVisibility(View.GONE);
                holder.holiday_rl.setVisibility(View.GONE);
                holder.count.setText(jsonObject.getString("day_of_month"));
                //holder.normal_count.setText(jsonObject.getString("day_of_month"));
                holder.present_rl.setClickable(true);
                holder.absent_rl.setClickable(false);
                holder.holiday_rl.setClickable(false);
                holder.normal_rl.setClickable(false);
                holder.checkin.setText(ApUtil.getTimeByTimeStamp(aDModel.getIn_report_time()));
                holder.checkout.setText(ApUtil.getTimeByTimeStamp(aDModel.getOut_time()));
                holder.hcount.setText("H="+aDModel.getHours());
                holder.present_rl.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(context, AttendanceListDetailActivity.class);
                        intent.putExtra("data",jsonObject.toString());
                        context.startActivity(intent);
                    }
                });

            }

            else {
                holder.present_rl.setVisibility(View.GONE);
                holder.absent_rl.setVisibility(View.VISIBLE);
                if (jsonObject.getString("is_holiday").equalsIgnoreCase("1")) {
                    holder.holiday_rl.setVisibility(View.VISIBLE);
                    holder.present_rl.setVisibility(View.GONE);
                    holder.absent_rl.setVisibility(View.GONE);
                    holder.normal_rl.setVisibility(View.GONE);
                    holder.holiday_count.setText(jsonObject.getString("day_of_month"));
                    final String holiday_details = jsonObject.getString("holiday_details");
                    holder.holiday_rl.setClickable(true);
                    holder.absent_rl.setClickable(false);
                    holder.normal_rl.setClickable(false);
                    holder.present_rl.setClickable(false);
                    holder.holiday_rl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(context, "Holiday Details" + " : " + holiday_details, Toast.LENGTH_SHORT).show();

                        }
                    });
                } else {
                    holder.holiday_rl.setVisibility(View.GONE);
                    holder.absent_rl.setVisibility(View.GONE);
                    holder.normal_rl.setVisibility(View.VISIBLE);
                    holder.normal_count.setText(jsonObject.getString("day_of_month"));
                }

            }








//            holder.present_rl.setClickable(false);
//            holder.absent_rl.setClickable(false);

            /*try {
                if(jsonObject.getString("is_absent").equalsIgnoreCase("1")){
                    holder.absent_rl.setVisibility(View.VISIBLE);
                    holder.absent_count.setText(jsonObject.getString("day_of_month"));
                    holder.absent_rl.setClickable(false);
                } else {
                    holder.absent_rl.setVisibility(View.GONE);
                }
            } catch (JSONException e1) {
                e1.printStackTrace();
            }*/





        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        //return count.length;
        if (attendanceList != null) {
            return attendanceList.length();
        } else {
            return 0;
        }
    }

   /* public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FFS_AttendanceAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FFS_AttendanceAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }*/
}
