package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

import static android.widget.Toast.*;

public class MBCommunityFarmPondActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private TextView mb_farm_pond;
    private Button mb_farm_pond_next;
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    private JSONArray farm_pond_list;
    private int farm_pond_id = 0;
    private String farm_pond_name = "",farmer_name="",response="";
    private int  district_id,taluka_id,village_id,farmer_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_community_farm_pond);
        getSupportActionBar().setTitle("MB Community Farm Pond");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBCommunityFarmPondActivity.this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        farmer_name = intent.getStringExtra("farmer_name");

        ids();
        functions();
    }

    private void ids(){
        mb_farm_pond = (TextView) findViewById(R.id.mb_farm_pond);
        mb_farm_pond_next = (Button) findViewById(R.id.mb_farm_pond_next);

        farm_pond_list = new JSONArray();
        farm_pond_list_service();
    }

    private void functions(){

        mb_farm_pond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(farm_pond_list,1,"Select Physical Verification","name","id",MBCommunityFarmPondActivity.this,MBCommunityFarmPondActivity.this);
            }
        });

        mb_farm_pond_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mb_farm_pond_save();
            }
        });
    }

    private void farm_pond_list_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.mb_community_pond_list();
        api.postRequest(responseCall, this, 1);
    }

    private void is_completed_service(){
            JSONObject param = new JSONObject();
            try{
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("farmer_name", farmer_id);
                param.put("pond_selected", farm_pond_name);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_is_completed(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
    }

    private void mb_farm_pond_save(){
        if(farm_pond_id==0) {
            Toast.makeText(this,"Select community farm pond form", LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try{
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("farmer_name", farmer_id);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 3);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farm_pond_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            response = jsonObject.getString("response");

                            if(response.equalsIgnoreCase("Valid")){
                                mb_farm_pond_next.setEnabled(true);
                            }else if(response.equalsIgnoreCase("Not Valid")){
                                mb_farm_pond.setText("Select");
                                mb_farm_pond_next.setEnabled(false);
                                Toast.makeText(this,"First Physical Verification is not completed", LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Data filled for First Physical Verification")){
                                mb_farm_pond.setText("Select");
                                mb_farm_pond_next.setEnabled(false);
                                Toast.makeText(this,"First Physical Verification is completed", LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Data filled for Last Physical Verification")){
                                mb_farm_pond.setText("Select");
                                mb_farm_pond_next.setEnabled(false);
                                Toast.makeText(this,"Last Physical Verification is completed", LENGTH_SHORT).show();
                            }else{
                                mb_farm_pond_next.setEnabled(false);
                            }
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(farm_pond_name.equalsIgnoreCase("First Physical Verification")){
                                Intent intent = new Intent(MBCommunityFarmPondActivity.this,MBCommunityFarmPond8Activity.class);
                                intent.putExtra("farmer_name",farmer_name);
                                intent.putExtra("district_id",district_id);
                                intent.putExtra("taluka_id",taluka_id);
                                intent.putExtra("village_id",village_id);
                                intent.putExtra("farmer_id",farmer_id);
                                startActivity(intent);
                                finish();
                            }else{
                                Intent intent = new Intent(MBCommunityFarmPondActivity.this,MBCommunityFarmPond9Activity.class);
                                intent.putExtra("farmer_name",farmer_name);
                                intent.putExtra("district_id",district_id);
                                intent.putExtra("taluka_id",taluka_id);
                                intent.putExtra("village_id",village_id);
                                intent.putExtra("farmer_id",farmer_id);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }
                }
            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            farm_pond_id = Integer.parseInt(s1);
            farm_pond_name = s;
            mb_farm_pond.setText(farm_pond_name);
            is_completed_service();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
