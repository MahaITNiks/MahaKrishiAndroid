package com.maha.agri.mb_recording;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class EstimatedSubsidyActivity extends AppCompatActivity implements ApiCallbackCode, ApiJSONObjCallback, AlertListEventListener {

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    View parentLayout;
    private String userID;
    private SearchableSpinner /*sp_farmer_district, sp_farmer_taluka,*/ sp_farmer_village, sp_scheme_name, sp_farmer_list;
    // RadioButton survey_radio_btn, gut_radio_btn;
    private TextView estimate_subsidy_et_gut_number;
    private TextView districtTextView;
    private TextView talukaTextView;
    private TextView componentTextView;
    private Button sub_btn;
    // JSONArray District_List;
    // JSONArray Taluka_List;
    JSONArray Village_List;
    JSONArray componentListArray = new JSONArray();
    JSONArray Scheme_List;
    JSONArray Farmer_List;

    //spinner
    // ArrayList<String> DistrictName;
    // ArrayList<String> TalukaName;
    ArrayList<String> VillageName;
    ArrayList<String> Scheme_Name;
    ArrayList<String> FarmerName;

    String str_district_name, str_taluka_name, str_village_name, str_component_name, str_farmer_name, str_scheme_name;
    String district_name, district_id = "", taluka_name, taluka_id = "", village_id = "", village_name, component_id = "", component_name, survey_no, farmer_name, farmer_id = "", scheme_name, scheme_id = "";

    // HashMap<Integer, String> farmer_district_map = new HashMap<Integer, String>();
    // HashMap<Integer, String> farmer_taluka_map = new HashMap<Integer, String>();
    HashMap<Integer, String> farmer_village_map = new HashMap<Integer, String>();
    HashMap<Integer, String> scheme_list_map = new HashMap<Integer, String>();
    HashMap<Integer, String> farmer_list_map = new HashMap<Integer, String>();

    String survey_type = "1", estimated_no = "", approval_amount = "", id = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimatedsubsidy);
        getSupportActionBar().setTitle("Farmer Registration");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(EstimatedSubsidyActivity.this);
        sharedPref = new SharedPref(EstimatedSubsidyActivity.this);
        userID = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);

        initialization();

        if (isNetworkAvailable()) {
            getDistrictTalukaById();
            // District_Service();
        } else {
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void initialization() {
        sub_btn = (Button) findViewById(R.id.submit_btn_estimated);
        districtTextView = (TextView) findViewById(R.id.districtTextView);
        talukaTextView = (TextView) findViewById(R.id.talukaTextView);
        // sp_farmer_district = (SearchableSpinner) findViewById(R.id.sp_farmer_district);
        // sp_farmer_taluka = (SearchableSpinner) findViewById(R.id.sp_farmer_taluka);
        sp_farmer_village = (SearchableSpinner) findViewById(R.id.sp_farmer_village);
        componentTextView = (TextView) findViewById(R.id.componentTextView);
        sp_scheme_name = (SearchableSpinner) findViewById(R.id.sp_scheme_name);
        sp_farmer_list = (SearchableSpinner) findViewById(R.id.sp_farmer_list);
        estimate_subsidy_et_gut_number = (TextView) findViewById(R.id.estimate_subsidy_et_gut_number);
        estimate_subsidy_et_gut_number.setText("6");
//        survey_gut_radio_group = (RadioGroup) findViewById(R.id.survey_gut_radio_group_estimated);
//        survey_radio_btn = (RadioButton) findViewById(R.id.survey_radio_btn_estimated);
//        gut_radio_btn = (RadioButton) findViewById(R.id.gut_radio_btn_estimated);
//        survey_radio_btn.setChecked(false);
//        gut_radio_btn.setChecked(false);
        // DistrictName = new ArrayList<>();
        // TalukaName = new ArrayList<>();
        VillageName = new ArrayList<>();
        Scheme_Name = new ArrayList<>();
        FarmerName = new ArrayList<>();
        Scheme_List = new JSONArray();

        /*sp_farmer_district.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                district_id = farmer_district_map.get(sp_farmer_district.getSelectedItemPosition());
                str_district_name = sp_farmer_district.getSelectedItem().toString();
                Taluka_Service();
                TalukaName.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_farmer_taluka.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                taluka_id = farmer_taluka_map.get(sp_farmer_taluka.getSelectedItemPosition());
                str_taluka_name = sp_farmer_taluka.getSelectedItem().toString();
                Village_Service();
                VillageName.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/

        sp_farmer_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = farmer_village_map.get(sp_farmer_village.getSelectedItemPosition());
                str_village_name = sp_farmer_village.getSelectedItem().toString();
                component_List_Service();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        componentTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (componentListArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(componentListArray, 1, "Select component type", "construction_name", "id", EstimatedSubsidyActivity.this, EstimatedSubsidyActivity.this);
                } else {
                    component_List_Service();
                }
            }
        });

        /* componentTextView.setOnClickListener(new OnC {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                component_id = component_list_map.get(componentTextView.getSelectedItemPosition());
                str_component_name = componentTextView.getSelectedItem().toString();
                Farmer_List_Service();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/

        sp_farmer_list.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                farmer_id = farmer_list_map.get(sp_farmer_list.getSelectedItemPosition());
                str_farmer_name = sp_farmer_list.getSelectedItem().toString();
                AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.MB_FARMER_NAME, str_farmer_name);
                Scheme_Service();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_scheme_name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                scheme_id = scheme_list_map.get(sp_scheme_name.getSelectedItemPosition());
                str_scheme_name = sp_scheme_name.getSelectedItem().toString();
                AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.MB_SCHEME_NAME, str_scheme_name);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

       /* survey_gut_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {

                    case R.id.survey_radio_btn_estimated:
                        survey_radio_btn.setChecked(true);
                        survey_type = "0";
                        break;

                    case R.id.gut_radio_btn_estimated:
                        gut_radio_btn.setChecked(true);
                        survey_type = "1";
                        break;


                }
            }
        });*/

        AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.SURVEY_NAME, survey_no);

        sub_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(str_scheme_name.contains("BFFLY")){
                    Intent intent = new Intent(EstimatedSubsidyActivity.this, MBRecordingBfflyForm1Activity.class);
                    intent.putExtra("scheme",scheme_name);
                    intent.putExtra("farmer_id",farmer_id);
                    intent.putExtra("district_id",district_id);
                    intent.putExtra("taluka_id",taluka_id);
                    intent.putExtra("village_id",village_id);
                    startActivity(intent);
                }else{
                    Estimated_Save_Service();
                }
            }
        });

    }


    /****To get district and taluka detail vy user Id*/
    private void getDistrictTalukaById() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", userID);
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
            DebugLog.getInstance().d("get_dist_taluka_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("get_dist_taluka_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void District_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_district_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Taluka_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_taluka_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void Village_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id", taluka_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void component_List_Service() {
        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", getResources().getString(R.string.please_wait), true);
        api.getRequestData(APIServices.COMPONENT_LIST, this, 7);
    }

    private void Farmer_List_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_list_mb_recording(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    /*private void Scheme_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.scheme_mb_recording(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }*/

    private void Scheme_Service() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.scheme_mb_recording();
        api.postRequest(responseCall, this, 5);
    }

    // save
    private void Estimated_Save_Service() {

        survey_no = estimate_subsidy_et_gut_number.getText().toString().trim();

        if (district_id.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select district", Toast.LENGTH_SHORT).show();
        } else if (taluka_id.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select taluka", Toast.LENGTH_SHORT).show();
        } else if (village_id.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select village", Toast.LENGTH_SHORT).show();
        } else if (farmer_id.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select farmer", Toast.LENGTH_SHORT).show();
        } else if (scheme_id.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select scheme", Toast.LENGTH_SHORT).show();
        } else if (survey_no.isEmpty()) {
            Toast.makeText(EstimatedSubsidyActivity.this, "Select survey no/Gut no", Toast.LENGTH_SHORT).show();
        } else {
            JSONObject param = new JSONObject();
            try {
                param.put("id", id);
                param.put("estimated_no", estimated_no);
                param.put("approval_amount", approval_amount);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("component_id", component_id);
                param.put("farmer_id", farmer_id);
                param.put("scheme_id", scheme_id);
                param.put("survey_type", survey_type);
                param.put("survey_text", survey_no);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 6);

        }
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            component_id = s1;
            component_name = s;
            componentTextView.setText(component_name);
            Farmer_List_Service();
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                // To get district and taluka against user id
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);

                        if (responseModel.isStatus()) {
                            JSONArray dataArray = responseModel.getData();
                            JSONObject dataJSON = dataArray.getJSONObject(0);
                            district_name = dataJSON.getString("district_name");
                            district_id = dataJSON.getString("district_id");
                            taluka_name = dataJSON.getString("taluka_name");
                            taluka_id = dataJSON.getString("taluka_id");

                            districtTextView.setText(district_name);
                            talukaTextView.setText(taluka_name);
                        }
                    }
                    Village_Service();
                }


                //district
                /*if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            District_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.DISTRICT_LIST, District_List.toString());
                            final int numberOfItemsInResp = District_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject district_json_object = District_List.getJSONObject(j);
                                district_id = district_json_object.getString("id");
                                district_name = district_json_object.getString("district_name");
                                DistrictName.add(district_name);
                                farmer_district_map.put(j, district_id);
                                district_id = "";
                            }

                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(EstimatedSubsidyActivity.this, android.R.layout.simple_spinner_dropdown_item, DistrictName);
                        sp_farmer_district.setAdapter(adapter);
                    }
                }


                //taluka
                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            farmer_taluka_map = new HashMap<Integer, String>();
                            TalukaName = new ArrayList<>();

                            Taluka_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.TALUKA_LIST, Taluka_List.toString());
                            final int numberOfItemsInResp = Taluka_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject taluka_json_object = Taluka_List.getJSONObject(j);
                                taluka_id = taluka_json_object.getString("id");
                                taluka_name = taluka_json_object.getString("taluka_name");
                                TalukaName.add(taluka_name);
                                farmer_taluka_map.put(j, taluka_id);
                                taluka_id = "";
                            }

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(EstimatedSubsidyActivity.this, android.R.layout.simple_spinner_dropdown_item, TalukaName);
                        sp_farmer_taluka.setAdapter(adapter);

                    }
                }*/


                //Village
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        farmer_village_map = new HashMap<Integer, String>();
                        FarmerName = new ArrayList<>();

                        if (responseModel.isStatus()) {
                            Village_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.VILLAGE_LIST, Village_List.toString());
                            final int numberOfItemsInResp = Village_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject village_json_object = Village_List.getJSONObject(j);
                                village_id = village_json_object.getString("id");
                                village_name = village_json_object.getString("village_name");
                                VillageName.add(village_name);
                                farmer_village_map.put(j, village_id);
                                village_id = "";

                            }

                        }

                        sp_farmer_village.setAdapter(new ArrayAdapter<String>(EstimatedSubsidyActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName));
                    } else {
                        Toast.makeText(EstimatedSubsidyActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                    }
                }

                //Farmer List
                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        farmer_list_map = new HashMap<Integer, String>();
                        FarmerName = new ArrayList<>();

                        if (responseModel.isStatus()) {
                            Farmer_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.FARMER_LIST, Farmer_List.toString());
                            final int numberOfItemsInResp = Farmer_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject farmer_json_object = Farmer_List.getJSONObject(j);
                                farmer_id = farmer_json_object.getString("id");
                                farmer_name = farmer_json_object.getString("first_name");
                                FarmerName.add(farmer_name);
                                farmer_list_map.put(j, farmer_id);
                                farmer_id = "";
                            }
                        }

                        sp_farmer_list.setAdapter(new ArrayAdapter<String>(EstimatedSubsidyActivity.this, android.R.layout.simple_spinner_dropdown_item, FarmerName));
                    } else {
                        Toast.makeText(EstimatedSubsidyActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                    }
                }


                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Scheme_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(EstimatedSubsidyActivity.this, ApConstants.SCHEME_LIST, Scheme_List.toString());
                            final int numberOfItemsInResp = Scheme_List.length();
                            Scheme_Name = new ArrayList<>();
                            scheme_list_map = new HashMap<Integer, String>();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject Scheme_json_object = Scheme_List.getJSONObject(j);
                                scheme_id = Scheme_json_object.getString("id");
                                scheme_name = Scheme_json_object.getString("name");
                                Scheme_Name.add(scheme_name);
                                scheme_list_map.put(j, scheme_id);
                                scheme_id = "";
                            }
                        }
                        sp_scheme_name.setAdapter(new ArrayAdapter<String>(EstimatedSubsidyActivity.this, android.R.layout.simple_spinner_dropdown_item, Scheme_Name));
                    } else {
                        Toast.makeText(EstimatedSubsidyActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                    }
                }

                //Farmer Registration save
                if (i == 6) {

                    JSONObject data = jsonObject.getJSONObject("data");
                    String farmer_reg_id = data.getString("farmer_reg_id");
                    preferenceManager.putPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID, farmer_reg_id);
                    Intent intent = new Intent(EstimatedSubsidyActivity.this, EstimatedSubsidyDetailActivity.class);
                    intent.putExtra("str_district_name", district_name);
                    intent.putExtra("str_taluka_name", taluka_name);
                    intent.putExtra("str_village_name", str_village_name);
                    intent.putExtra("str_farmer_name", str_farmer_name);
                    intent.putExtra("str_scheme_name", str_scheme_name);
                    intent.putExtra("survey_type", survey_type);
                    intent.putExtra("district_id", district_id);
                    intent.putExtra("taluka_id", taluka_id);
                    intent.putExtra("village_id", village_id);
                    intent.putExtra("component_id", component_id);
                    intent.putExtra("component_name", component_name);
                    intent.putExtra("taluka_id", taluka_id);
                    intent.putExtra("survey_no", survey_no);
                    intent.putExtra("farmer_id", farmer_id);
                    intent.putExtra("scheme_id", scheme_id);
                    startActivity(intent);

                    /*if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        //responseID = jsonObject.getString("data");
                        JSONObject data = jsonObject.getJSONObject("data");
                        String farmer_reg_id = data.getString("farmer_reg_id");
                        preferenceManager.putPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID, farmer_reg_id);
                        Intent intent = new Intent(EstimatedSubsidyActivity.this, EstimatedSubsidyDetailActivity.class);
                        intent.putExtra("str_district_name", str_district_name);
                        intent.putExtra("str_taluka_name", str_taluka_name);
                        intent.putExtra("str_village_name", str_village_name);
                        intent.putExtra("str_farmer_name", str_farmer_name);
                        intent.putExtra("str_scheme_name", str_scheme_name);
                        intent.putExtra("survey_type", survey_type);
                        intent.putExtra("district_id", district_id);
                        intent.putExtra("taluka_id", taluka_id);
                        intent.putExtra("village_id", village_id);
                        intent.putExtra("taluka_id", taluka_id);
                        intent.putExtra("survey_no", survey_no);
                        intent.putExtra("farmer_id", farmer_id);
                        intent.putExtra("scheme_id", scheme_id);
                        startActivity(intent);

                    } else {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        String farmer_reg_id = data.getString("farmer_reg_id");
                        preferenceManager.putPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID, farmer_reg_id);
                        Intent intent = new Intent(EstimatedSubsidyActivity.this, EstimatedSubsidyDetailActivity.class);
                        intent.putExtra("str_district_name", str_district_name);
                        intent.putExtra("str_taluka_name", str_taluka_name);
                        intent.putExtra("str_village_name", str_village_name);
                        intent.putExtra("str_farmer_name", str_farmer_name);
                        intent.putExtra("str_scheme_name", str_scheme_name);
                        intent.putExtra("survey_type", survey_type);
                        intent.putExtra("district_id", district_id);
                        intent.putExtra("taluka_id", taluka_id);
                        intent.putExtra("village_id", village_id);
                        intent.putExtra("taluka_id", taluka_id);
                        intent.putExtra("survey_no", survey_no);
                        intent.putExtra("farmer_id", farmer_id);
                        intent.putExtra("scheme_id", scheme_id);
                        startActivity(intent);
                    }*/
                }

                // Component List
                if (i == 7) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            componentListArray = jsonObject.getJSONArray("data");
                        }
                    } else {
                        Toast.makeText(EstimatedSubsidyActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Throwable throwable, int i) {

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
