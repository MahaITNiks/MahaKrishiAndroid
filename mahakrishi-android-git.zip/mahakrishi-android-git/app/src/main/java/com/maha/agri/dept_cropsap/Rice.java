package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Rice extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView dept_cropsap_plant_ricetv,rice_generic_tv,rice_major_pest,rice_minor_pest;
    private LinearLayout rice_blue_beetle_ll,rice_hispa_ll,rice_yellow_stem_ll,rice_gall_midge_ll,rice_plant_hoppers_ll,rice_generic_ll;
    private EditText rice_blue_beetle_et,rice_hispa_et,rice_yellow_stem_et,rice_gall_midge_et,rice_plant_hoppers_et,rice_generic_et,rice_defender_et;
    private ImageView rice_blue_beetle_photo,rice_hispa_photo,rice_yellow_stem_photo,rice_gall_midge_photo,rice_plant_hoppers_photo,rice_generic_photo;
    private Button btn_save_continue_rice,btn_add_pest_details_rice;
    private TableLayout add_pest_titleTableLayout_rice;
    private RecyclerView add_more_pest_rv_rice;
    private SweetAlertDialog sweetAlertDialog;

    private int count = 1;
    private int crop_cond_id = 0;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private int crop_id = 0;
    private int selected_pest_id = 0;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private int district_id, taluka_id, village_id, farmer_id;
    private String rice_crop_name="",pest_name = "";
    private AppLocationManager locationManager;
    private JSONArray rice_crop_plant_list,rice_major_pest_list,rice_minor_pest_list;
    private int crop_rice_plant_id=0;
    private String type = "",generic_et_str="",yellow_str="",gall_str="",blue_str="",plant_hop_str="",hispa_str="",total_def_str="";

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private File photoFile3 = null;
    private File photoFile4 = null;
    private File photoFile5 = null;
    private File photoFile6 = null;
    private String imagePath1 = "", imagePath2="",imagePath3="",imagePath4="",imagePath5="",imagePath6="";
    private String image_1_file_name="",image_2_file_name="",image_3_file_name="",image_4_file_name="",image_5_file_name="",image_6_file_name="";
    public double lat,lang;

    private ArrayList<String> pest_list_names_rice=new ArrayList<String>();
    private ArrayList<LinearLayout> pest_list_layout_rice=new ArrayList<LinearLayout>();
    private ArrayList<EditText> pest_list_et_rice=new ArrayList<EditText>();
    private boolean flag=false;

    private JSONArray pest_details_json_array = new JSONArray();

    JSONObject yellow_stem_pest_json_obj = new JSONObject();
    JSONObject gall_midge_pest_json_obj = new JSONObject();
    JSONObject blue_beetle_pest_json_obj = new JSONObject();
    JSONObject plant_hoppers_pest_json_obj = new JSONObject();
    JSONObject army_worm_pest_json_obj = new JSONObject();
    JSONObject leaf_folder_pest_json_obj = new JSONObject();
    JSONObject case_worm_pest_json_obj = new JSONObject();
    JSONObject hispa_pest_json_obj = new JSONObject();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_rice);
        getSupportActionBar().setTitle("CROPSAP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(Rice.this);
        sharedPref = new SharedPref(Rice.this);
        locationManager = new AppLocationManager(this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        crop_cond_id = intent.getIntExtra("crop_cond",0);
        crop_growth_id = intent.getIntExtra("crop_growth_id",0);
        soil_moisture_id = intent.getIntExtra("soil_moisture_id",0);
        lat = locationManager.getLatitude();
        lang = locationManager.getLongitude();

        initView();
        setListners();
    }

    private void initView() {
        //Textview
        dept_cropsap_plant_ricetv =(TextView) findViewById(R.id.dept_cropsap_plant_ricetv);
        rice_major_pest =(TextView) findViewById(R.id.rice_major_pest);
        rice_minor_pest =(TextView) findViewById(R.id.rice_minor_pest);
        rice_generic_tv =(TextView) findViewById(R.id.rice_generic_tv);
        dept_cropsap_plant_ricetv.setEnabled(false);
        //LL
        rice_blue_beetle_ll = (LinearLayout) findViewById(R.id.rice_blue_beetle_ll);
        rice_hispa_ll = (LinearLayout) findViewById(R.id.rice_hispa_ll);
        rice_yellow_stem_ll = (LinearLayout) findViewById(R.id.rice_yellow_stem_ll);
        rice_gall_midge_ll = (LinearLayout) findViewById(R.id.rice_gall_midge_ll);
        rice_plant_hoppers_ll = (LinearLayout) findViewById(R.id.rice_plant_hoppers_ll);
        rice_generic_ll = (LinearLayout) findViewById(R.id.rice_generic_ll);
        add_more_pest_rv_rice = (RecyclerView) findViewById(R.id.add_more_pest_rv_rice);
        add_pest_titleTableLayout_rice = (TableLayout) findViewById(R.id.add_pest_titleTableLayout_rice);
       //Edittext
        rice_blue_beetle_et = (EditText) findViewById(R.id.rice_blue_beetle_et);
        rice_hispa_et = (EditText) findViewById(R.id.rice_hispa_et);
        rice_yellow_stem_et = (EditText) findViewById(R.id.rice_yellow_stem_et);
        rice_gall_midge_et = (EditText) findViewById(R.id.rice_gall_midge_et);
        rice_plant_hoppers_et = (EditText) findViewById(R.id.rice_plant_hoppers_et);
        rice_generic_et = (EditText) findViewById(R.id.rice_generic_et);
        rice_defender_et = (EditText) findViewById(R.id.rice_defender_et);
        //Imageview
        rice_blue_beetle_photo = (ImageView) findViewById(R.id.rice_blue_beetle_photo);
        rice_hispa_photo = (ImageView) findViewById(R.id.rice_hispa_photo);
        rice_yellow_stem_photo = (ImageView) findViewById(R.id.rice_yellow_stem_photo);
        rice_gall_midge_photo = (ImageView) findViewById(R.id.rice_gall_midge_photo);
        rice_plant_hoppers_photo = (ImageView) findViewById(R.id.rice_plant_hoppers_photo);
        rice_generic_photo = (ImageView) findViewById(R.id.rice_generic_photo);
        //Button
        btn_save_continue_rice = (Button) findViewById(R.id.btn_save_continue_rice);
        btn_add_pest_details_rice = (Button) findViewById(R.id.btn_add_pest_details_rice);

        rice_crop_plant_list = new JSONArray();
        rice_major_pest_list = new JSONArray();
        rice_minor_pest_list = new JSONArray();

        square_meter_service();
        major_pest_service();
        minor_pest_service();
    }

    private void setListners() {

        pest_list_names_rice.add("YELLOW STEM BORER");
        pest_list_names_rice.add("GALL MIDGE");
        pest_list_names_rice.add("BLUE BEETLE");
        pest_list_names_rice.add("PLANT HOPPERS");
        pest_list_names_rice.add("HISPA");

        pest_list_et_rice.add(rice_yellow_stem_et);
        pest_list_et_rice.add(rice_gall_midge_et);
        pest_list_et_rice.add(rice_blue_beetle_et);
        pest_list_et_rice.add(rice_plant_hoppers_et);
        pest_list_et_rice.add(rice_hispa_et);

        pest_list_layout_rice.add(rice_yellow_stem_ll);
        pest_list_layout_rice.add(rice_gall_midge_ll);
        pest_list_layout_rice.add(rice_blue_beetle_ll);
        pest_list_layout_rice.add(rice_plant_hoppers_ll);
        pest_list_layout_rice.add(rice_hispa_ll);

        dept_cropsap_plant_ricetv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rice_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(rice_crop_plant_list, 1, "Select Square Meter", "square_name", "square_id", Rice.this, Rice.this);
                }
            }
        });

        rice_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rice_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(rice_major_pest_list, 2, "Select Major Pest", "pest_eng_name", "id", Rice.this, Rice.this);
                }else{
                    major_pest_service();
                }
            }
        });

        rice_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rice_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(rice_minor_pest_list, 3, "Select Minor Pest", "pest_eng_name", "id", Rice.this, Rice.this);
                }else{
                    minor_pest_service();
                }
            }
        });

        rice_yellow_stem_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        rice_gall_midge_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        rice_blue_beetle_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "3";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        rice_plant_hoppers_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "4";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        rice_hispa_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "5";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        rice_generic_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(Rice.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "6";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_add_pest_details_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generic_et_str = rice_generic_et.getText().toString().trim();
                yellow_str = rice_yellow_stem_et.getText().toString().trim();
                gall_str = rice_gall_midge_et.getText().toString().trim();
                blue_str = rice_blue_beetle_et.getText().toString().trim();
                plant_hop_str = rice_plant_hoppers_et.getText().toString().trim();
                hispa_str = rice_hispa_et.getText().toString().trim();

                if(pest_name.equalsIgnoreCase("ARMY WORM") || pest_name.equalsIgnoreCase("LEAF FOLDER") || pest_name.equalsIgnoreCase("CASE WORM")){
                    if(generic_et_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of pest present ",Toast.LENGTH_SHORT).show();
                    }else if(photoFile6 == null){
                        Toast.makeText(Rice.this,"Click photo of the pest",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("YELLOW STEM BORER")){
                    if(yellow_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of dead hearts/white ear heads",Toast.LENGTH_SHORT).show();
                    }else if(photoFile1 == null){
                        Toast.makeText(Rice.this,"Click photo of the dead hearts/white ear heads",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("GALL MIDGE")){
                    if(gall_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of silver shoots/hill",Toast.LENGTH_SHORT).show();
                    }else if(photoFile2 == null){
                        Toast.makeText(Rice.this,"Click photo of the silver shoots/hill",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("BLUE BEETLE")){
                    if(blue_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of infested leaves/hill",Toast.LENGTH_SHORT).show();
                    }else if(photoFile3 == null){
                        Toast.makeText(Rice.this,"Click photo of the infested leaves/hill",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("PLANT HOPPERS")){
                    if(plant_hop_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of plant hoppers per hill",Toast.LENGTH_SHORT).show();
                    }else if(photoFile4 == null){
                        Toast.makeText(Rice.this,"Click photo of the plant hoppers per hill",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("HISPA")){
                    if(hispa_str.equalsIgnoreCase("")){
                        Toast.makeText(Rice.this,"Enter the number of infested leaves/hill",Toast.LENGTH_SHORT).show();
                    }else if(photoFile5 == null){
                        Toast.makeText(Rice.this,"Click photo of the infested leaves/hill",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else{

                }
            }
        });

        btn_save_continue_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total_def_str = rice_defender_et.getText().toString().trim();
                if(pest_details_json_array.length()>0) {
                    if(pest_details_json_array.toString().contains("YELLOW STEM BORER") &&
                            pest_details_json_array.toString().contains("GALL MIDGE") &&
                            pest_details_json_array.toString().contains("BLUE BEETLE") &&
                            pest_details_json_array.toString().contains("PLANT HOPPERS") &&
                            pest_details_json_array.toString().contains("ARMY WORM")) {
                        if (total_def_str.equalsIgnoreCase("")) {
                            Toast.makeText(Rice.this, "Enter total defender", Toast.LENGTH_SHORT).show();
                        } else {
                            save_rice_crop_data_service();
                        }
                    }else{
                        sweetAlertDialog = new SweetAlertDialog(Rice.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Enter data for all major pests");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                            }
                        }).show();
                    }
                } else {
                    final Toast toast = Toast.makeText(Rice.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 0);
                }
            }
        });
    }

    private void takeImageFromCameraUri() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }else if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }else if (type.equalsIgnoreCase("3")) {
                photoFile3 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile3);
                } else {
                    photoURI = Uri.fromFile(photoFile3);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }else if (type.equalsIgnoreCase("4")) {
                photoFile4 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile4);
                } else {
                    photoURI = Uri.fromFile(photoFile4);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }else if (type.equalsIgnoreCase("5")) {
                photoFile5 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile5);
                } else {
                    photoURI = Uri.fromFile(photoFile5);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }if (type.equalsIgnoreCase("6")) {
                photoFile6 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile6);
                } else {
                    photoURI = Uri.fromFile(photoFile6);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else {
            photoFile1 = null;
            photoFile2 = null;
            photoFile3 = null;
            photoFile4 = null;
            photoFile5 = null;
            photoFile6 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(rice_yellow_stem_photo.getWidth(), rice_yellow_stem_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_yellow_stem_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("2")) {

            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(rice_gall_midge_photo.getWidth(), rice_gall_midge_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_gall_midge_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if(type.equalsIgnoreCase("3")) {

            if (photoFile3 != null) {

                if (photoFile3.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile3, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath3 = "file://" + photoFile3;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath3)
                                    .resize(rice_blue_beetle_photo.getWidth(), rice_blue_beetle_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_blue_beetle_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile3);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if(type.equalsIgnoreCase("4")) {

            if (photoFile4 != null) {

                if (photoFile4.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile4, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath4 = "file://" + photoFile4;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath4)
                                    .resize(rice_plant_hoppers_photo.getWidth(), rice_plant_hoppers_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_plant_hoppers_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile4);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if(type.equalsIgnoreCase("5")) {

            if (photoFile5 != null) {

                if (photoFile5.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile5, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath5 = "file://" + photoFile5;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath5)
                                    .resize(rice_hispa_photo.getWidth(), rice_hispa_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_hispa_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile5);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if(type.equalsIgnoreCase("6")) {

            if (photoFile6 != null) {

                if (photoFile6.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile6, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath6 = "file://" + photoFile6;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath6)
                                    .resize(rice_generic_photo.getWidth(), rice_generic_photo.getHeight())
                                    .centerCrop()
                                    .into(rice_generic_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile6);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void square_meter_service() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_rice_spot_list();
        api.postRequest(responseCall, this, 1);
    }

    private void major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void add_pest_details(int sel_pest_id,String pest_name){

        try {
            if(pest_name.equalsIgnoreCase("YELLOW STEM BORER")) {
                yellow_stem_pest_json_obj.put("pest_id", sel_pest_id);
                yellow_stem_pest_json_obj.put("pest_name", pest_name);
                yellow_stem_pest_json_obj.put("yellow_stem_pest_no", rice_yellow_stem_et.getText().toString().trim());
                yellow_stem_pest_json_obj.put("yellow_stem_pest_pic", image_1_file_name);
                yellow_stem_pest_json_obj.put("lat", String.valueOf(lat));
                yellow_stem_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(yellow_stem_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("GALL MIDGE")) {
                gall_midge_pest_json_obj.put("pest_id", sel_pest_id);
                gall_midge_pest_json_obj.put("pest_name", pest_name);
                gall_midge_pest_json_obj.put("gall_midge_pest_no", rice_gall_midge_et.getText().toString().trim());
                gall_midge_pest_json_obj.put("gall_midge_pest_pic", image_2_file_name);
                gall_midge_pest_json_obj.put("lat", String.valueOf(lat));
                gall_midge_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(gall_midge_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("BLUE BEETLE")) {
                blue_beetle_pest_json_obj.put("pest_id", sel_pest_id);
                blue_beetle_pest_json_obj.put("pest_name", pest_name);
                blue_beetle_pest_json_obj.put("blue_beetle_pest_no", rice_blue_beetle_et.getText().toString().trim());
                blue_beetle_pest_json_obj.put("blue_beetle_pest_pic", image_3_file_name);
                blue_beetle_pest_json_obj.put("lat", String.valueOf(lat));
                blue_beetle_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(blue_beetle_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("PLANT HOPPERS")) {
                plant_hoppers_pest_json_obj.put("pest_id", sel_pest_id);
                plant_hoppers_pest_json_obj.put("pest_name", pest_name);
                plant_hoppers_pest_json_obj.put("plant_hoppers_pest_no", rice_plant_hoppers_et.getText().toString().trim());
                plant_hoppers_pest_json_obj.put("plant_hoppers_pest_pic", image_4_file_name);
                plant_hoppers_pest_json_obj.put("lat", String.valueOf(lat));
                plant_hoppers_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(plant_hoppers_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("ARMY WORM")) {
                army_worm_pest_json_obj.put("pest_id", sel_pest_id);
                army_worm_pest_json_obj.put("pest_name", pest_name);
                army_worm_pest_json_obj.put("army_worm_pest_no", rice_generic_et.getText().toString().trim());
                army_worm_pest_json_obj.put("army_worm_pest_pic", image_6_file_name);
                army_worm_pest_json_obj.put("lat", String.valueOf(lat));
                army_worm_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(army_worm_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("LEAF FOLDER")) {
                leaf_folder_pest_json_obj.put("pest_id", sel_pest_id);
                leaf_folder_pest_json_obj.put("pest_name", pest_name);
                leaf_folder_pest_json_obj.put("leaf_folder_pest_no", rice_generic_et.getText().toString().trim());
                leaf_folder_pest_json_obj.put("leaf_folder_pest_pic", image_6_file_name);
                leaf_folder_pest_json_obj.put("lat", String.valueOf(lat));
                leaf_folder_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(leaf_folder_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("CASE WORM")) {
                case_worm_pest_json_obj.put("pest_id", sel_pest_id);
                case_worm_pest_json_obj.put("pest_name", pest_name);
                case_worm_pest_json_obj.put("case_worm_pest_no", rice_generic_et.getText().toString().trim());
                case_worm_pest_json_obj.put("case_worm_pest_pic", image_6_file_name);
                case_worm_pest_json_obj.put("lat", String.valueOf(lat));
                case_worm_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(case_worm_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("HISPA")) {
                hispa_pest_json_obj.put("pest_id", sel_pest_id);
                hispa_pest_json_obj.put("pest_name", pest_name);
                hispa_pest_json_obj.put("hispa_pest_no", rice_hispa_et.getText().toString().trim());
                hispa_pest_json_obj.put("hispa_pest_pic", image_5_file_name);
                hispa_pest_json_obj.put("lat", String.valueOf(lat));
                hispa_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(hispa_pest_json_obj);
            }

            if(pest_details_json_array.length()>0){
                add_pest_titleTableLayout_rice.setVisibility(View.VISIBLE);
                add_more_pest_rv_rice.setVisibility(View.VISIBLE);
                add_more_pest_rv_rice.setLayoutManager(new LinearLayoutManager(Rice.this));
                AddPestAdapter addPestAdapter = new AddPestAdapter(pest_details_json_array, Rice.this);
                add_more_pest_rv_rice.setAdapter(addPestAdapter);
                addPestAdapter.notifyDataSetChanged();
                rice_yellow_stem_ll.setVisibility(View.GONE);
                rice_gall_midge_ll.setVisibility(View.GONE);
                rice_blue_beetle_ll.setVisibility(View.GONE);
                rice_plant_hoppers_ll.setVisibility(View.GONE);
                rice_hispa_ll.setVisibility(View.GONE);
                rice_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_rice.setVisibility(View.GONE);
                rice_major_pest.setText("Select");
                rice_minor_pest.setText("Select");
                rice_yellow_stem_et.setText("");
                rice_gall_midge_et.setText("");
                rice_blue_beetle_et.setText("");
                rice_plant_hoppers_et.setText("");
                rice_hispa_et.setText("");
                rice_generic_et.setText("");
                rice_yellow_stem_photo.setImageResource(R.drawable.camera);
                rice_gall_midge_photo.setImageResource(R.drawable.camera);
                rice_blue_beetle_photo.setImageResource(R.drawable.camera);
                rice_plant_hoppers_photo.setImageResource(R.drawable.camera);
                rice_hispa_photo.setImageResource(R.drawable.camera);
                rice_generic_photo.setImageResource(R.drawable.camera);
                photoFile1 = null;
                photoFile2 = null;
                photoFile3 = null;
                photoFile4 = null;
                photoFile5 = null;
                photoFile6 = null;
            }else{
                add_pest_titleTableLayout_rice.setVisibility(View.GONE);
                add_more_pest_rv_rice.setVisibility(View.GONE);
                final Toast toast = Toast.makeText(Rice.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 0);
            }

            System.out.println(pest_details_json_array.toString());

        }catch (Exception e){

        }
    }

    private void uploadImageOnServer() {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;

                case "2":
                    File file2 = new File(photoFile2.getPath());
                    RequestBody reqFile2 = RequestBody.create(MediaType.parse("image/*"), file2);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file2.getName(), reqFile2);
                    break;

                case "3":
                    File file3 = new File(photoFile3.getPath());
                    RequestBody reqFile3 = RequestBody.create(MediaType.parse("image/*"), file3);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file3.getName(), reqFile3);
                    break;

                case "4":
                    File file4 = new File(photoFile4.getPath());
                    RequestBody reqFile4 = RequestBody.create(MediaType.parse("image/*"), file4);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file4.getName(), reqFile4);
                    break;

                case "5":
                    File file5 = new File(photoFile5.getPath());
                    RequestBody reqFile5 = RequestBody.create(MediaType.parse("image/*"), file5);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file5.getName(), reqFile5);
                    break;

                case "6":
                    File file6 = new File(photoFile6.getPath());
                    RequestBody reqFile6 = RequestBody.create(MediaType.parse("image/*"), file6);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file6.getName(), reqFile6);
                    break;
            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void save_rice_crop_data_service() {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("spot_id", count);
                param.put("crop_id", crop_id);
                param.put("crop_condition_id", crop_cond_id);
                param.put("crop_grow_id", crop_growth_id);
                param.put("soil_mois_id", soil_moisture_id);
                param.put("pest_details", pest_details_json_array.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(Rice.this,RiceGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            rice_crop_plant_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            rice_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            rice_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if(type.equalsIgnoreCase("1")){
                                image_1_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("2")){
                                image_2_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("3")){
                                image_3_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("4")){
                                image_4_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("5")){
                                image_5_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("6")){
                                image_6_file_name = data.getString("file_url");
                            }
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            if(count < rice_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("CROPSAP");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Square Meter" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        count++;
                                        dept_cropsap_plant_ricetv.setText("Square Meter" + " " + count);
                                        rice_major_pest.setText("Select");
                                        rice_minor_pest.setText("Select");
                                        pest_details_json_array = new JSONArray();
                                        rice_generic_ll.setVisibility(View.GONE);
                                        rice_yellow_stem_ll.setVisibility(View.GONE);
                                        rice_gall_midge_ll.setVisibility(View.GONE);
                                        rice_blue_beetle_ll.setVisibility(View.GONE);
                                        rice_plant_hoppers_ll.setVisibility(View.GONE);
                                        rice_hispa_ll.setVisibility(View.GONE);
                                        btn_add_pest_details_rice.setVisibility(View.GONE);
                                        add_pest_titleTableLayout_rice.setVisibility(View.GONE);
                                        add_more_pest_rv_rice.setVisibility(View.GONE);
                                        rice_defender_et.setText("");
                                        sweetAlertDialog.dismissWithAnimation();
                                    }
                                });
                                sweetAlertDialog.show();
                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("CROPSAP");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Square Meter" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(Rice.this,RicePheromone.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_rice_plant_id = Integer.parseInt(s1);
            rice_crop_name = s;
            dept_cropsap_plant_ricetv.setText(s);
        }

        if(i == 2){
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            rice_major_pest.setText(s);
            rice_minor_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == rice_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(Rice.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                rice_yellow_stem_ll.setVisibility(View.GONE);
                rice_gall_midge_ll.setVisibility(View.GONE);
                rice_blue_beetle_ll.setVisibility(View.GONE);
                rice_plant_hoppers_ll.setVisibility(View.GONE);
                rice_hispa_ll.setVisibility(View.GONE);
                rice_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_rice.setVisibility(View.GONE);
                rice_yellow_stem_et.setText("");
                rice_gall_midge_et.setText("");
                rice_blue_beetle_et.setText("");
                rice_plant_hoppers_et.setText("");
                rice_hispa_et.setText("");
                rice_generic_et.setText("");
                rice_yellow_stem_photo.setImageResource(R.drawable.camera);
                rice_gall_midge_photo.setImageResource(R.drawable.camera);
                rice_blue_beetle_photo.setImageResource(R.drawable.camera);
                rice_plant_hoppers_photo.setImageResource(R.drawable.camera);
                rice_hispa_photo.setImageResource(R.drawable.camera);
                rice_generic_photo.setImageResource(R.drawable.camera);
            }else{
                btn_add_pest_details_rice.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
        if(i == 3){
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            rice_minor_pest.setText(s);
            rice_major_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == rice_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(Rice.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                rice_yellow_stem_ll.setVisibility(View.GONE);
                rice_gall_midge_ll.setVisibility(View.GONE);
                rice_blue_beetle_ll.setVisibility(View.GONE);
                rice_plant_hoppers_ll.setVisibility(View.GONE);
                rice_hispa_ll.setVisibility(View.GONE);
                rice_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_rice.setVisibility(View.GONE);
                rice_yellow_stem_et.setText("");
                rice_gall_midge_et.setText("");
                rice_blue_beetle_et.setText("");
                rice_plant_hoppers_et.setText("");
                rice_hispa_et.setText("");
                rice_generic_et.setText("");
                rice_yellow_stem_photo.setImageResource(R.drawable.camera);
                rice_gall_midge_photo.setImageResource(R.drawable.camera);
                rice_blue_beetle_photo.setImageResource(R.drawable.camera);
                rice_plant_hoppers_photo.setImageResource(R.drawable.camera);
                rice_hispa_photo.setImageResource(R.drawable.camera);
                rice_generic_photo.setImageResource(R.drawable.camera);
            }else{
                btn_add_pest_details_rice.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }

    private void layout_View_Gone(String s) {
        if(pest_list_names_rice.contains(s)){
            rice_generic_ll.setVisibility(View.GONE);
            rice_generic_photo.setVisibility(View.GONE);
            rice_generic_tv.setText("");
            rice_generic_et.setText("");
            for(int i=0;i<pest_list_et_rice.size();i++){
                pest_list_et_rice.get(i).setText("");
            }

            for(int j=0;j<pest_list_names_rice.size();j++){
                if(pest_list_names_rice.get(j).equals(s)){
                    pest_list_layout_rice.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout_rice.get(j).setVisibility(View.GONE);
                    rice_generic_et.setText("");
                }
            }
        }
        else{
            if(!pest_list_names_rice.contains(s)) {
                String localstr = s;
                String localstr2;
                localstr2 = capitalizeWord(localstr);
                rice_generic_ll.setVisibility(View.VISIBLE);
                rice_generic_photo.setVisibility(View.VISIBLE);
                rice_generic_tv.setText(localstr2);
                rice_generic_et.setText("");
                for (int j = 0; j < pest_list_names_rice.size(); j++) {
                    pest_list_layout_rice.get(j).setVisibility(View.GONE);
                    pest_list_et_rice.get(j).setText("");
                }
            }
        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }
}