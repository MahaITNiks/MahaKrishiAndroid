package com.maha.agri.dept_cropsap;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;

import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSapActivityNew extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener, OnMultiRecyclerItemClickListener {

    private TextView dept_cropsap_new_district_tv,dept_cropsap_new_taluka_tv,cropsap_new_farmer_name_tv,tv_fieldloc,cropsap_new_irrigation_tv,cropsap_new_crop_variety_tv,
            crop_sap_sowing_date_tv,cropsap_new_season_tv,cropsap_new_crop_tv,cropsap_new_soil_type_tv,
            dept_cropsap_new_field_tv,cropsap_new_village_name_tv;
    private LinearLayout farmer_random_ll,farmer_fixed_ll,cropsap_other_variety_ll;
    private ImageView crop_sap_sowing_date_iv;
    private RadioGroup dept_cropsap_new_survey_gut_radio_group,cropsap_plot_type_rg;
    private RadioButton dept_cropsap_new_survey_radio_btn,dept_cropsap_new_gut_radio_btn,cropsap_random,cropsap_fixed;
    private Button dept_cropsap_submit_btn;
    private EditText dept_cropsap_new_district_et,dept_cropsap_new_taluka_et,cropsap_new_village_name_et,cropsap_new_farmer_name_et,
            dept_cropsap_new_et_gut_number,dept_cropsap_new_row_to_row_edt,dept_cropsap_new_plant_to_plant_edt,cropsap_other_variety_et;
    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private JSONArray village_list,farmer_list,District_List,season_list,crop_list,crop_variety_list,crop_irrigation_list,soil_type_list;
    private String crop_data_list = "";
    String divison_id_str = "",divison_name_str,circle_id_str = "", sajja_id_str = "",circle_name = "", sajja_name="",district_id_str="",district_name,
            taluka_name,taluka_id_str="", village_name = "",farmer_name = "", crop_name,crop_variety_name="";
    private String activityID = "",village_id_str="";

    private int district_id = 0,divison_id = 0,circle_id = 0,sajja_id = 0;
    private int taluka_id = 0;
    private int village_id = 0;
    private int season_id = 0;
    private int crop_id = 0;
    private int crop_variety_id = 0;
    private int crop_irrigation_id = 0;
    private int soil_type_id = 0;
    private int farmer_id = 0,row_row_int = 0,plant_plant_int = 0,row_total = 150;
    private String row_row_str="",plant_plant_str="",data;
    ArrayList<String> VillageName;
    HashMap<Integer,String> village_map = new HashMap<Integer, String>();


    private int mYear, mMonth, mDay;
    private String sowing_date="",survey_gut_type="0",survey_gut_text="",field_location="",plot="0",plot_name="";
    private DatePickerDialog sowing_date_PickerDialog;
    private AppLocationManager locationManager;
    private double latitude,longitude;
    public double lat,lang;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap_new);
        getSupportActionBar().setTitle("New Farmer Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(CropSapActivityNew.this);
        sharedPref = new SharedPref(CropSapActivityNew.this);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        initView();
        default_confiq();
        setListners();

    }

    private void initView() {
        locationManager = new AppLocationManager(this);
        latitude = locationManager.getLatitude();
        longitude = locationManager.getLongitude();

        //Text view
        dept_cropsap_new_district_tv = (TextView) findViewById(R.id.dept_cropsap_new_district_tv);
        dept_cropsap_new_taluka_tv = (TextView) findViewById(R.id.dept_cropsap_new_taluka_tv);
        cropsap_new_village_name_tv = (TextView) findViewById(R.id.cropsap_new_village_name_tv);
        cropsap_new_farmer_name_tv = (TextView) findViewById(R.id.cropsap_new_farmer_name_tv);
        tv_fieldloc = (TextView) findViewById(R.id.tv_fieldloc);
        cropsap_new_irrigation_tv = (TextView) findViewById(R.id.cropsap_new_irrigation_tv);
        cropsap_new_crop_variety_tv = (TextView) findViewById(R.id.cropsap_new_crop_variety_tv);
        crop_sap_sowing_date_tv = (TextView) findViewById(R.id.crop_sap_sowing_date_tv);
        cropsap_new_season_tv = (TextView) findViewById(R.id.cropsap_new_season_tv);
        cropsap_new_crop_tv = (TextView) findViewById(R.id.cropsap_new_crop_tv);
        cropsap_new_soil_type_tv = (TextView) findViewById(R.id.cropsap_new_soil_type_tv);
        dept_cropsap_new_field_tv = (TextView) findViewById(R.id.dept_cropsap_new_field_tv);

        //Linear layout
        farmer_random_ll = (LinearLayout) findViewById(R.id.farmer_random_ll);
        farmer_fixed_ll = (LinearLayout) findViewById(R.id.farmer_fixed_ll);
        cropsap_other_variety_ll = (LinearLayout) findViewById(R.id.cropsap_other_variety_ll);
        //Image view
        crop_sap_sowing_date_iv = (ImageView) findViewById(R.id.crop_sap_sowing_date_iv);
        //Edit text
        cropsap_new_farmer_name_et = (EditText) findViewById(R.id.cropsap_new_farmer_name_et);
        dept_cropsap_new_et_gut_number = (EditText) findViewById(R.id.dept_cropsap_new_et_gut_number);
        dept_cropsap_new_row_to_row_edt = (EditText) findViewById(R.id.dept_cropsap_new_row_to_row_edt);
        dept_cropsap_new_plant_to_plant_edt = (EditText) findViewById(R.id.dept_cropsap_new_plant_to_plant_edt);
        cropsap_other_variety_et = (EditText) findViewById(R.id.cropsap_other_variety_et);
        //cropsap_new_croparea_et = (EditText) findViewById(R.id.cropsap_new_croparea_et);

        //Button
        dept_cropsap_submit_btn  = (Button)findViewById(R.id.dept_cropsap_submit_btn);

        //Radio group
        dept_cropsap_new_survey_gut_radio_group = (RadioGroup) findViewById(R.id.dept_cropsap_new_survey_gut_radio_group);
        cropsap_plot_type_rg = (RadioGroup) findViewById(R.id.cropsap_plot_type_rg);
        dept_cropsap_new_survey_radio_btn = (RadioButton) findViewById(R.id.dept_cropsap_new_survey_radio_btn);
        dept_cropsap_new_gut_radio_btn = (RadioButton)findViewById(R.id.dept_cropsap_new_gut_radio_btn);
        cropsap_random = (RadioButton)findViewById(R.id.cropsap_random);
        cropsap_fixed = (RadioButton)findViewById(R.id.cropsap_fixed);
        dept_cropsap_new_survey_radio_btn.setChecked(false);
        dept_cropsap_new_gut_radio_btn.setChecked(false);

    }

    private void default_confiq(){

        if(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("3")||preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("4")
            ||preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("5")||preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("6")||
                preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("7")){
            dept_cropsap_new_field_tv.setText("Random");
        }else{
            dept_cropsap_new_field_tv.setText("Fixed");
        }

        season_list = new JSONArray();
        crop_list = new JSONArray();
        crop_variety_list = new JSONArray();
        crop_irrigation_list = new JSONArray();
        soil_type_list = new JSONArray();
        farmer_list = new JSONArray();

        season_service();
        soil_type_service();
        field_location = String.valueOf(latitude + longitude);
        tv_fieldloc.setText(field_location);

        cropsap_new_village_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getVillageLocation();
                if(plot.equalsIgnoreCase("0")){
                    Toast.makeText(CropSapActivityNew.this,"Please select plot type",Toast.LENGTH_SHORT).show();
                }else if(village_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(village_list, 9, "Select Village", "village_name", "village_id", CropSapActivityNew.this, CropSapActivityNew.this);
                }else{
                    getVillageLocation();
                }
            }
        });

        cropsap_new_farmer_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(village_id == 0){
                    Toast.makeText(CropSapActivityNew.this,"Select village",Toast.LENGTH_SHORT).show();
                }else if (farmer_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(farmer_list, 7, "Select Farmer", "Farmer_Name", "id", CropSapActivityNew.this, CropSapActivityNew.this);
                }else{
                    farmer_list_based_on_dtv(village_id);
                }
            }
        });

        cropsap_new_season_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (season_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(season_list, 2, "Select Season", "name", "id", CropSapActivityNew.this, CropSapActivityNew.this);
                }else{
                    season_service();
                }
            }
        });

        cropsap_new_crop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(season_id == 0){
                    Toast.makeText(CropSapActivityNew.this,"Select season",Toast.LENGTH_SHORT).show();
                }else if(crop_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(crop_list, 3, "Select Crop", "crop_english", "id", CropSapActivityNew.this, CropSapActivityNew.this);
                }else{

                }
            }
        });

        cropsap_new_crop_variety_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(crop_id == 0){
                    Toast.makeText(CropSapActivityNew.this,"Select crop",Toast.LENGTH_SHORT).show();
                }
                else if (crop_variety_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(crop_variety_list, 4, "Select Crop Variety", "variety_name_english", "id", CropSapActivityNew.this, CropSapActivityNew.this);
                } else {
                    crop_variety_based_based_on_crop(crop_id);
                }

            }
        });

        cropsap_new_irrigation_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(crop_id == 0){
                    Toast.makeText(CropSapActivityNew.this,"Select crop",Toast.LENGTH_SHORT).show();
                }else if (crop_irrigation_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(crop_irrigation_list, 5, "Select Crop Irrigation", "irrigation_name_eng", "id", CropSapActivityNew.this, CropSapActivityNew.this);
                } else {
                    crop_irrigation_based_based_on_crop(crop_id);
                }

            }
        });

        cropsap_new_soil_type_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(soil_type_list, 6, "Select Soil Type ", "soil_type", "id", CropSapActivityNew.this, CropSapActivityNew.this);
            }
        });

        dept_cropsap_new_row_to_row_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                row_row_str = dept_cropsap_new_row_to_row_edt.getText().toString().trim();
                if(!row_row_str.equalsIgnoreCase("")){
                    row_row_int = Integer.parseInt(row_row_str);
                    if(row_row_int>150){
                        row_row_str="0";
                        dept_cropsap_new_row_to_row_edt.setText("");
                        Toast.makeText(CropSapActivityNew.this,"Row to row cannot be more than 150cm",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    row_row_int=0;
                    //Toast.makeText(CropSapActivityNew.this,"0",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        dept_cropsap_new_plant_to_plant_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                plant_plant_str = dept_cropsap_new_plant_to_plant_edt.getText().toString().trim();
                if(!plant_plant_str.equalsIgnoreCase("")){
                    plant_plant_int = Integer.parseInt(plant_plant_str);
                    if(plant_plant_int>100){
                        plant_plant_str="0";
                        dept_cropsap_new_plant_to_plant_edt.setText("");
                        Toast.makeText(CropSapActivityNew.this,"Plant to plant cannot be more than 100cm",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    plant_plant_int=0;
                    //Toast.makeText(CropSapActivityNew.this,"0",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void setListners(){

        dept_cropsap_new_survey_gut_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.dept_cropsap_new_survey_radio_btn:
                        dept_cropsap_new_survey_radio_btn.setChecked(true);
                        dept_cropsap_new_et_gut_number.setKeyListener(DigitsKeyListener.getInstance("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/"));
                        dept_cropsap_new_et_gut_number.setRawInputType(InputType.TYPE_CLASS_TEXT);
                        dept_cropsap_new_et_gut_number.setText("");
                        survey_gut_type = "1";
                        break;

                    case R.id.dept_cropsap_new_gut_radio_btn:
                        dept_cropsap_new_gut_radio_btn.setChecked(true);
                        dept_cropsap_new_et_gut_number.setInputType(InputType.TYPE_CLASS_TEXT);
                        dept_cropsap_new_et_gut_number.setText("");
                        survey_gut_type = "2";
                        break;
                }
            }
        });

        cropsap_plot_type_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.cropsap_random:
                        cropsap_random.setChecked(true);
                        plot_name = cropsap_random.getText().toString();
                        farmer_random_ll.setVisibility(View.VISIBLE);
                        farmer_fixed_ll.setVisibility(View.GONE);
                        cropsap_new_village_name_tv.setText("Select");
                        cropsap_new_farmer_name_tv.setText("Select");
                        cropsap_new_farmer_name_et.setText("");
                        get_district_taluka();
                        farmer_id = 0;
                        plot = "1";
                        break;

                    case R.id.cropsap_fixed:
                        cropsap_fixed.setChecked(true);
                        plot_name = cropsap_fixed.getText().toString();
                        farmer_random_ll.setVisibility(View.GONE);
                        farmer_fixed_ll.setVisibility(View.VISIBLE);
                        cropsap_new_village_name_tv.setText("Select");
                        cropsap_new_farmer_name_tv.setText("Select");
                        cropsap_new_farmer_name_et.setText("");
                        get_district_taluka();
                        plot = "2";
                        break;
                }
            }
        });


        crop_sap_sowing_date_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sowing_date_Picker();
            }
        });


        dept_cropsap_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(plot.equalsIgnoreCase("1")){
                    if(cropsap_new_farmer_name_et.getText().toString().equalsIgnoreCase("")){
                        Toast.makeText(CropSapActivityNew.this,"Enter Farmer name",Toast.LENGTH_SHORT).show();
                    }else{
                        cropsap_master_save();
                    }
                }else if(plot.equalsIgnoreCase("2")){
                    if (village_id == 0) {
                        Toast.makeText(CropSapActivityNew.this, "Select Village", Toast.LENGTH_SHORT).show();
                    }else if (farmer_id == 0) {
                        Toast.makeText(CropSapActivityNew.this, "Select Farmer name", Toast.LENGTH_SHORT).show();
                    }else{
                        cropsap_master_save();
                    }
                }else{

                }
            }
        });
    }

    private void sowing_date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        sowing_date_PickerDialog = new DatePickerDialog(CropSapActivityNew.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        sowing_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        crop_sap_sowing_date_tv.setText(sowing_date);
                    }
                }, mYear, mMonth, mDay);

        sowing_date_PickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        sowing_date_PickerDialog.getDatePicker().setMinDate(newDate.getTime());
        sowing_date_PickerDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void get_district_taluka(){
        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 9);

    }

    private void farmer_list_based_on_dtv(int village_id){
        JSONObject param = new JSONObject();
        try {
            param.put("village_id",village_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_get_farmer_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);
    }

    private void season_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("panchnama_scheme_id","");
            param.put("primary_report_id","");
        }catch (Exception e){
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void crop_list_based_on_season(int season_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id",season_id);
            param.put("crop_type","");
            param.put("horti_crop_type_id","");
            param.put("primary_report_id","");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id","0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void crop_variety_based_based_on_crop(int crop_id){
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id",activityID);
            param.put("crop_name_id",crop_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropVariety(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }


    private void crop_irrigation_based_based_on_crop(int crop_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropIrrigation(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void soil_type_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soil_type_list();
        api.postRequest(responseCall, this, 6);
    }


    private void cropsap_master_save() {
        survey_gut_text = dept_cropsap_new_et_gut_number.getText().toString().trim();

        if(plot.equalsIgnoreCase("0")){
            Toast.makeText(CropSapActivityNew.this, "Select plot type", Toast.LENGTH_SHORT).show();
        }else if(survey_gut_type.equalsIgnoreCase("0")){
            Toast.makeText(CropSapActivityNew.this, "Select Survey or Gat Number", Toast.LENGTH_SHORT).show();
        }else if (survey_gut_text.equalsIgnoreCase("")) {
            Toast.makeText(CropSapActivityNew.this, "Enter Survey or Gat Number", Toast.LENGTH_SHORT).show();
        } else if (sowing_date.equalsIgnoreCase("")) {
            Toast.makeText(CropSapActivityNew.this, "Select Sowing Date", Toast.LENGTH_SHORT).show();
        } else if (season_id == 0) {
            Toast.makeText(CropSapActivityNew.this, "Select Season", Toast.LENGTH_SHORT).show();
        } else if (crop_id == 0) {
            Toast.makeText(CropSapActivityNew.this, "Select Crop", Toast.LENGTH_SHORT).show();
        } else if (crop_variety_id == 0) {
            Toast.makeText(CropSapActivityNew.this, "Select Crop Variety", Toast.LENGTH_SHORT).show();
        } else if (crop_irrigation_id == 0) {
            Toast.makeText(CropSapActivityNew.this, "Select Crop Irrigation", Toast.LENGTH_SHORT).show();
        } else if (dept_cropsap_new_row_to_row_edt.getText().toString().trim().equalsIgnoreCase("")) {
            Toast.makeText(CropSapActivityNew.this, "Enter row to row spacing", Toast.LENGTH_SHORT).show();
        } else if (dept_cropsap_new_plant_to_plant_edt.getText().toString().trim().equalsIgnoreCase("")) {
            Toast.makeText(CropSapActivityNew.this, "Enter plant to plant spacing", Toast.LENGTH_SHORT).show();
        } else if (soil_type_id == 0) {
            Toast.makeText(CropSapActivityNew.this, "Select Soil Type", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("division_id", divison_id);
                param.put("circle_id", circle_id);
                param.put("sajja_id", sajja_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("field", dept_cropsap_new_field_tv.getText().toString().trim());
                param.put("farmer_id", farmer_id);
                param.put("farmer_random", cropsap_new_farmer_name_et.getText().toString().trim());
                param.put("plot_type", plot_name);
                param.put("survery_gut_type", survey_gut_type);
                param.put("survey_gut_text", dept_cropsap_new_et_gut_number.getText().toString().trim());
                param.put("field_location", field_location);
                param.put("sowing_date", sowing_date);
                param.put("season_id", season_id);
                param.put("crop_id", crop_id);
                param.put("crop_variety_id", crop_variety_id);
                param.put("other_crop_variety", cropsap_other_variety_et.getText().toString().trim());
                param.put("irrigation_id", crop_irrigation_id);
                param.put("row_to_row", dept_cropsap_new_row_to_row_edt.getText().toString().trim());
                param.put("plant_to_plant", dept_cropsap_new_plant_to_plant_edt.getText().toString().trim());
                param.put("soil_type_id", soil_type_id);
                param.put("is_active", "");
                param.put("is_deleted", "");
                param.put("created_by", "");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_master_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 8);
        }
    }


    @Override
        public void onResponse(JSONObject jsonObject, int i) {

            if (jsonObject != null) {

                try {
                    //district
                    if (i == 1) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {

                                District_List = jsonObject.getJSONArray("data");
                                if(District_List.length()>0) {
                                    for (int j = 0; j <= District_List.length(); j++) {
                                        JSONObject district_json_object = District_List.getJSONObject(j);
                                        divison_id_str = district_json_object.getString("division_id");
                                        divison_name_str = district_json_object.getString("division_name");
                                        district_name = district_json_object.getString("district_name");
                                        taluka_name = district_json_object.getString("taluka_name");
                                        district_id_str = district_json_object.getString("district_id");
                                        taluka_id_str = district_json_object.getString("taluka_id");
                                        circle_id_str = district_json_object.getString("circle_id");
                                        circle_name = district_json_object.getString("circle_name");
                                        sajja_id_str = district_json_object.getString("sajja_id");
                                        sajja_name = district_json_object.getString("sajja_name");

                                        divison_id = Integer.valueOf(divison_id_str);
                                        district_id = Integer.valueOf(district_id_str);
                                        taluka_id = Integer.valueOf(taluka_id_str);
                                        circle_id = Integer.valueOf(circle_id_str);
                                        sajja_id = Integer.valueOf(sajja_id_str);

                                        dept_cropsap_new_district_tv.setText(district_name);
                                        dept_cropsap_new_taluka_tv.setText(taluka_name);

                                        getVillageLocation();

                                    }
                                }else{
                                    new AlertDialog.Builder(CropSapActivityNew.this)
                                            .setTitle("Error!")
                                            .setMessage("You have not been assigned any villages against your saja, please contact Taluka office ")
                                            .setCancelable(false)
                                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    finish();
                                                }
                                            }).show();
                                }
                            }
                        }
                    }

                    //Season List

                    if (i == 2) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                season_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }

                    //Crop List based on season
                    if (i == 3) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                crop_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }

                    //Crop Variety based on crop
                    if (i == 4) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                crop_variety_list = jsonObject.getJSONArray("data");
                            }

                        }
                    }

                    //Crop irrigation based on crop
                    if (i == 5) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                crop_irrigation_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }
                    //Soil type

                    if (i == 6) {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                soil_type_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }

                    if (i == 7) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                farmer_list = jsonObject.getJSONArray("data");
                            }

                        }else{
                            farmer_list = new JSONArray();
                            farmer_id = 0;
                            Toast toast= Toast.makeText(getApplicationContext(), "Farmer list not found", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                    //Cropsap master save

                    if (i == 8) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                String last_inserted_id = jsonObject.getString("data");
                                preferenceManager.putPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID, last_inserted_id);
                                new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                        .setTitleText("Cropsap")
                                        .setContentText(jsonObject.getString("response"))
                                        .setConfirmText("Ok")
                                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(SweetAlertDialog sDialog) {
                                                finish();
                                            }
                                        })
                                        .show();
                            }
                        }
                    }

                    if (i == 9) {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                village_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }

                }catch (Exception e){

                }
            }
        }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 2) {
            season_id = Integer.parseInt(s1);
            cropsap_new_season_tv.setText(s);
            crop_list_based_on_season(season_id);
            cropsap_other_variety_ll.setVisibility(View.GONE);
            cropsap_new_crop_tv.setText("Select");
            cropsap_new_crop_variety_tv.setText("Select");
            cropsap_other_variety_et.setText("Enter");
            cropsap_new_irrigation_tv.setText("Select");
            crop_variety_list = new JSONArray();
        }

        if (i == 3) {
            crop_id = Integer.parseInt(s1);
            cropsap_new_crop_tv.setText(s);
            cropsap_other_variety_ll.setVisibility(View.GONE);
            cropsap_new_crop_variety_tv.setText("Select");
            cropsap_other_variety_et.setText("Enter");
            cropsap_new_irrigation_tv.setText("Select");
            crop_name = s;
            crop_variety_based_based_on_crop(crop_id);
            crop_irrigation_based_based_on_crop(crop_id);
            crop_variety_list = new JSONArray();
        }

        if (i == 4) {
            crop_variety_id = Integer.parseInt(s1);
            crop_variety_name = s;
            cropsap_new_crop_variety_tv.setText(crop_variety_name);
            cropsap_new_irrigation_tv.setText("Select");
            if(crop_variety_name.equalsIgnoreCase("Other Variety")){
                cropsap_other_variety_ll.setVisibility(View.VISIBLE);
                cropsap_other_variety_et.setText("");
            }else{
                cropsap_other_variety_ll.setVisibility(View.GONE);
                cropsap_other_variety_et.setText("");
            }
        }

        if (i == 5) {
            crop_irrigation_id = Integer.parseInt(s1);
            cropsap_new_irrigation_tv.setText(s);
        }

        if (i == 6) {
            soil_type_id = Integer.parseInt(s1);
            cropsap_new_soil_type_tv.setText(s);
        }

        if (i == 7) {
            farmer_id = Integer.parseInt(s1);
            farmer_name = s;
            cropsap_new_farmer_name_tv.setText(farmer_name);
        }

        if (i == 9) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            cropsap_new_village_name_tv.setText(village_name);
            farmer_list_based_on_dtv(village_id);
            cropsap_new_farmer_name_tv.setText("Select");
        }

    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        
    }
}
