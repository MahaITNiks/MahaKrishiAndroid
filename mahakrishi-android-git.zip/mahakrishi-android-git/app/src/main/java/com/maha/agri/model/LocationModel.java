/*
 * Copyright (c) 2019. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/1/19 1:04 PM
 */

package com.maha.agri.model;

import org.json.JSONObject;
import in.co.appinventor.services_api.app_util.AppUtility;

public class LocationModel {

    private int village_id;
    private String village_code;
    private String village_name;
    private String min_lat;
    private String min_long;
    private String max_lat;
    private String max_long;
    private JSONObject jsonObject;

    public LocationModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getVillage_id() {
        return village_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject , "village_id");
    }

    public String getVillage_code() {
        return village_code  = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "village_code");
    }

    public String getVillage_name() {
        return village_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "village_name");
    }
    public String getMin_lat() {
        min_lat = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "min_lat");
        return min_lat;
    }

    public String getMin_long() {
        min_long = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "min_long");
        return min_long;
    }

    public String getMax_lat() {
        max_lat = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "max_lat");
        return max_lat;
    }

    public String getMax_long() {
        max_long = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "max_long");
        return max_long;
    }



}
