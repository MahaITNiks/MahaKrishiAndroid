package com.maha.agri;

import android.view.View;

public class ValidationView {
    View view;
    String string;

    public ValidationView(View view, String string){
        this.view = view;
        this.string = string;

    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }
}
