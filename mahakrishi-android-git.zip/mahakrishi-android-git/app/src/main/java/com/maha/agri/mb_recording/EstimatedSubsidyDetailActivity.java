package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class EstimatedSubsidyDetailActivity extends AppCompatActivity implements ApiCallbackCode {

    Button btn_st_mb_rcdng;
    String str_district_name,str_taluka_name,str_village_name,survey_no,str_farmer_name,str_scheme_name,survey_type ="",estimated_number="",Approval_Amount="";
    private String district_id,taluka_id,village_id,farmer_id,scheme_id;
    TextView tv_district,tv_taluka,tv_village,tv_component,tv_gut_number,tv_Farmer_name,tv_scheme_name;
    TextView edt_estimated_number,edt_Approval_Amount;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String component_id;
    private String component_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimated_subsidy_detail);
        getSupportActionBar().setTitle("MB Recording");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(EstimatedSubsidyDetailActivity.this);
        sharedPref = new SharedPref(EstimatedSubsidyDetailActivity.this);
        init();
        default_confiq();
    }

    private void init() {
        btn_st_mb_rcdng = (Button)findViewById(R.id.btn_submit);

        tv_district = (TextView)findViewById(R.id.tv_district);
        tv_taluka = (TextView)findViewById(R.id.tv_taluka);
        tv_village = (TextView)findViewById(R.id.tv_village);
        tv_component = (TextView)findViewById(R.id.tv_component);
        tv_gut_number = (TextView)findViewById(R.id.tv_gut_number);
        tv_Farmer_name = (TextView)findViewById(R.id.tv_Farmer_name);
        tv_scheme_name = (TextView)findViewById(R.id.tv_scheme_name);
        edt_estimated_number = (TextView)findViewById(R.id.edt_estimated_number);
        edt_Approval_Amount = (TextView)findViewById(R.id.edt_Approval_Amount);

        Intent intent = getIntent();
        str_district_name = intent.getStringExtra("str_district_name");
        tv_district.setText(str_district_name);

        str_taluka_name = intent.getStringExtra("str_taluka_name");
        tv_taluka.setText(str_taluka_name);

        str_village_name = intent.getStringExtra("str_village_name");
        tv_village.setText(str_village_name);

        component_id = intent.getStringExtra("component_id");
        component_name = intent.getStringExtra("component_name");
        tv_component.setText(component_name);

        survey_no = intent.getStringExtra("survey_no");
        tv_gut_number.setText(survey_no);

        str_farmer_name = intent.getStringExtra("str_farmer_name");
        tv_Farmer_name.setText(str_farmer_name);

        str_scheme_name = intent.getStringExtra("str_scheme_name");
        tv_scheme_name.setText(str_scheme_name);

        survey_type = intent.getStringExtra("survey_type");

        district_id = intent.getStringExtra("district_id");
        taluka_id = intent.getStringExtra("taluka_id");
        village_id = intent.getStringExtra("village_id");
        farmer_id = intent.getStringExtra("farmer_id");
        scheme_id = intent.getStringExtra("scheme_id");

    }

    private void default_confiq(){

        btn_st_mb_rcdng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Estimated_Save_Service();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // save
    private void Estimated_Save_Service(){

        estimated_number = edt_estimated_number.getText().toString().trim();
        Approval_Amount = edt_Approval_Amount.getText().toString().trim();

        if(estimated_number.isEmpty()){
            Toast.makeText(EstimatedSubsidyDetailActivity.this,"select Estimated Number",Toast.LENGTH_SHORT).show();
        }else if(Approval_Amount.isEmpty()){
            Toast.makeText(EstimatedSubsidyDetailActivity.this,"select Approval Amount",Toast.LENGTH_SHORT).show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
                param.put("estimated_no", Integer.valueOf(estimated_number));
                param.put("approval_amount", Integer.valueOf(Approval_Amount));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("component_id", component_id);
                param.put("farmer_id", farmer_id);
                param.put("scheme_id", scheme_id);
                param.put("survey_type", survey_type);
                param.put("survey_text", survey_no);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);
        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {
            try {
                //Farmer Registration save1
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        AppSettings.getInstance().setIntValue(this, ApConstants.MB_STAGE_LAVAL,0);
                        AppSettings.getInstance().setValue(this, ApConstants.LIFT_TO_SOIL_ID, ApConstants.LIFT_TO_SOIL_ID);
                        Intent intent = new Intent(EstimatedSubsidyDetailActivity.this,Mb_Recording.class);
                        startActivity(intent);
                        finish();
                    } else {
                        UIToastMessage.show(EstimatedSubsidyDetailActivity.this,jsonObject.getString("response"));
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}
