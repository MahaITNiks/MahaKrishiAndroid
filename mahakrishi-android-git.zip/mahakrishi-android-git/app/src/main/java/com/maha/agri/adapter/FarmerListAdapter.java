package com.maha.agri.adapter;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.dept_cropsap.DepartmentCropSapActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerListAdapter extends RecyclerView.Adapter<FarmerListAdapter.MyViewHolder> {
    private JSONArray farmer_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView farmer_single_title;
        private RelativeLayout farmer_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.farmer_single_title = itemView.findViewById(R.id.farmer_single_text_view);
            this.farmer_single_item_rl = itemView.findViewById(R.id.farmer_single_item_rl);

        }
    }

    public FarmerListAdapter(PreferenceManager preferenceManager, JSONArray farmer_array_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.farmer_array_list = farmer_array_list;
        this.context = context;

    }

    @Override
    public FarmerListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_list_single_item, parent, false);

        FarmerListAdapter.MyViewHolder myViewHolder = new FarmerListAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final FarmerListAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = farmer_array_list.getJSONObject(listPosition);

            holder.farmer_single_item_rl.setTag(listPosition);

            holder.farmer_single_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = farmer_array_list.getJSONObject(index).getString("id");
                        String name = farmer_array_list.getJSONObject(index).getString("farmer_name");
                        String comment = farmer_array_list.getJSONObject(index).getString("comment");
                        String filename = farmer_array_list.getJSONObject(index).getString("filename");
                        String survey_no = farmer_array_list.getJSONObject(index).getString("survey_no");

                        String district_name = farmer_array_list.getJSONObject(index).getString("district_name");
                        String taluka_name = farmer_array_list.getJSONObject(index).getString("taluka_name");
                        String village_name = farmer_array_list.getJSONObject(index).getString("village_name");
                        String season_name = farmer_array_list.getJSONObject(index).getString("season_name");
                        String crop_name = farmer_array_list.getJSONObject(index).getString("crop_name");

                        Intent intent = new Intent(context, DepartmentCropSapActivity.class);
                        intent.putExtra("farmer_id",id);
                        intent.putExtra("farmer_name",name);
                        intent.putExtra("comment",comment);
                        intent.putExtra("filename",filename);
                        intent.putExtra("survey_no",survey_no);
                        intent.putExtra("district_name",district_name);
                        intent.putExtra("taluka_name",taluka_name);
                        intent.putExtra("village_name",village_name);
                        intent.putExtra("season_name",season_name);
                        intent.putExtra("crop_name",crop_name);
                        context.startActivity(intent);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
            {
                holder.farmer_single_title.setText(jsonObject.getString("farmer_name"));

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (farmer_array_list != null) {
            return farmer_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FarmerListAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FarmerListAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
