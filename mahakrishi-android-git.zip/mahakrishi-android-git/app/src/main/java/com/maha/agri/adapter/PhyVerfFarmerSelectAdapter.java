package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PhyVerfFarmerSelectAdapter extends RecyclerView.Adapter<PhyVerfFarmerSelectAdapter.MyViewHolder> {
    private JSONArray cropsap_farmer_list;
    private Context context;
    private JSONObject jsonObject;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView cropsap_farmername_si,cropsap_survey_si,cropsap_plot_si;
        private RelativeLayout cropsap_farmer_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.cropsap_farmername_si = itemView.findViewById(R.id.cropsap_farmername_si);
            this.cropsap_survey_si = itemView.findViewById(R.id.cropsap_survey_si);
            this.cropsap_plot_si = itemView.findViewById(R.id.cropsap_plot_si);
            this.cropsap_farmer_single_item_rl = itemView.findViewById(R.id.cropsap_farmer_single_item_rl);

        }
    }

    public PhyVerfFarmerSelectAdapter(JSONArray farmer_claim_array_list, Context context) {
        this.cropsap_farmer_list = farmer_claim_array_list;
        this.context = context;
    }

    @NonNull
    @Override
    public PhyVerfFarmerSelectAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.cropsap_farmer_listing_single_item, viewGroup, false);

        PhyVerfFarmerSelectAdapter.MyViewHolder myViewHolder = new PhyVerfFarmerSelectAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PhyVerfFarmerSelectAdapter.MyViewHolder myViewHolder, int i) {
        try {
            jsonObject = cropsap_farmer_list.getJSONObject(i);
            myViewHolder.cropsap_farmername_si.setText(jsonObject.getString("FullName"));
            myViewHolder.cropsap_survey_si.setText(jsonObject.getString("VillageName"));
            //myViewHolder.cropsap_plot_si.setText(jsonObject.getString("scheme_name"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (cropsap_farmer_list != null) {
            return cropsap_farmer_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private PhyVerfFarmerSelectAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final PhyVerfFarmerSelectAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
