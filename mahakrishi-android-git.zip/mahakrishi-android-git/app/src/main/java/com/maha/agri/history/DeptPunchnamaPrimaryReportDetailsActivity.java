package com.maha.agri.history;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.eftimoff.viewpagertransformers.CubeOutTransformer;
import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DeptPunchnamaPrimaryReportDetailsActivity extends AppCompatActivity implements ApiCallbackCode {

    ViewPager dept_primary_report_details_viewpager;
    private JSONArray dept_primary_report_details_list;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    String village_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dept_punchnama_primary_report_details);
        getSupportActionBar().setTitle("Primary Report Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DeptPunchnamaPrimaryReportDetailsActivity.this);
        sharedPref = new SharedPref(DeptPunchnamaPrimaryReportDetailsActivity.this);
        IdCalling();

        Intent intent = getIntent();
        village_id = intent.getStringExtra("village_id");

        if (isNetworkAvailable()){
            getdept_village_list_list_details();

        }else {

        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        dept_primary_report_details_viewpager = (ViewPager) findViewById(R.id.dept_primary_report_details_viewpager);

    }

    private void getdept_village_list_list_details() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("village_id",village_id);

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.primary_report_details(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dept_primary_report_details_list = jsonObject.getJSONArray("data");
                            dept_primary_report_details_viewpager.setAdapter(new DepartmentPrimaryReportDetailsPagerAdapter(preferenceManager,dept_primary_report_details_list,this));
                            dept_primary_report_details_viewpager.setPageTransformer(true,new CubeOutTransformer());

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
