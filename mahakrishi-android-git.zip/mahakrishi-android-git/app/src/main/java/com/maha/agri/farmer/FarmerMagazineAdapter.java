package com.maha.agri.farmer;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;

import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerMagazineAdapter extends RecyclerView.Adapter<FarmerMagazineAdapter.MyViewHolder> {
    private JSONArray farmer_magazine_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView farmer_magazine_single_title;
        private RelativeLayout farmer_magazine_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.farmer_magazine_single_title = itemView.findViewById(R.id.farmer_magazine_single_text_view);
            this.farmer_magazine_single_item_rl = itemView.findViewById(R.id.farmer_magazine_single_item_rl);

        }
    }

    public FarmerMagazineAdapter(PreferenceManager preferenceManager, JSONArray farmer_magazine_array_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.farmer_magazine_array_list = farmer_magazine_array_list;
        this.context = context;

    }

    @Override
    public FarmerMagazineAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_magazine_single_item, parent, false);

        FarmerMagazineAdapter.MyViewHolder myViewHolder = new FarmerMagazineAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final FarmerMagazineAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = farmer_magazine_array_list.getJSONObject(listPosition);

           /* holder.farmer_magazine_single_item_rl.setTag(listPosition);

            holder.farmer_magazine_single_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = farmer_magazine_array_list.getJSONObject(index).getString("id");
                        preferencemanager.putPreferenceValues(Preference_Constant.FARMER_MAGAZINE_MONTH_ID,id);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });*/
            {
                holder.farmer_magazine_single_title.setText(jsonObject.getString("name_mr"));

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (farmer_magazine_array_list != null) {
            return farmer_magazine_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FarmerMagazineAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FarmerMagazineAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
