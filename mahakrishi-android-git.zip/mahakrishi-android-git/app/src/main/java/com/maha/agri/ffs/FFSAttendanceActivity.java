package com.maha.agri.ffs;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ffs.adaptor.FFS_AttendanceAdapter;
import com.maha.agri.ffs.model.AttendanceModel;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FFSAttendanceActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {

    private PreferenceManager preferenceManager;
    private DBHandler dbHandler;

    private String userID;
    private String reg_type;
    private String planId;

    private String villageId;
    private String farmerId;
    // private String farmerName;

    private String cropID;
    private AppLocationManager locationManager;

    // For Image upload
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 222;

    String currentTime;
    private ManagePermission managePermissions;
    private File photoFile = null;
    private Transformation transformation;
    private String selectedImage = "0";
    private String currentImglatLong = "";
    private TextView msgTextView;
    private RecyclerView recyclerView;
    private ImageView attendanceImageView;
    private ImageView attendanceListImageView;

    private TextView numUsersTextView;
    private TextView nameTextView;
    private TextView mobileTextView;
    private ImageView checkImageView;

    private double lat;
    private double lang;

    private FFS_AttendanceAdapter attendanceAdapter;
    private File imgFile = null;
    private double lat1;
    private double lang1;

    private File imgFile2 = null;
    private double lat2;
    private double lang2;

    private int genderId = 0;
    private JSONArray mDataArrays;
    private Dialog guestFarmerDialog;
    private int imageType = 0;
    int update_visit = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance2);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        preferenceManager = new PreferenceManager(FFSAttendanceActivity.this);
        currentTime = ApUtil.getCurrentTimeStamp();
        dbHandler = new DBHandler(FFSAttendanceActivity.this);
        locationManager = new AppLocationManager(this);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);

        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        msgTextView = findViewById(R.id.msgTextView);
        recyclerView = findViewById(R.id.recyclerView);
        attendanceImageView = findViewById(R.id.attendanceImageView);
        attendanceListImageView = findViewById(R.id.attendanceListImageView);
        numUsersTextView = findViewById(R.id.numUsersTextView);
        nameTextView = findViewById(R.id.nameTextView);
        mobileTextView = findViewById(R.id.mobileTextView);
        checkImageView = findViewById(R.id.checkImageView);

    }

    private void setConfiguration() {

        villageId = getIntent().getStringExtra("villageID");
        farmerId = getIntent().getStringExtra("farmerId");
        // farmerName  = "Host farmer : "+ getIntent().getStringExtra("farmerName");
        // nameTextView.setText(farmerName);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (getIntent() != null && getIntent().hasExtra("update_visit")) {
            update_visit = getIntent().getIntExtra("update_visit", 0);
        }

        DebugLog.getInstance().d("update_visit=" + update_visit);
        if (update_visit == 1) {
            findViewById(R.id.imgLinearLayout).setVisibility(View.GONE);
        } else {
            findViewById(R.id.imgLinearLayout).setVisibility(View.VISIBLE);
        }

        fetchAttendanceList();
        fetchSocialCategoryMasterData();

        attendanceImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageType = 1; // Group photo attendance
                if ((ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    // if ((ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    // String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        attendanceListImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageType = 2; // Attendance list photo
                if ((ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    //if ((ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    //String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitButtonAction();
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();

        if ((ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(FFSAttendanceActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();
        } else {
            String[] permissionRequest = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionRequest, LOCATION_PERMISSION_REQUEST_CODE);
            }
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.guest_farmer_add, menu); // TODO
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_add:
                registerGuestFarmerDialog();
                return true;

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }





    private void submitButtonAction() {

        try {
            JSONArray jsonArray = new JSONArray();
            if (attendanceAdapter != null && attendanceAdapter.mDataArray != null) {
                for (int i = 0; i < attendanceAdapter.mDataArray.length(); i++) {
                    JSONObject jsonObject = attendanceAdapter.mDataArray.getJSONObject(i);
                    AttendanceModel model = new AttendanceModel(jsonObject);
                    if (model.getIs_selected() == 1) {
                        jsonArray.put(jsonObject);
                    }
                }
            }


            if (update_visit == 1) { // For visit update
                if (jsonArray.length() == 0) {
                    UIToastMessage.show(this, getResources().getString(R.string.attendance_select_err));
                } else {
                    AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE, jsonArray.toString());
                    EventBus.getDefault().post(new EventModel("update_1"));
                    finish();
                }

            } else {
                if (jsonArray.length() == 0) {
                    UIToastMessage.show(this, getResources().getString(R.string.attendance_select_err));
                } else if (imgFile == null) {
                    UIToastMessage.show(this, getResources().getString(R.string.attendance_photo_err));
                } else if (imgFile2 == null) {
                    UIToastMessage.show(this, getResources().getString(R.string.attendance_photo_list_err));
                } else {
                    AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE, jsonArray.toString());
                    EventBus.getDefault().post(new EventModel("update_1"));
                    finish();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

        if (attendanceAdapter != null) {
            JSONArray jsonArray = new JSONArray();
            for (int k = 0; k < attendanceAdapter.mDataArray.length(); k++) {
                try {
                    JSONObject jsonObject = attendanceAdapter.mDataArray.getJSONObject(k);
                    AttendanceModel model = new AttendanceModel(jsonObject);
                    if (model.getIs_selected() == 1) {
                        jsonArray.put(jsonObject);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            String user;
            if (jsonArray.length() > 0) {

                if (jsonArray.length() == 1) {
                    user = jsonArray.length() + " Farmer Present";
                } else {
                    user = jsonArray.length() + " Farmers Present";
                }
                numUsersTextView.setText(user);
            } else {
                numUsersTextView.setText("");
            }
        }
    }


    /*private void fetchDatabaseData() {

        String farmer_name = getIntent().getStringExtra("farmer_name");
        String host_farmer_mobile = getIntent().getStringExtra("host_farmer_mobile");
        String name = appString.getHostFarmer() + farmer_name;
        String mob = appString.getMobile() + host_farmer_mobile;

        nameTextView.setText(name);
        mobileTextView.setText(mob);
        checkImageView.setVisibility(View.VISIBLE);


        final AppSession session = new AppSession(this);
        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                DBHandler db = AppDelegate.getInstance(mContext).getAppDatabase();
                List<FarmersPlotEY> mDataArray = db.farmersPlotDAO().getGuestFarmerForPlot(session.getPlotID());
                final JSONArray jsonArray = new JSONArray();

                for (FarmersPlotEY farmersPlotEY : mDataArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", farmersPlotEY.getUid());
                        jsonObject.put("first_name", farmersPlotEY.getFirst_name());
                        jsonObject.put("last_name", farmersPlotEY.getLast_name());
                        jsonObject.put("middle_name", farmersPlotEY.getMiddle_name());
                        jsonObject.put("age", farmersPlotEY.getAge());
                        jsonObject.put("mobile", farmersPlotEY.getMobile());
                        jsonObject.put("social_category_id", farmersPlotEY.getSocial_category_id());
                        jsonObject.put("plot_id", farmersPlotEY.getPlot_id());
                        jsonObject.put("social_category_name", farmersPlotEY.getSocial_category_name());
                        jsonObject.put("lat", farmersPlotEY.getLat());
                        jsonObject.put("lng", farmersPlotEY.getLng());
                        jsonObject.put("physically_challenged", farmersPlotEY.getPhysically_challenged());
                        jsonObject.put("gender", farmersPlotEY.getGender());

                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                FFSAttendanceActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if (jsonArray.length() > 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            msgTextView.setVisibility(View.GONE);
                        } else {
                            msgTextView.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        }

                        attendanceAdapter = new FFS_AttendanceAdapter(FFSAttendanceActivity.this, FFSAttendanceActivity.this, jsonArray);
                        recyclerView.setAdapter(attendanceAdapter);
                    }
                });

                mDataArrays = new JSONArray();
                List<M_Social_CategoryEY> socialDataArr = db.socialCategoryDAO().getAll();
                for (M_Social_CategoryEY social_categoryEY : socialDataArr) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", social_categoryEY.getUid());
                        jsonObject.put("name", social_categoryEY.getName());
                        mDataArrays.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                db.close();
            }
        }).start();
    }*/


    /*private void refreshDatabaseData() {

        final AppSession session = new AppSession(this);
        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getAppDatabase();
                List<FarmersPlotEY> mDataArray = db.farmersPlotDAO().getGuestFarmerForPlot(session.getPlotID());
                final JSONArray jsonArray = new JSONArray();

                for (FarmersPlotEY farmersPlotEY : mDataArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", farmersPlotEY.getUid());
                        jsonObject.put("first_name", farmersPlotEY.getFirst_name());
                        jsonObject.put("last_name", farmersPlotEY.getLast_name());
                        jsonObject.put("middle_name", farmersPlotEY.getMiddle_name());
                        jsonObject.put("age", farmersPlotEY.getAge());
                        jsonObject.put("mobile", farmersPlotEY.getMobile());
                        jsonObject.put("social_category_id", farmersPlotEY.getSocial_category_id());
                        jsonObject.put("plot_id", farmersPlotEY.getPlot_id());
                        jsonObject.put("social_category_name", farmersPlotEY.getSocial_category_name());
                        jsonObject.put("lat", farmersPlotEY.getLat());
                        jsonObject.put("lng", farmersPlotEY.getLng());
                        jsonObject.put("physically_challenged", farmersPlotEY.getPhysically_challenged());
                        jsonObject.put("gender", farmersPlotEY.getGender());

                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                FFSAttendanceActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if (jsonArray.length() > 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            msgTextView.setVisibility(View.GONE);
                        } else {
                            msgTextView.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        }

                        attendanceAdapter = new FFS_AttendanceAdapter(FFSAttendanceActivity.this, FFSAttendanceActivity.this, jsonArray);
                        recyclerView.setAdapter(attendanceAdapter);
                    }
                });
                db.close();
            }
        }).start();
    }*/


    private void fetchAttendanceList() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("plan_id", planId);
            param.put("reg_type", reg_type);
        } catch (Exception e) {

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        // Call<JsonObject> responseCall = apiRequest.gest_farmer_list(requestBody);
        Call<JsonObject> responseCall = apiRequest.get_farmer_list(requestBody);
        DebugLog.getInstance().d("guest_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("guest_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }


    // For Image upload
    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userID + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (imageType == 1) {
                            imgFile = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat1 = locationManager.getLatitude();
                            lang1 = locationManager.getLatitude();
                        } else if (imageType == 2) {
                            imgFile2 = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat2 = locationManager.getLatitude();
                            lang2 = locationManager.getLatitude();
                        }

                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } else {
            Toast.makeText(FFSAttendanceActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {
            currentImglatLong = locationManager.getLatitude() + "_" + locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

            //creating a file
            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("image_name", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.upload_technology_demo_img(partBody, params);
            api.postRequest(responseCall, this, 33);

            DebugLog.getInstance().d("activity_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("activity_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //:: TODO Guest Farmer Registration
    private void registerGuestFarmerDialog() {
        genderId = -1;

        guestFarmerDialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        guestFarmerDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        guestFarmerDialog.setCancelable(false);
        guestFarmerDialog.setContentView(R.layout.dialog_guest_farmer_reg);

        final EditText lNameEditText = guestFarmerDialog.findViewById(R.id.lNameEditText);
        final EditText fNameEditText = guestFarmerDialog.findViewById(R.id.fNameEditText);
        final EditText mNameEditText = guestFarmerDialog.findViewById(R.id.mNameEditText);
        final EditText mobEditText = guestFarmerDialog.findViewById(R.id.mobEditText);

        RadioGroup radioGroup = guestFarmerDialog.findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                  @Override
                                                  public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                      if (checkedId == R.id.maleRadioButton) {
                                                          genderId = 1;
                                                      } else if (checkedId == R.id.femaleRadioButton) {
                                                          genderId = 2;
                                                      } else {
                                                          genderId = 3;
                                                      }
                                                  }
                                              }
        );


        Button cancelButton = guestFarmerDialog.findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guestFarmerDialog.dismiss();
            }
        });


        Button submitButton = guestFarmerDialog.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String lName = lNameEditText.getText().toString();
                String fName = fNameEditText.getText().toString();
                String mName = mNameEditText.getText().toString();
                String mob = mobEditText.getText().toString();

                if (lName.isEmpty()) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please enter last name");

                } else if (fName.isEmpty()) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please enter first name");

                } else if (mName.isEmpty()) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please enter middle name");

                } else if (genderId == -1) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please select gender");

                } else if (mob.isEmpty()) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please enter mobile number");

                } else if (!AppUtility.getInstance().isValidPhoneNumber(mob)) {
                    UIToastMessage.show(FFSAttendanceActivity.this, "Please enter valid mobile number");

                } else {
                    validatePostRequest(lName, fName, mName, mob);


                }

            }
        });

        guestFarmerDialog.show();
    }


    private void fetchSocialCategoryMasterData() {

        String url = APIServices.kSocialCat;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                mDataArrays = response.getData();
                            } else {
                                UIToastMessage.show(FFSAttendanceActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    private void validatePostRequest(String lName, String fName, String mName, String mob) {

        try {
            AppSession session = new AppSession(this);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            jsonObject.put("created_by", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("village_id", villageId);
            jsonObject.put("plan_id", planId);
            jsonObject.put("host_farmer_id", farmerId);
            jsonObject.put("last_name", lName);
            jsonObject.put("first_name", fName);
            jsonObject.put("middle_name", mName);
            jsonObject.put("gender", genderId);
            jsonObject.put("mobile", mob);
            jsonObject.put("lat", lat);
            jsonObject.put("lon", lang);
            jsonObject.put("reg_type", reg_type);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.registerGuestFarmer(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            // To get guest farmer list
            if (i == 1) {
                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        attendanceAdapter = new FFS_AttendanceAdapter(FFSAttendanceActivity.this, FFSAttendanceActivity.this, jsonArray);
                        recyclerView.setAdapter(attendanceAdapter);
                    } else {
                        msgTextView.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                        UIToastMessage.show(FFSAttendanceActivity.this, responseModel.getMsg());
                    }
                }
            }


            // DebugLog.getInstance().d("onResponse=" + jsonObject.toString());

            if (i == 33) {
                ResponseModel response = new ResponseModel(jsonObject);
                if (response.isStatus()) {

                    if (imageType == 1) {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_FILE, jsonObject.toString());
                        if (currentImglatLong.equalsIgnoreCase("")) {
                            AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_FILE_LOC, currentImglatLong);
                        } else {
                            AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_FILE_LOC, ApConstants.kATTENDANCE_FILE_LOC);
                        }
                        String imgUrl = jsonObject1.getString("file_url");
                        if (!imgUrl.equalsIgnoreCase("")) {
                            Picasso.get()
                                    //.load("")
                                    // .load(photoFile)
                                    .load(imgUrl)
                                    .resize(150, 150)
                                    .centerCrop()
                                    .into(attendanceImageView);
                        }
                    }

                    if (imageType == 2) {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_LIST_FILE, jsonObject.toString());
                        if (currentImglatLong.equalsIgnoreCase("")) {
                            AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_LIST_FILE_LOC, currentImglatLong);
                        } else {
                            AppSettings.getInstance().setValue(this, ApConstants.kATTENDANCE_LIST_FILE_LOC, ApConstants.kATTENDANCE_LIST_FILE_LOC);
                        }
                        String imgUrl = jsonObject1.getString("file_url");
                        if (!imgUrl.equalsIgnoreCase("")) {
                            Picasso.get()
                                    //.load("")
                                    // .load(photoFile)
                                    .load(imgUrl)
                                    .resize(150, 150)
                                    .centerCrop()
                                    .into(attendanceListImageView);
                        }
                    }

                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

            // Guest Farmer registration
            if (i == 2) {
                ResponseModel response = new ResponseModel(jsonObject);
                if (response.isStatus()) {
                    UIToastMessage.show(this, response.getMsg());
                    EditText lNameEditText = guestFarmerDialog.findViewById(R.id.lNameEditText);
                    lNameEditText.setText("");
                    EditText fNameEditText = guestFarmerDialog.findViewById(R.id.fNameEditText);
                    fNameEditText.setText("");
                    EditText mNameEditText = guestFarmerDialog.findViewById(R.id.mNameEditText);
                    mNameEditText.setText("");
                    EditText mobEditText = guestFarmerDialog.findViewById(R.id.mobEditText);
                    mobEditText.setText("");
                    RadioGroup radioGroup = guestFarmerDialog.findViewById(R.id.radioGroup);
                    radioGroup.clearCheck();
                    fetchAttendanceList();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
