package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.maha.agri.R;

public class DepartmentCategoryPanchnamaActivity extends AppCompatActivity {

    private Button dept_panchnama_primary_report_btn,dept_panchnama_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_category_panchnama);
        getSupportActionBar().setTitle("Crop Loss Assessment(Panchnama");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        dept_panchnama_primary_report_btn = (Button)findViewById(R.id.dept_panchnama_primary_report_btn);
        dept_panchnama_btn = (Button)findViewById(R.id.dept_panchnama_btn);


        dept_panchnama_primary_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent primary_report = new Intent(DepartmentCategoryPanchnamaActivity.this, PrimaryReportActivity.class);
                startActivity(primary_report);
            }
        });

        dept_panchnama_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent primary_report = new Intent(DepartmentCategoryPanchnamaActivity.this, DepartmentPanchnamaReportActivity.class);
                startActivity(primary_report);
            }
        });
    }

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cropsap_menu, menu);
        return true;
    }
*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            /*case R.id.history:
                Intent punchnama_history  = new Intent(DepartmentCategoryPanchnamaActivity.this, DeptPunchnamaHistoryActivity.class);
                startActivity(punchnama_history);
                return true;*/

            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
