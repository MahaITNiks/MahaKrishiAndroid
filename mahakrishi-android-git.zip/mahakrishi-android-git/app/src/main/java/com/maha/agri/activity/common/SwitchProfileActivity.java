package com.maha.agri.activity.common;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SwitchProfileAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

import static com.maha.agri.database.DBHandler.TABLE_SWITCH_PROFILE_DATA;


public class SwitchProfileActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView switch_profile_rv;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private DBHandler dbHandler;
    private JSONArray assigned_charge = new JSONArray();
    private String switch_profile_location[] = {"Circle : xxxx || Sajja : xxxx","Circle : yyyy || Sajja : yyyy","Circle : zzzz || Sajja : zzzz","Circle : aaaa || Sajja : aaaa"};
    private String switch_profile_role[] = {"AA-Primary","AA-Additional","AS-Additional","CAO-Additional"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch_profile);
        preferenceManager = new PreferenceManager(SwitchProfileActivity.this);
        sharedPref = new SharedPref(SwitchProfileActivity.this);
        dbHandler = new DBHandler(this);

        init();
        default_config();
        getAssignedCharges();

        if(isNetworkAvailable()) {
            getAssignedCharges();
        } else {
            getOfflineswitchprofiledata();
        }
    }

    private void init(){
        switch_profile_rv = (RecyclerView) findViewById(R.id.switch_profile_rv);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        switch_profile_rv.setLayoutManager(gridLayoutManager);
    }

    private void default_config(){

    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void getOfflineswitchprofiledata(){
        assigned_charge = dbHandler.getSwitchProfileData();
        switch_profile_rv.setAdapter(new SwitchProfileAdapter(this,preferenceManager,assigned_charge));
    }

    private void getAssignedCharges() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            param.put("primary_job_category", "1");
            param.put("job_category", "1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.assigned_charge_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {
            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            assigned_charge = jsonObject.getJSONArray("data");
                            switch_profile_rv.setAdapter(new SwitchProfileAdapter(this,preferenceManager,assigned_charge));
                            SQLiteDatabase db = dbHandler.getReadableDatabase();
                            db.delete(TABLE_SWITCH_PROFILE_DATA, null, null);
                            for (int j = 0; j < assigned_charge.length(); j++) {
                                JSONObject work_location_obj = assigned_charge.getJSONObject(j);
                                dbHandler.insertswitchprofiledata(work_location_obj.getString("circle_id"),work_location_obj.getString("circle_name"),
                                        work_location_obj.getString("circle_code"),work_location_obj.getString("c_location_type"),work_location_obj.getString("sajja_id"),
                                        work_location_obj.getString("sajja_name"),work_location_obj.getString("sajja_code"),work_location_obj.getString("s_location_type"),
                                        work_location_obj.getString("role_charge"),work_location_obj.getString("role_charge_id"),work_location_obj.getString("role_officer"),
                                        work_location_obj.getString("role_officer_id"));
                            }
                        }
                    }else{
                        new AlertDialog.Builder(SwitchProfileActivity.this)
                                .setTitle("Maha-Krushi")
                                .setMessage("Please contact with you higher officer for providing locations")
                                .setCancelable(false)

                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                                .show();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}