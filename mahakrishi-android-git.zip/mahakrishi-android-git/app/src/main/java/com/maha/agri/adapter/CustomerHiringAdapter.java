package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class CustomerHiringAdapter extends RecyclerView.Adapter<CustomerHiringAdapter.MyViewHolder> {
    private JSONArray add_more_list;
    private JSONObject jsonObject;
    private Context context;
    private PreferenceManager preferenceManager;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView chc_tool_real_name_tv,chc_reg_name_tv,chc_bill_amt_app_tv,chc_bill_amt_actual_tv;
        private ImageView chc_remove;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.chc_tool_real_name_tv = itemView.findViewById(R.id.chc_tool_real_name_tv);
            this.chc_reg_name_tv = itemView.findViewById(R.id.chc_reg_name_tv);
            this.chc_bill_amt_actual_tv = itemView.findViewById(R.id.chc_bill_amt_actual_tv);
            this.chc_bill_amt_app_tv = itemView.findViewById(R.id.chc_bill_amt_app_tv);
            this.chc_remove = itemView.findViewById(R.id.chc_remove);

        }
    }

    public CustomerHiringAdapter(PreferenceManager preferenceManager, JSONArray add_more_list, Context context) {
        this.preferenceManager = preferenceManager;
        this.add_more_list = add_more_list;
        this.context = context;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.customer_hiring_single_item, viewGroup, false);

        CustomerHiringAdapter.MyViewHolder myViewHolder = new CustomerHiringAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int i) {
        try {
            jsonObject = add_more_list.getJSONObject(i);
            holder.chc_tool_real_name_tv.setText(jsonObject.getString("real_name"));
            holder.chc_reg_name_tv.setText(jsonObject.getString("reg_name"));
            holder.chc_bill_amt_app_tv.setText(jsonObject.getString("bill_amt_app"));
            holder.chc_bill_amt_actual_tv.setText(jsonObject.getString("bill_amt_actual"));
            holder.chc_remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    add_more_list.remove(i);
                    notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private CustomerHiringAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CustomerHiringAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
