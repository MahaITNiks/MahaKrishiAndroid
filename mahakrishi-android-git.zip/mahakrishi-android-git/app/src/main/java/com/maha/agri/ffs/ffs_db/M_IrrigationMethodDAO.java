package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_IrrigationMethodDAO {

    @Query("SELECT * FROM M_IrrigationMethodEY")
    List<M_IrrigationMethodEY> getAll();

    @Query("SELECT * FROM M_IrrigationMethodEY WHERE uid IN (:userIds)")
    List<M_IrrigationMethodEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_IrrigationMethodEY WHERE uid = :id")
    List<M_IrrigationMethodEY> checkIdExists(int id);


    @Insert
    void insertAll(M_IrrigationMethodEY... m_rainfallCondition);

    @Insert
    void insertOnlySingle(M_IrrigationMethodEY m_rainfallConditionEY);
}
