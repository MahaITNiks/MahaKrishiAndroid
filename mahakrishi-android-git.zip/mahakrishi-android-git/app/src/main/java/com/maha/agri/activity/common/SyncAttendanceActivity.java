package com.maha.agri.activity.common;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.GPSTracker;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SyncAttendanceActivity extends AppCompatActivity implements ApiCallbackCode {

    GPSTracker gps;
    private DBHandler dbHandler;
    PreferenceManager preferenceManager;
    private ManagePermission managePermissions;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;

    private String userId;
    private TextView syncCompleteTView;
    private TextView syncTView;
    private JSONArray allAttendanceArray;
    private int syncedCount = 0;
    private String sync_lat = "";
    private String sync_long = "";
    private String file_in = "";
    private String file_out = "";
    private String responseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync_attendance);

        getSupportActionBar().setTitle("Sync Attendance");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dbHandler = new DBHandler(this);

        preferenceManager = new PreferenceManager(SyncAttendanceActivity.this);
        init();
        defaultConfig();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {

        userId = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        syncCompleteTView = (TextView) findViewById(R.id.syncCompleteTView);
        syncTView = (TextView) findViewById(R.id.syncTView);
    }

    private void defaultConfig() {


    }

    @Override
    protected void onResume() {
        super.onResume();

        allAttendanceArray = dbHandler.getAttendanceDetail(userId);

        if (Build.VERSION.SDK_INT < 19) {
            getLocation();
            syncAttendance();
        } else {
            if (checkUserPermission(APP_PERMISSION_REQUEST_CODE)) {
                getLocation();
                syncAttendance();
            }
        }
    }




    private void syncAttendance() {

        if (allAttendanceArray.length() > 0) {

            if (allAttendanceArray.length() > syncedCount) {
                syncTView.setVisibility(View.VISIBLE);
                syncCompleteTView.setVisibility(View.GONE);

                for (int i = syncedCount; i < allAttendanceArray.length(); i++) {
                    try {
                        JSONObject attendanceJSON = allAttendanceArray.getJSONObject(i);
                        syncOnServer(attendanceJSON);
                        break;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            } else if (syncedCount >= allAttendanceArray.length()){
                dbHandler.deleteAllData();
                syncCompleteTView.setVisibility(View.VISIBLE);
                syncTView.setVisibility(View.GONE);
            }

        }else {
            dbHandler.deleteAllData();
            syncCompleteTView.setVisibility(View.VISIBLE);
            syncTView.setVisibility(View.GONE);

        }
    }

    private void syncOnServer(JSONObject attendanceJSON) {

        try {
            String in_time = attendanceJSON.getString("in_time");
            String address_in = attendanceJSON.getString("address_in");
            String in_lat = attendanceJSON.getString("in_lat");
            String in_long = attendanceJSON.getString("in_long");
            file_in = attendanceJSON.getString("file_in");
            String file_in_lat = attendanceJSON.getString("file_in_lat");
            String file_in_long = attendanceJSON.getString("file_in_long");

            String out_time = attendanceJSON.getString("out_time");
            String address_out = attendanceJSON.getString("address_out");
            String out_lat = attendanceJSON.getString("out_lat");
            String out_long = attendanceJSON.getString("out_long");
            file_out = attendanceJSON.getString("file_out");
            String file_out_lat = attendanceJSON.getString("file_out_lat");
            String file_out_long = attendanceJSON.getString("file_out_long");

            String reasonId = attendanceJSON.getString("reasonId");



            JSONObject param = new JSONObject();
            try {
                param.put("user_id", userId);
                param.put("lat", in_lat);
                param.put("lng", in_long);
                param.put("in_address", address_in);
                param.put("report_time", in_time);
                param.put("file_lat", file_in_lat);
                param.put("file_long", file_in_long);
                param.put("out_lat", out_lat);
                param.put("out_long", out_long);
                param.put("out_address", address_out);
                param.put("out_time", out_time);
                param.put("out_file_lat", file_out_lat);
                param.put("out_file_long", file_out_long);
                param.put("absent_reason_id", reasonId);
                param.put("sync_time", ApUtil.getCurrentTimeStamp());
                param.put("sync_lat", sync_lat);
                param.put("sync_long", sync_long);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.offlinecheckinandoutsurl(requestBody);
            DebugLog.getInstance().d("offline_sync_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("offline_sync_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    // To get Lat & long
    private void getLocation() {
        gps = new GPSTracker(this);
        // Check if GPS enabled

        if (ActivityCompat.checkSelfPermission(SyncAttendanceActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(SyncAttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(SyncAttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(SyncAttendanceActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        } else {

            if (gps.canGetLocation()) {

                final double latitude = gps.getLatitude();
                final double longitude = gps.getLongitude();

                sync_lat = String.valueOf(latitude);
                sync_long = String.valueOf(longitude);

                // Write you code here if permission already given.

            } else {
                // Can't get location.
                // GPS or network is not enabled.
                // Ask user to enable GPS/network in settings.
                showSettingsAlert();
            }
        }
    }


    /**
     * Function to show settings alert dialog.
     * On pressing the Settings button it will launch Settings Options.
     */
    public void showSettingsAlert() {
        android.app.AlertDialog.Builder alertDialog = new android.app.AlertDialog.Builder(this);

        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings");

        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");

        // On pressing the Settings button.
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });


        // On pressing the cancel button
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }


    /**** For permission with ManagePermissionClass*****/
    private boolean checkUserPermission(int appPermissionCode) {

        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionFineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int permissionCoarseLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int permissionStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        ArrayList<String> listPermissionsNeeded = new ArrayList<>();


        if (permissionWrite != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionFineLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionCoarseLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            managePermissions = new ManagePermission(this, listPermissionsNeeded, APP_PERMISSION_REQUEST_CODE);
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), APP_PERMISSION_REQUEST_CODE);
            return false;
        }

        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case APP_PERMISSION_REQUEST_CODE: {
                boolean isPermissionsGranted = managePermissions.processPermissionsResult(requestCode, permissions, grantResults);
                if (isPermissionsGranted) {
                    getLocation();
                } else {
                    // toast("Permissions denied.")
                    managePermissions.checkPermission();
                }
            }

        }
    }



    private void uploadImageOnServer(String imgType,String resId) {
        try {
            File photoFile ;
            if (imgType.equalsIgnoreCase("check_in")){
                photoFile = new File(file_in);
            }else {
                photoFile = new File(file_out);
            }

            MultipartBody.Part partBody = null;
           //  DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id",userId);
            params.put("type",imgType);
            params.put("timestamp",ApUtil.getCurrentTimeStamp());
            params.put("id",resId );


            //creating a file
            File file = new File(photoFile.getPath());
            // File file = new File(imagePath);

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.offlineImgUpload(partBody, params);
            if (imgType.equalsIgnoreCase("check_in")){
                api.postRequest(responseCall, this, 2);
            }else {
                api.postRequest(responseCall, this, 3);
            }

            DebugLog.getInstance().d("offline_attendance_img_upload_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("offline_attendance_img_upload_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                // Profile update response
                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);

                    if (responseModel.isStatus()) {
                        JSONObject data = jsonObject.getJSONObject("data");
                        responseId = data.getString("id");
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                syncedCount++;
                                uploadImageOnServer(ApConstants.kIMG_IN,responseId);
                            }
                        }, 2000);
                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }

                // In Img upload response
                if (i == 2) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);

                    if (responseModel.isStatus()) {

                        JSONObject data = jsonObject.getJSONObject("data");

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                uploadImageOnServer(ApConstants.kIMG_OUT,responseId);
                            }
                        }, 2000);

                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }


                // Profile pic update response
                if (i == 3) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);

                    if (responseModel.isStatus()) {
                        JSONObject data = jsonObject.getJSONObject("data");
                        if (Build.VERSION.SDK_INT < 19) {
                            getLocation();
                            syncAttendance();
                        } else {
                            if (checkUserPermission(APP_PERMISSION_REQUEST_CODE)) {
                                getLocation();
                                syncAttendance();
                            }
                        }

                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
