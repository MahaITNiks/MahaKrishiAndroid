package com.maha.agri.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;


public class AttendDetailModel {



    private String id;
    private String in_lat;
    private String in_long;
    private String in_file_name;
    private String in_file_lat;
    private String in_file_long;
    private String in_report_time;
    private String out_lat;
    private String out_long;
    private String out_file_name;
    private String out_time;
    private String out_file_lat;
    private String out_file_long;
    private String date;
    private String is_present;
    private String hours;
    private String day_of_month;
    private String absent_reason_id;
    private String absent_reason_name;


    private JSONObject jsonObject;


    public AttendDetailModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public JSONArray getData() {
        try {
            return this.jsonObject.getJSONArray("data");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getId() {
        return id = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "id");
    }

    public String getIn_lat() {
        return in_lat = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "lat");
    }

    public String getIn_long() {
        return in_long = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "long");
    }

    public String getIn_file_name() {
        return in_file_name = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "file_name");
    }

    public String getIn_file_lat() {
        return in_file_lat = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "file_lat");
    }

    public String getIn_file_long() {
        return in_file_long = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "file_long");
    }

    public String getIn_report_time() {
        return in_report_time = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "report_time");
    }

    public String getOut_lat() {
        return out_lat = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_lat");
    }

    public String getOut_long() {
        return out_long = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_long");
    }

    public String getOut_file_name() {
        return out_file_name = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_file_name");
    }

    public String getOut_time() {
        return out_time = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_time");
    }

    public String getOut_file_lat() {
        return out_file_lat = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_file_lat");
    }

    public String getOut_file_long() {
        return out_file_long = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "out_file_long");
    }

    public String getDate() {
        return date = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "date");
    }

    public String getIs_present() {
        return is_present = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "is_present");
    }

    public String getHours() {
        return hours = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "hours");
    }

    public String getDay_of_month() {
        return day_of_month = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "day_of_month");
    }

    public String getAbsent_reason_id() {
        return absent_reason_id  = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "absent_reason_id");
    }

    public String getAbsent_reason_name() {
        return absent_reason_name  = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "absent_reason_name");
    }
}
