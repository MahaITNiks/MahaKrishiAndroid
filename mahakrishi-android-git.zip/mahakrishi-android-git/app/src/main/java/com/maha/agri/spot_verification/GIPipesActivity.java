package com.maha.agri.spot_verification;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GIPipesActivity extends AppCompatActivity implements ApiCallbackCode {
    
    private RadioGroup green_house1_bis_rg,green_house1_items_rg,green_house1_bis1_rg,green_house1_bis2_rg,green_house1_bis3_rg,green_house1_bis4_rg,
            green_house1_bis5_rg,green_house1_bis6_rg,green_house1_bis7_rg,green_house1_bis8_rg,green_house1_bis9_rg,green_house1_bis10_rg;
    
    private RadioButton green_house1_bis_yes,green_house1_bis_no,green_house1_items_yes,green_house1_items_no,green_house1_bis1_yes,green_house1_bis1_no,
            green_house1_bis2_yes,green_house1_bis2_no,green_house1_bis3_yes,green_house1_bis3_no,green_house1_bis4_yes,green_house1_bis4_no,green_house1_bis5_yes,
            green_house1_bis5_no,green_house1_bis6_yes,green_house1_bis6_no,green_house1_bis7_yes,green_house1_bis7_no,green_house1_bis8_yes,green_house1_bis8_no,
            green_house1_bis9_yes,green_house1_bis9_no,green_house1_bis10_yes,green_house1_bis10_no;
    
    private EditText green_house1_table1_row1_actual,green_house1_table1_row2_actual,green_house1_table1_row3_actual,green_house1_table1_row4_actual,
            green_house1_table1_row5_actual,green_house1_table1_row6_actual,green_house1_table1_row7_actual,green_house1_table1_row1_comment,green_house1_table1_row2_comment,
            green_house1_table1_row3_comment,green_house1_table1_row4_comment,green_house1_table1_row5_comment,green_house1_table1_row6_comment,
            green_house1_table1_row7_comment,green_house1_table2_row1_actual,green_house1_table2_row2_actual,green_house1_table2_row3_actual,
            green_house1_table2_row4_actual,green_house1_table2_row5_actual,green_house1_table2_row6_actual,green_house1_table2_row7_actual,green_house1_table2_row1_comment,
            green_house1_table2_row2_comment,green_house1_table2_row3_comment,green_house1_table2_row4_comment,green_house1_table2_row5_comment,
            green_house1_table2_row6_comment,green_house1_table2_row7_comment,green_house1_table3_row1_actual,green_house1_table3_row2_actual,
            green_house1_table3_row3_actual,green_house1_table3_row4_actual,green_house1_table3_row5_actual,green_house1_table3_row6_actual,green_house1_table3_row7_actual,
            green_house1_table3_row1_comment,green_house1_table3_row2_comment,green_house1_table3_row3_comment,green_house1_table3_row4_comment,
            green_house1_table3_row5_comment,green_house1_table3_row6_comment,green_house1_table3_row7_comment;
    
    private Button green_house1_part2_save;
    private String bis="0",items="0",bis1="0",bis2="0",bis3="0",bis4="0",bis5="0",bis6="0",bis7="0",bis8="0",bis9="0",bis10="0";
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_g_i_pipes);
        getSupportActionBar().setTitle("GI Pipes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(GIPipesActivity.this);

        ids();
        functions();
    }

    private void ids(){
        //Edittext
        green_house1_table1_row1_actual = (EditText) findViewById(R.id.green_house1_table1_row1_actual);
        green_house1_table1_row2_actual = (EditText) findViewById(R.id.green_house1_table1_row2_actual);
        green_house1_table1_row3_actual = (EditText) findViewById(R.id.green_house1_table1_row3_actual);
        green_house1_table1_row4_actual = (EditText) findViewById(R.id.green_house1_table1_row4_actual);
        green_house1_table1_row5_actual = (EditText) findViewById(R.id.green_house1_table1_row5_actual);
        green_house1_table1_row6_actual = (EditText) findViewById(R.id.green_house1_table1_row6_actual);
        green_house1_table1_row7_actual = (EditText) findViewById(R.id.green_house1_table1_row7_actual);
        green_house1_table1_row1_comment = (EditText) findViewById(R.id.green_house1_table1_row1_comment);
        green_house1_table1_row2_comment = (EditText) findViewById(R.id.green_house1_table1_row2_comment);
        green_house1_table1_row3_comment = (EditText) findViewById(R.id.green_house1_table1_row3_comment);
        green_house1_table1_row4_comment = (EditText) findViewById(R.id.green_house1_table1_row4_comment);
        green_house1_table1_row5_comment = (EditText) findViewById(R.id.green_house1_table1_row5_comment);
        green_house1_table1_row6_comment = (EditText) findViewById(R.id.green_house1_table1_row6_comment);
        green_house1_table1_row7_comment = (EditText) findViewById(R.id.green_house1_table1_row7_comment);
        green_house1_table2_row1_actual = (EditText) findViewById(R.id.green_house1_table2_row1_actual);
        green_house1_table2_row2_actual = (EditText) findViewById(R.id.green_house1_table2_row2_actual);
        green_house1_table2_row3_actual = (EditText) findViewById(R.id.green_house1_table2_row3_actual);
        green_house1_table2_row4_actual = (EditText) findViewById(R.id.green_house1_table2_row4_actual);
        green_house1_table2_row5_actual = (EditText) findViewById(R.id.green_house1_table2_row5_actual);
        green_house1_table2_row6_actual = (EditText) findViewById(R.id.green_house1_table2_row6_actual);
        green_house1_table2_row7_actual = (EditText) findViewById(R.id.green_house1_table2_row7_actual);
        green_house1_table2_row1_comment = (EditText) findViewById(R.id.green_house1_table2_row1_comment);
        green_house1_table2_row2_comment = (EditText) findViewById(R.id.green_house1_table2_row2_comment);
        green_house1_table2_row3_comment = (EditText) findViewById(R.id.green_house1_table2_row3_comment);
        green_house1_table2_row4_comment = (EditText) findViewById(R.id.green_house1_table2_row4_comment);
        green_house1_table2_row5_comment = (EditText) findViewById(R.id.green_house1_table2_row5_comment);
        green_house1_table2_row6_comment = (EditText) findViewById(R.id.green_house1_table2_row6_comment);
        green_house1_table2_row7_comment = (EditText) findViewById(R.id.green_house1_table2_row7_comment);
        green_house1_table3_row1_actual = (EditText) findViewById(R.id.green_house1_table3_row1_actual);
        green_house1_table3_row2_actual = (EditText) findViewById(R.id.green_house1_table3_row2_actual);
        green_house1_table3_row3_actual = (EditText) findViewById(R.id.green_house1_table3_row3_actual);
        green_house1_table3_row4_actual = (EditText) findViewById(R.id.green_house1_table3_row4_actual);
        green_house1_table3_row5_actual = (EditText) findViewById(R.id.green_house1_table3_row5_actual);
        green_house1_table3_row6_actual = (EditText) findViewById(R.id.green_house1_table3_row6_actual);
        green_house1_table3_row7_actual = (EditText) findViewById(R.id.green_house1_table3_row7_actual);
        green_house1_table3_row1_comment = (EditText) findViewById(R.id.green_house1_table3_row1_comment);
        green_house1_table3_row2_comment = (EditText) findViewById(R.id.green_house1_table3_row2_comment);
        green_house1_table3_row3_comment = (EditText) findViewById(R.id.green_house1_table3_row3_comment);
        green_house1_table3_row4_comment = (EditText) findViewById(R.id.green_house1_table3_row4_comment);
        green_house1_table3_row5_comment = (EditText) findViewById(R.id.green_house1_table3_row5_comment);
        green_house1_table3_row6_comment = (EditText) findViewById(R.id.green_house1_table3_row6_comment);
        green_house1_table3_row7_comment = (EditText) findViewById(R.id.green_house1_table3_row7_comment);

        //RadioGroup
        green_house1_bis1_rg = (RadioGroup) findViewById(R.id.green_house1_bis1_rg);
        green_house1_bis2_rg = (RadioGroup) findViewById(R.id.green_house1_bis2_rg);
        green_house1_bis3_rg = (RadioGroup) findViewById(R.id.green_house1_bis3_rg);
        green_house1_bis4_rg = (RadioGroup) findViewById(R.id.green_house1_bis4_rg);
        green_house1_bis5_rg = (RadioGroup) findViewById(R.id.green_house1_bis5_rg);
        green_house1_bis6_rg = (RadioGroup) findViewById(R.id.green_house1_bis6_rg);
        green_house1_bis7_rg = (RadioGroup) findViewById(R.id.green_house1_bis7_rg);
        green_house1_bis8_rg = (RadioGroup) findViewById(R.id.green_house1_bis8_rg);
        green_house1_bis9_rg = (RadioGroup) findViewById(R.id.green_house1_bis9_rg);
        green_house1_bis10_rg = (RadioGroup) findViewById(R.id.green_house1_bis10_rg);
        green_house1_items_rg = (RadioGroup) findViewById(R.id.green_house1_items_rg);
        green_house1_bis_rg = (RadioGroup) findViewById(R.id.green_house1_bis_rg);

        //RadioButton
        green_house1_bis1_yes = (RadioButton) findViewById(R.id.green_house1_bis1_yes);
        green_house1_bis1_no = (RadioButton) findViewById(R.id.green_house1_bis1_no);
        green_house1_bis2_yes = (RadioButton) findViewById(R.id.green_house1_bis2_yes);
        green_house1_bis2_no = (RadioButton) findViewById(R.id.green_house1_bis2_no);
        green_house1_bis3_yes = (RadioButton) findViewById(R.id.green_house1_bis3_yes);
        green_house1_bis3_no = (RadioButton) findViewById(R.id.green_house1_bis3_no);
        green_house1_bis4_yes = (RadioButton) findViewById(R.id.green_house1_bis4_yes);
        green_house1_bis4_no = (RadioButton) findViewById(R.id.green_house1_bis4_no);
        green_house1_bis5_yes = (RadioButton) findViewById(R.id.green_house1_bis5_yes);
        green_house1_bis5_no = (RadioButton) findViewById(R.id.green_house1_bis5_no);
        green_house1_bis6_yes = (RadioButton) findViewById(R.id.green_house1_bis6_yes);
        green_house1_bis6_no = (RadioButton) findViewById(R.id.green_house1_bis6_no);
        green_house1_bis7_yes = (RadioButton) findViewById(R.id.green_house1_bis7_yes);
        green_house1_bis7_no = (RadioButton) findViewById(R.id.green_house1_bis7_no);
        green_house1_bis8_yes = (RadioButton) findViewById(R.id.green_house1_bis8_yes);
        green_house1_bis8_no = (RadioButton) findViewById(R.id.green_house1_bis8_no);
        green_house1_bis9_yes = (RadioButton) findViewById(R.id.green_house1_bis9_yes);
        green_house1_bis9_no = (RadioButton) findViewById(R.id.green_house1_bis9_no);
        green_house1_bis10_yes = (RadioButton) findViewById(R.id.green_house1_bis10_yes);
        green_house1_bis10_no = (RadioButton) findViewById(R.id.green_house1_bis10_no);
        green_house1_bis_yes = (RadioButton) findViewById(R.id.green_house1_bis_yes);
        green_house1_bis_no = (RadioButton) findViewById(R.id.green_house1_bis_no);
        green_house1_items_yes = (RadioButton) findViewById(R.id.green_house1_items_yes);
        green_house1_items_no = (RadioButton) findViewById(R.id.green_house1_items_no);

        green_house1_part2_save = (Button) findViewById(R.id.green_house1_part2_save);
    }

    private void functions(){
        green_house1_bis_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis_yes:
                        green_house1_bis_yes.setChecked(true);
                        bis = "1";
                        break;

                    case R.id.green_house1_bis_no:
                        green_house1_bis_no.setChecked(true);
                        bis = "2";
                        break;
                }
            }
        });

        green_house1_items_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_items_yes:
                        green_house1_items_yes.setChecked(true);
                        items = "1";
                        break;

                    case R.id.green_house1_items_no:
                        green_house1_items_no.setChecked(true);
                        items = "2";
                        break;
                }
            }
        });

        green_house1_bis1_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis1_yes:
                        green_house1_bis1_yes.setChecked(true);
                        bis1 = "1";
                        break;

                    case R.id.green_house1_bis1_no:
                        green_house1_bis1_no.setChecked(true);
                        bis1 = "2";
                        break;
                }
            }
        });

        green_house1_bis2_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis2_yes:
                        green_house1_bis2_yes.setChecked(true);
                        bis2 = "1";
                        break;

                    case R.id.green_house1_bis2_no:
                        green_house1_bis2_no.setChecked(true);
                        bis2 = "2";
                        break;
                }
            }
        });

        green_house1_bis3_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis3_yes:
                        green_house1_bis3_yes.setChecked(true);
                        bis3 = "1";
                        break;

                    case R.id.green_house1_bis3_no:
                        green_house1_bis3_no.setChecked(true);
                        bis3 = "2";
                        break;
                }
            }
        });

        green_house1_bis4_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis4_yes:
                        green_house1_bis4_yes.setChecked(true);
                        bis4 = "1";
                        break;

                    case R.id.green_house1_bis4_no:
                        green_house1_bis4_no.setChecked(true);
                        bis4 = "2";
                        break;
                }
            }
        });

        green_house1_bis5_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis5_yes:
                        green_house1_bis5_yes.setChecked(true);
                        bis5 = "1";
                        break;

                    case R.id.green_house1_bis5_no:
                        green_house1_bis5_no.setChecked(true);
                        bis5 = "2";
                        break;
                }
            }
        });

        green_house1_bis6_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis6_yes:
                        green_house1_bis6_yes.setChecked(true);
                        bis6 = "1";
                        break;

                    case R.id.green_house1_bis6_no:
                        green_house1_bis6_no.setChecked(true);
                        bis6 = "2";
                        break;
                }
            }
        });

        green_house1_bis7_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis7_yes:
                        green_house1_bis7_yes.setChecked(true);
                        bis7 = "1";
                        break;

                    case R.id.green_house1_bis7_no:
                        green_house1_bis7_no.setChecked(true);
                        bis7 = "2";
                        break;
                }
            }
        });

        green_house1_bis8_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis8_yes:
                        green_house1_bis8_yes.setChecked(true);
                        bis8 = "1";
                        break;

                    case R.id.green_house1_bis8_no:
                        green_house1_bis8_no.setChecked(true);
                        bis8 = "2";
                        break;
                }
            }
        });

        green_house1_bis9_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis9_yes:
                        green_house1_bis9_yes.setChecked(true);
                        bis9 = "1";
                        break;

                    case R.id.green_house1_bis9_no:
                        green_house1_bis9_no.setChecked(true);
                        bis9 = "2";
                        break;
                }
            }
        });

        green_house1_bis10_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house1_bis10_yes:
                        green_house1_bis10_yes.setChecked(true);
                        bis10 = "1";
                        break;

                    case R.id.green_house1_bis10_no:
                        green_house1_bis10_no.setChecked(true);
                        bis10 = "2";
                        break;
                }
            }
        });

        green_house1_part2_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //green_house1_save_service();
            }
        });
    }

    private void green_house1_save_service(){
        if(bis.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "सर्व जीआय पाईप्सवर BIS मानांकन चिन्ह/मार्क व क्रमांक (IS 1161:2014) आहेत काय?", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row1_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row2_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row3_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row4_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row5_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row6_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row7_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enterप्रत्यक्ष for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row1_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row2_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row3_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row4_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row5_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row6_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table1_row7_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचा व्यास(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row1_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row2_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row3_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row4_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row5_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row6_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row7_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row1_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row2_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row3_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row4_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row5_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row6_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table2_row7_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपची जाडी(मीमी)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row1_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row2_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row3_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row4_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row5_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row6_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row7_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row1_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row2_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row3_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row4_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row5_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row6_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(green_house1_table3_row7_comment.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter शेरा for पाईपचे वजन(किलो/मी.)", Toast.LENGTH_SHORT).show();
        }else if(items.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "सिहरितगृह / शेडनेटगृहाच्या मार्गदर्शक सूचनेतील अनिवार्य साहित्याच्या यादीनुसार आवश्यकतेप्रमाणे साहित्य पुरवठा केला आहे काय ?", Toast.LENGTH_SHORT).show();
        }else if(bis1.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "BIS (IS 15827:2009) प्रमाणे आहे काय? होय/नाही ?", Toast.LENGTH_SHORT).show();
        }else if(bis2.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "BIS प्रमाणे नसल्यास अधिकृतपणे आयात केलेली व IS 15827 किंवा त्यापेक्षा उच्च दर्जाची आहे काय ?", Toast.LENGTH_SHORT).show();
        }else if(bis3.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "मार्गदर्शक सूचनेत दिलेले गुणधर्म (UV Stabilized, 200 micron, multi layered, anti drip, anti fog, anti dust, diffused, % of light transmittance, and sulphur) आहेत काय?", Toast.LENGTH_SHORT).show();
        }else if(bis4.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "हरितगृहासाठी व शेडनेटगृहासाठीची शेडनेट IS 16008:2016 प्रमाणे आहे काय ?", Toast.LENGTH_SHORT).show();
        }else if(bis5.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "टेपनेट पासून निर्मित शेडनेट असल्यास IS 16008(part1):2016 नुसार शेडनेटचे १ वर्ग मीटर आकाराचे वजन ५०% मध्ये -१०० ग्राम, ७५ % मध्ये १२० ग्राम व ९० % मध्ये १४० ग्राम आहे काय?", Toast.LENGTH_SHORT).show();
        }else if(bis6.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "मोनोफिलामेंट नेट असल्यास IS 16008(part2):2016 नुसार १ वर्ग मोटर आकाराचे वजन ५० % मध्ये १२५ ग्राम व ७५ % मध्ये ३१० ग्राम व ९० % मध्ये ४६० ग्राम आहे काय?", Toast.LENGTH_SHORT).show();
        }else if(bis7.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "इतर साहीत्य मार्गदर्शक सृचनेतील तांत्रिक निकषाप्रमाणे आहे काय?", Toast.LENGTH_SHORT).show();
        }else if(bis8.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "वातावरण नियंत्रित हरितगृहासाठी (CCPH) वातावरण नियंत्रणासाठी वापरण्यात येणारे साहित्य व उपकरणे मार्गदर्शक सूचनेतील तांत्रिक निकषांप्रमाणे आहेत काय?", Toast.LENGTH_SHORT).show();
        }else if(bis9.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "हरितगृह/शेडनेटगृह उभारणीची जागा व दिशा विचारात घेवून मार्गदर्शक सूचनेतील आराखडयाप्रमाणे उभारणी नियोजन (आरेखन) आहे काय?", Toast.LENGTH_SHORT).show();
        }else if(bis10.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "हरितगृह/शेडनेटगृहाच्या पायासाठी घेण्यात येणारे खड्डे योग्य आकारमानाचे आहेत काय?", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("tb1_rw1_actual", green_house1_table1_row1_actual.getText().toString().trim());
                param.put("tb1_rw2_actual", green_house1_table1_row2_actual.getText().toString().trim());
                param.put("tb1_rw3_actual", green_house1_table1_row3_actual.getText().toString().trim());
                param.put("tb1_rw4_actual", green_house1_table1_row4_actual.getText().toString().trim());
                param.put("tb1_rw5_actual", green_house1_table1_row5_actual.getText().toString().trim());
                param.put("tb1_rw6_actual", green_house1_table1_row6_actual.getText().toString().trim());
                param.put("tb1_rw7_actual", green_house1_table1_row7_actual.getText().toString().trim());
                param.put("tb1_rw1_comment", green_house1_table1_row1_comment.getText().toString().trim());
                param.put("tb1_rw2_comment", green_house1_table1_row2_comment.getText().toString().trim());
                param.put("tb1_rw3_comment", green_house1_table1_row3_comment.getText().toString().trim());
                param.put("tb1_rw4_comment", green_house1_table1_row4_comment.getText().toString().trim());
                param.put("tb1_rw5_comment", green_house1_table1_row5_comment.getText().toString().trim());
                param.put("tb1_rw6_comment", green_house1_table1_row6_comment.getText().toString().trim());
                param.put("tb1_rw7_comment", green_house1_table1_row7_comment.getText().toString().trim());
                param.put("tb2_rw1_actual", green_house1_table2_row1_actual.getText().toString().trim());
                param.put("tb2_rw2_actual", green_house1_table2_row2_actual.getText().toString().trim());
                param.put("tb2_rw3_actual", green_house1_table2_row3_actual.getText().toString().trim());
                param.put("tb2_rw4_actual", green_house1_table2_row4_actual.getText().toString().trim());
                param.put("tb2_rw5_actual", green_house1_table2_row5_actual.getText().toString().trim());
                param.put("tb2_rw6_actual", green_house1_table2_row6_actual.getText().toString().trim());
                param.put("tb2_rw7_actual", green_house1_table2_row7_actual.getText().toString().trim());
                param.put("tb2_rw1_comment", green_house1_table2_row1_comment.getText().toString().trim());
                param.put("tb2_rw2_comment", green_house1_table2_row2_comment.getText().toString().trim());
                param.put("tb2_rw3_comment", green_house1_table2_row3_comment.getText().toString().trim());
                param.put("tb2_rw4_comment", green_house1_table2_row4_comment.getText().toString().trim());
                param.put("tb2_rw5_comment", green_house1_table2_row5_comment.getText().toString().trim());
                param.put("tb2_rw6_comment", green_house1_table2_row6_comment.getText().toString().trim());
                param.put("tb2_rw7_comment", green_house1_table2_row7_comment.getText().toString().trim());
                param.put("tb3_rw1_actual", green_house1_table3_row1_actual.getText().toString().trim());
                param.put("tb3_rw2_actual", green_house1_table3_row2_actual.getText().toString().trim());
                param.put("tb3_rw3_actual", green_house1_table3_row3_actual.getText().toString().trim());
                param.put("tb3_rw4_actual", green_house1_table3_row4_actual.getText().toString().trim());
                param.put("tb3_rw5_actual", green_house1_table3_row5_actual.getText().toString().trim());
                param.put("tb3_rw6_actual", green_house1_table3_row6_actual.getText().toString().trim());
                param.put("tb3_rw7_actual", green_house1_table3_row7_actual.getText().toString().trim());
                param.put("tb3_rw1_comment", green_house1_table3_row1_comment.getText().toString().trim());
                param.put("tb3_rw2_comment", green_house1_table3_row2_comment.getText().toString().trim());
                param.put("tb3_rw3_comment", green_house1_table3_row3_comment.getText().toString().trim());
                param.put("tb3_rw4_comment", green_house1_table3_row4_comment.getText().toString().trim());
                param.put("tb3_rw5_comment", green_house1_table3_row5_comment.getText().toString().trim());
                param.put("tb3_rw6_comment", green_house1_table3_row6_comment.getText().toString().trim());
                param.put("tb3_rw7_comment", green_house1_table3_row7_comment.getText().toString().trim());
                param.put("bis", bis);
                param.put("bis1", bis1);
                param.put("bis2", bis2);
                param.put("bis3", bis3);
                param.put("bis4", bis4);
                param.put("bis5", bis5);
                param.put("bis6", bis6);
                param.put("bis7", bis7);
                param.put("bis8", bis8);
                param.put("bis9", bis9);
                param.put("bis10", bis10);
                param.put("items", items);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Green House / Shade Net House");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
