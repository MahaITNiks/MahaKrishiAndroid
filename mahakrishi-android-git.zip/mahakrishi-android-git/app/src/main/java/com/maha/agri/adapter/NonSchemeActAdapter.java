package com.maha.agri.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import androidx.recyclerview.widget.RecyclerView;

import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.maha.agri.R;
import com.maha.agri.cropsowingreport.CropSowingReportActivity;
import com.maha.agri.cropsowingreport.VillageMappingAreaActivity;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ochard_mapping.OrchardMappingActivity;
import com.maha.agri.ochard_mapping.OrchardSurveyAdapter;
import com.maha.agri.ochard_mapping.OrchardSurveyListViewDialog;
import com.maha.agri.panchnama.DepartmentCategoryPanchnamaActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;

public class NonSchemeActAdapter extends RecyclerView.Adapter<NonSchemeActAdapter.CustomViewHolder> {

    private Context context;
    private JSONArray non_scheme_array_list, orchardSurveyList;
    private JSONObject jsonObject;
    private OnMultiRecyclerItemClickListener listener;
    private PreferenceManager preferenceManager;
    private DBHandler dbHandler;
    private OrchardSurveyListViewDialog customDialog;


    public NonSchemeActAdapter(Context context, JSONArray non_scheme_array_list, JSONArray orchardSurveyList, PreferenceManager preferenceManager) {
        this.context = context;
        this.listener = listener;
        this.non_scheme_array_list = non_scheme_array_list;
        this.orchardSurveyList = orchardSurveyList;
        this.preferenceManager = preferenceManager;

    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private TextView listTitleTextView;
        private ImageView scheme_act_number_tv;
        private LinearLayout scheme_list_type_ll;


        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            listTitleTextView = (TextView) mView.findViewById(R.id.listTitle);
            scheme_act_number_tv = (ImageView) mView.findViewById(R.id.scheme_act_number_tv);
            scheme_list_type_ll = (LinearLayout) mView.findViewById(R.id.scheme_list_type_ll);
            listTitleTextView.setTypeface(null, Typeface.BOLD);

        }
    }

    @Override
    public NonSchemeActAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.schemelist_group_single_item, parent, false);
        return new NonSchemeActAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NonSchemeActAdapter.CustomViewHolder holder, int position) {
        dbHandler = new DBHandler(context);

        try {
            JSONObject jsonObject = non_scheme_array_list.getJSONObject(position);
            holder.scheme_list_type_ll.setTag(position);
            holder.listTitleTextView.setText(jsonObject.getString("name"));
            //holder.scheme_act_number_tv.setText(jsonObject.getString("sr_no"));
            holder.scheme_act_number_tv.setImageResource(R.drawable.ic_arrow_right_black_24dp);

            holder.scheme_list_type_ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int index = (Integer) view.getTag();
                    JSONObject sledJSON = new JSONObject();
                    String actName = "";

                    try {
                        sledJSON = non_scheme_array_list.getJSONObject(index);
                        String activityId = sledJSON.getString("id");
                        actName = non_scheme_array_list.getJSONObject(index).getString("name");
                        preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_NAME, actName);
                        preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_ID, activityId);
                        AppSettings.getInstance().setValue(context, ApConstants.kSLED_ACTIVITY, activityId);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (isNetworkAvailable()) {
                        if (dbHandler.getAllOfflineSchemeWorkDetails().length() > 0) {
                            UIToastMessage.show(context, "Please sync offline task details");
                        } else if (actName.equalsIgnoreCase("Crop loss assessment (Panchnama)")) {
                            Intent intent = new Intent(context, DepartmentCategoryPanchnamaActivity.class);
                            context.startActivity(intent);
                            //Toast toast= Toast.makeText(context, "Coming Soon !", Toast.LENGTH_SHORT);
                            //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                            //toast.show();
                        } else if (actName.equalsIgnoreCase("Crop Sowing Report")) {
                            Intent intent = new Intent(context, CropSowingReportActivity.class);
                            context.startActivity(intent);
                        } else if (actName.equalsIgnoreCase("Dealers and Manufacturers")) {
                            Toast toast = Toast.makeText(context, "Coming Soon !", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL, 0, 0);
                            toast.show();
                        } else if (actName.equalsIgnoreCase("Orchard Mapping")) {


                            if (orchardSurveyList!=null && orchardSurveyList.length() > 0) {
                               // OrchardSurveyAdapter dataAdapter = new OrchardSurveyAdapter(orchardSurveyList, this);
                                customDialog = new OrchardSurveyListViewDialog(context,  orchardSurveyList);


                                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                                layoutParams.copyFrom(customDialog.getWindow().getAttributes());
                                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                                layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT;
                                customDialog.getWindow().setAttributes(layoutParams);

                                customDialog.show();

                                customDialog.setCanceledOnTouchOutside(false);
                             //   dataAdapter.notifyDataSetChanged();
                            } else {
                                Intent intent = new Intent(context, OrchardMappingActivity.class);
                                context.startActivity(intent);
                            }


                        } else if (actName.equalsIgnoreCase("Village Mapping Area")) {
                            Intent intent = new Intent(context, VillageMappingAreaActivity.class);
                            context.startActivity(intent);
                                    /*Toast toast= Toast.makeText(context, "Coming Soon !", Toast.LENGTH_SHORT);
                                    toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                                    toast.show();*/
                        }
                    }
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return non_scheme_array_list.length();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private NonSchemeActAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final NonSchemeActAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
