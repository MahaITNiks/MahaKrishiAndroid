package com.maha.agri.web_services;

import com.google.gson.JsonObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;

import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

public interface APIRequest {

    // Login
    @POST(APIServices.AUTH_URL)
    Call<JsonObject> oauthRequest(@Body RequestBody params);

    @POST(APIServices.UPDATE_APP)
    Call<JsonObject> check_version(@Body RequestBody params);

    // Login
    @POST(APIServices.UPDATE_URL)
    Call<JsonObject> onupdaterequest(@Body RequestBody params);

    @Multipart
    @POST(APIServices.UPDATE_PROFILE_PIC_URL)
    Call<JsonObject> onupdateprofilepic(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.ASSIGNED_VILLAGE_URL)
    Call<JsonObject> assignedvillageurl(@Body RequestBody params);

    @POST(APIServices.ASSIGNED_LOCATION_URL)
    Call<JsonObject> assignedLocationUrl(@Body RequestBody params);

    @POST(APIServices.ATTENDANCE_USER_DETAILS_URL)
    Call<JsonObject> userattendancedetailsurl(@Body RequestBody params);

    @POST(APIServices.OFFLINECHECKINANDOUT_URL)
    Call<JsonObject> offlinecheckinandoutsurl(@Body RequestBody params);

    @Multipart
    @POST(APIServices.OFFLINE_IMG_UPLOAD)
    Call<JsonObject> offlineImgUpload(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.AB_REASON_URL)
    Call<JsonObject> absentReasonListReq(@Body RequestBody params);

    @POST(APIServices.TASK_MANAGER_TYPES_URL)
    Call<JsonObject> taskManagerTypes(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_URL)
    Call<JsonObject> schemeList(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_TYPES_URL)
    Call<JsonObject> schemeListTypes(@Body RequestBody params);

    @POST(APIServices.TASK_MANAGER_ADD_SCHEME_WORK)
    Call<JsonObject> taskManagerAddSchemeWork(@Body RequestBody params);

    @Multipart
    @POST(APIServices.SCHEME_RELATED_WORK_PIC)
    Call<JsonObject> schemeRelatedPicUrl(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.ATTENDANCE_MONTH_FILTER_URL)
    Call<JsonObject> attendanceMonthFilter(@Body RequestBody params);

    // For Report
    @POST(APIServices.TASK_MANAGER_TYPES_REPORT_URL)
    Call<JsonObject> taskManagerReportTypes(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_REPORT_URL)
    Call<JsonObject> schemeReportList(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_REPORT_TYPES_URL)
    Call<JsonObject> schemeListReportTypes(@Body RequestBody params);

    //For forgot password

    @POST(APIServices.FORGOT_PASSWORD)
    Call<JsonObject>forgot_password(@Body RequestBody params);

    @POST(APIServices.RESEND_OTP)
    Call<JsonObject>resend_otp(@Body RequestBody params);

    @POST(APIServices.VALIDATE_OTP)
    Call<JsonObject>validate_otp(@Body RequestBody params);

    @POST(APIServices.CHANGE_PASSWORD)
    Call<JsonObject>change_password(@Body RequestBody params);

    @POST(APIServices.APPROVE_ATTENDANCE)
    Call<JsonObject>approve_attendance(@Body RequestBody params);

    @POST(APIServices.APPROVE_ATTENDANCE_SAVE)
    Call<JsonObject>approve_attendance_save(@Body RequestBody params);

    @POST(APIServices.APPROVE_ATTENDANCE_USER_LIST)
    Call<JsonObject>approve_attendance_user_list(@Body RequestBody params);

    @POST(APIServices.APPROVE_ATTENDANCE_MONTH_FILTER)
    Call<JsonObject>approve_attendance_month_filter(@Body RequestBody params);

    @POST(APIServices.APPROVE_ATTENDANCE_DAYS_YEARWISE)
    Call<JsonObject>approve_attendance_days_yearwise(@Body RequestBody params);

    @POST(APIServices.TASK_MANAGER_REPORT_DETAILS)
    Call<JsonObject>task_manager_report__details(@Body RequestBody params);

    //For Offline Task Manager
    @POST(APIServices.TASK_MANAGER_TYPES_OFFLINE_URL)
    Call<JsonObject>task_manager_type_offline(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_OFFLINE_URL)
    Call<JsonObject>task_manager_scheme_list_offline(@Body RequestBody params);

    @POST(APIServices.SCHEME_lIST_ACTIVITY_OFFLINE_URL)
    Call<JsonObject>task_manager_scheme_list_activity_offline(@Body RequestBody params);

    @POST(APIServices.TASK_MANAGER_SCHEME_WORK_OFFLINE_URL)
    Call<JsonObject>task_manager_scheme_work_offline(@Body RequestBody params);

    @POST(APIServices.ADD_WORK_DETAILS_OFFLINE_URL)
    Call<JsonObject>add_work_details_offline_url(@Body RequestBody params);

    @Multipart
    @POST(APIServices.ADD_WORK_DETAILS_IMAGE_OFFLINE_URL)
    Call<JsonObject> add_work_details_image_offline_url(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //For Farmer Registration
    @POST(APIServices.FARMER_REGISTRAION_URL)
    Call<JsonObject>farmer_registration_url(@Body RequestBody params);

    //For Farmer Dashboard
    @POST(APIServices.FARMER_DASHBOARD_URL)
    Call<JsonObject>farmer_dashboard_url(@Body RequestBody params);

    //For Farmer Magazine
    @POST(APIServices.FARMER_MAGAZINE_URL)
    Call<JsonObject>farmer_magazine_url(@Body RequestBody params);

        // For Farmer Categories
    @GET(APIServices.FARMER_CATEGORIES_URL)
    Call<JsonObject>farmer_magazine_categories_url();

    //For Farmer Magazine PDF
    @POST(APIServices.FARMER_MAGAZINE_PDF_URL)
    Call<JsonObject>farmer_magazine_pdf_url(@Body RequestBody params);

    //For Farmer Magazine PDF
    @POST(APIServices.FARMER_VERIFY_MOBILE_NUMBER)
    Call<JsonObject>farmer_verify_mobile_number_url(@Body RequestBody params);


    //For Farmer Magazine PDF
    @POST(APIServices.FARMER_VERIFY_OTP)
    Call<JsonObject>farmer_verify_otp_url(@Body RequestBody params);

    //For Farmer District
    @POST(APIServices.FARMER_DISTRICT_URL)
    Call<JsonObject>farmer_district_url(@Body RequestBody params);

    //For Farmer Taluka
    @POST(APIServices.FARMER_TALUKA_URL)
    Call<JsonObject>farmer_taluka_url(@Body RequestBody params);

    //For Farmer Village
    @POST(APIServices.FARMER_VILLAGE_URL)
    Call<JsonObject>farmer_village_url(@Body RequestBody params);

    //For Farmer Season
    @POST(APIServices.FARMER_SEASONS_URL)
    Call<JsonObject>farmer_seasons_url(@Body RequestBody params);

    //For Farmer Crop
    @POST(APIServices.FARMER_CROP_SEASON_URL)
    Call<JsonObject>farmer_crop_season_url(@Body RequestBody params);

    //For Farmer CropSap Save
    @POST(APIServices.FARMER_CROPSAP_SAVE_URL)
    Call<JsonObject>farmer_cropsap_save_url(@Body RequestBody params);

    //For Farmer CropSap Image
    @Multipart
    @POST(APIServices.FARMER_CROPSAP_UPLOAD_IMAGE_URL)
    Call<JsonObject> upload_cropsap_image_url(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //For Farmer CropSap Details
    @POST(APIServices.FARMER_CROPSAP_DETAILS_FOR_DEPT_URL)
    Call<JsonObject>farmer_cropsap_details_url(@Body RequestBody params);

    //For Department Demonstration Purpose
    @POST(APIServices.DEPARTMENT_DEMON_PURPOSE_URL)
    Call<JsonObject>dept_demon_purpose_url(@Body RequestBody params);

    //For Department Demonstration Input
    @POST(APIServices.DEPARTMENT_DEMON_INPUT_URL)
    Call<JsonObject>dept_demon_input_url(@Body RequestBody params);

    //For Department Demonstration Limit
    @POST(APIServices.DEPARTMENT_DEMON_LIMIT_URL)
    Call<JsonObject>dept_demon_limit_url(@Body RequestBody params);

    //For Department Demonstration Unit
    @POST(APIServices.DEPARTMENT_DEMON_UNIT_URL)
    Call<JsonObject>dept_demon_unit_url(@Body RequestBody params);

    //For Department Demonstration Save Master Step 1
    @POST(APIServices.DEPARTMENT_DEMON_SAVE_MASTER_STEP_ONE_URL)
    Call<JsonObject>dept_demon_save_master_step_one_url(@Body RequestBody params);

    //For Department Demonstration Save Master Step 1
    @POST(APIServices.DEPARTMENT_DEMON_SAVE_MASTER_STEP_TWO_URL)
    Call<JsonObject>dept_demon_save_master_step_Two_url(@Body RequestBody params);

    //For Department Demonstration Edit Master Step 1
    @POST(APIServices.DEPARTMENT_DEMON_EDIT_MASTER_STEP_ONE_URL)
    Call<JsonObject>dept_demon_edit_master_step_one_url(@Body RequestBody params);

    //For Department  department-login-get-district-taluka
    @POST(APIServices.DEPARTMENT_LOGIN_GET_DISTRICT_TALUKA)
    Call<JsonObject>department_login_get_district_taluka_url(@Body RequestBody params);


    //For Farmer Punchnama Year
    @POST(APIServices.FARMER_PUNCHNAMA_YEAR_URL)
    Call<JsonObject>farmer_punchnama_year_url(@Body RequestBody params);

    //For Farmer Punchnama Farm Type
    @POST(APIServices.FARMER_PUNCHNAMA_FARM_TYPE_URL)
    Call<JsonObject>farmer_punchnama_farm_type_url(@Body RequestBody params);

    //For Farmer Punchnama Scheme Type
    @POST(APIServices.FARMER_PUNCHNAMA_SCHEME_URL)
    Call<JsonObject>farmer_punchnama_scheme_url(@Body RequestBody params);

    //For Farmer Punchnama Season
    @POST(APIServices.FARMER_PUNCHNAMA_SEASON_URL)
    Call<JsonObject>farmer_punchnama_season_url(@Body RequestBody params);

    //For Farmer Punchnama Crop Type
    @POST(APIServices.FARMER_PUNCHNAMA_CROP_TYPE_URL)
    Call<JsonObject>farmer_punchnama_crop_type_url(@Body RequestBody params);

    //For Farmer punchnama Name of Crop
    @POST(APIServices.FARMER_PUNCHNAMA_CROP_LIST_URL)
    Call<JsonObject>farmer_punchnama_crop_list_url(@Body RequestBody params);

    //For Farmer punchnama Damage_Type
    @POST(APIServices.FARMER_PUNCHNAMA_DAMAGE_TYPE_URL)
    Call<JsonObject>farmer_punchnama_damage_type_url(@Body RequestBody params);

    //For Farmer punchnama Name of Crop
    @POST(APIServices.FARMER_PUNCHNAMA_DAMAGE_REASON_URL)
    Call<JsonObject>farmer_punchnama_damage_reason_url(@Body RequestBody params);

    //For Farmer Punchanama Save
    @POST(APIServices.FARMER_PUNCHNAMA_SAVE_URL)
    Call<JsonObject>farmer_punchnama_save_url(@Body RequestBody params);

    //Farmer Panchnama Save Image
    @Multipart
    @POST(APIServices.FARMER_PUNCHNAMA_SAVE_IMAGE_URL)
    Call<JsonObject> farmer_punchnama_save_image_url(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //For Dept Punchanama Type
    @POST(APIServices.DEPT_PUNCHNAMA_TYPE_URL)
    Call<JsonObject>dept_punchnama_type_url(@Body RequestBody params);

    //For Dept Punchanama Claims List
    @POST(APIServices.DEPT_PUNCHNAMA_CLAIMS_URL)
    Call<JsonObject>dept_punchnama_claims_url(@Body RequestBody params);

    //For Dept Punchanama Form Submit
    @POST(APIServices.DEPT_PUNCHNAMA_SAVE_URL)
    Call<JsonObject>dept_punchnama_form_submit_url(@Body RequestBody params);

    //For Dept Self Punchanama Form Submit
    @POST(APIServices.DEPT_SELF_PUNCHNAMA_SAVE_URL)
    Call<JsonObject>dept_self_punchnama_form_submit_url(@Body RequestBody params);

    //For Dept Self Punchanama Image Form Submit
    @Multipart
    @POST(APIServices.DEPT_SELF_PUNCHNAMA_SAVE_IMAGE_URL)
    Call<JsonObject> dept_self_punchnama_image_form_submit_url(@Part MultipartBody.Part image, @PartMap Map<String, String> params);


    //Farmer CROPSAP History
    //1.cropsap_count
    @POST(APIServices.FARMER_CROPSAP_HISTORY_COUNT)
    Call<JsonObject>farmer_cropsap_history_count(@Body RequestBody params);

    //2.Cropsap crop list count
    @POST(APIServices.FARNER_CROPSAP_HISTORY_CROP_LIST_COUNT)
    Call<JsonObject>farmer_cropsap_history_crop_count(@Body RequestBody params);

    //3.Farmer Cropsap Details based on crop
    @POST(APIServices.FARNER_CROPSAP_HISTORY_BASED_ON_CROP)
    Call<JsonObject>farmer_cropsap_history_based_on_crop(@Body RequestBody params);

    //Department Login Get District
    @POST(APIServices.DEPARTMENT_LOGIN_GET_DISTRICT_TALUKA)
    Call<JsonObject>department_login_get_district_taluka(@Body RequestBody params);

    //Department Login Get Villages
    @POST(APIServices.DEPARTMENT_LOGIN_GET_VILLAGES)
    Call<JsonObject>department_login_get_villages(@Body RequestBody params);

    //Department CropSap Save Details
    @POST(APIServices.DEPARTMENT_SAVE_CROPSAP_DETAILS_URL)
    Call<JsonObject>department_save_cropsap_details_url(@Body RequestBody params);

    //Department CropSap Save Image
    @Multipart
    @POST(APIServices.DEPARTMENT_SAVE_CROPSAP_IMAGE_URL)
    Call<JsonObject> department_save_cropsap_image_url(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Department CROPSAP History
    //1.cropsap_count
    @POST(APIServices.DEPARTMENT_CROPSAP_HISTORY_COUNT)
    Call<JsonObject>dept_cropsap_history_count(@Body RequestBody params);

    //2.Cropsap crop list count
    @POST(APIServices.DEPARTMENT_CROPSAP_HISTORY_CROP_LIST_COUNT)
    Call<JsonObject>dept_cropsap_history_crop_count(@Body RequestBody params);

    //3.Farmer Cropsap Details based on crop
    @POST(APIServices.DEPARTMENT_CROPSAP_HISTORY_BASED_ON_CROP)
    Call<JsonObject>dept_cropsap_history_based_on_crop(@Body RequestBody params);


    //Department CropSap New

    //Crop Sap - Farmer Selection :
    @POST(APIServices.DEPARTMENT_CROPSAP_FARMER_LIST)
    Call<JsonObject>dept_crop_sap_new_get_farmer_list(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_CROPSAP_FARMER_CROP_LIST)
    Call<JsonObject>dept_crop_sap_new_get_farmer_crop_list(@Body RequestBody params);

    //Pre Cropsap Form Submission
    @POST(APIServices.DEPARTMENT_PRE_CROPSAP_MASTER_FORM_SAVE)
    Call<JsonObject>dept_crop_sap_new_pre_master_cropsap_form_save(@Body RequestBody params);

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_SEASON_URL)
    Call<JsonObject>dept_crop_sap_new_season_list();

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROPLIST_BASED_ON_SEASON_URL)
    Call<JsonObject>dept_crop_sap_new_crop_based_on_season(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROPVARIETY_BASED_ON_CROP_URL)
    Call<JsonObject>dept_crop_sap_new_crop_variety_based_on_crop(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROPGROWTH_BASED_ON_CROP_URL)
    Call<JsonObject>dept_crop_sap_new_crop_growth_based_on_crop(@Body RequestBody params);

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_SOIL_TYPE_URL)
    Call<JsonObject>dept_crop_sap_new_soil_type_list();

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CONDITION_URL)
    Call<JsonObject>dept_crop_sap_new_crop_condition_list();

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_SOIL_MOISTURE_URL)
    Call<JsonObject>dept_crop_sap_new_soil_moisture_list();

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_FARMER_LIST_URL)
    Call<JsonObject>dept_crop_sap_new_farmer_list(@Body RequestBody params);

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_MINOR_PEST_URL)
    Call<JsonObject>dept_crop_sap_new_minor_pest_list();

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROPIRRIGATION_BASED_ON_CROP_URL)
    Call<JsonObject>dept_crop_sap_new_crop_irrigation_based_on_crop(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_MASTER_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_master_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_MASTER_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_master_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Crop sap cotton crop

    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_COTTON_PLANT_LIST)
    Call<JsonObject>dept_crop_sap_new_cotton_plant_list();

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_COTTON_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_new_crop_cotton_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);


    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_COTTON_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_cotton_save_save(@Body RequestBody params);

    //Cotton Last Form Save
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_COTTON_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_new_crop_cotton_last_form_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);


    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_COTTON_LAST_FORM_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_cotton_last_form_save_save(@Body RequestBody params);


    //  CROP  S O R G H U M
                // GET PLANT
    @GET(APIServices.dept_cropsap_sorghum_plant_list)
    Call<JsonObject>dept_crop_sap_new_sorghum_plant_list();

                // SAVE
    @POST(APIServices.dept_cropsap_sorghum_plant_save)
    Call<JsonObject>dept_crop_sap_new_sorghum_plant_save(@Body RequestBody params);

                // IMAGE
    @Multipart
    @POST(APIServices.dept_cropsap_sorghum_plant_saveimage)
    Call<JsonObject>dept_cropsap_sorghum_plant_saveimage(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    // LAST FORM
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SORGHUM_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_new_crop_sorghum_last_form_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);


    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SORGHUM_LAST_FORM_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_sorghum_last_form_save_save(@Body RequestBody params);


    //  CROP  M A I Z E
    // GET SPOT
    @GET(APIServices.dept_cropsap_maize_spot_list)
    Call<JsonObject>dept_crop_sap_new_maize_spot_list();

    // SAVE
    @POST(APIServices.dept_cropsap_maize_spot_save)
    Call<JsonObject>dept_crop_sap_new_maize_spot_save(@Body RequestBody params);

    // IMAGE

    @Multipart
    @POST(APIServices.dept_cropsap_maize_spot_saveimage)
    Call<JsonObject>dept_cropsap_maize_spot_saveimage(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    // LAST FORM

    // IMAGE
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_MAIZE_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_new_crop_maize_last_form_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    // SAVE
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_MAIZE_LAST_FORM_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_maize_last_form_save(@Body RequestBody params);


    //                                                          CROP S O Y A  B E A N
    // GET SPOT
    @GET(APIServices.DEPT_CROPSAP_SOYABEAN_SPOT_LIST)
    Call<JsonObject>dept_crop_sap_new_soya_spot_list();

    // IMAGE
    @Multipart
    @POST(APIServices.DEPT_CROPSAP_SOYABEAN_SPOT_SAVEIMAGE)
    Call<JsonObject>dept_cropsap_soyabean_spot_saveimage(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    // SAVE
    @POST(APIServices.DEPT_CROPSAP_SOYABEAN_SPOT_DATA)
    Call<JsonObject>dept_crop_sap_new_soyabean_spot_save(@Body RequestBody params);

    //Crop sap Sugarcane crop
    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SPOT_LIST)
    Call<JsonObject>dept_crop_sap_new_sugarcane_spot_list();

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_sugarcane_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SAVE_IMAGE_URL)
    Call<JsonObject>dept_cropsap_new_crop_sugarcane_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);
    //Sugarcane Last Form Save
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>crop_sugarcane_ls_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_LAST_FORM_SAVE_URL)
    Call<JsonObject>crop_sugarcane_last_step_save(@Body RequestBody params);

    //Crop sap Pigeonpea crop
    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_PLANT_LIST)
    Call<JsonObject>pigeonpea_plant_list();

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_SAVE_URL)
    Call<JsonObject>dept_crop_sap_new_crop_pigeonpea_save(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_SAVE_URL)
    Call<JsonObject>crop_pigeonpea_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_SAVE_IMAGE_URL)
    Call<JsonObject>crop_pigeonpea_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);
    //Pigeonpea Last Form Save
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>crop_pigeonpea_save_ls_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);


    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_LAST_FORM_SAVE_URL)
    Call<JsonObject>crop_pigeonpea_last_step_save(@Body RequestBody params);

    //Crop sap Chickpea crop
    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_PLANT_LIST)
    Call<JsonObject>chickpea_spot_list();

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_SAVE_IMAGE_URL)
    Call<JsonObject>crop_chikpea_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_SAVE_URL)
    Call<JsonObject>crop_chikpea_save(@Body RequestBody params);
    //Chickpea Last Form Save
    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_LAST_FORM_SAVE_IMAGE_URL)
    Call<JsonObject>crop_chickpea_save_ls_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_LAST_FORM_SAVE_URL)
    Call<JsonObject>crop_chickpea_last_step_save(@Body RequestBody params);

    //Crop sap Rice crop
    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_RICE_SPOT_LIST)
    Call<JsonObject>dept_crop_sap_new_rice_spot_list();

    //4.Dept Login Farmer Cropsap count
    @POST(APIServices.DEPARTMENT_LOGIN_FARMER_CROPSAP_HISTORY_COUNT)
    Call<JsonObject>dept_login_farmer_cropsap_history_count(@Body RequestBody params);

    //Farmer Punchnama History
    //1.Total count
    @POST(APIServices.FARMER_PUNCHNAMA_HISTORY_COUNT)
    Call<JsonObject>farmer_panchnama_history_count(@Body RequestBody params);

    //2.Crop List with count
    @POST(APIServices.FARMER_PUNCHNAMA_CROP_LIST_WITH_COUNT)
    Call<JsonObject>farmer_panchnama_crop_list_with_count(@Body RequestBody params);

    //3.List based on crop
    @POST(APIServices.FARMER_PUNCHNAMA_LIST_BASED_ON_CROP)
    Call<JsonObject>farmer_panchnama_list_based_on_crop(@Body RequestBody params);

    //Department Punchnama History
    //1. Total count
    @POST(APIServices.DEPARTMENT_PUNCHNAMA_HISTORY_COUNT)
    Call<JsonObject>department_login_panchnama_total_count(@Body RequestBody params);

    //2.
    @POST(APIServices.DEPARTMENT_PUNCHNAMA_HISTORY_CROP_LIST_COUNT)
    Call<JsonObject>department_login_panchnama_crop_list_with_count(@Body RequestBody params);

    //3.
    @POST(APIServices.DEPARTMENT_PUNCHNAMA_LIST_BASED_ON_CROP)
    Call<JsonObject>department_login_panchnama_list_based_on_crop(@Body RequestBody params);

    @POST(APIServices.PRIMARY_REPORT_VILLAGE_WISE_CROP_DATA)
    Call<JsonObject>primary_report_village_wise_crop_data(@Body RequestBody params);

    //Primary Report
    @POST(APIServices.PRIMARY_REPORT_SAVE)
    Call<JsonObject>primary_report_save(@Body RequestBody params);

    // For MB Recording

    @POST(APIServices.MB_SOIL_REPORT_LIST)
    Call<JsonObject>mbSoilReportList(@Body RequestBody params);

    @POST(APIServices.FARMER_LIST_MB_RECORDING)
    Call<JsonObject>farmer_list_mb_recording(@Body RequestBody params);

    /*@POST(APIServices.SCHEME_MB_RECORDING)
    Call<JsonObject>scheme_mb_recording(@Body RequestBody params);*/

    @GET(APIServices.SCHEME_MB_RECORDING)
    Call<JsonObject>scheme_mb_recording();

    @POST(APIServices.FARMER_REGISTRATION_MB_RECORDING)
    Call<JsonObject>farmer_registration_mb_recording(@Body RequestBody params);

    @POST(APIServices.SOIL_REGISTRATION_MB_RECORDING)
    Call<JsonObject>soil_registration_mb_recording(@Body RequestBody params);

    @Multipart
    @POST(APIServices.IMAGE_MB_RECORDING)
    Call<JsonObject>image_mb_recording(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //MB Recording BFFLY
    @GET(APIServices.MB_RECORDING_BFFLY_FRUITS)
    Call<JsonObject>mb_recording_bffly_fruits();

    @GET(APIServices.MB_RECORDING_BFFLY_YEARS)
    Call<JsonObject>mb_recording_bffly_years();

    @POST(APIServices.MB_RECORDING_BFFLY_FORM1_SAVE)
    Call<JsonObject>mbrecording_bffly_form1_save(@Body RequestBody params);

    @POST(APIServices.MB_RECORDING_BFFLY_FORM2_SAVE)
    Call<JsonObject>mbrecording_bffly_form2_save(@Body RequestBody params);

    @POST(APIServices.MB_RECORDING_BFFLY_FORM2_IS_COMPLETED)
    Call<JsonObject>mbrecording_bffly_form_check_iscompleted(@Body RequestBody params);

    @POST(APIServices.MB_RECORDING_BFFLY_FORM3_SAVE)
    Call<JsonObject>mbrecording_bffly_form3_save(@Body RequestBody params);

    @POST(APIServices.MB_RECORDING_BFFLY_FORM4_SAVE)
    Call<JsonObject>mbrecording_bffly_form4_save(@Body RequestBody params);

    @POST(APIServices.MB_RECORDING_BFFLY_FORM5_SAVE)
    Call<JsonObject>mbrecording_bffly_form5_save(@Body RequestBody params);

    //sprinkler list
    @POST(APIServices.SPRINKLER_LIST)
    Call<JsonObject>sprinkler_list(@Body RequestBody params);

    //sprinkler save
    @POST(APIServices.SPRINKLE_SAVE)
    Call<JsonObject>sprinkler_save(@Body RequestBody params);

    //Primary Report History
    //1..panchnama-primary-report-list
    @POST(APIServices.PRIMARY_REPORT_COUNT_AGAINST_VILLAGE_SAVE)
    Call<JsonObject>primary_report_count_against_village_save(@Body RequestBody params);

    //2.Primary Report total count
    @POST(APIServices.PRIMARY_REPORT_TOTAL_COUNT_)
    Call<JsonObject>primary_report_total_count(@Body RequestBody params);

    //3.Primart Report Details
    @POST(APIServices.PRIMARY_REPORT_DETAILS)
    Call<JsonObject>primary_report_details(@Body RequestBody params);

    //Final Report
    @POST(APIServices.DEPARTMENT_PUNCHNAMA_FINAL_REPORT_LIST)
    Call<JsonObject>department_panchnama_final_report_list(@Body RequestBody params);

    @POST(APIServices.DEPARTMENT_PUNCHNAMA_FINAL_REPORT_PDF)
    Call<JsonObject>department_panchnama_final_report_pdf(@Body RequestBody params);


    /**** FOR DEMO OR FFS**/
    // To get Plan area
    @POST(APIServices.kPlanAreaUrl)
    Call<JsonObject> planAreaRequest(@Body RequestBody params);

    // To add demo or ffs Plan
    @POST(APIServices.kPlanUrl)
    Call<JsonObject> planRegistrationRequest(@Body RequestBody params);

    @POST(APIServices.kPlanListUrl)
    Call<JsonObject> planListRequest(@Body RequestBody params);


    // FOR FFS
    @POST(APIServices.kVillagePlot)
    Call<JsonObject> fetchVillagePlotOfFacilitatorRequest(@Body RequestBody params);

    @POST(APIServices.kHostFarmerRegistration)
    Call<JsonObject> registerHostFarmer(@Body RequestBody params);

    @POST(APIServices.kHostFarmerList)
    Call<JsonObject> hostFarmerList(@Body RequestBody params);

    @POST(APIServices.kGuestRegistration)
    Call<JsonObject> registerGuestFarmer(@Body RequestBody params);

    @POST(APIServices.kHostFarmerEditList)
    Call<JsonObject> fetchHostFarmerEditListRequest(@Body RequestBody params);

    @POST(APIServices.kUpdateGuestFarmer)
    Call<JsonObject> updateGuestFarmer(@Body RequestBody params);

    @POST(APIServices.kMasterSeason)
    Call<JsonObject> fetchMasterSeasonList(@Body RequestBody params);

    @POST(APIServices.kMasterCropType)
    Call<JsonObject> fetchMasterCropType(@Body RequestBody params);

    @POST(APIServices.kMasterCrop)
    Call<JsonObject> fetchMasterCrop(@Body RequestBody params);

    @POST(APIServices.kMasterCropVariety)
    Call<JsonObject> fetchMasterCropVariety(@Body RequestBody params);

    @POST(APIServices.kMasterCropPestList)
    Call<JsonObject> fetchMasterCropPestList(@Body RequestBody params);

    @POST(APIServices.kMasterCropIrrigationList)
    Call<JsonObject> fetchMasterCropIrrigation(@Body RequestBody params);

    @POST(APIServices.kMasterCropGrowthList)
    Call<JsonObject> fetchMasterCropGrowth(@Body RequestBody params);

    @POST(APIServices.kCrops)
    Call<JsonObject> fetchMasterCropList(@Body RequestBody params);

    @POST(APIServices.kCropsVerity)
    Call<JsonObject> fetchCropVerity(@Body RequestBody params);

    @POST(APIServices.kCropsVerityById)
    Call<JsonObject> fetchCropVerityById(@Body RequestBody params);

    @POST(APIServices.kHostFarmerUpdate)
    Call<JsonObject> updateHostFarmer(@Body RequestBody params);

    @POST(APIServices.kGuestFarmerList)
    Call<JsonObject> fetchGuestFarmerListRequest(@Body RequestBody params);

    // For Schedule Detail
    @POST(APIServices.kSchedules)
    Call<JsonObject> fetchSchedules(@Body RequestBody params);

    //For Crop Sowing Report
    @GET(APIServices.CROP_SOWING_REPORT_CROP_TYPE)
    Call<JsonObject>crop_sowing_report_crop_type_list();

    @POST(APIServices.CROP_SOWING_REPORT_CROP_TYPE_SOWN_SUB_LIST)
    Call<JsonObject> crop_sowing_report_crop_type_sown_sublist(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_FIELD_CROP_TYPE_SOWN_LIST)
    Call<JsonObject> field_crop_type(@Body RequestBody params);

    //For Crop Sowing Farmer Report
    @POST(APIServices.CROP_SOWING_REPORT_CROP_TYPE_SOWN_SUB_CROP_LIST)
    Call<JsonObject> crop_sowing_report_crop_type_sown_sub_crop_list(@Body RequestBody params);

    // Year of Plantation
    @GET(APIServices.CROP_SOWING_REPORT_FARMER_YEAR_OF_PLATATION)
    Call<JsonObject>crop_sowing_report_farmer_year_of_plantation();

    @GET(APIServices.CROP_SOWING_REPORT_FARMER_SCHEME_NAMES)
    Call<JsonObject>crop_sowing_report_farmer_scheme_name();

    @POST(APIServices.FARMER_REPORT_SAVE)
    Call<JsonObject> csr_farmerwise_report_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.FARMER_REPORT_IMG_SAVE)
    Call<JsonObject> farmerwise_report_img_save(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.CROP_SOWING_REPORT_VILLAGE_WISE_CROP_DATA)
    Call<JsonObject> crop_sowing_village_wise_crop_data(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_SUBMIT)
    Call<JsonObject> crop_sowing_report_submit(@Body RequestBody params);

    //For Crop Sowing History
    @POST(APIServices.CROP_SOWING_REPORT_VILLAGE_HISTORY_COUNT)
    Call<JsonObject> crop_sowing_report_village_history_count(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_HISTORY_LIST)
    Call<JsonObject> department_showing_report_list(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_HISTORY_DETAILS)
    Call<JsonObject> department_sowing_report_details(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_AREA_CALCULATION)
    Call<JsonObject> get_crop_calculated_area_value(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_METEOROLOGICAL_WEEK)
    Call<JsonObject> meteorological_week(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_REPORT_GEO_CUL_AREA)
    Call<JsonObject>  get_geo_cul_area_village_mapping_area(@Body RequestBody params);

    @POST(APIServices.CROP_SOWING_SEASON_SOWN_AREA)
    Call<JsonObject>  get_csr_season_sown_area(@Body RequestBody params);

    //CROP SOWING REPORT HISTORY

    @POST(APIServices.CROP_SOWING_REPORT_HISTORY_METEROLOGICAL_WEEK)
    Call<JsonObject>  get_csr_history_meterological_week(@Body RequestBody params);



    //Consolidate Report
    @POST(APIServices.CONSOLIDATE_REPORT_SAVE)
    Call<JsonObject> consolidated_report_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.CONSOLIDATE_REPORT_IMG_SAVE)
    Call<JsonObject> consolidated_report_img_save(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    // For Pre Showing
    @POST(APIServices.kPreShowingVisit)
    Call<JsonObject> getPreShowingList(@Body RequestBody params);

    //Demonstration Tehcnology Form
    @GET(APIServices.DEMO_PACKAGE)
    Call<JsonObject>demonstrationpackage();

    @POST(APIServices.DEMO_INPUT_TECHNOLOGY)
    Call<JsonObject> demonstration_input_list(@Body RequestBody params);

    @POST(APIServices.DEMO_MASTER_PACKAGE_DETAIL)
    Call<JsonObject> DemonstrationMasterPackageDetail(@Body RequestBody params);

    @Multipart
    @POST(APIServices.DEMO_TECHNOLOGY_IMAGES)
    Call<JsonObject> upload_technology_demo_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Demonstration AESA Form
    @POST(APIServices.DEMO_AESA_METHOD_OF_SOWING)
    Call<JsonObject> get_methodOfSowing_list(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_BIOLOGICAL_PEST)
    Call<JsonObject> get_pest_list(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_SOIL_CONDITION)
    Call<JsonObject> get_soil_condition(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_RODENT_DAMAGE)
    Call<JsonObject> get_rodent_damage(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_WEATHER_CONDITION)
    Call<JsonObject> get_weather_condition(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_WIND_CONDITION)
    Call<JsonObject> get_wind_condition(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_WEED_TYPE_INTENSITY)
    Call<JsonObject> get_weeds_type_intensity(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_BIOLOGICAL_DEFENDER)
    Call<JsonObject> get_defender_list(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_DISEASE_TYPE)
    Call<JsonObject> get_crop_disease(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_DISEASE_SEVERITY)
    Call<JsonObject> get_disease_type_severity(@Body RequestBody params);

    @POST(APIServices.DEMO_AESA_IRRIGATION_METHOD)
    Call<JsonObject> get_irrigationMethod_list(@Body RequestBody params);

    //Demonstration Attendance Form
    @POST(APIServices.GUEST_FARMER_LIST)
    Call<JsonObject> gest_farmer_list(@Body RequestBody params);

    @POST(APIServices.GET_FARMER_LIST)
    Call<JsonObject> get_farmer_list(@Body RequestBody params);


    @POST(APIServices.DEMO_ATTENDANCE_SAVE)
    Call<JsonObject> demo_attendance_save(@Body RequestBody params);

    //For Physical Verification - Farmer list
    @POST(APIServices.PHYSICAL_VERIFICATION_FARMER_LIST)
    Call<JsonObject>phy_verify_farmer_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_COMPONENT_LIST)
    Call<JsonObject>phy_verf_component_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_SCHEME_LIST)
    Call<JsonObject>phy_verf_scheme_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_ASSIGN_FARMER_LIST)
    Call<JsonObject>phy_verf_farmer_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_FORM_LIST)
    Call<JsonObject>phy_verf_form_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_DEALER_LIST)
    Call<JsonObject>phy_verf_dealer_list(@Body RequestBody params);

    @POST(APIServices.PHYSICAL_VERIFICATION_MANUFACTURE_LIST)
    Call<JsonObject>phy_verf_manufacture_list(@Body RequestBody params);

    @Multipart
    @POST(APIServices.kPreShowingImg_Upload)
    Call<JsonObject> visit_image_upload(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.kPreShowingDetailInsert)
    Call<JsonObject> insertPreShowingDetail(@Body RequestBody params);

    @POST(APIServices.kShowingDetailInsert)
    Call<JsonObject> insertShowingDetail(@Body RequestBody params);

    @POST(APIServices.kGetShowingDetail)
    Call<JsonObject> getShowingVisitDetail(@Body RequestBody params);

    @POST(APIServices.kD_F_EVENT_SAVE)
    Call<JsonObject> postD_F_VisitsRequest(@Body RequestBody params);

    @POST(APIServices.kFFS_TECH_LIST)
    Call<JsonObject> fetchTechDemos(@Body RequestBody params);

    // FFS Observation
    @POST(APIServices.kIRRIGATION_LIST)
    Call<JsonObject> fetchIrrigationList(@Body RequestBody params);

    @POST(APIServices.kSHOWING_LIST)
    Call<JsonObject> fetchShowingList(@Body RequestBody params);

    @POST(APIServices.kPEST_LIST)
    Call<JsonObject> fetchPestList(@Body RequestBody params);

    @POST(APIServices.kDEFENDER_LIST)
    Call<JsonObject> fetchDefenderList(@Body RequestBody params);

    @POST(APIServices.kCROP_VERITY_LIST)
    Call<JsonObject> fetchCropVerityList(@Body RequestBody params);

    @Multipart
    @POST(APIServices.SPOT_FARMER_MECH_IMAGE_SAVE)
    Call<JsonObject> mechanism_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @Multipart
    @POST(APIServices.SPOT_CUSTOMER_HIRING_CENTER_SAVE_IMAGE)
    Call<JsonObject> customer_hiring_center_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.SPOT_CUSTOMER_HIRING_CENTER_SAVE_DETAILS)
    Call<JsonObject>customer_hiring_center_save_details(@Body RequestBody params);


    @POST(APIServices.kDISEASE_LIST)
    Call<JsonObject> fetchDisaesList(@Body RequestBody params);

    @POST(APIServices.kDISEASE_SEVERITY_LIST)
    Call<JsonObject> fetchDiesesSeverityList(@Body RequestBody params);

    @POST(APIServices.kRODANT_DAMAGE_LIST)
    Call<JsonObject> fetchDamageList(@Body RequestBody params);

    @POST(APIServices.kSOIL_CONDITION_LIST)
    Call<JsonObject> fetchSoilConditionList(@Body RequestBody params);

    @POST(APIServices.kWEATHER_LIST)
    Call<JsonObject> fetchWeatherList(@Body RequestBody params);

    @POST(APIServices.kWEED_TYPE_LIST)
    Call<JsonObject> fetchWeedTypeList(@Body RequestBody params);

    @POST(APIServices.kWIND_CONDITION_LIST)
    Call<JsonObject> fetchWindConditionList(@Body RequestBody params);

    //Spot Verificiation- Farmer Mechnization

    @POST(APIServices.SPOT_FARMER_MECH_SAVE)
    Call<JsonObject> mechanism_master_save(@Body RequestBody params);

    @POST(APIServices.SPOT_GET_FARMER_MECH_DETAILS)
    Call<JsonObject> mechanis_list(@Body RequestBody params);

    //Spot Verification - Drip data
    @POST(APIServices.SPOT_VERIFICATION_DRIP_FETCH_DATA)
    Call<JsonObject>fetch_spot_verification_drip_data(@Body RequestBody params);

    @GET(APIServices.SPOT_VERIFICATION_DRIP_SYSTEM_TYPE)
    Call<JsonObject>drip_system_type();

    @GET(APIServices.SPOT_VERIFICATION_DRIP_SPACING)
    Call<JsonObject>drip_spacing();

    @POST(APIServices.SPOT_VERIFICATION_DRIP_FORM_SAVE)
    Call<JsonObject>drip_form_save(@Body RequestBody params);

    @GET(APIServices.SPOT_VERIFICATION_DRIP_LISTING_DATA)
    Call<JsonObject>fetch_spot_verification_drip_listing_data();

    @POST(APIServices.SPOT_VERIFICATION_DRIP_BILL_AGAINST_ID_DATA)
    Call<JsonObject>fetch_spot_verification_drip_bill_against_id(@Body RequestBody params);

    @POST(APIServices.DRIP_FETCH_DETAILS)
    Call<JsonObject>drip_fetch_details(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_DRIP_BILL_AGAINST_ID_SAVE_DATA)
    Call<JsonObject>spot_verification_drip_bill_against_id_save(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_DRIP_BILL_LIST_SAVE)
    Call<JsonObject>spot_verification_drip_bill_list_against_id(@Body RequestBody params);

    //Spot Verification - Plantation
    @GET(APIServices.PLANTATION_LIST)
    Call<JsonObject>plantation_list();

    @POST(APIServices.PLANTATION_SAVE)
    Call<JsonObject>plantation_save(@Body RequestBody params);

    //Spot Verification - Rejuvenation
    @POST(APIServices.REJUVENATION_SAVE)
    Call<JsonObject>rejuvenation_save(@Body RequestBody params);

    //Spot Verification - Mechanization MIDH
    @POST(APIServices.MECH_MIDH_SAVE)
    Call<JsonObject>mech_midh_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.MECH_MIDH_IMG_SAVE)
    Call<JsonObject>mech_midh_img_save(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Spot Verification - MB Community Farm Pond 8
    @GET(APIServices.MB_COMMUNITY_FARM_POND_LIST)
    Call<JsonObject>mb_community_pond_list();

    @POST(APIServices.MB_COMMUNITY_FARM_POND_SAVE)
    Call<JsonObject>mb_community_pond_save(@Body RequestBody params);

    @POST(APIServices.MB_COMMUNITY_FARM_POND_IS_COMPLETED)
    Call<JsonObject>mb_community_pond_is_completed(@Body RequestBody params);

    @POST(APIServices.MB_COMMUNITY_POND_8)
    Call<JsonObject>mb_community_pond_8_save(@Body RequestBody params);

    //Spot Verification - MB Community Farm Pond 9
    @POST(APIServices.MB_COMMUNITY_POND_9)
    Call<JsonObject>mb_community_pond_9_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.MB_COMMUNITY_POND_9_IMAGE)
    Call<JsonObject>mb_community_pond_9_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Spot Verification - MB Farmer Pond
    @POST(APIServices.MB_FARMER_POND)
    Call<JsonObject>mb_farmer_pond_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.MB_FARMER_POND_IMAGE)
    Call<JsonObject>mb_farmer_pond_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Spot Verification - Sprinkler data
    @GET(APIServices.SPOT_VERIFICATION_SPRINKLER_LISTING_DATA)
    Call<JsonObject>fetch_spot_verification_sprinkler_listing_data();

    @POST(APIServices.SPRINKLER_FETCH_DETAILS)
    Call<JsonObject>sprinkler_fetch_details(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_SPRINKLER_BILL_AGAINST_ID_SAVE_DATA)
    Call<JsonObject>spot_verification_sprinkler_bill_against_id_save(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_SPRINKLER_BILL_LIST_SAVE)
    Call<JsonObject>spot_verification_sprinkler_bill_list_against_id(@Body RequestBody params);

    @POST(APIServices.kRAIN_CONDITION_LIST)
    Call<JsonObject> fetchRainConditionList(@Body RequestBody params);


    //Soyabean crop
    @GET(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_PLANT_LIST)
    Call<JsonObject> soyabean_spot_list();

    @Multipart
    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_SAVE_IMAGE_URL)
    Call<JsonObject> crop_soyabean_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_SAVE_URL)
    Call<JsonObject> crop_soyabean_save(@Body RequestBody params);

    //PHYSICAL VERIFICATION - WBCIS
    @GET(APIServices.PHY_VERI_YEAR_URL)
    Call<JsonObject>phy_veri_year();

    @GET(APIServices.PHY_VERI_DISTRICT_URL)
    Call<JsonObject>phy_veri_district();

    @POST(APIServices.PHY_VERI_TALUKA_URL)
    Call<JsonObject> phy_veri_taluka(@Body RequestBody params);

    @POST(APIServices.PHY_VERI_REVENUE_URL)
    Call<JsonObject> phy_veri_revenue(@Body RequestBody params);

    @POST(APIServices.PHY_VERI_GRAM_PANCHAYAT_URL)
    Call<JsonObject> phy_veri_gram_panchayat(@Body RequestBody params);

    @POST(APIServices.PHY_VERI_VILLAGE_URL)
    Call<JsonObject> phy_veri_village(@Body RequestBody params);

    @GET(APIServices.PHY_VERI_SEASON_URL)
    Call<JsonObject>phy_veri_season();

    @POST(APIServices.PHY_VERI_CROP_URL)
    Call<JsonObject> phy_veri_crop(@Body RequestBody params);

    @POST(APIServices.PHY_VERI_SAVE_URL)
    Call<JsonObject> phy_veri_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.PHY_VERI_SAVE_IMAGE_URL)
    Call<JsonObject> phy_veri_save_image(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    //Orchard Mapping
    @POST(APIServices.ORCHARD_MAPPING_DISTRICT_TALUKA)
    Call<JsonObject> orchard_mapping_district_taluka(@Body RequestBody params);

    @POST(APIServices.ORCHARD_MAPPING_SAVE)
    Call<JsonObject> orchard_mapping_save(@Body RequestBody params);

    @Multipart
    @POST(APIServices.ORCHARD_MAPPING_SAVE_IMG)
    Call<JsonObject> orchard_mapping_save_img(@Part MultipartBody.Part image, @PartMap Map<String, String> params);

    @POST(APIServices.VILLAGE_MAPPING_AREA_SAVE)
    Call<JsonObject> village_mapping_area_save(@Body RequestBody params);

    @POST(APIServices.VILLAGE_MAPPING_AREA_GET_FILLED_DATA)
    Call<JsonObject> village_mapping_area_get_filled_data(@Body RequestBody params);


    //Assigned Charged
    @POST(APIServices.ASSIGNED_CHARGE)
    Call<JsonObject> assigned_charge_list(@Body RequestBody params);


    @POST(APIServices.ASSIGNED_LOCATION_CHARGE)
    Call<JsonObject> assigned_location_charge(@Body RequestBody params);

    @POST(APIServices.ASSIGNED_SAJJA_LIST)
    Call<JsonObject> assigned_sajja_list(@Body RequestBody params);

    @POST(APIServices.ASSIGNED_VILLAGE_LIST)
    Call<JsonObject> assigned_village_list(@Body RequestBody params);

    @POST(APIServices.ADDITIONAL_CHARGE_VILLAGE_LIST)
    Call<JsonObject> additional_charge_village_list(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_ITEM_LIST)
    Call<JsonObject>spot_veri_item_list(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_DESC_LIST)
    Call<JsonObject>spot_veri_desc_list(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_RATE_LIST)
    Call<JsonObject>spot_veri_rate_list(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_SPRINKLER_TYPE_LIST)
    Call<JsonObject>spot_veri_type_list(@Body RequestBody params);

    @POST(APIServices.SPOT_VERIFICATION_SPRINKLER_TYPE_SPACING)
    Call<JsonObject>spot_veri_type_spacing(@Body RequestBody params);

    @POST(APIServices.kReasons)
    Call<JsonObject> fetchReasonList(@Body RequestBody params);

    // Orchard mapping................................................................................................

    @POST(APIServices.ORCHARD_SURVEY_LIST_URL)
    Call<JsonObject> orchard_survey_list(@Body RequestBody params);

    @POST(APIServices.REMOVE_ORCHARD_SURVEY_FROM_LIST_URL)
    Call<JsonObject> remove_orchard_survey_from_list(@Body RequestBody params);

    //Assigned Charged
    @POST(APIServices.ORCHARD_MOBILE_EXISTS)
    Call<JsonObject> orchard_mobile_exists(@Body RequestBody params);

    @POST(APIServices.UPDATE_APP_NEW)
    Call<JsonObject> updateAppNew(@Body RequestBody params);

    //
}
