package com.maha.agri.activity.TaskManagerReport;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class TaskManagerDetails extends AppCompatActivity implements ApiCallbackCode {
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private JSONArray task_manager_report_details_List;
    private RecyclerView task_manager_List_rv;
    private String activityId;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_manager_details);
        preferenceManager = new PreferenceManager(TaskManagerDetails.this);
        sharedPref = new SharedPref(TaskManagerDetails.this);
        getSupportActionBar().setTitle("Task Manager Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        intent = getIntent();
        activityId = intent.getStringExtra("activityId");
        init();
        task_manager_details_Webservice();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init(){

        task_manager_List_rv = (RecyclerView) findViewById(R.id.tmDetailRecyclerView);
        task_manager_List_rv.setLayoutManager(new LinearLayoutManager(this));
        task_manager_List_rv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));
    }


    private void task_manager_details_Webservice () {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("activityId", activityId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.task_manager_report__details(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }



    @Override
    public void onResponse (JSONObject jsonObject,int i){

        try {

            if (jsonObject != null) {
                if (i == 1) {

                    if (jsonObject.getString("status").equals("200")) {
                        task_manager_report_details_List = jsonObject.getJSONArray("data");
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            task_manager_report_details_List = jsonObject.getJSONArray("data");
                            task_manager_List_rv.setAdapter(new TaskManagerDetailsAdapter(this,task_manager_report_details_List,preferenceManager));
                        }
                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFailure (Object o, Throwable throwable,int i){

    }

}
