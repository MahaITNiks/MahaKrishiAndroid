package com.maha.agri.ffs;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.ffs.adaptor.DemoTechFormAdapter;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.model.TechDemoModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DemoTechnologyForm extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener, AlertListEventListener {

    private AppLocationManager locationManager;
    private String userID;
    private String activityID;

    // For Image upload
    private File photoFile = null;
    private Transformation transformation;
    private String selectedImage = "0";
    private String currentImglatLong = "";
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    String currentTime;
    private ImageView attch1ImageView, attch2ImageView;

    private File imgFile = null;
    private double lat1;
    private double lang1;

    private File imgFile2 = null;
    private double lat2;
    private double lang2;

    private RecyclerView demoTechRecyclerView;
    private LinearLayout packageLL, technologyLL;
    private TextView cropNameTV, packageTV, technologyTV, totalAmountTV, permissibleAmountTV;
    private Button submit;
    private EditText commentEText, totalCropQtyEText;
    private DemoTechFormAdapter demo_techFormAdapter;
    private JSONArray packagearray, inputArray;
    private LinearLayout demoTechListLLayout;

    private boolean isDemoTechAvailable = false;

    private int packageID = 0;
    private int inputID = 0;
    private String cropID;
    private AppSession session;
    private double cropVerityRate;
    private double permissiableAmt;
    private int update_visit = 0;
    private String visit_number;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_technology_form);
        getSupportActionBar().setTitle("Technology Demonstrated/Discussed");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        userID = AppSettings.getInstance().getValue(this, ApConstants.kUSER_ID, ApConstants.kUSER_ID);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        init();
        configuration();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void init() {
        commentEText = (EditText) findViewById(R.id.commentEText);
        attch1ImageView = (ImageView) findViewById(R.id.attch1ImageView);
        attch2ImageView = (ImageView) findViewById(R.id.attch2ImageView);
        submit = (Button) findViewById(R.id.submitButton);

        cropNameTV = (TextView) findViewById(R.id.planNameTextView);
        packageLL = (LinearLayout) findViewById(R.id.packageLL);
        packageTV = (TextView) findViewById(R.id.packageTV);
        technologyLL = (LinearLayout) findViewById(R.id.technologyLL);
        technologyTV = (TextView) findViewById(R.id.technologyTV);
        totalAmountTV = (TextView) findViewById(R.id.totalAmountTV);
        permissibleAmountTV = (TextView) findViewById(R.id.permissibleAmountTV);

        totalCropQtyEText = (EditText) findViewById(R.id.totalCropQtyEText);
        currentTime = ApUtil.getCurrentTimeStamp();

        demoTechListLLayout = (LinearLayout) findViewById(R.id.demoTechListLLayout);
        demoTechRecyclerView = findViewById(R.id.demoTechRecyclerView);

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
    }

    private void configuration() {

        cropID = getIntent().getStringExtra("crop_id");
        visit_number = getIntent().getStringExtra("visit_num");

        session = new AppSession(this);
        String cropName = session.getCropName();
        cropNameTV.setText(cropName);

        packageLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                demoPackage();
            }
        });

        technologyLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (packageID == 0) {
                    UIToastMessage.show(DemoTechnologyForm.this, "Please select demonstration package");
                } else {
                    inputTechnology();
                }
            }
        });

        attch1ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedImage = "1";
                if ((ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ) {
                    locationManager = new AppLocationManager(DemoTechnologyForm.this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        attch2ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedImage = "2";
                if ((ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(DemoTechnologyForm.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    // && (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ) {
                    locationManager = new AppLocationManager(DemoTechnologyForm.this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String qty = totalCropQtyEText.getText().toString().trim();

                if (packageID == 0){
                    UIToastMessage.show(DemoTechnologyForm.this, "Please select package");
                }else if (inputID == 0){
                    UIToastMessage.show(DemoTechnologyForm.this, "Please select input used");
                }else if (qty.equalsIgnoreCase("")){
                    UIToastMessage.show(DemoTechnologyForm.this, "Please input quantity");
                }else {

                    try {

                        JSONArray inputDataArray = getInputUsedData();

                        JSONArray jsonArray = new JSONArray();

                        if (demo_techFormAdapter != null && demo_techFormAdapter.mDataArray != null) {
                            for (int i = 0; i < demo_techFormAdapter.mDataArray.length(); i++) {
                                JSONObject jsonObject = demo_techFormAdapter.mDataArray.getJSONObject(i);
                                TechDemoModel model = new TechDemoModel(jsonObject);
                                if (model.getIs_selected() == 1) {
                                    jsonArray.put(jsonObject);
                                }
                            }
                        }


                        if (update_visit == 1) {
                            if (inputDataArray.length() == 0) {
                                UIToastMessage.show(DemoTechnologyForm.this, getResources().getString(R.string.input_used_err));
                            } else {
                                AppSettings.getInstance().setValue(DemoTechnologyForm.this, ApConstants.kTECH_DEMO, jsonArray.toString());
                                AppSettings.getInstance().setValue(DemoTechnologyForm.this, ApConstants.kINPUT_DEMO, inputDataArray.toString());
                                EventBus.getDefault().post(new EventModel("update_2"));
                                finish();
                            }
                        } else {
                            if (inputDataArray.length() == 0) {
                                UIToastMessage.show(DemoTechnologyForm.this, getResources().getString(R.string.input_used_err));
                            } else if (imgFile == null) {
                                UIToastMessage.show(DemoTechnologyForm.this, getResources().getString(R.string.tech_attach_photo));
                            } else {
                                AppSettings.getInstance().setValue(DemoTechnologyForm.this, ApConstants.kTECH_DEMO, jsonArray.toString());
                                AppSettings.getInstance().setValue(DemoTechnologyForm.this, ApConstants.kINPUT_DEMO, inputDataArray.toString());
                                EventBus.getDefault().post(new EventModel("update_2"));
                                finish();
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

        // fetchTechnologyList();
        // JSONArray jsonArray = AppHelper.getInstance().getCAReports();
        //DemoTechFormAdapter demo_techFormAdapter =  new DemoTechFormAdapter(DemoTechnologyForm.this, DemoTechnologyForm.this,this,jsonArray);
        //techRView.setAdapter(demo_techFormAdapter);

        totalCropQtyEText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String quantity = totalCropQtyEText.getText().toString().trim();
                double qty = 0.0;
                if (!quantity.equalsIgnoreCase("")) {
                    qty = Double.valueOf(quantity);
                }

                double amount = cropVerityRate * qty;
                totalAmountTV.setText(String.valueOf(amount));

                if (amount>permissiableAmt){
                    permissibleAmountTV.setText(String.valueOf(permissiableAmt));
                }else {
                    permissibleAmountTV.setText(String.valueOf(amount));
                }

            }
        });
    }

    private JSONArray getInputUsedData() {

        JSONArray jsonArray = new JSONArray();

        try {
            String packageName = packageTV.getText().toString().trim();
            String inputUsed = technologyTV.getText().toString().trim();
            String qty = totalCropQtyEText.getText().toString().trim();
            String amount = totalAmountTV.getText().toString().trim();
            String perAmount = totalAmountTV.getText().toString().trim();

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("packageId",packageID);
            jsonObject.put("packageName",packageName);
            jsonObject.put("inputId",inputID);
            jsonObject.put("inputName",inputUsed);
            jsonObject.put("quantity",qty);
            jsonObject.put("amount",amount);
            jsonObject.put("perAmount",perAmount);

            jsonArray.put(jsonObject);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }


    @Override
    protected void onResume() {
        super.onResume();
        fetchDemoPackage();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void fetchTechnologyList() {

        try {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("crop_id", cropID);
                jsonObject.put("visit_number", visit_number);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchTechDemos(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, new ApiCallbackCode() {
                @Override
                public void onResponse(JSONObject jsonObject, int i) {
                    try {
                        if (i == 1) {

                            if (jsonObject != null) {
                                DebugLog.getInstance().d("onResponse=" + jsonObject);
                                ResponseModel response = new ResponseModel(jsonObject);
                                if (response.isStatus()) {
                                    JSONArray jsonArray = response.getData();
                                    if (jsonArray.length() > 0) {
                                        demoTechListLLayout.setVisibility(View.VISIBLE);
                                        isDemoTechAvailable = true;
                                        demo_techFormAdapter = new DemoTechFormAdapter(DemoTechnologyForm.this, DemoTechnologyForm.this, jsonArray);
                                        demoTechRecyclerView.setAdapter(demo_techFormAdapter);
                                    } else {
                                        demoTechListLLayout.setVisibility(View.GONE);
                                        isDemoTechAvailable = false;
                                    }
                                } else {
                                    demoTechListLLayout.setVisibility(View.GONE);
                                    isDemoTechAvailable = false;
                                    UIToastMessage.show(DemoTechnologyForm.this, response.getMsg());
                                }
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Object o, Throwable throwable, int i) {

                }
            }, 1);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void demoPackage() {

        if (packagearray == null) {
            fetchDemoPackage();
        } else {
            AppUtility.getInstance().showListDialogIndex(packagearray, 1, "Select Package", "name", "id", this, this);
        }
    }

    private void inputTechnology() {

        if (inputArray == null) {
            fetchInputTech(packageID);
        } else {
            AppUtility.getInstance().showListDialogIndex(inputArray, 2, "Select Input/Technology", "name", "id", this, this);
        }
    }

    private void fetchDemoPackage() {

        JSONObject jsonObject = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.demonstrationpackage();
        api.postRequest(responseCall, this, 1);

    }

    private void fetchInputTech(int packageID) {

        AppSettings.getInstance().setValue(DemoTechnologyForm.this, ApConstants.kCROP_ID_DEMO_FFS, String.valueOf(cropID));

        try {
            AppSession session = new AppSession(this);
            JSONObject jsonObject = new JSONObject();

            jsonObject.put("package_id", packageID);
            jsonObject.put("crop_id", cropID);
            jsonObject.put("token", session.getToken());

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.demonstration_input_list(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {
            try {

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        packagearray = responseModel.getData();
                    } else {
                        packagearray = new JSONArray();
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        inputArray = responseModel.getData();
                    } else {
                        inputArray = new JSONArray();
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 33) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {

                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        String imgUrl = jsonObject1.getString("file_url");
                        if (selectedImage.equalsIgnoreCase("1")) {

                            AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1, jsonObject.toString());
                            if (currentImglatLong.equalsIgnoreCase("")) {
                                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1_LOC, currentImglatLong);
                            } else {
                                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1_LOC, ApConstants.kTECH_DEMO_FILE1_LOC);
                            }

                            if (imgUrl != null) {
                                Picasso.get()
                                        .load(imgUrl)
                                        .transform(transformation)
                                        .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                        .centerCrop()
                                        .into(attch1ImageView);
                            }


                        } else {
                            AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2, jsonObject.toString());
                            if (currentImglatLong.equalsIgnoreCase("")) {
                                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2_LOC, currentImglatLong);
                            } else {
                                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2_LOC, ApConstants.kTECH_DEMO_FILE2_LOC);
                            }
                            if (imgUrl != null) {
                                Picasso.get()
                                        .load(imgUrl)
                                        .transform(transformation)
                                        .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                        .centerCrop()
                                        .into(attch2ImageView);
                            }
                        }
                    }
                }


                if (i == 5) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        JSONArray dataArray = responseModel.getData();
                        JSONObject data = dataArray.getJSONObject(0);
                        String rate = data.getString("rate");
                        cropVerityRate = Double.parseDouble(rate);
                        String ceilingLimit = data.getString("row_ceiling_limit");
                        permissiableAmt = Double.parseDouble(ceilingLimit) * cropVerityRate;
                        // permissibleAmountTV.setText(String.valueOf(permissiableAmt));
                    }else {
                        UIToastMessage.show(this,responseModel.getMsg());
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            packageID = Integer.parseInt(s1);
            packageTV.setText(s);
            fetchInputTech(packageID);
            technologyTV.setText("Select");
        }

        if (i == 2) {
            inputID = Integer.parseInt(s1);
            technologyTV.setText(s);
            get_tech_detail();
        }
    }

    // To get Permissible amount
    private void get_tech_detail() {

        try {
            String demoSchemeId = getIntent().getStringExtra("demoSchemeId");
            String cropingSysId = getIntent().getStringExtra("cropingSysId");
            String crop_id = getIntent().getStringExtra("crop_id");
            String season_id = getIntent().getStringExtra("season_id");

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("scheme_id", demoSchemeId);
            jsonObject.put("cropping_system_id", cropingSysId);
            jsonObject.put("season_id", season_id);
            jsonObject.put("crop_id", crop_id);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.DemonstrationMasterPackageDetail(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    // For Image upload
    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userID + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (selectedImage.equalsIgnoreCase("1")) {
                            imgFile = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat1 = locationManager.getLatitude();
                            lang1 = locationManager.getLatitude();
                        } else if (selectedImage.equalsIgnoreCase("2")) {
                            imgFile2 = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat2 = locationManager.getLatitude();
                            lang2 = locationManager.getLatitude();
                        }
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(DemoTechnologyForm.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {

            currentImglatLong = locationManager.getLatitude() + "_" + locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", userID);
            params.put("crop_id", String.valueOf(cropID));
            params.put("ima_sr_no", selectedImage);

            //creating a file
            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("image_name", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.visit_image_upload(partBody, params);
            api.postRequest(responseCall, this, 33);

            DebugLog.getInstance().d("technology_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("technology_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
