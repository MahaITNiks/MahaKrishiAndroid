package com.maha.agri.mb_recording;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.InputFilterMinMax;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Hard_Man_Boulder_Activity extends AppCompatActivity implements ApiCallbackCode {

    private AppLocationManager locationManager;
    private int soil_lavel;
    public double lat;
    public double lang;
    private String soil_id = "1";
    private String soilName;

    // For Image upload
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private File photoFile1 = null;
    static final Integer CAMERA = 0x5;
    String imagePath, currentTime;
    private Transformation transformation;
    String type;

    private String image1URL;
    private String image2URL;

    Button btn_submit_HManBoulder;
    EditText edt_list_from_hard_man_boulder, edt_lift_to_hard_man_boulder, edt_diameter_hard_man_boulder, edt_height_hard_man_boulder, edt_qty_hard_man_boulder;
    String str_farmer_name;
    TextView txt_farmer_name;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    String str_list_from_hard_man_boulder, str_lift_to_hard_man_boulder, str_diameter_hard_man_boulder, str_height_hard_man_boulder, str_qty_hard_man_boulder;
    ImageView farmers_photo_hard_man_boulder, farmers_photo_hard_man_boulder_1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard_man_boulder_);
        getSupportActionBar().setTitle("Hard Man Boulder");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(Hard_Man_Boulder_Activity.this);
        sharedPref = new SharedPref(Hard_Man_Boulder_Activity.this);
        soil_lavel = AppSettings.getInstance().getIntValue(this, ApConstants.MB_STAGE_LAVAL, 0);
        init();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {
        soil_id = getIntent().getStringExtra("soilId");
        soilName = getIntent().getStringExtra("soilName");
        locationManager = new AppLocationManager(this);

        farmers_photo_hard_man_boulder = (ImageView) findViewById(R.id.farmers_photo_hard_man_boulder);
        farmers_photo_hard_man_boulder_1 = (ImageView) findViewById(R.id.farmers_photo_hard_man_boulder_1);
        btn_submit_HManBoulder = (Button) findViewById(R.id.btn_submit_HManBoulder);

        edt_list_from_hard_man_boulder = (EditText) findViewById(R.id.edt_list_from_hard_man_boulder);
        edt_lift_to_hard_man_boulder = (EditText) findViewById(R.id.edt_lift_to_hard_man_boulder);
        edt_diameter_hard_man_boulder = (EditText) findViewById(R.id.edt_diameter_hard_man_boulder);
        edt_height_hard_man_boulder = (EditText) findViewById(R.id.edt_height_hard_man_boulder);
        edt_qty_hard_man_boulder = (EditText) findViewById(R.id.edt_qty_hard_man_boulder);


        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();


        String soilData = getIntent().getStringExtra("soilData");
        if (!soilData.equalsIgnoreCase("")){
            setSoilDetail(soilData);
        }

        farmers_photo_hard_man_boulder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "0";
                    takeImage0FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        farmers_photo_hard_man_boulder_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Hard_Man_Boulder_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "1";
                    takeImage1FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        txt_farmer_name = (TextView) findViewById(R.id.txt_farmer_name);

        str_farmer_name = AppSettings.getInstance().getValue(Hard_Man_Boulder_Activity.this, ApConstants.MB_FARMER_NAME, "");
        txt_farmer_name.setText(str_farmer_name);

        String liftToSoil = AppSettings.getInstance().getValue(Hard_Man_Boulder_Activity.this, ApConstants.LIFT_TO_SOIL_ID, "");
        edt_list_from_hard_man_boulder.setText(liftToSoil);


        edt_lift_to_hard_man_boulder.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1 = 0;
                double value2 = 0;
                String v1 = edt_list_from_hard_man_boulder.getText().toString();
                String v2 = edt_lift_to_hard_man_boulder.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }

                double to = value1;
                if (value1 == 0){
                    to = 1;
                }

                if (new InputFilterMinMax().isInRange(to, 12, value2)) {
                    if (value2 > value1) {
                        edt_height_hard_man_boulder.setText(String.valueOf(value2 - value1));
                    } else {
                        UIToastMessage.show(Hard_Man_Boulder_Activity.this, "lift to value must be greater than Lift From");
                    }

                } else {
                    UIToastMessage.show(Hard_Man_Boulder_Activity.this, "lift to value must be in between "+ value1+", 12");
                }

            }
        });

        edt_diameter_hard_man_boulder.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1 = 0;
                double value2 = 0;
                double value3 = 0;
                String v1 = edt_list_from_hard_man_boulder.getText().toString();
                String v2 = edt_lift_to_hard_man_boulder.getText().toString();
                String v3 = edt_diameter_hard_man_boulder.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
                if (!v3.equalsIgnoreCase("")) {
                    value3 = Double.parseDouble(v3);
                }

                double height = Math.round(value2 - value1)/100.0;
                double qty = Math.round(0.785 * (value3 * value3) * (value2 - value1))/100.0;
                edt_height_hard_man_boulder.setText(String.valueOf(height));
                edt_qty_hard_man_boulder.setText(String.valueOf(qty));
            }
        });


        btn_submit_HManBoulder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Hard_man_Boulder_Save_Service();
            }
        });
    }

    private void setSoilDetail(String soilData) {
        btn_submit_HManBoulder.setVisibility(View.INVISIBLE);
        try {
            JSONObject soilJSON = new JSONObject(soilData);
            String liftFrom = soilJSON.getString("str_list_from");
            String liftTo = soilJSON.getString("str_lift_to");
            String diameter = soilJSON.getString("str_diameter");
            String height = soilJSON.getString("str_height");
            String qty = soilJSON.getString("str_qty");

            edt_list_from_hard_man_boulder.setText(liftFrom);
            edt_lift_to_hard_man_boulder.setText(liftTo);
            edt_diameter_hard_man_boulder.setText(diameter);
            edt_height_hard_man_boulder.setText(height);
            edt_qty_hard_man_boulder.setText(qty);

            String img1URL = soilJSON.getString("img1Url");
            if (!img1URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img1URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_hard_man_boulder);
            }

            String img2URL = soilJSON.getString("img2Url");
            if (!img2URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img2URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_hard_man_boulder_1);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void takeImage0FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (type.equalsIgnoreCase("0")) {

                if (photoFile.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                           /* Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_hard_man_boulder.getWidth(), farmers_photo_hard_man_boulder.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_hard_man_boulder);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    uploadImage0OnServer(imagePath);
                }
            }
        }
        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                           /* Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_hard_man_boulder_1.getWidth(), farmers_photo_hard_man_boulder_1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_hard_man_boulder_1);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    uploadImage1OnServer(imagePath);
                }
            }
        }

    }

    private void uploadImage0OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage1OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    // save
    private void Hard_man_Boulder_Save_Service() {

        str_list_from_hard_man_boulder = edt_list_from_hard_man_boulder.getText().toString().trim();
        str_lift_to_hard_man_boulder = edt_lift_to_hard_man_boulder.getText().toString().trim();
        str_diameter_hard_man_boulder = edt_diameter_hard_man_boulder.getText().toString().trim();
        str_height_hard_man_boulder = edt_height_hard_man_boulder.getText().toString().trim();
        str_qty_hard_man_boulder = edt_qty_hard_man_boulder.getText().toString().trim();
        str_farmer_name = txt_farmer_name.getText().toString().trim();

        float fromValue = Float.valueOf(str_list_from_hard_man_boulder);
        if (fromValue == 0.0){
            fromValue = 1;
        }

        if (str_list_from_hard_man_boulder.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input lift from soil", Toast.LENGTH_SHORT).show();
        } else if (str_lift_to_hard_man_boulder.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input lift to soil", Toast.LENGTH_SHORT).show();
        } else if (!new InputFilterMinMax().isInRange(fromValue, 12, Double.valueOf(str_lift_to_hard_man_boulder))) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "lift to value must be in range of "+fromValue+" to 12", Toast.LENGTH_SHORT).show();
        } else if (str_diameter_hard_man_boulder.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input Diameter", Toast.LENGTH_SHORT).show();
        } else if (str_height_hard_man_boulder.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input Height", Toast.LENGTH_SHORT).show();
        } else if (str_qty_hard_man_boulder.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input qty", Toast.LENGTH_SHORT).show();
        } else if (str_farmer_name.isEmpty()) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input farmer name", Toast.LENGTH_SHORT).show();
        } else if (photoFile == null) {
            Toast.makeText(Hard_Man_Boulder_Activity.this, "Input Hard Man Boulder photo", Toast.LENGTH_SHORT).show();
        } else {

            soil_lavel++;
            JSONObject param = new JSONObject();
            try {
                param.put("farmer_reg_id", Integer.valueOf(preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID)));
                param.put("soil_id", Integer.valueOf(soil_id));
                param.put("soil_name", soilName);
                param.put("stepID", soil_lavel);
                param.put("str_lift_to_hard_man_boulder", str_lift_to_hard_man_boulder);
                param.put("str_list_from_hard_man_boulder", str_list_from_hard_man_boulder);
                param.put("str_height_hard_man_boulder", str_height_hard_man_boulder);
                param.put("str_diameter_hard_man_boulder", str_diameter_hard_man_boulder);
                param.put("str_qty_hard_man_boulder", str_qty_hard_man_boulder);
                param.put("str_farmer_name", str_farmer_name);
                param.put("img1Url", image1URL);
                param.put("img2Url", image2URL);
                param.put("lat", lat);
                param.put("lang", lang);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.soil_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                //save1
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        AppSettings.getInstance().setValue(Hard_Man_Boulder_Activity.this, ApConstants.LIFT_TO_SOIL_ID, edt_lift_to_hard_man_boulder.getText().toString().trim());
                        AppSettings.getInstance().setIntValue(Hard_Man_Boulder_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                        finish();
                    } else {
                        soil_lavel--;
                        AppSettings.getInstance().setIntValue(Hard_Man_Boulder_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                    }
                }


                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image1URL = data.getString("file_url");
                        if (!image1URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image1URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_hard_man_boulder.getWidth(), farmers_photo_hard_man_boulder.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_hard_man_boulder);
                        }
                    } else {
                        UIToastMessage.show(Hard_Man_Boulder_Activity.this, jsonObject.getString("response"));
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image2URL = data.getString("file_url");
                        if (!image2URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image2URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_hard_man_boulder_1.getWidth(), farmers_photo_hard_man_boulder_1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_hard_man_boulder_1);
                        }
                    } else {
                        UIToastMessage.show(Hard_Man_Boulder_Activity.this, jsonObject.getString("response"));
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
