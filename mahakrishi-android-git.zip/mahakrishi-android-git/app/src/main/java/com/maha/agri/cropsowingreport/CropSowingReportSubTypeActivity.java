package com.maha.agri.cropsowingreport;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.maha.agri.R;

public class CropSowingReportSubTypeActivity extends AppCompatActivity {
    private Button dept_consolidated_report_btn,dept_farmer_report_btn;
    private String current_week="",last_week="",village_name="";
    private int crop_type_id = 0 ,horti_type_id= 0 ,season_id = 0,divison_id = 0,district_id = 0, taluka_id = 0, sajja_id = 0,village_id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sowing_report_sub_type);
        getSupportActionBar().setTitle("Crop Sowing Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        dept_consolidated_report_btn = (Button)findViewById(R.id.dept_consolidated_report_btn);
        dept_farmer_report_btn = (Button)findViewById(R.id.dept_farmer_report_btn);

        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_id = intent.getIntExtra("sajja_id",0);
        village_id = intent.getIntExtra("village_id",0);
        village_name = intent.getStringExtra("village_name");
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        current_week = intent.getStringExtra("current_week");
        last_week = intent.getStringExtra("last_week");


        dept_consolidated_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dept_consolidated_report_btn = new Intent(CropSowingReportSubTypeActivity.this, ConsolidatedReportActivity.class);
                dept_consolidated_report_btn.putExtra("divison_id",divison_id);
                dept_consolidated_report_btn.putExtra("district_id",district_id);
                dept_consolidated_report_btn.putExtra("taluka_id",taluka_id);
                dept_consolidated_report_btn.putExtra("sajja_id",sajja_id);
                dept_consolidated_report_btn.putExtra("village_id",village_id);
                dept_consolidated_report_btn.putExtra("season_id",season_id);
                dept_consolidated_report_btn.putExtra("crop_type_id",crop_type_id);
                dept_consolidated_report_btn.putExtra("horti_type_id",horti_type_id);
                dept_consolidated_report_btn.putExtra("current_week",current_week);
                dept_consolidated_report_btn.putExtra("last_week",last_week);
                startActivity(dept_consolidated_report_btn);
            }
        });

        dept_farmer_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dept_farmer_report_btn = new Intent(CropSowingReportSubTypeActivity.this, FarmerReportActivity.class);
                dept_farmer_report_btn.putExtra("divison_id",divison_id);
                dept_farmer_report_btn.putExtra("district_id",district_id);
                dept_farmer_report_btn.putExtra("taluka_id",taluka_id);
                dept_farmer_report_btn.putExtra("sajja_id",sajja_id);
                dept_farmer_report_btn.putExtra("season_id",season_id);
                dept_farmer_report_btn.putExtra("village_id",village_id);
                dept_farmer_report_btn.putExtra("village_name",village_name);
                dept_farmer_report_btn.putExtra("crop_type_id",crop_type_id);
                dept_farmer_report_btn.putExtra("horti_type_id",horti_type_id);
                dept_farmer_report_btn.putExtra("current_week",current_week);
                dept_farmer_report_btn.putExtra("last_week",last_week);
                startActivity(dept_farmer_report_btn);
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
