package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.spot_verification.DripFormActivity;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBRecordingBfflyForm3Activity extends AppCompatActivity implements ApiCallbackCode {
    private LinearLayout mb_bffly3_sap_ll,mb_bffly3_graft_ll;
    private EditText mb_bffly3_total_sap,mb_bffly3_total_graft;
    private TextView mb_bffly3_subsidy_year1;
    private RadioGroup mb_bffly3_irrigation_rg;
    private RadioButton mb_bffly3_irrigation_yes,mb_bffly3_irrigation_no;
    private Button mb_bffly3_next;
    private String type="0",irrigation="0",button="0",farmer_id="",district_id="",taluka_id="",village_id="";
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_recording_bffly_form3);
        getSupportActionBar().setTitle("MB Recording BFFLY Form 3");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBRecordingBfflyForm3Activity.this);
        Intent intent = getIntent();
        type = intent.getStringExtra("type_sap_graft");
        farmer_id = intent.getStringExtra("farmer_id");
        district_id = intent.getStringExtra("district_id");
        taluka_id = intent.getStringExtra("taluka_id");
        village_id = intent.getStringExtra("village_id");

        ids();
        functions();
    }

    private void ids(){
        mb_bffly3_sap_ll = (LinearLayout) findViewById(R.id.mb_bffly3_sap_ll);
        mb_bffly3_graft_ll = (LinearLayout) findViewById(R.id.mb_bffly3_graft_ll);
        mb_bffly3_total_sap = (EditText) findViewById(R.id.mb_bffly3_total_sap);
        mb_bffly3_total_graft = (EditText) findViewById(R.id.mb_bffly3_total_graft);
        mb_bffly3_subsidy_year1 = (TextView) findViewById(R.id.mb_bffly3_subsidy_year1);
        mb_bffly3_irrigation_rg = (RadioGroup) findViewById(R.id.mb_bffly3_irrigation_rg);
        mb_bffly3_irrigation_yes = (RadioButton) findViewById(R.id.mb_bffly3_irrigation_yes);
        mb_bffly3_irrigation_no = (RadioButton) findViewById(R.id.mb_bffly3_irrigation_no);
        mb_bffly3_next = (Button) findViewById(R.id.mb_bffly3_next);
    }

    private void functions(){

        if(type.equalsIgnoreCase("1")){
            mb_bffly3_sap_ll.setVisibility(View.VISIBLE);
        }else if(type.equalsIgnoreCase("2")){
            mb_bffly3_graft_ll.setVisibility(View.VISIBLE);
        }else{
            mb_bffly3_graft_ll.setVisibility(View.GONE);
            mb_bffly3_sap_ll.setVisibility(View.GONE);
        }

        mb_bffly3_irrigation_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_bffly3_irrigation_yes:
                        mb_bffly3_irrigation_yes.setChecked(true);
                        mb_bffly3_next.setText("Next");
                        irrigation = "1";
                        break;

                    case R.id.mb_bffly3_irrigation_no:
                        mb_bffly3_irrigation_no.setChecked(true);
                        mb_bffly3_next.setText("Submit");
                        irrigation = "2";
                        break;
                }
            }
        });

        mb_bffly3_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(irrigation.equalsIgnoreCase("1")){
                    Intent intent = new Intent(MBRecordingBfflyForm3Activity.this, DripFormActivity.class);
                    intent.putExtra("button",button);
                    startActivity(intent);
                }else {
                    mb_bffly_form3_save_service();
                }
            }
        });
    }

    private void mb_bffly_form3_save_service(){
        if(irrigation.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Is irrigation system installed?", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("total_sap", mb_bffly3_total_sap.getText().toString().trim());
                param.put("total_graft", mb_bffly3_total_graft.getText().toString().trim());
                param.put("irrigration_rg", irrigation);
                param.put("subsidy_year1", "0");
                param.put("is_completed", "1");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mbrecording_bffly_form3_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Recording by BFFLY Form 3");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                   finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }
            }catch (Exception e){
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
