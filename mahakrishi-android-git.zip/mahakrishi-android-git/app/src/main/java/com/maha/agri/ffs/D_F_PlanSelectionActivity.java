package com.maha.agri.ffs;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.ffs.host_gusest_farmer.D_F_HostFarmerRagistrationActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_PlanSelectionActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private PreferenceManager preferenceManager;
    private String schemeID;
    private String reg_type;

    private TextView districtNameTV;
    private TextView subDivNameTV;
    private TextView talNameTV;

    private TextView villageNameTV;
    private int villageID;
    private JSONArray village_list = new JSONArray();

    private TextView planTextView;
    private TextView planNameTextView;
    private String plan_name;
    private int planID;
    private JSONArray plan_list = new JSONArray();

    private Button submitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_plan_selection);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(D_F_PlanSelectionActivity.this);

        init();
        defaultConfig();
    }

    private void init() {

        districtNameTV = (TextView) findViewById(R.id.districtNameTV);
        subDivNameTV = (TextView) findViewById(R.id.subDivNameTV);
        talNameTV = (TextView) findViewById(R.id.talNameTV);
        villageNameTV = (TextView) findViewById(R.id.villageNameTV);
        planTextView = (TextView) findViewById(R.id.planTextView);
        planNameTextView = (TextView) findViewById(R.id.planNameTextView);
        submitBtn = (Button) findViewById(R.id.submitBtn);
    }

    private void defaultConfig() {

        villageNameTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(village_list, 1, "Select Village", "village_name", "village_id", D_F_PlanSelectionActivity.this, D_F_PlanSelectionActivity.this);
            }
        });

        planNameTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (villageID == 0) {
                    UIToastMessage.show(D_F_PlanSelectionActivity.this, "Select Village");
                } else {
                    if (plan_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(plan_list, 3, "Select Plan", "plan_name", "id", D_F_PlanSelectionActivity.this, D_F_PlanSelectionActivity.this);
                    } else {
                        getPlanList(villageID);
                    }
                }
            }
        });


        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (villageID == 0) {
                    UIToastMessage.show(D_F_PlanSelectionActivity.this, "Select village");
                } else if (planID == 0) {
                    UIToastMessage.show(D_F_PlanSelectionActivity.this, "Select Plan");
                } else {
                    AppSettings.getInstance().setValue(D_F_PlanSelectionActivity.this, ApConstants.kVILLAGE_ID_DEMO_FFS, String.valueOf(villageID));
                    AppSettings.getInstance().setValue(D_F_PlanSelectionActivity.this, ApConstants.kPLAN_ID_DEMO_FFS, String.valueOf(planID));

                    String planData = "";
                    String totalFarmerArea = "";
                    String planArea = "";
                    String rabiPlanArea = "";
                    String kharifPlanArea = "";
                    try {
                        if (plan_list.length()>0){
                            for (int i = 0; i<plan_list.length();i++){
                                JSONObject planJSON = plan_list.getJSONObject(i);
                                int plan_id = planJSON.getInt("id");
                                if (plan_id == planID){
                                    planData = planJSON.toString();
                                    totalFarmerArea = planJSON.getString("total_farmer_area");
                                    planArea = planJSON.getString("total_plan_area");
                                    rabiPlanArea = planJSON.getString("rabi_plan_area");
                                    kharifPlanArea = planJSON.getString("kharif_plan_area");
                                }
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String area = "0";
                    if ( planArea.equalsIgnoreCase("")){
                        area = String.valueOf(Integer.parseInt(kharifPlanArea) + Integer.parseInt(rabiPlanArea)) ;
                    }else {
                        area = planArea;
                    }

                    if (Integer.parseInt(totalFarmerArea)<Integer.parseInt(area)){
                        Intent intent = new Intent(D_F_PlanSelectionActivity.this, D_F_HostFarmerRagistrationActivity.class);
                        intent.putExtra("totalPlanArea", Integer.valueOf(area));
                        intent.putExtra("totalFarmerArea",Integer.valueOf(totalFarmerArea));
                        intent.putExtra("plan_id",planID);
                        intent.putExtra("plan_data",planData);
                        intent.putExtra("actionType","selectPlan");
                        startActivity(intent);
                    }else {
                        Intent intent = new Intent(D_F_PlanSelectionActivity.this, D_F_ScheduleListActivity.class);
                        intent.putExtra("cropDetail",planData);
                        startActivity(intent);
                    }
                }
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        schemeID = preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_ID);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        String data = AppSettings.getInstance().getValue(D_F_PlanSelectionActivity.this, ApConstants.kLOGIN_DATA, "");
        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
            getSupportActionBar().setTitle("Demonstration observations");
            planTextView.setText("Select demonstration plan");
        }else {
            getSupportActionBar().setTitle("FFS observations");
            planTextView.setText("Select ffs plan");
        }

        get_district_taluka();
    }


    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("get_destrict_taluka=" + responseCall.request().toString());
        DebugLog.getInstance().d("get_destrict_taluka=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            villageID = Integer.parseInt(s1);
            villageNameTV.setText(s);
            // farmerNameTV.setText("");
            planNameTextView.setText("");
            if (villageID > 0) {
                getPlanList(villageID);
            }
        }

        if (i == 3) {
            planID = Integer.parseInt(s1);
            planNameTextView.setText(s);
        }

    }


    private void getPlanList(int villageID) {

        try {
            JSONObject jsonObject = new JSONObject();

            jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("village_id", villageID);
            jsonObject.put("reg_type", reg_type);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.planListRequest(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {

                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {

                        JSONArray district_List = jsonObject.getJSONArray("data");
                        for (int j = 0; j < district_List.length(); j++) {
                            JSONObject district_json_object = district_List.getJSONObject(j);

                            String district_name = district_json_object.getString("district_name");
                            districtNameTV.setText(district_name);

                            String subDiv_name = district_json_object.getString("subdivision_name");
                            subDivNameTV.setText(subDiv_name);

                            String taluka_name = district_json_object.getString("taluka_name");
                            talNameTV.setText(taluka_name);
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        plan_list = responseModel.getData();
                    } else {
                        plan_list = new JSONArray();
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
