package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.maha.agri.R;
import com.maha.agri.activity.TaskManagerReport.TaskManagerReportActivity;

public class TaskReportActivity extends AppCompatActivity {

    private Button self_task_report_btn,all_task_report_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_report);
        getSupportActionBar().setTitle("Task Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        self_task_report_btn = (Button) findViewById(R.id.self_task_reportbtn);
        //all_task_report_btn = (Button) findViewById(R.id.all_task_reportbtn);
        self_task_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(TaskReportActivity.this, TaskManagerReportActivity.class));
            }
        });

        /*all_task_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UIToastMessage.show(TaskReportActivity.this,"Comming Soon");

            }
        });*/
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
