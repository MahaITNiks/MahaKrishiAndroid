package com.maha.agri.activity.TaskManagerReport;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class TaskManagerReportActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView task_manager_rv;
    private JSONArray task_manager_types_list;
    private int[] task_manager_backy = {R.drawable.dash_assigned_villages,R.drawable.dash_attedance_approved};
    PreferenceManager preferenceManager;
    SharedPref sharedPref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_manager_report);
        getSupportActionBar().setTitle("Task Manager");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(TaskManagerReportActivity.this);
        sharedPref = new SharedPref(TaskManagerReportActivity.this);
        IdCalling();
        default_Config();
        getTaskManagerListWebservie();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        task_manager_rv = (RecyclerView)findViewById(R.id.task_manager_rv);
        task_manager_rv.setLayoutManager(new LinearLayoutManager(this));

    }

    private void default_Config() {

    }

    private void getTaskManagerListWebservie() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.taskManagerReportTypes(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);

                        if (responseModel.isStatus()) {
                            task_manager_types_list = jsonObject.getJSONArray("data");
                            task_manager_rv.setAdapter(new TaskManagerReportAdapter(preferenceManager,task_manager_types_list,task_manager_backy,this));
                        }

                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
