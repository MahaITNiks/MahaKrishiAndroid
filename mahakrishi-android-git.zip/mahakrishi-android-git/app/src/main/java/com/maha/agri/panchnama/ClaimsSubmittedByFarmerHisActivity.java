package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ClaimsSubmittedByFarmerHisActivity extends AppCompatActivity implements ApiCallbackCode {
    private Spinner sp_claims;
    private RecyclerView claims_rv;
    ArrayList<String> ClaimsName;
    HashMap<Integer,String> claims_map = new HashMap<Integer, String>();
    private String claimsname;
    private String claimsID;
    private JSONArray claimsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claims_submitted_by_farmer_his);
        getSupportActionBar().setTitle("Claims Submmitted by farmer");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        init();
        default_confiq();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    private void init(){

        sp_claims = (Spinner) findViewById(R.id.claims_submitted_by_farmer_submit);
        ClaimsName = new ArrayList<>();
        PunchnamaClaimWebservice();
        sp_claims.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                claimsID = claims_map.get(sp_claims.getSelectedItemPosition());
                PunchnamaClaimListWebservice();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        claims_rv = (RecyclerView)findViewById(R.id.claims_submmitted_by_farmer_rv);
        claims_rv.setLayoutManager(new LinearLayoutManager(this));


    }

    private void default_confiq(){

        claims_rv.addOnItemTouchListener(new DepartmentPunchnamaAdapter.RecyclerTouchListener(this, claims_rv, new DepartmentPunchnamaAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Intent intent = new Intent(ClaimsSubmittedByFarmerHisActivity.this, ClaimsSubmittedByFarmerDetailsHistoryAct.class);
                intent.putExtra("punchanam_details",claimsList.toString());
                intent.putExtra("position",position);
                startActivity(intent);

            }



            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }

    private void PunchnamaClaimWebservice(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_punchnama_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void PunchnamaClaimListWebservice(){
        JSONObject param = new JSONObject();
        try {
            param.put("panchnama_type_id",claimsID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_punchnama_claims_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            claimsList = jsonObject.getJSONArray("data");
                            final int numberOfItemsInResp = claimsList.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject claims_json_object = claimsList.getJSONObject(j);
                                claimsID = claims_json_object.getString("id");
                                claimsname = claims_json_object.getString("name");
                                ClaimsName.add(claimsname);
                                claims_map.put(j, claimsID);
                            }

                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(ClaimsSubmittedByFarmerHisActivity.this, android.R.layout.simple_spinner_dropdown_item, ClaimsName);

                        sp_claims.setAdapter(adapter);
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            claimsList = jsonObject.getJSONArray("data");
                            claims_rv.setAdapter(new DepartmentPunchnamaAdapter(claimsList,this));
                        }

                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}

