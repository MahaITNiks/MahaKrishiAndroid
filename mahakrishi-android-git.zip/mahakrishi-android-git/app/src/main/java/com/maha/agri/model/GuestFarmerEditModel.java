/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class GuestFarmerEditModel {

    private int guest_farmer_id;
    private int plot_id;
    private String plot_code;
    private String first_name;
    private String middle_name;
    private String last_name;
    private int gender;
    private String age;
    private String mobile;
    private int social_category_id;
    private String social_category_name;
    private int physically_challenged;
    private JSONObject jsonObject;

    public GuestFarmerEditModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getGuest_farmer_id() {
        guest_farmer_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "guest_farmer_id");
        return guest_farmer_id;
    }

    public int getPlot_id() {
        plot_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "plot_id");
        return plot_id;
    }

    public String getPlot_code() {
        plot_code = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "plot_code");
        return plot_code;
    }

    public String getFirst_name() {
        first_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "first_name");
        return first_name;
    }

    public String getMiddle_name() {
        middle_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "middle_name");
        return middle_name;
    }

    public String getLast_name() {
        last_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "last_name");
        return last_name;
    }

    public int getGender() {
        gender = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "gender");
        return gender;
    }

    public String getAge() {
        age = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "age");
        return age;
    }

    public String getMobile() {
        mobile = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "mobile");
        return mobile;
    }

    public int getSocial_category_id() {
        social_category_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "social_category_id");
        return social_category_id;
    }

    public String getSocial_category_name() {
        social_category_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "social_category_name");
        return social_category_name;
    }

    public int getPhysically_challenged() {
        physically_challenged = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "physically_challenged");
        return physically_challenged;
    }




}
