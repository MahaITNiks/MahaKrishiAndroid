package com.maha.agri.dept_cropsap;

import android.content.Context;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class AddPestAdapter extends RecyclerView.Adapter<AddPestAdapter.MyViewHolder> {
    private JSONArray add_more_list;
    private JSONObject jsonObject ;
    private Context context;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView pest_id_txt_view,pest_name_txt_view;
        private ImageView pest_row_delete_iv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.pest_id_txt_view = itemView.findViewById(R.id.pest_id_txt_view);
            this.pest_name_txt_view = itemView.findViewById(R.id.pest_name_txt_view);
            this.pest_row_delete_iv = itemView.findViewById(R.id.pest_row_delete_iv);

        }
    }

    public AddPestAdapter(JSONArray add_more_list,Context context) {
        this.add_more_list = add_more_list;
        this.context = context;

    }

    @Override
    public AddPestAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.add_pest_list, parent, false);

        AddPestAdapter.MyViewHolder myViewHolder = new AddPestAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final AddPestAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = add_more_list.getJSONObject(listPosition);
            holder.pest_id_txt_view.setText(jsonObject.getString("pest_id"));
            holder.pest_name_txt_view.setText(jsonObject.getString("pest_name"));
            holder.pest_row_delete_iv.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View view) {
                    add_more_list.remove(listPosition);

                    /*String s= new String();
                    try {
                        s=jsonObject.getString("pest_name");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    SoyabeanCrop access_object= new SoyabeanCrop();
                    String finalS = s;
                    access_object.filled_pest.removeIf(name -> name.equals(finalS));
                    System.out.print("AFTER REMOVE"+ access_object.filled_pest);*/

                    notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private AddPestAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final AddPestAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }
                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
