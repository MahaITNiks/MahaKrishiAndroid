package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;

import java.util.ArrayList;

public class AttedanceDashboardAdapter extends RecyclerView.Adapter<AttedanceDashboardAdapter.MyViewHolder> {

//    private int[] attendanceDashboardImage,attendanceDashboardBackground;
//    private String[] attendanceDashboardTitle;

    ArrayList<String> attendanceDashboardTitle = new ArrayList<String>();
    ArrayList<Integer> attendanceDashboardImage = new ArrayList<Integer>();
    ArrayList<Integer> attendanceDashboardBackground = new ArrayList<Integer>();
    private Context context;
    private PreferenceManager preferenceManager;


    public static class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView attendanceDashboardSingleIv,attendanceDashboardBackSingleIv;
        private TextView attedanceDashboardSingleTv;


        public MyViewHolder(View itemView){
            super(itemView);
            attendanceDashboardBackSingleIv = itemView.findViewById(R.id.dash_attendance_back_single_image_view);
            attendanceDashboardSingleIv = itemView.findViewById(R.id.dash_attendance_single_image_view);
            attedanceDashboardSingleTv = itemView.findViewById(R.id.dash_attendance_single_text_view);
        }
    }

    /*public AttedanceDashboardAdapter(int[] attendanceDashboardBackground,int[] attendanceDashboardImage, String[] attendanceDashboardTitle,PreferenceManager preferenceManager, Context context) {
        this.attendanceDashboardBackground = attendanceDashboardBackground;
        this.attendanceDashboardImage = attendanceDashboardImage;
        this.attendanceDashboardTitle = attendanceDashboardTitle;
        this.preferenceManager = preferenceManager;
        this.context = context;
    }*/

    public AttedanceDashboardAdapter(ArrayList<String> attendanceDashboardTitle, ArrayList<Integer> attendanceDashboardImage, ArrayList<Integer> attendanceDashboardBackground, Context context, PreferenceManager preferenceManager) {
        this.attendanceDashboardTitle = attendanceDashboardTitle;
        this.attendanceDashboardImage = attendanceDashboardImage;
        this.attendanceDashboardBackground = attendanceDashboardBackground;
        this.context = context;
        this.preferenceManager = preferenceManager;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.attendance_dashboard_single_item,viewGroup,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

        myViewHolder.attendanceDashboardBackSingleIv.setImageResource(attendanceDashboardBackground.get(i));
        myViewHolder.attendanceDashboardSingleIv.setImageResource(attendanceDashboardImage.get(i));
        myViewHolder.attedanceDashboardSingleTv.setText(attendanceDashboardTitle.get(i));

        if (preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("1")) {

            if(i==4){

                myViewHolder.attendanceDashboardBackSingleIv.setVisibility(View.GONE);
                myViewHolder.attendanceDashboardSingleIv.setVisibility(View.GONE);
                myViewHolder.attedanceDashboardSingleTv.setVisibility(View.GONE);

            }
           /* attendanceDashboardBackground.remove(4);
            attendanceDashboardImage.remove(4);
            attendanceDashboardTitle.remove(4);*/



        }
    }

    @Override
    public int getItemCount() {
        return attendanceDashboardTitle.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private AttedanceDashboardAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final AttedanceDashboardAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }


}
