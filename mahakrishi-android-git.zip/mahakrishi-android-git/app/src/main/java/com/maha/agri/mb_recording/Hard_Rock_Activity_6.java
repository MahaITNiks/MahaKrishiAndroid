package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.util.ApConstants;

import in.co.appinventor.services_api.settings.AppSettings;

public class Hard_Rock_Activity_6 extends AppCompatActivity {
  Button btn_submit_Hard_Rock_6;
  EditText edt_list_from_Hard_rock_6,edt_lift_to_Hard_rock_6,edt_diameter_Hard_rock_6,edt_height_Hard_rock_6,edt_qty_Hard_rock_6;
  String lift_to_Hard_rock_5;
    String str_farmer_name;
    TextView txt_farmer_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard_rock_6);
        init();
        Intent intent = getIntent();
        lift_to_Hard_rock_5 = intent.getStringExtra("lift_to_Hard_rock_5");
        edt_list_from_Hard_rock_6.setText(lift_to_Hard_rock_5);
    }

    private void init() {
        btn_submit_Hard_Rock_6 = (Button)findViewById(R.id.btn_submit_Hard_Rock_6);

        edt_list_from_Hard_rock_6 = (EditText)findViewById(R.id.edt_list_from_Hard_rock_6);
        edt_lift_to_Hard_rock_6 = (EditText)findViewById(R.id.edt_lift_to_Hard_rock_6);
        edt_diameter_Hard_rock_6 = (EditText)findViewById(R.id.edt_diameter_Hard_rock_6);
        edt_height_Hard_rock_6 = (EditText)findViewById(R.id.edt_height_Hard_rock_6);
        edt_qty_Hard_rock_6 = (EditText)findViewById(R.id.edt_qty_Hard_rock_6);

        txt_farmer_name = (TextView)findViewById(R.id.txt_farmer_name);

        str_farmer_name = AppSettings.getInstance().getValue(Hard_Rock_Activity_6.this, ApConstants.MB_FARMER_NAME,"");
        txt_farmer_name.setText(str_farmer_name);

        edt_lift_to_Hard_rock_6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1= 0;
                double value2 =0;
                String v1=edt_list_from_Hard_rock_6.getText().toString();
                String v2=edt_lift_to_Hard_rock_6.getText().toString();
                if (!v1.equalsIgnoreCase("")){
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")){
                    value2 = Double.parseDouble(v2);
                }
                edt_height_Hard_rock_6.setText(String.valueOf(value2-value1));
            }
        });

        edt_diameter_Hard_rock_6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1=0;
                double value2=0;
                double value3=0;
                String v1=edt_list_from_Hard_rock_6.getText().toString();
                String v2=edt_lift_to_Hard_rock_6.getText().toString();
                String v3=edt_diameter_Hard_rock_6.getText().toString();
                if (!v1.equalsIgnoreCase("")){
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")){
                    value2 = Double.parseDouble(v2);
                }
                if (!v3.equalsIgnoreCase("")){
                    value3 = Double.parseDouble(v3);
                }
                edt_height_Hard_rock_6.setText(String.valueOf(value2-value1));
                edt_qty_Hard_rock_6.setText(String.valueOf(0.785*(value3*value3)*(value2-value1)));
            }
        });


        btn_submit_Hard_Rock_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Hard_Rock_Activity_6.this,Plain_Cement_Concrete.class);
                startActivity(intent);
            }
        });
    }
}
