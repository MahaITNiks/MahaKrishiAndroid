package com.maha.agri.activity.common;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GetOfflineData extends AppCompatActivity implements ApiCallbackCode {

    private static Context mContext;
    private DBHandler dbHandler;
    private JSONArray offline_task_type_json_array_list, offline_scheme_list_json_array, offline_scheme_activity_json_array, offline_scheme_work_json_array, offline_scheme_work_details_json_aray;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public GetOfflineData() {
    }

    public GetOfflineData(Context context) {
        mContext = context;
        dbHandler = new DBHandler(mContext);
        Log.i("testttt", "GetOfflineData");
    }


    public void task_type() {

        Log.i("testttt", "task_type()");

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(mContext, APIServices.API_URL, "", ApConstants.kMSG, false);

        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.task_manager_type_offline(requestBody);
        DebugLog.getInstance().d("param=" + responseCall.request().toString());
        DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
        Log.i("testttt", "task_type() after");
    }

    public void scheme_list() {

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(mContext, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.task_manager_scheme_list_offline(requestBody);
        DebugLog.getInstance().d("param=" + responseCall.request().toString());
        DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    public void scheme_activity() {

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(mContext, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeListTypes(requestBody);
        DebugLog.getInstance().d("param=" + responseCall.request().toString());
        DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    public void scheme_work() {

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(mContext, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.task_manager_scheme_work_offline(requestBody);
        DebugLog.getInstance().d("param=" + responseCall.request().toString());
        DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                //For Task Type

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Log.i("testttt", "on response 1");
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            offline_task_type_json_array_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j < offline_task_type_json_array_list.length(); j++) {
                                JSONObject task_type_json_object = offline_task_type_json_array_list.getJSONObject(j);

                                String id = task_type_json_object.getString("id");
                                String name = task_type_json_object.getString("name");
                                String is_active = task_type_json_object.getString("is_active");

                                if (dbHandler.isItemPresent(String.valueOf(j+1), DBHandler.TABLE_TASK_TYPE)){
                                    dbHandler.updateTaskType(id, name, is_active);
                                }else {
                                    dbHandler.insertTaskType( name, is_active);
                                }
                            }
                        }

                        scheme_list();
                    }

                }

                //For Scheme List

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            offline_scheme_list_json_array = jsonObject.getJSONArray("data");
                            for (int j = 0; j < offline_scheme_list_json_array.length(); j++) {
                                JSONObject scheme_list_json_object = offline_scheme_list_json_array.getJSONObject(j);
                                String id = scheme_list_json_object.getString("id");
                                String typeId = scheme_list_json_object.getString("typeId");
                                String name = scheme_list_json_object.getString("name");
                                String is_active = scheme_list_json_object.getString("is_active");
                                String sr_no = scheme_list_json_object.getString("sr_no");

                                if (dbHandler.isItemPresent(String.valueOf(j+1),DBHandler.TABLE_SCHEME_LIST)){
                                    dbHandler.updateSchemeList(id, typeId, name, is_active, sr_no);
                                }else {
                                    dbHandler.insertSchemeList( typeId, name, is_active, sr_no);
                                }
                            }
                        }
                        scheme_activity();
                    }

                }

                //For Scheme Activity

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            offline_scheme_activity_json_array = jsonObject.getJSONArray("data");
                            for (int j = 0; j < offline_scheme_activity_json_array.length(); j++) {

                                JSONObject scheme_activity_json_object = offline_scheme_activity_json_array.getJSONObject(j);
                                String id = scheme_activity_json_object.getString("id");
                                String typeId = scheme_activity_json_object.getString("typeId");
                                String name = scheme_activity_json_object.getString("name");
                               /* String is_active = scheme_activity_json_object.getString("is_active");
                                String is_deleted = scheme_activity_json_object.getString("is_deleted");
                                String parent_id = scheme_activity_json_object.getString("parent_id");*/
                                String has_subactivity = scheme_activity_json_object.getString("has_subactivity");
                                String sr_no = scheme_activity_json_object.getString("sr_no");

                                if (dbHandler.isItemPresent(String.valueOf(j+1),DBHandler.TABLE_SCHEME_ACTIVITIES)){
                                   // dbHandler.updateSchemeActivity(id, typeId, name, is_active, is_deleted, parent_id, has_subactivity, sr_no);
                                    dbHandler.updateSchemeActivity(id, typeId, name,has_subactivity, sr_no);
                                }else {
                                  //  dbHandler.insertSchemeActivity(typeId, name, is_active, is_deleted, parent_id, has_subactivity, sr_no);
                                    dbHandler.insertSchemeActivity(typeId, name,has_subactivity, sr_no);
                                }

                            }
                        }
                        scheme_work();
                    }

                }


                //For Scheme Work

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            offline_scheme_work_json_array = jsonObject.getJSONArray("data");
                            for (int j = 0; j < offline_scheme_work_json_array.length(); j++) {
                                JSONObject work_json_object = offline_scheme_work_json_array.getJSONObject(j);

                                String id = work_json_object.getString("id");
                                String activity_id = work_json_object.getString("activity_id");
                                String details = work_json_object.getString("details");
                                String photo = work_json_object.getString("photo");
                                String farmer_name = work_json_object.getString("farmer_name");
                                String crop_name = work_json_object.getString("crop_name");
                                String area = work_json_object.getString("area");
                                String site_location = work_json_object.getString("site_location");
                                String no_of_participants = work_json_object.getString("no_of_participants");

                                if (dbHandler.isItemPresent(String.valueOf(j+1),DBHandler.TABLE_SCHEME_WORK)){
                                    dbHandler.updateSchemeWork(id, activity_id, details, photo, farmer_name, crop_name, area, site_location, no_of_participants);
                                }else {
                                    dbHandler.insertSchemeWork( activity_id, details, photo, farmer_name, crop_name, area, site_location, no_of_participants);
                                }

                            }
                        }

                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}