package com.maha.agri.history;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.dept_cropsap.DepartmentCropSapVillageList;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DeptCropSapHistoryActivity extends AppCompatActivity implements ApiCallbackCode {
    private Button cases_recorded_by_farmer,cases_recorded_by_dept;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dept_crop_sap_history);
        getSupportActionBar().setTitle("CROPSAP History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DeptCropSapHistoryActivity.this);
        sharedPref = new SharedPref(DeptCropSapHistoryActivity.this);
        init();
        default_confiq();
        getFarmerCropsapCount();
        getDeptCropsapCount();


    }

    private void init(){
        cases_recorded_by_farmer = (Button)findViewById(R.id.cases_recorded_by_farmer);
        cases_recorded_by_dept = (Button)findViewById(R.id.cases_recorded_by_dept);
    }

    private void default_confiq(){


    }

    private void getFarmerCropsapCount() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_login_farmer_cropsap_history_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }



    private void getDeptCropsapCount() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_cropsap_history_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            cases_recorded_by_farmer.setVisibility(View.VISIBLE);
                            String total_cropsap_count = jsonObject.getString("total_cropsap");
                            String cropsap_data = jsonObject.getString("data");
                            preferenceManager.putPreferenceValues(Preference_Constant.FARMER_VILLAGE_LIST_WITH_CROPSAP_COUNT,cropsap_data);
                            cases_recorded_by_farmer.setText("Cases Recorded by Farmer" + " (" + total_cropsap_count + ")");
                            cases_recorded_by_farmer.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent cases_recorded_by_farmer  = new Intent(DeptCropSapHistoryActivity.this, DepartmentCropSapVillageList.class);
                                    startActivity(cases_recorded_by_farmer);

                                }
                            });
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }


                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            cases_recorded_by_dept.setVisibility(View.VISIBLE);
                            String cropsap_count = jsonObject.getString("data");
                            cases_recorded_by_dept.setText("Self Observation Recorded" + " (" + cropsap_count + ")");
                            cases_recorded_by_dept.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent cases_recorded_by_dept  = new Intent(DeptCropSapHistoryActivity.this, DepartmentCropSapCropCountActivity.class);
                                    startActivity(cases_recorded_by_dept);
                                }
                            });

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
