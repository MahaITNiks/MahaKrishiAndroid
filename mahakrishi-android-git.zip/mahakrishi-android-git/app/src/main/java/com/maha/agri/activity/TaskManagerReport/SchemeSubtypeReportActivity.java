package com.maha.agri.activity.TaskManagerReport;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SchemeListTypeAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SchemeSubtypeReportActivity extends AppCompatActivity implements ApiCallbackCode {
    private JSONArray schemeListTypes;
    private RecyclerView scheme_List_subtypes_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_subtype_report);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SchemeSubtypeReportActivity.this);
        sharedPref = new SharedPref(SchemeSubtypeReportActivity.this);
        Intent intent = getIntent();
        String jsonArray = intent.getStringExtra("schemeList");

        try {
            JSONArray array = new JSONArray(jsonArray);
            int position = intent.getIntExtra("position",0);
            JSONObject jsonObject = array.getJSONObject(position);
            getSupportActionBar().setTitle(jsonObject.getString("name"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        init();
        default_confiq();
        getSchemeListTypesWebservice();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init(){
        scheme_List_subtypes_rv = (RecyclerView) findViewById(R.id.scheme__subtype_List_type_recyclerView);
        scheme_List_subtypes_rv.setLayoutManager(new LinearLayoutManager(this));
        scheme_List_subtypes_rv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));
    }

    private void default_confiq(){
        scheme_List_subtypes_rv.addOnItemTouchListener(new SchemeListTypeAdapter.RecyclerTouchListener(this, scheme_List_subtypes_rv, new SchemeListTypeAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
               /* if(position==0){
                    Intent intent = new Intent(SchemeSubtypeReportActivity.this,AddSchemeSubTypeDetailsActivity.class);
                    intent.putExtra("schemeList", schemeListTypes.toString());
                    intent.putExtra("position", 0);
                    startActivity(intent);
                } if(position==1){
                    Intent intent = new Intent(SchemeSubtypeReportActivity.this,AddSchemeSubTypeDetailsActivity.class);
                    intent.putExtra("schemeList", schemeListTypes.toString());
                    intent.putExtra("position", 1);
                    startActivity(intent);
                }*/

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    private void getSchemeListTypesWebservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("typeId","1");
            param.put("parentId", "8");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeListReportTypes(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                // Absent reason Response
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            schemeListTypes = jsonObject.getJSONArray("data");
                            scheme_List_subtypes_rv.setAdapter(new SchemeListSubTypeReportAdapter(this,schemeListTypes,preferenceManager));
                            //UIToastMessage.show(this, jsonObject.getString("response"));
                            }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
