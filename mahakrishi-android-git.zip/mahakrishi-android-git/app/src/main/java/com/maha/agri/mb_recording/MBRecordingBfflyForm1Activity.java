package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBRecordingBfflyForm1Activity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private TextView mb_bffly1_scheme,mb_bffly1_year,mb_bffly1_area_app,mb_bffly1_fruit_app,mb_bffly1_fruit_actual,mb_bffly1_fruit_spacing_app,
            mb_bffly1_total_subsidy_with_sap,mb_bffly1_total_subsidy_with_graft,mb_bffly1_total_subsidy_without_sap,mb_bffly1_total_subsidy_without_graft,
            mb_bffly1_per_day_labour,mb_bffly1_per_sap_rate,mb_bffly1_per_graft_rate;

    private EditText mb_bffly1_area_actual,mb_bffly1_fruit_spacing_actual;
    private Button mb_bffly1_save;
    private JSONArray fruit_list;
    private SweetAlertDialog sweetAlertDialog;
    private PreferenceManager preferenceManager;
    private String scheme="",fruit_name="",village_id="",taluka_id="",district_id="",farmer_id="";
    private int fruit_id=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_recording_bffly_form1);
        getSupportActionBar().setTitle("MB Recording BFFLY Form 1");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBRecordingBfflyForm1Activity.this);
        Intent intent = getIntent();
        scheme = intent.getStringExtra("scheme");
        village_id = intent.getStringExtra("village_id");
        district_id = intent.getStringExtra("district_id");
        taluka_id = intent.getStringExtra("taluka_id");
        farmer_id = intent.getStringExtra("farmer_id");

        ids();
        functions();
    }

    private void ids(){
        //Textview
        mb_bffly1_scheme = (TextView) findViewById(R.id.mb_bffly1_scheme);
        mb_bffly1_year = (TextView) findViewById(R.id.mb_bffly1_year);
        mb_bffly1_area_app = (TextView) findViewById(R.id.mb_bffly1_area_app);
        mb_bffly1_fruit_app = (TextView) findViewById(R.id.mb_bffly1_fruit_app);
        mb_bffly1_fruit_actual = (TextView) findViewById(R.id.mb_bffly1_fruit_actual);
        mb_bffly1_fruit_spacing_app = (TextView) findViewById(R.id.mb_bffly1_fruit_spacing_app);
        mb_bffly1_total_subsidy_with_sap = (TextView) findViewById(R.id.mb_bffly1_total_subsidy_with_sap);
        mb_bffly1_total_subsidy_with_graft = (TextView) findViewById(R.id.mb_bffly1_total_subsidy_with_graft);
        mb_bffly1_total_subsidy_without_sap = (TextView) findViewById(R.id.mb_bffly1_total_subsidy_without_sap);
        mb_bffly1_total_subsidy_without_graft = (TextView) findViewById(R.id.mb_bffly1_total_subsidy_without_graft);
        mb_bffly1_per_day_labour = (TextView) findViewById(R.id.mb_bffly1_per_day_labour);
        mb_bffly1_per_sap_rate = (TextView) findViewById(R.id.mb_bffly1_per_sap_rate);
        mb_bffly1_per_graft_rate = (TextView) findViewById(R.id.mb_bffly1_per_graft_rate);
        mb_bffly1_scheme.setText(scheme);

        //Edittext
        mb_bffly1_area_actual = (EditText) findViewById(R.id.mb_bffly1_area_actual);
        mb_bffly1_fruit_spacing_actual = (EditText) findViewById(R.id.mb_bffly1_fruit_spacing_actual);

        mb_bffly1_save = (Button) findViewById(R.id.mb_bffly1_save);

        fruit_list = new JSONArray();
        fruit_list_service();
    }

    private void functions(){
        mb_bffly1_fruit_actual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(fruit_list,1,"Select Fruit","fruit_crop_name","id",MBRecordingBfflyForm1Activity.this,MBRecordingBfflyForm1Activity.this);
            }
        });

        mb_bffly1_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_bffly_form1_save_service();
            }
        });
    }

    private void fruit_list_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.mb_recording_bffly_fruits();
        api.postRequest(responseCall, this, 1);
    }

    private void mb_bffly_form1_save_service(){
        if(mb_bffly1_area_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter actual area of fruit plantation", Toast.LENGTH_SHORT).show();
        }else if(fruit_id == 0){
            Toast.makeText(getApplicationContext(), "Select actual fruit planted", Toast.LENGTH_SHORT).show();
        }else if(mb_bffly1_fruit_spacing_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter actual spacing of fruit planted", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("scheme_name", scheme);
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("year_selected", "0");
                param.put("area_app", "0");
                param.put("area_actual", mb_bffly1_area_actual.getText().toString().trim());
                param.put("fruit_app", "0");
                param.put("fruit_actual", fruit_name);
                param.put("fruit_space_app", "0");
                param.put("fruit_space_actual", mb_bffly1_fruit_spacing_actual.getText().toString().trim());
                param.put("total_with_sap", "0");
                param.put("total_with_graft", "0");
                param.put("total_without_sap", "0");
                param.put("total_without_graft", "0");
                param.put("per_day_labour", "0");
                param.put("per_sap", "0");
                param.put("per_graft", "0");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mbrecording_bffly_form1_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            fruit_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Recording by BFFLY Form 1");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    Intent intent = new Intent(MBRecordingBfflyForm1Activity.this,MBRecordingBfflyForm2Activity.class);
                                    intent.putExtra("farmer_id",farmer_id);
                                    intent.putExtra("district_id",district_id);
                                    intent.putExtra("taluka_id",taluka_id);
                                    intent.putExtra("village_id",village_id);
                                    startActivity(intent);
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }
            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if(i ==1) {
            fruit_id = Integer.parseInt(s1);
            fruit_name = s;
            mb_bffly1_fruit_actual.setText(fruit_name);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
