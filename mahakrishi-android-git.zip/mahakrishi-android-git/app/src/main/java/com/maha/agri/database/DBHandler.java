package com.maha.agri.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.debug.DebugLog;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "Offline";
    //For Attendance
    public static final String TABLE_ATTENDANCE = "Attendance";
    private static final String KEY_ID = "id";
    private static final String USER_ID = "user_id";
    private static final String ATTEND_DATE = "attend_date";

    private static final String IN_TIME = "in_time";
    private static final String ADDRESS_IN = "address_in";
    private static final String IN_LAT = "in_lat";
    private static final String IN_LONG = "in_long";
    private static final String FILE_IN = "file_in";
    private static final String FILE_IN_LAT = "file_in_lat";
    private static final String FILE_IN_LONG = "file_in_long";

    private static final String OUT_TIME = "out_time";
    private static final String ADDRESS_OUT = "address_out";
    private static final String OUT_LAT = "out_lat";
    private static final String OUT_LONG = "out_long";
    private static final String FILE_OUT = "file_out";
    private static final String FILE_OUT_LAT = "file_out_lat";
    private static final String FILE_OUT_LONG = "file_out_long";

    private static final String REASON_ID = "reasonId";


    //For Task Type
    public static final String TABLE_TASK_TYPE = "Task_Type";
    private static final String TYPE_KEY_ID = "id";
    private static final String TYPE_NAME = "name";
    private static final String IS_TYPE_ACTIVE = "is_active";

    //For Scheme List
    public static final String TABLE_SCHEME_LIST = "Scheme_List";
    private static final String SCHEME_KEY_ID = "id";
    private static final String SCHEME_TYPE_ID = "typeId";
    private static final String SCHEME_NAME = "name";
    private static final String IS_SCHEME_ACTIVE = "is_active";
    private static final String SCHEME_LIST_SR_N0 = "sr_no";

    //For Scheme Activity
    public static final String TABLE_SCHEME_ACTIVITIES = "Scheme_Activity";
    private static final String SCHEME_ACTIVITY_KEY_ID = "id";
    private static final String SCHEME_ACTIVITY_ID = "typeId";
    private static final String SCHEME_ACTIVITY_NAME = "name";
  //  private static final String IS_SCHEME_ACTIVITY_ACTIVE = "is_active";
  //  private static final String IS_SCHEME_ACTIVITY_DELETED = "is_deleted";
  //  private static final String IS_SCHEME_ACTIVITY_PARENT_ID = "parent_id";
    private static final String IS_SCHEME_ACTIVITY_HAS_SUBACTIVITY = "has_subactivity";
    private static final String SCHEME_ACTIVITY_SR_N0 = "sr_no";

    //For Scheme Work
    public static final String TABLE_SCHEME_WORK = "Scheme_Work";
    private static final String SCHEME_WORK_KEY_ID = "id";
    private static final String SCHEME_WORK_ACTIVITY_ID = "activity_id";
    private static final String SCHEME_WORK_Details = "details";
    private static final String IS_SCHEME_WORK_PHOTO = "photo";
    private static final String IS_SCHEME_WORK_FARMER_NAME = "farmer_name";
    private static final String IS_SCHEME_WORK_CROP_NAME = "crop_name";
    private static final String IS_SCHEME_WORK_AREA_NAME = "area";
    private static final String IS_SCHEME_WORK_SITE_LOCATIONS = "site_location";
    private static final String IS_SCHEME_WORK_NUMBER_OF_PARTICIPANTS = "no_of_participants";


    //For Scheme Work Details
    public static final String TABLE_SCHEME_WORK_DETAILS = "Scheme_Work_Details";
    private static final String SCHEME_WORK_DETAILS_ID = "id";
    private static final String SCHEME_WORK_DETAILS_USER_ID = "user_id";
    private static final String SCHEME_WORK_DETAILS_ACTIVITY_ID = "activity_id";
    private static final String SCHEME_WORK_DETAILS_ACTIVITY_NAME = "activity_name";
    private static final String SCHEME_WORK_DETAILS_Details = "details";
    private static final String SCHEME_WORK_DETAILS_PHOTO = "photo";
    private static final String SCHEME_WORK_DETAILS_FARMER_NAME = "farmer_name";
    private static final String SCHEME_WORK_DETAILS_CROP_NAME = "crop_name";
    private static final String SCHEME_WORK_DETAILS_AREA_NAME = "area";
    private static final String SCHEME_WORK_DETAILS_SITE_LOCATIONS = "site_location";
    private static final String SCHEME_WORK_DETAILS_NUMBER_OF_PARTICIPANTS = "no_of_participants";
    private static final String SCHEME_WORK_DETAILS_SCHEME_ID = "scheme_id";
    private static final String SCHEME_WORK_DETAILS_IS_ACTIVE = "is_active";
    private static final String SCHEME_WORK_DETAILS_IS_DELETED = "is_deleted";


    //Pre Showing Detail Table
    public static final String TABLE_PRE_SHOWING_DETAILS = "pre_showing_Details";
    private static final String PRE_SHOWING_ID = "id";
    private static final String PRE_SHOWING_USER_ID = "user_id";
    private static final String PRE_SHOWING_VILLAGE = "village_id";
    private static final String PRE_SHOWING_VISIT_DAY = "visit_day";
    private static final String PRE_SHOWING_ACTIVITY = "activity";
    private static final String PRE_SHOWING_ACTIVITY_ID = "activity_id";
    private static final String PRE_SHOWING_CROP_ID = "crop_id";
    private static final String PRE_SHOWING_PLAN_ID = "plan_id";
    private static final String PRE_SHOWING_UNIT = "unit";
    private static final String PRE_SHOWING_COMMENT = "comment";
    private static final String PRE_SHOWING_IMG1 = "img1";
    private static final String PRE_SHOWING_IMG1_LAT_LANG = "lat_lang1";
    private static final String PRE_SHOWING_IMG2 = "img2";
    private static final String PRE_SHOWING_IMG2_LAT_LANG = "lat_lang2";
    private static final String PRE_SHOWING_SUBMITED = "is_submitted";

    //Crop Sowing Report District Taluka
    public static final String TABLE_CSR_DISTRICT_TALUKA = "kdp_tbl_M_Users";
    private static final String CSR_LAST_NAME = "last_name";
    private static final String CSR_FIRST_NAME = "first_name";
    private static final String CSR_EMAIL = "email";
    private static final String CSR_MOBILE = "mobile";
    private static final String CSR_PASSWORD = "password";
    private static final String CSR_MIDDLE_NAME = "middle_name";
    private static final String CSR_PROFILE_PIC = "profile_pic";
    private static final String CSR_KEY_ID = "id";
    private static final String CSR_ROLE_ID = "role_id";
    private static final String CSR_CREATED_AT = "created_at";
    private static final String CSR_UPDATED_AT = "updated_at";
    private static final String CSR_IS_ACTIVE = "is_active";
    private static final String CSR_IS_DELETED = "is_deleted";
    private static final String CSR_OTP = "otp";
    private static final String CSR_OTP_CREATED_AT = "otp_created_at";
    private static final String CSR_OTP_EXPIRED_AT = "otp_expired_at";
    private static final String CSR_LOGGED_IN = "logged_in";
    private static final String CSR_AADHAR_NO = "aadhar_no";
    private static final String CSR_SALUTATION_NAME = "salutation_name";
    private static final String CSR_USERTYPE = "usertype";
    private static final String CSR_GENDER = "gender";
    private static final String CSR_CREATED_BY = "created_by";
    private static final String CSR_MODIFIED_AT = "modified_at";
    private static final String CSR_MODIFIED_BY = "modified_by";
    private static final String CSR_DISTRICT_ID = "district_id";
    private static final String CSR_TALUKA_ID = "taluka_id";
    private static final String CSR_VILLAGE_ID = "village_id";
    private static final String CSR_FLAGGM= "flagGM";
    private static final String CSR_ASSIGNED = "assigned";

    //Login data save - Harshil
    public static final String TABLE_LOGIN_DATA = "Login_table";
    private static final String LOGIN_KEY_ID = "id";
    private static final String LOGIN_USER_ID = "user_id";
    private static final String LOGIN_LAST_NAME = "last_name";
    private static final String LOGIN_FIRST_NAME = "first_name";
    private static final String LOGIN_MIDDLE_NAME = "middle_name";
    private static final String LOGIN_EMAIL = "email";
    private static final String LOGIN_MOBILE = "mobile";
    private static final String LOGIN_ROLE_ID = "role_id";
    private static final String LOGIN_DESGN = "role_desg";
    private static final String LOGIN_DESGN_SF = "role_desg_short";
    private static final String LOGIN_JUNIOR_ROLE_ID = "junior_role_id";
    private static final String LOGIN_PROFILE_PIC = "profile_pic";
    private static final String LOGIN_LOGGED_IN = "logged_in";
    private static final String LOGIN_SALUTATION_NAME = "salutation_name";
    private static final String LOGIN_USER_TYPE = "usertype";
    private static final String LOGIN_AADHAR_NO = "aadhar_no";
    private static final String LOGIN_PRIMARY_JOB_CAT = "primary_job_category";
    private static final String LOGIN_JOB_CAT = "job_category";
    private static final String LOGIN_WORK_LOC = "work_location";
    private static final String LOGIN_COUNT_LOC = "count_location";
    private static final String LOGIN_SAJJA_DETAILS = "sajjaDetails";
    private static final String LOGIN_VILLAGE_LOC = "villages_location";

    //Switch profile data
    public static final String TABLE_SWITCH_PROFILE_DATA = "switch_profile_data";
    private static final String SPF_KEY_ID = "id";
    private static final String SPF_CIRCLE_ID = "circle_id";
    private static final String SPF_CIRCLE_NAME = "circle_name";
    private static final String SPF_CIRCLE_CODE = "circle_code";
    private static final String SPF_C_LOC_TYPE = "c_loc_type";
    private static final String SPF_SAJA_ID = "saja_id";
    private static final String SPF_SAJA_NAME = "saja_name";
    private static final String SPF_SAJA_CODE = "saja_code";
    private static final String SPF_S_LOC_TYPE = "s_loc_type";
    private static final String SPF_ROLE_CHARGE = "role_charge";
    private static final String SPF_ROLE_CHARGE_ID = "role_charge_id";
    private static final String SPF_ROLE_OFFICER = "role_officer";
    private static final String SPF_ROLE_OFFICER_ID = "role_officer_id";

    private static DBHandler dbHandler = null;

    public static DBHandler getInstance(Context context) {
        if (dbHandler == null) {
            dbHandler = new DBHandler(context);
        }
        return dbHandler;
    }


    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // For Attendance
        final String CREATE_FUN_FACTS_TABLE = "CREATE TABLE " + TABLE_ATTENDANCE + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + USER_ID + " TEXT,"
                + ATTEND_DATE + " TEXT, "

                + IN_TIME + " TEXT,"
                + ADDRESS_IN + " TEXT ,"
                + IN_LAT + " TEXT ,"
                + IN_LONG + " TEXT ,"
                + FILE_IN + " TEXT ,"
                + FILE_IN_LAT + " TEXT ,"
                + FILE_IN_LONG + " TEXT ,"

                + OUT_TIME + " TEXT ,"
                + ADDRESS_OUT + " TEXT ,"
                + OUT_LAT + " TEXT ,"
                + OUT_LONG + " TEXT ,"
                + FILE_OUT + " TEXT ,"
                + FILE_OUT_LAT + " TEXT ,"
                + FILE_OUT_LONG + " TEXT ,"
                + REASON_ID + " TEXT)";


        //For Task Type
        final String CREATE_TASK_TYPE_TABLE = "CREATE TABLE " + TABLE_TASK_TYPE + "("
                + TYPE_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + TYPE_NAME + " TEXT,"
                + IS_TYPE_ACTIVE + " TEXT)";


        //For Scheme List
        final String CREATE_SCHEME_LIST_TABLE = "CREATE TABLE " + TABLE_SCHEME_LIST + "("
                + SCHEME_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SCHEME_TYPE_ID + " TEXT,"
                + SCHEME_NAME + " TEXT ,"
                + IS_SCHEME_ACTIVE + " TEXT ,"
                + SCHEME_LIST_SR_N0 + " TEXT)";


        //For Scheme Activity
       /* final String CREATE_SCHEME_ACTIVITY_TABLE = "CREATE TABLE " + TABLE_SCHEME_ACTIVITIES + "("
                + SCHEME_ACTIVITY_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SCHEME_ACTIVITY_ID + " TEXT,"
                + SCHEME_ACTIVITY_NAME + " TEXT,"
                + IS_SCHEME_ACTIVITY_ACTIVE + " TEXT,"
                + IS_SCHEME_ACTIVITY_DELETED + " TEXT,"
                + IS_SCHEME_ACTIVITY_PARENT_ID + " TEXT,"
                + IS_SCHEME_ACTIVITY_HAS_SUBACTIVITY + " TEXT,"
                + SCHEME_ACTIVITY_SR_N0 + " TEXT)";*/

        final String CREATE_SCHEME_ACTIVITY_TABLE = "CREATE TABLE " + TABLE_SCHEME_ACTIVITIES + "("
                + SCHEME_ACTIVITY_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SCHEME_ACTIVITY_ID + " TEXT,"
                + SCHEME_ACTIVITY_NAME + " TEXT,"
                + IS_SCHEME_ACTIVITY_HAS_SUBACTIVITY + " TEXT,"
                + SCHEME_ACTIVITY_SR_N0 + " TEXT)";


        //For Scheme Work
        final String CREATE_SCHEME_WORK_TABLE = "CREATE TABLE " + TABLE_SCHEME_WORK + "("
                + SCHEME_WORK_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SCHEME_WORK_ACTIVITY_ID + " TEXT,"
                + SCHEME_WORK_Details + " TEXT,"
                + IS_SCHEME_WORK_PHOTO + " TEXT,"
                + IS_SCHEME_WORK_FARMER_NAME + " TEXT,"
                + IS_SCHEME_WORK_CROP_NAME + " TEXT,"
                + IS_SCHEME_WORK_AREA_NAME + " TEXT,"
                + IS_SCHEME_WORK_SITE_LOCATIONS + " TEXT,"
                + IS_SCHEME_WORK_NUMBER_OF_PARTICIPANTS + " TEXT)";

        //For Scheme Work Details
        final String CREATE_SCHEME_WORK_DETAILS_TABLE = "CREATE TABLE " + TABLE_SCHEME_WORK_DETAILS + "("
                + SCHEME_WORK_DETAILS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SCHEME_WORK_DETAILS_USER_ID + " TEXT,"
                + SCHEME_WORK_DETAILS_ACTIVITY_ID + " TEXT,"
                + SCHEME_WORK_DETAILS_ACTIVITY_NAME + " TEXT,"
                + SCHEME_WORK_DETAILS_Details + " TEXT,"
                + SCHEME_WORK_DETAILS_PHOTO + " TEXT,"
                + SCHEME_WORK_DETAILS_FARMER_NAME + " TEXT,"
                + SCHEME_WORK_DETAILS_CROP_NAME + " TEXT,"
                + SCHEME_WORK_DETAILS_AREA_NAME + " TEXT,"
                + SCHEME_WORK_DETAILS_SITE_LOCATIONS + " TEXT,"
                + SCHEME_WORK_DETAILS_NUMBER_OF_PARTICIPANTS + " TEXT,"
                + SCHEME_WORK_DETAILS_SCHEME_ID + " TEXT,"
                + SCHEME_WORK_DETAILS_IS_ACTIVE + " TEXT,"
                + SCHEME_WORK_DETAILS_IS_DELETED + " TEXT )";


        /**** Pre Showing visit table */
        final String CREATE_PRE_SHOWING_DETAILS_TABLE = "CREATE TABLE " + TABLE_PRE_SHOWING_DETAILS + "("
                + PRE_SHOWING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + PRE_SHOWING_USER_ID + " TEXT,"
                + PRE_SHOWING_VILLAGE + " TEXT,"
                + PRE_SHOWING_VISIT_DAY + " TEXT,"
                + PRE_SHOWING_ACTIVITY + " TEXT,"
                + PRE_SHOWING_ACTIVITY_ID + " TEXT,"
                + PRE_SHOWING_CROP_ID + " TEXT,"
                + PRE_SHOWING_PLAN_ID + " TEXT,"
                + PRE_SHOWING_UNIT + " TEXT,"
                + PRE_SHOWING_COMMENT + " TEXT,"
                + PRE_SHOWING_IMG1 + " TEXT,"
                + PRE_SHOWING_IMG1_LAT_LANG + " TEXT,"
                + PRE_SHOWING_IMG2 + " TEXT,"
                + PRE_SHOWING_IMG2_LAT_LANG + " TEXT,"
                + PRE_SHOWING_SUBMITED + " TEXT )";

        /* Crop Sowing Report District Taluka*/
        final String CREATE_CSR_DISTRICT_TALUKA_TABLE = "CREATE TABLE " + TABLE_CSR_DISTRICT_TALUKA + "("
                + CSR_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + CSR_LAST_NAME + " TEXT,"
                + CSR_FIRST_NAME + " TEXT,"
                + CSR_EMAIL + " TEXT,"
                + CSR_MOBILE + " TEXT,"
                + CSR_PASSWORD + " TEXT,"
                + CSR_MIDDLE_NAME + " TEXT,"
                + CSR_PROFILE_PIC + " TEXT,"
                + CSR_ROLE_ID + " TEXT,"
                + CSR_CREATED_AT + " TEXT,"
                + CSR_UPDATED_AT + " TEXT,"
                + CSR_IS_ACTIVE + " TEXT,"
                + CSR_IS_DELETED + " TEXT,"
                + CSR_OTP + " TEXT,"
                + CSR_OTP_CREATED_AT + " TEXT,"
                + CSR_OTP_EXPIRED_AT + " TEXT,"
                + CSR_LOGGED_IN + " TEXT,"
                + CSR_AADHAR_NO + " TEXT,"
                + CSR_SALUTATION_NAME + " TEXT,"
                + CSR_USERTYPE + " TEXT,"
                + CSR_GENDER + " TEXT,"
                + CSR_CREATED_BY + " TEXT,"
                + CSR_MODIFIED_AT + " TEXT,"
                + CSR_MODIFIED_BY + " TEXT,"
                + CSR_DISTRICT_ID + " TEXT,"
                + CSR_TALUKA_ID + " TEXT,"
                + CSR_VILLAGE_ID + " TEXT,"
                + CSR_FLAGGM + " TEXT,"
                + CSR_ASSIGNED + " TEXT )";

        //Login data save
        final String CREATE_LOGIN_DATA_SAVE = "CREATE TABLE " + TABLE_LOGIN_DATA + "("
                + LOGIN_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + LOGIN_USER_ID + " TEXT,"
                + LOGIN_LAST_NAME + " TEXT,"
                + LOGIN_FIRST_NAME + " TEXT,"
                + LOGIN_MIDDLE_NAME + " TEXT,"
                + LOGIN_EMAIL + " TEXT,"
                + LOGIN_MOBILE + " TEXT,"
                + LOGIN_ROLE_ID + " TEXT,"
                + LOGIN_DESGN + " TEXT,"
                + LOGIN_DESGN_SF + " TEXT,"
                + LOGIN_JUNIOR_ROLE_ID + " TEXT,"
                + LOGIN_PROFILE_PIC + " TEXT,"
                + LOGIN_LOGGED_IN + " TEXT,"
                + LOGIN_SALUTATION_NAME + " TEXT,"
                + LOGIN_USER_TYPE + " TEXT,"
                + LOGIN_AADHAR_NO + " TEXT,"
                + LOGIN_PRIMARY_JOB_CAT + " TEXT,"
                + LOGIN_JOB_CAT + " TEXT,"
                + LOGIN_WORK_LOC + " TEXT,"
                + LOGIN_COUNT_LOC + " TEXT,"
                + LOGIN_SAJJA_DETAILS + " TEXT,"
                + LOGIN_VILLAGE_LOC + " TEXT )";

        //Login data save
        final String CREATE_SWITCH_PROFILE_DATA = "CREATE TABLE " + TABLE_SWITCH_PROFILE_DATA + "("
                + SPF_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + SPF_CIRCLE_ID + " TEXT,"
                + SPF_CIRCLE_NAME + " TEXT,"
                + SPF_CIRCLE_CODE + " TEXT,"
                + SPF_C_LOC_TYPE + " TEXT,"
                + SPF_SAJA_ID + " TEXT,"
                + SPF_SAJA_NAME + " TEXT,"
                + SPF_SAJA_CODE + " TEXT,"
                + SPF_S_LOC_TYPE + " TEXT,"
                + SPF_ROLE_CHARGE + " TEXT,"
                + SPF_ROLE_CHARGE_ID + " TEXT,"
                + SPF_ROLE_OFFICER + " TEXT,"
                + SPF_ROLE_OFFICER_ID + " TEXT )";

        // For Attendance
        sqLiteDatabase.execSQL(CREATE_FUN_FACTS_TABLE);
        //For Task Type
        sqLiteDatabase.execSQL(CREATE_TASK_TYPE_TABLE);
        //For Scheme List
        sqLiteDatabase.execSQL(CREATE_SCHEME_LIST_TABLE);
        //For Scheme Activity
        sqLiteDatabase.execSQL(CREATE_SCHEME_ACTIVITY_TABLE);
        //For Scheme Work
        sqLiteDatabase.execSQL(CREATE_SCHEME_WORK_TABLE);
        //For Scheme Work Details
        sqLiteDatabase.execSQL(CREATE_SCHEME_WORK_DETAILS_TABLE);

        sqLiteDatabase.execSQL(CREATE_PRE_SHOWING_DETAILS_TABLE);
        //Crop Sowing Report District Taluka
        sqLiteDatabase.execSQL(CREATE_CSR_DISTRICT_TALUKA_TABLE);
        //Login data save
        sqLiteDatabase.execSQL(CREATE_LOGIN_DATA_SAVE);
        //Switch profile data
        sqLiteDatabase.execSQL(CREATE_SWITCH_PROFILE_DATA);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

        try {

            if (oldVersion != newVersion) {

                // For Attendance
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_ATTENDANCE);
                //For Task Type
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_TASK_TYPE);
                //For Scheme List
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEME_LIST);
                //For Scheme Activity
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEME_ACTIVITIES);
                //For Scheme Work
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEME_WORK);
                //For Scheme Work Details
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEME_WORK_DETAILS);

                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_PRE_SHOWING_DETAILS);

                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_CSR_DISTRICT_TALUKA);
                //Login data save
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGIN_DATA);
                //Switch profile data
                sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SWITCH_PROFILE_DATA);

                onCreate(sqLiteDatabase);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // for for deleting all table data from database
    public void deleteAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(TABLE_ATTENDANCE, null, null);
        db.delete(TABLE_TASK_TYPE, null, null);
        db.delete(TABLE_SCHEME_LIST, null, null);
        db.delete(TABLE_SCHEME_ACTIVITIES, null, null);
        db.delete(TABLE_SCHEME_WORK, null, null);
        db.delete(TABLE_SCHEME_WORK_DETAILS, null, null);
        db.delete(TABLE_PRE_SHOWING_DETAILS, null, null);
        db.delete(TABLE_CSR_DISTRICT_TALUKA, null, null);
        db.delete(TABLE_LOGIN_DATA, null, null);
        db.delete(TABLE_SWITCH_PROFILE_DATA, null, null);
    }

    public void deleteTableData(String TableName) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(TableName, null, null);
    }

    public void deleteWorkDetails(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("DELETE FROM " + TABLE_SCHEME_WORK_DETAILS + " WHERE " + SCHEME_WORK_DETAILS_ID + "= '" + id + "'");
        db.close();
    }


    // To check is id exist in table
    public boolean isItemPresent(String id, String tableName) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from " + tableName + " WHERE id = " + id + " ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String itemId = cursor.getString(cursor.getColumnIndex("id"));
                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", itemId);
                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Task Type Array" + jsonArray.toString());
        }

        if (jsonArray.length() > 0) {
            return true;
        } else {
            return false;
        }

    }


    //For Attendance
    public boolean insertInAttendanceDetails(String userId, String attendDate, String inTime, String inAddress, String inLat, String inLong, String fileIn, String fileInLat, String fileInLong,
                                             String outTime, String outAddress, String outLat, String outLong, String fileOut, String fileOutLat, String fileOutLong, String reasonId) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(USER_ID, userId);
            values.put(ATTEND_DATE, attendDate);

            values.put(IN_TIME, inTime);
            values.put(ADDRESS_IN, inAddress);
            values.put(IN_LAT, inLat);
            values.put(IN_LONG, inLong);
            values.put(FILE_IN, fileIn);
            values.put(FILE_IN_LAT, fileInLat);
            values.put(FILE_IN_LONG, fileInLong);

            values.put(OUT_TIME, outTime);
            values.put(ADDRESS_OUT, outAddress);
            values.put(OUT_LAT, outLat);
            values.put(OUT_LONG, outLong);
            values.put(FILE_OUT, fileOut);
            values.put(FILE_OUT_LAT, fileOutLat);
            values.put(FILE_OUT_LONG, fileOutLong);

            values.put(REASON_ID, reasonId);

            result = db.insert(TABLE_ATTENDANCE, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    //For Update Attendance

    public boolean updateOutAttendanceDetails(String userId, String attendDate, /*String inTime, String inAddress, String inLat, String inLong, String fileIn, String fileInLat, String fileInLong,*/
                                              String outTime, String outAddress, String outLat, String outLong, String fileOut, String fileOutLat, String fileOutLong) {
        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(USER_ID, userId);
            values.put(ATTEND_DATE, attendDate);

            /*values.put(IN_TIME, inTime);
            values.put(ADDRESS_IN, inAddress);
            values.put(IN_LAT, inLat);
            values.put(IN_LONG, inLong);
            values.put(FILE_IN, fileIn);
            values.put(FILE_IN_LAT, fileInLat);
            values.put(FILE_IN_LONG, fileInLong);*/

            values.put(OUT_TIME, outTime);
            values.put(ADDRESS_OUT, outAddress);
            values.put(OUT_LAT, outLat);
            values.put(OUT_LONG, outLong);
            values.put(FILE_OUT, fileOut);
            values.put(FILE_OUT_LAT, fileOutLat);
            values.put(FILE_OUT_LONG, fileOutLong);

            // values.put(REASON_ID, reasonId);

            result = db.update(TABLE_ATTENDANCE, values, " user_id = '" + userId + "'AND attend_date = '" + attendDate + "'", null);
            // result =  db.insert(TABLE_ATTENDANCE, null, values);
            db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    /****Task Type */

    //For Task Type
    public boolean insertTaskType(String name, String is_active) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(TYPE_NAME, name);
            values.put(IS_TYPE_ACTIVE, is_active);

            result = db.insert(TABLE_TASK_TYPE, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    //For Update Task Type
    public boolean updateTaskType(String id, String name, String is_active) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(TYPE_KEY_ID, id);
            values.put(TYPE_NAME, name);
            values.put(IS_TYPE_ACTIVE, is_active);

            result = db.update(TABLE_TASK_TYPE, values, " id = " + id, null);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


    /****Scheme List */

    //For Scheme List
    public boolean insertSchemeList(String typeId, String name, String is_active, String sr_no) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();


            values.put(SCHEME_TYPE_ID, typeId);
            values.put(SCHEME_NAME, name);
            values.put(IS_SCHEME_ACTIVE, is_active);
            values.put(SCHEME_LIST_SR_N0, sr_no);

            result = db.insert(TABLE_SCHEME_LIST, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    //For Update Scheme List
    public boolean updateSchemeList(String id, String typeId, String name, String is_active, String sr_no) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_KEY_ID, id);
            values.put(SCHEME_TYPE_ID, typeId);
            values.put(SCHEME_NAME, name);
            values.put(IS_SCHEME_ACTIVE, is_active);
            values.put(SCHEME_ACTIVITY_SR_N0, sr_no);

            result = db.update(TABLE_SCHEME_LIST, values, " id = " + id, null);

            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;

        } else {
            return true;
        }

    }


    /****Scheme Activity */

    //For Scheme Activity
    public boolean insertSchemeActivity(String typeId, String name,String has_subactivity, String sr_no) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_ACTIVITY_ID, typeId);
            values.put(SCHEME_ACTIVITY_NAME, name);
            /*values.put(IS_SCHEME_ACTIVITY_ACTIVE, is_active);
            values.put(IS_SCHEME_ACTIVITY_DELETED, is_deleted);
            values.put(IS_SCHEME_ACTIVITY_PARENT_ID, parent_id);*/
            values.put(IS_SCHEME_ACTIVITY_HAS_SUBACTIVITY, has_subactivity);
            values.put(SCHEME_ACTIVITY_SR_N0, sr_no);

            result = db.insert(TABLE_SCHEME_ACTIVITIES, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    //For Update Scheme Activity
    public boolean updateSchemeActivity(String id, String typeId, String name,String has_subactivity, String sr_no) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_ACTIVITY_KEY_ID, id);
            values.put(SCHEME_ACTIVITY_ID, typeId);
            values.put(SCHEME_ACTIVITY_NAME, name);
          /*  values.put(IS_SCHEME_ACTIVITY_ACTIVE, is_active);
            values.put(IS_SCHEME_ACTIVITY_DELETED, is_deleted);
            values.put(IS_SCHEME_ACTIVITY_PARENT_ID, parent_id);*/
            values.put(IS_SCHEME_ACTIVITY_HAS_SUBACTIVITY, has_subactivity);
            values.put(SCHEME_ACTIVITY_SR_N0, sr_no);

            result = db.update(TABLE_SCHEME_ACTIVITIES, values, " id = " + id, null);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    /****Scheme Work */

    //For Scheme Work
    public boolean insertSchemeWork(String activity_id, String details, String photo, String farmer_name, String crop_name, String area, String site_location, String no_of_participants) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_WORK_ACTIVITY_ID, activity_id);
            values.put(SCHEME_WORK_Details, details);
            values.put(IS_SCHEME_WORK_PHOTO, photo);
            values.put(IS_SCHEME_WORK_FARMER_NAME, farmer_name);
            values.put(IS_SCHEME_WORK_CROP_NAME, crop_name);
            values.put(IS_SCHEME_WORK_AREA_NAME, area);
            values.put(IS_SCHEME_WORK_SITE_LOCATIONS, site_location);
            values.put(IS_SCHEME_WORK_NUMBER_OF_PARTICIPANTS, no_of_participants);

            result = db.insert(TABLE_SCHEME_WORK, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    //For Update Scheme Work
    public boolean updateSchemeWork(String id, String activity_id, String details, String photo, String farmer_name, String crop_name, String area, String site_location, String no_of_participants) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_WORK_KEY_ID, id);
            values.put(SCHEME_WORK_ACTIVITY_ID, activity_id);
            values.put(SCHEME_WORK_Details, details);
            values.put(IS_SCHEME_WORK_PHOTO, photo);
            values.put(IS_SCHEME_WORK_FARMER_NAME, farmer_name);
            values.put(IS_SCHEME_WORK_CROP_NAME, crop_name);
            values.put(IS_SCHEME_WORK_AREA_NAME, area);
            values.put(IS_SCHEME_WORK_SITE_LOCATIONS, site_location);
            values.put(IS_SCHEME_WORK_NUMBER_OF_PARTICIPANTS, no_of_participants);

            result = db.update(TABLE_SCHEME_WORK, values, " id = " + id, null);

            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    /****Scheme Work Details */

    //For Scheme Work Details
    public boolean insertSchemeWorkDetails(String user_id, String actId,String actName, String details, String photo, String farmer_name, String crop_name, String area, String siteLocation, String noOfParticipants, String schemeId, String isActive, String isDeleted) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_WORK_DETAILS_USER_ID, user_id);
            values.put(SCHEME_WORK_DETAILS_ACTIVITY_ID, actId);
            values.put(SCHEME_WORK_DETAILS_ACTIVITY_NAME, actName);
            values.put(SCHEME_WORK_DETAILS_Details, details);
            values.put(SCHEME_WORK_DETAILS_PHOTO, photo);
            values.put(SCHEME_WORK_DETAILS_FARMER_NAME, farmer_name);
            values.put(SCHEME_WORK_DETAILS_CROP_NAME, crop_name);
            values.put(SCHEME_WORK_DETAILS_AREA_NAME, area);
            values.put(SCHEME_WORK_DETAILS_SITE_LOCATIONS, siteLocation);
            values.put(SCHEME_WORK_DETAILS_NUMBER_OF_PARTICIPANTS, noOfParticipants);
            values.put(SCHEME_WORK_DETAILS_SCHEME_ID, schemeId);
            values.put(SCHEME_WORK_DETAILS_IS_ACTIVE, isActive);
            values.put(SCHEME_WORK_DETAILS_IS_DELETED, isDeleted);

            result = db.insert(TABLE_SCHEME_WORK_DETAILS, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    //For Update Scheme Work Details
    public boolean updateSchemeWorkDetails(String id, String user_id, String activity_id, String details, String photo, String farmer_name, String crop_name, String area, String site_location, String no_of_participants, String scheme_id, String is_active, String is_deleted) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SCHEME_WORK_DETAILS_ID, id);
            values.put(SCHEME_WORK_DETAILS_USER_ID, user_id);
            values.put(SCHEME_WORK_DETAILS_ACTIVITY_ID, activity_id);
            values.put(SCHEME_WORK_DETAILS_Details, details);
            values.put(SCHEME_WORK_DETAILS_PHOTO, photo);
            values.put(SCHEME_WORK_DETAILS_FARMER_NAME, farmer_name);
            values.put(SCHEME_WORK_DETAILS_CROP_NAME, crop_name);
            values.put(SCHEME_WORK_DETAILS_AREA_NAME, area);
            values.put(SCHEME_WORK_DETAILS_SITE_LOCATIONS, site_location);
            values.put(SCHEME_WORK_DETAILS_NUMBER_OF_PARTICIPANTS, no_of_participants);
            values.put(SCHEME_WORK_DETAILS_SCHEME_ID, scheme_id);
            values.put(SCHEME_WORK_DETAILS_IS_ACTIVE, is_active);
            values.put(SCHEME_WORK_DETAILS_IS_DELETED, is_deleted);

            result = db.update(TABLE_SCHEME_WORK_DETAILS, values, " id = " + id, null);

            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }


    /****Get Detail*/

    //For Attendance
    public JSONArray getAttendanceByDateType(String userId, String attendDate) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from  Attendance WHERE user_id = '" + userId + "' AND attend_date = '" + attendDate + "' ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex("id"));
                userId = cursor.getString(cursor.getColumnIndex("user_id"));
                attendDate = cursor.getString(cursor.getColumnIndex("attend_date"));

                String inTime = cursor.getString(cursor.getColumnIndex("in_time"));
                String inAddress = cursor.getString(cursor.getColumnIndex("address_in"));
                String inLat = cursor.getString(cursor.getColumnIndex("in_lat"));
                String inLong = cursor.getString(cursor.getColumnIndex("in_long"));
                String fileIn = cursor.getString(cursor.getColumnIndex("file_in"));
                String fileInLat = cursor.getString(cursor.getColumnIndex("file_in_lat"));
                String fileInLong = cursor.getString(cursor.getColumnIndex("file_in_long"));

                String outTime = cursor.getString(cursor.getColumnIndex("out_time"));
                String addressOut = cursor.getString(cursor.getColumnIndex("address_out"));
                String outLat = cursor.getString(cursor.getColumnIndex("out_lat"));
                String outLong = cursor.getString(cursor.getColumnIndex("out_long"));
                String fileOut = cursor.getString(cursor.getColumnIndex("file_out"));
                String fileOutLat = cursor.getString(cursor.getColumnIndex("file_out_lat"));
                String fileOutLong = cursor.getString(cursor.getColumnIndex("file_out_long"));
                String reasonId = cursor.getString(cursor.getColumnIndex("reasonId"));


                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("user_id", userId);
                    jsonObject1.put("attend_date", attendDate);

                    jsonObject1.put("in_time", inTime);
                    jsonObject1.put("address_in", inAddress);
                    jsonObject1.put("in_lat", inLat);
                    jsonObject1.put("in_long", inLong);
                    jsonObject1.put("file_in", fileIn);
                    jsonObject1.put("file_in_lat", fileInLat);
                    jsonObject1.put("file_in_long", fileInLong);

                    jsonObject1.put("out_time", outTime);
                    jsonObject1.put("address_out", addressOut);
                    jsonObject1.put("out_lat", outLat);
                    jsonObject1.put("out_long", outLong);
                    jsonObject1.put("file_out", fileOut);
                    jsonObject1.put("file_out_lat", fileOutLat);
                    jsonObject1.put("file_out_long", fileOutLong);
                    jsonObject1.put("reasonId", reasonId);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("Attendance JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    public JSONArray getAttendanceDetail(String userId) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from  Attendance WHERE user_id = '" + userId + "' ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                userId = cursor.getString(cursor.getColumnIndex("user_id"));
                String attendDate = cursor.getString(cursor.getColumnIndex("attend_date"));

                String inTime = cursor.getString(cursor.getColumnIndex("in_time"));
                String inAddress = cursor.getString(cursor.getColumnIndex("address_in"));
                String inLat = cursor.getString(cursor.getColumnIndex("in_lat"));
                String inLong = cursor.getString(cursor.getColumnIndex("in_long"));
                String fileIn = cursor.getString(cursor.getColumnIndex("file_in"));
                String fileInLat = cursor.getString(cursor.getColumnIndex("file_in_lat"));
                String fileInLong = cursor.getString(cursor.getColumnIndex("file_in_long"));

                String outTime = cursor.getString(cursor.getColumnIndex("out_time"));
                String addressOut = cursor.getString(cursor.getColumnIndex("address_out"));
                String outLat = cursor.getString(cursor.getColumnIndex("out_lat"));
                String outLong = cursor.getString(cursor.getColumnIndex("out_long"));
                String fileOut = cursor.getString(cursor.getColumnIndex("file_out"));
                String fileOutLat = cursor.getString(cursor.getColumnIndex("file_out_lat"));
                String fileOutLong = cursor.getString(cursor.getColumnIndex("file_out_long"));
                String reasonId = cursor.getString(cursor.getColumnIndex("reasonId"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("user_id", userId);
                    jsonObject1.put("attend_date", attendDate);

                    jsonObject1.put("in_time", inTime);
                    jsonObject1.put("address_in", inAddress);
                    jsonObject1.put("in_lat", inLat);
                    jsonObject1.put("in_long", inLong);
                    jsonObject1.put("file_in", fileIn);
                    jsonObject1.put("file_in_lat", fileInLat);
                    jsonObject1.put("file_in_long", fileInLong);

                    jsonObject1.put("out_time", outTime);
                    jsonObject1.put("address_out", addressOut);
                    jsonObject1.put("out_lat", outLat);
                    jsonObject1.put("out_long", outLong);
                    jsonObject1.put("file_out", fileOut);
                    jsonObject1.put("file_out_lat", fileOutLat);
                    jsonObject1.put("file_out_long", fileOutLong);
                    jsonObject1.put("reasonId", reasonId);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Attendance JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    //For TASK Manager

    public JSONArray getTaskType() {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from Task_Type ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String is_active = cursor.getString(cursor.getColumnIndex("is_active"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("name", name);
                    jsonObject1.put("is_active", is_active);
                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Task Type Array" + jsonArray.toString());
        }
        return jsonArray;
    }


    public JSONArray getSchemeList(String typeId) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from Scheme_List WHERE typeId = '" + typeId + "' ORDER BY sr_no ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex("id"));
                String tTypeId = cursor.getString(cursor.getColumnIndex("typeId"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String is_active = cursor.getString(cursor.getColumnIndex("is_active"));
                String sr_no = cursor.getString(cursor.getColumnIndex("sr_no"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("typeId", tTypeId);
                    jsonObject1.put("name", name);
                    jsonObject1.put("is_active", is_active);
                    jsonObject1.put("sr_no", sr_no);
                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme List JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }

    public JSONArray getSchemeActivity(String typeId, String parentId) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
      //  String query = " SELECT * from Scheme_Activity WHERE typeId = '" + typeId + "' AND parent_id = " + parentId + " ORDER BY id ASC ";
        String query = " SELECT * from Scheme_Activity WHERE typeId = '" + typeId + "' ORDER BY id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex("id"));
                String tTypeId = cursor.getString(cursor.getColumnIndex("typeId"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
               /* String is_active = cursor.getString(cursor.getColumnIndex("is_active"));
                String is_deleted = cursor.getString(cursor.getColumnIndex("is_deleted"));
                String parent_id = cursor.getString(cursor.getColumnIndex("parent_id"));*/
                String has_subactivity = cursor.getString(cursor.getColumnIndex("has_subactivity"));
                String sr_no = cursor.getString(cursor.getColumnIndex("sr_no"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("typeId", tTypeId);
                    jsonObject1.put("name", name);

                   /* jsonObject1.put("is_active", is_active);
                    jsonObject1.put("is_deleted", is_deleted);
                    jsonObject1.put("parent_id", parent_id);*/
                    jsonObject1.put("has_subactivity", has_subactivity);
                    jsonObject1.put("sr_no", sr_no);
                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme Activity JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    public JSONArray getOfflineSchemeWork(String activity_id) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from Scheme_Work WHERE activity_id = '" + activity_id + "' ORDER BY  activity_id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String details = cursor.getString(cursor.getColumnIndex("details"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                String farmer_name = cursor.getString(cursor.getColumnIndex("farmer_name"));
                String crop_name = cursor.getString(cursor.getColumnIndex("crop_name"));
                String area = cursor.getString(cursor.getColumnIndex("area"));
                String site_location = cursor.getString(cursor.getColumnIndex("site_location"));
                String no_of_participants = cursor.getString(cursor.getColumnIndex("no_of_participants"));
                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("details", details);

                    jsonObject1.put("photo", photo);
                    jsonObject1.put("farmer_name", farmer_name);
                    jsonObject1.put("crop_name", crop_name);
                    jsonObject1.put("area", area);
                    jsonObject1.put("site_location", site_location);
                    jsonObject1.put("no_of_participants", no_of_participants);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme Work JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    public JSONArray getOfflineSchemeWork() {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from Scheme_Work  ORDER BY id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                String activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String details = cursor.getString(cursor.getColumnIndex("details"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                String farmer_name = cursor.getString(cursor.getColumnIndex("farmer_name"));
                String crop_name = cursor.getString(cursor.getColumnIndex("crop_name"));
                String area = cursor.getString(cursor.getColumnIndex("area"));
                String site_location = cursor.getString(cursor.getColumnIndex("site_location"));
                String no_of_participants = cursor.getString(cursor.getColumnIndex("no_of_participants"));
                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("details", details);

                    jsonObject1.put("photo", photo);
                    jsonObject1.put("farmer_name", farmer_name);
                    jsonObject1.put("crop_name", crop_name);
                    jsonObject1.put("area", area);
                    jsonObject1.put("site_location", site_location);
                    jsonObject1.put("no_of_participants", no_of_participants);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme Work JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }

    public JSONArray getOfflineSchemeWorkDetailsById(String activity_id) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from  Scheme_Work_Details WHERE activity_id = '" + activity_id + "' ORDER BY  activity_id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String taskId = cursor.getString(cursor.getColumnIndex("id"));
                String user_id = cursor.getString(cursor.getColumnIndex("user_id"));
                activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String activity_name = cursor.getString(cursor.getColumnIndex("activity_name"));
                String details = cursor.getString(cursor.getColumnIndex("details"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                String farmer_name = cursor.getString(cursor.getColumnIndex("farmer_name"));
                String crop_name = cursor.getString(cursor.getColumnIndex("crop_name"));
                String area = cursor.getString(cursor.getColumnIndex("area"));
                String site_location = cursor.getString(cursor.getColumnIndex("site_location"));
                String no_of_participants = cursor.getString(cursor.getColumnIndex("no_of_participants"));
                String scheme_id = cursor.getString(cursor.getColumnIndex("scheme_id"));
                String is_active = cursor.getString(cursor.getColumnIndex("is_active"));
                String is_deleted = cursor.getString(cursor.getColumnIndex("is_deleted"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", taskId);
                    jsonObject1.put("user_id", user_id);
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("activity_name", activity_name);
                    jsonObject1.put("details", details);
                    jsonObject1.put("photo", photo);
                    jsonObject1.put("farmer_name", farmer_name);
                    jsonObject1.put("crop_name", crop_name);
                    jsonObject1.put("area", area);
                    jsonObject1.put("site_location", site_location);
                    jsonObject1.put("no_of_participants", no_of_participants);
                    jsonObject1.put("scheme_id", scheme_id);
                    jsonObject1.put("is_active", is_active);
                    jsonObject1.put("is_deleted", is_deleted);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme Work Details JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    public JSONArray getAllOfflineSchemeWorkDetails() {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from  Scheme_Work_Details ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                String user_id = cursor.getString(cursor.getColumnIndex("user_id"));
                String activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String activity_name = cursor.getString(cursor.getColumnIndex("activity_name"));
                String details = cursor.getString(cursor.getColumnIndex("details"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                String farmer_name = cursor.getString(cursor.getColumnIndex("farmer_name"));
                String crop_name = cursor.getString(cursor.getColumnIndex("crop_name"));
                String area = cursor.getString(cursor.getColumnIndex("area"));
                String site_location = cursor.getString(cursor.getColumnIndex("site_location"));
                String no_of_participants = cursor.getString(cursor.getColumnIndex("no_of_participants"));
                String scheme_id = cursor.getString(cursor.getColumnIndex("scheme_id"));
                String is_active = cursor.getString(cursor.getColumnIndex("is_active"));
                String is_deleted = cursor.getString(cursor.getColumnIndex("is_deleted"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("user_id", user_id);
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("activity_name", activity_name);
                    jsonObject1.put("details", details);
                    jsonObject1.put("photo", photo);
                    jsonObject1.put("farmer_name", farmer_name);
                    jsonObject1.put("crop_name", crop_name);
                    jsonObject1.put("area", area);
                    jsonObject1.put("site_location", site_location);
                    jsonObject1.put("no_of_participants", no_of_participants);
                    jsonObject1.put("scheme_id", scheme_id);
                    jsonObject1.put("is_active", is_active);
                    jsonObject1.put("is_deleted", is_deleted);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("All Scheme Work Details JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }




    // For PRE Showing VISIT

    //For Task Type
    public boolean insertPreShowingVisitDetail(String userId, String villageId, String visitName, String activity, String activityId,
                                               String cropId,String planId,String unit,String comment,String img1URL,String lat_lang1,
                                               String omg2Url,String lat_lang2,String isSubmitted) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(PRE_SHOWING_USER_ID, userId);
            values.put(PRE_SHOWING_VILLAGE, villageId);
            values.put(PRE_SHOWING_VISIT_DAY, visitName);
            values.put(PRE_SHOWING_ACTIVITY, activity);
            values.put(PRE_SHOWING_ACTIVITY_ID, activityId);
            values.put(PRE_SHOWING_CROP_ID, cropId);
            values.put(PRE_SHOWING_PLAN_ID, planId);
            values.put(PRE_SHOWING_UNIT, unit);
            values.put(PRE_SHOWING_COMMENT, comment);
            values.put(PRE_SHOWING_IMG1, img1URL);
            values.put(PRE_SHOWING_IMG1_LAT_LANG, lat_lang1);
            values.put(PRE_SHOWING_IMG2, omg2Url);
            values.put(PRE_SHOWING_IMG1_LAT_LANG, lat_lang2);
            values.put(PRE_SHOWING_SUBMITED, isSubmitted);

            result = db.insert(TABLE_PRE_SHOWING_DETAILS, null, values);
            //db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    //For Update Task Type
    public boolean updatePreShowingVisitDetail(String userId, String villageId,String visitName, String activity,String activityId,
                                               String cropId,String planId,String unit,String comment,String img1URL,String img1LatLang,
                                               String omg2Url,String img2LatLang,String isSubmitted) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(PRE_SHOWING_USER_ID, userId);
            values.put(PRE_SHOWING_VILLAGE, villageId);
            values.put(PRE_SHOWING_VISIT_DAY, visitName);
            values.put(PRE_SHOWING_ACTIVITY, activity);
            values.put(PRE_SHOWING_ACTIVITY_ID, activityId);
            values.put(PRE_SHOWING_CROP_ID, cropId);
            values.put(PRE_SHOWING_PLAN_ID, planId);
            values.put(PRE_SHOWING_UNIT, unit);
            values.put(PRE_SHOWING_COMMENT, comment);
            values.put(PRE_SHOWING_IMG1, img1URL);
            values.put(PRE_SHOWING_IMG1_LAT_LANG, img1LatLang);
            values.put(PRE_SHOWING_IMG2, omg2Url);
            values.put(PRE_SHOWING_IMG2_LAT_LANG, img2LatLang);
            values.put(PRE_SHOWING_SUBMITED, isSubmitted);

            result = db.update(TABLE_PRE_SHOWING_DETAILS, values, " activity_id = " + activityId, null);
            // db.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public JSONArray getPreShowingActivityList(String preShowingVisit) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from pre_showing_Details WHERE visit_day = '" +preShowingVisit + "' ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String id = cursor.getString(cursor.getColumnIndex("id"));
                String user_id = cursor.getString(cursor.getColumnIndex("user_id"));
                String village_id = cursor.getString(cursor.getColumnIndex("village_id"));
                String visit_day = cursor.getString(cursor.getColumnIndex("visit_day"));
                String activity = cursor.getString(cursor.getColumnIndex("activity"));
                String activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String crop_id = cursor.getString(cursor.getColumnIndex("crop_id"));
                String plan_id = cursor.getString(cursor.getColumnIndex("plan_id"));
                String unit = cursor.getString(cursor.getColumnIndex("unit"));
                String comment = cursor.getString(cursor.getColumnIndex("comment"));
                String img1 = cursor.getString(cursor.getColumnIndex("img1"));
                String img1LatLang = cursor.getString(cursor.getColumnIndex("lat_lang1"));
                String img2 = cursor.getString(cursor.getColumnIndex("img2"));
                String img2LatLang = cursor.getString(cursor.getColumnIndex("lat_lang2"));
                String is_submitted = cursor.getString(cursor.getColumnIndex("is_submitted"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("user_id", user_id);
                    jsonObject1.put("village_id", village_id);
                    jsonObject1.put("visit_day", visit_day);
                    jsonObject1.put("activity", activity);
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("crop_id", crop_id);
                    jsonObject1.put("plan_id", plan_id);
                    jsonObject1.put("unit", unit);
                    jsonObject1.put("comment", comment);
                    jsonObject1.put("img1", img1);
                    jsonObject1.put("lat_lang1", img1LatLang == null?"":img1LatLang);
                    jsonObject1.put("img2", img2);
                    jsonObject1.put("lat_lang2", img2LatLang == null?"":img2LatLang);
                    jsonObject1.put("is_submitted", is_submitted);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("Pre schedule Details JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }


    public boolean isActivityDetailExist(String activityId) {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from pre_showing_Details WHERE activity_id = '" + activityId + "' ORDER BY  id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String activity_id = cursor.getString(cursor.getColumnIndex("activity_id"));
                String crop_id = cursor.getString(cursor.getColumnIndex("crop_id"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("activity_id", activity_id);
                    jsonObject1.put("crop_id", crop_id);
                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("Pre schedule Details JsonArray" + jsonArray.toString());
        }

        return jsonArray.length() > 0;
    }

    //For login data save
    public boolean insertlogindata(String userId, String last_name, String first_name, String middle_name, String email, String mobile, String role_id,
                                   String designation, String designation_sf, String junior_role_id, String profile_pic, String logged_in, String salutation_name,
                                   String user_type, String aadhar_no, String primary_job_cat, String job_cat,String work_loc, String count_loc, String saja_details,
                                   String village_loc) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(LOGIN_USER_ID, userId);
            values.put(LOGIN_LAST_NAME, last_name);
            values.put(LOGIN_FIRST_NAME, first_name);
            values.put(LOGIN_MIDDLE_NAME, middle_name);
            values.put(LOGIN_EMAIL, email);
            values.put(LOGIN_MOBILE, mobile);
            values.put(LOGIN_ROLE_ID, role_id);
            values.put(LOGIN_DESGN, designation);
            values.put(LOGIN_DESGN_SF, designation_sf);
            values.put(LOGIN_JUNIOR_ROLE_ID, junior_role_id);
            values.put(LOGIN_PROFILE_PIC, profile_pic);
            values.put(LOGIN_LOGGED_IN, logged_in);
            values.put(LOGIN_SALUTATION_NAME, salutation_name);
            values.put(LOGIN_USER_TYPE, user_type);
            values.put(LOGIN_AADHAR_NO, aadhar_no);
            values.put(LOGIN_PRIMARY_JOB_CAT, primary_job_cat);
            values.put(LOGIN_JOB_CAT, job_cat);
            values.put(LOGIN_WORK_LOC, work_loc);
            values.put(LOGIN_COUNT_LOC, count_loc);
            values.put(LOGIN_SAJJA_DETAILS, saja_details);
            values.put(LOGIN_VILLAGE_LOC, village_loc);

            result = db.insert(TABLE_LOGIN_DATA, null, values);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //For login data save
    public boolean insertswitchprofiledata(String circle_id, String circle_name, String circle_code, String c_loc_type, String saja_id, String saja_name,
                                           String saja_code,String s_loc_type, String role_charge, String role_charge_id, String role_officer, String role_officer_id) {

        long result = -1;
        try {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(SPF_CIRCLE_ID, circle_id);
            values.put(SPF_CIRCLE_NAME, circle_name);
            values.put(SPF_CIRCLE_CODE, circle_code);
            values.put(SPF_C_LOC_TYPE, c_loc_type);
            values.put(SPF_SAJA_ID, saja_id);
            values.put(SPF_SAJA_NAME, saja_name);
            values.put(SPF_SAJA_CODE, saja_code);
            values.put(SPF_S_LOC_TYPE, s_loc_type);
            values.put(SPF_ROLE_CHARGE, role_charge);
            values.put(SPF_ROLE_CHARGE_ID, role_charge_id);
            values.put(SPF_ROLE_OFFICER, role_officer);
            values.put(SPF_ROLE_OFFICER_ID, role_officer_id);

            result = db.insert(TABLE_SWITCH_PROFILE_DATA, null, values);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public JSONArray getSwitchProfileData() {

        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from switch_profile_data ORDER BY id ASC ";

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                String circle_id = cursor.getString(cursor.getColumnIndex("circle_id"));
                String circle_name = cursor.getString(cursor.getColumnIndex("circle_name"));
                String circle_code = cursor.getString(cursor.getColumnIndex("circle_code"));
                String c_loc_type = cursor.getString(cursor.getColumnIndex("c_loc_type"));
                String saja_id = cursor.getString(cursor.getColumnIndex("saja_id"));
                String saja_name = cursor.getString(cursor.getColumnIndex("saja_name"));
                String saja_code = cursor.getString(cursor.getColumnIndex("saja_code"));
                String s_loc_type = cursor.getString(cursor.getColumnIndex("s_loc_type"));
                String role_charge = cursor.getString(cursor.getColumnIndex("role_charge"));
                String role_charge_id = cursor.getString(cursor.getColumnIndex("role_charge_id"));
                String role_officer = cursor.getString(cursor.getColumnIndex("role_officer"));
                String role_officer_id = cursor.getString(cursor.getColumnIndex("role_officer_id"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("circle_id", circle_id);
                    jsonObject1.put("circle_name", circle_name);
                    jsonObject1.put("circle_code", circle_code);
                    jsonObject1.put("c_loc_type", c_loc_type);
                    jsonObject1.put("sajja_id", saja_id);
                    jsonObject1.put("sajja_name", saja_name);
                    jsonObject1.put("sajja_code", saja_code);
                    jsonObject1.put("s_loc_type", s_loc_type);
                    jsonObject1.put("role_charge", role_charge);
                    jsonObject1.put("role_charge_id", role_charge_id);
                    jsonObject1.put("role_officer", role_officer);
                    jsonObject1.put("role_officer_id", role_officer_id);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
            DebugLog.getInstance().d("Switch Profile Data JsonArray" + jsonArray.toString());
        }
        return jsonArray;
    }
}
