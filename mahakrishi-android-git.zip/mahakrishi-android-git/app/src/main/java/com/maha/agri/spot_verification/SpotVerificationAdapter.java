package com.maha.agri.spot_verification;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;

public class SpotVerificationAdapter extends RecyclerView.Adapter<SpotVerificationAdapter.ViewHolder> {

    private Context context;
    private JSONArray spot_verification_drip_bill_data;
    private JSONObject jsonObject;
    private OnMultiRecyclerItemClickListener mListener;

    public SpotVerificationAdapter(Context context, JSONArray spot_verification_drip_bill_data) {
        this.context = context;
        this.spot_verification_drip_bill_data = spot_verification_drip_bill_data;

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView spot_verification_drip_list_titleTV;
        private ImageView spot_verification_drip_list_tick;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            spot_verification_drip_list_titleTV = itemView.findViewById(R.id.spot_verification_drip_list_titleTV);
            spot_verification_drip_list_tick = itemView.findViewById(R.id.spot_verification_drip_list_tick);
        }
    }

    @NonNull
    @Override
    public SpotVerificationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_spot_verification, viewGroup, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull SpotVerificationAdapter.ViewHolder viewHolder, int i) {
        try {
            jsonObject = spot_verification_drip_bill_data.getJSONObject(i);
            viewHolder.spot_verification_drip_list_titleTV.setText(jsonObject.getString("item_name"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (spot_verification_drip_bill_data != null) {
            return spot_verification_drip_bill_data.length();
        } else {
            return 0;
        }
    }


    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SpotVerificationAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SpotVerificationAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }


}
