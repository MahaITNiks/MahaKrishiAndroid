package com.maha.agri.util;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;

import com.maha.agri.activity.common.LoginActivity;
import com.maha.agri.activity.common.SplashActivity;

import java.util.Timer;
import java.util.TimerTask;

public class LogoutTimer extends TimerTask {

    Activity nActivity;

    public LogoutTimer(Activity nActivity) {
        this.nActivity = nActivity;
    }

    @Override
    public void run() {

        //redirect user to login screen
        Intent i = new Intent(nActivity, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        nActivity.startActivity(i);
        nActivity.finish();
    }


}
