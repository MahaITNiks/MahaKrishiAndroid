package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.maha.agri.R;
import com.maha.agri.activity.approve_attendance.AprovAttUserListActivity;
import com.maha.agri.activity.approve_attendance.AttendanceReportActivity;
import com.maha.agri.activity.attendance.AttedanceCalenderActivity;
import com.maha.agri.activity.attendance.AttendanceActivity;
import com.maha.agri.adapter.AttedanceDashboardAdapter;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;

import java.util.ArrayList;

public class AttedanceDashboardActivity extends AppCompatActivity {
    private RecyclerView attendance_dash_recycler_view;
    private ImageView attendance_dash_back_btn,attendance_dashboard_backy;
    ArrayList<String> attendanceDashboardTitle = new ArrayList<String>();
    ArrayList<Integer> attendanceDashboardImage = new ArrayList<Integer>();
    ArrayList<Integer> attendanceDashboardBackground = new ArrayList<Integer>();
    PreferenceManager preferenceManager;
    SharedPref sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attedance_dashboard);
        getSupportActionBar().setTitle("Attendance");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(this);
        sharedPref = new SharedPref(this);
        init();
        defaultConfig();
    }


    private void init() {

        preferenceManager = new PreferenceManager(this);

        attendance_dash_recycler_view = (RecyclerView) findViewById(R.id.attendance_dashboard_rv);
        //attendance_dash_back_btn = (ImageView) findViewById(R.id.attendance_dashboard_back_btn);
        /*attendance_dashboard_backy = (ImageView) findViewById(R.id.attendance_dashboard_backy);
        attendance_dashboard_backy.setClipToOutline(true);*/


        attendance_dash_recycler_view.setLayoutManager(new GridLayoutManager(this,2));

        attendanceDashboardBackground.add(R.drawable.dash_attendance);
        attendanceDashboardBackground.add(R.drawable.dash_task);
        attendanceDashboardBackground.add(R.drawable.dash_assigned_villages);
        attendanceDashboardBackground.add(R.drawable.dash_task_report);
        attendanceDashboardBackground.add(R.drawable.dash_my_profile);

        attendanceDashboardImage.add(R.drawable.appointment);
        attendanceDashboardImage.add(R.drawable.attendence);
        attendanceDashboardImage.add(R.drawable.sync_attendence);
        attendanceDashboardImage.add(R.drawable.report);
        attendanceDashboardImage.add(R.drawable.ic_check_unchek);

        attendanceDashboardTitle.add("Attendance");
        attendanceDashboardTitle.add("Attendance Calendar");
        attendanceDashboardTitle.add("Sync Attendance");
        attendanceDashboardTitle.add("Attendance Report");
        attendanceDashboardTitle.add("Approve Attendance");

        attendance_dash_recycler_view.setAdapter(new AttedanceDashboardAdapter(attendanceDashboardTitle,attendanceDashboardImage, attendanceDashboardBackground,this, preferenceManager));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void defaultConfig() {

        attendance_dash_recycler_view.addOnItemTouchListener(new AttedanceDashboardAdapter.RecyclerTouchListener(this, attendance_dash_recycler_view, new AttedanceDashboardAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                switch (position) {
                    case 0:
                        Intent attendance = new Intent(AttedanceDashboardActivity.this, AttendanceActivity.class);
                        startActivity(attendance);
                        break;

                    case 1:
                        Intent taskmanager = new Intent(AttedanceDashboardActivity.this, AttedanceCalenderActivity.class);
                        startActivity(taskmanager);
                        break;

                    case 2:
                        Intent syncattendance = new Intent(AttedanceDashboardActivity.this, SyncAttendanceActivity.class);
                        startActivity(syncattendance);
                        break;

                    case 3:
                        Intent attendancelist = new Intent(AttedanceDashboardActivity.this, AttendanceReportActivity.class);
                        startActivity(attendancelist);
                        break;

                    case 4:
                        Intent syncAttendance = new Intent(AttedanceDashboardActivity.this, AprovAttUserListActivity.class);
                        startActivity(syncAttendance);
                        break;

                }
            }



            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        /*attendance_dash_back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backintent = new Intent(AttedanceDashboardActivity.this, AADashboardActivity.class);
                startActivity(backintent);
            }
        });*/


    }

    @Override
    protected void onResume() {
        super.onResume();

    }

}
