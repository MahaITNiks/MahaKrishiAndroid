package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBCommunityFarmPond8Activity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView mb_pond8_obsdate,mb_pond8_benificiary_name,mb_pond8_villagetv,mb_pond8_talukatv,mb_pond8_districttv,mb_pond8_surveyno,mb_pond8_vargvari,
            mb_pond8_bab1tv,mb_pond8_bab2tv,mb_pond8_bab3tv,mb_pond8_previous_accepteddate,mb_pond8_previous_dimensions1tv,mb_pond8_previous_dimensions2tv,
            mb_pond8_previous_dimensions3tv;

    private EditText mb_pond8_capacity,mb_pond8_dimensions,mb_pond8_para1,mb_pond8_para2,mb_pond8_para3,mb_pond8_para4,mb_pond8_para5,mb_pond8_para6,
            mb_pond8_para7,mb_pond8_para8,mb_pond8_para9;

    private ImageView mb_pond8_obsdate_iv;

    private RadioGroup mb_pond8_rg;
    private RadioButton mb_pond8_yes,mb_pond8_no;
    private CheckBox mb_pond8_checkbox;
    private Button mb_pond8_save;

    private String type="0";
    private SweetAlertDialog sweetAlertDialog;
    private int mYear, mMonth, mDay;
    private DatePickerDialog mb_pond8_datepicker;
    private String mb_pond8_date="0",farmer_name="";
    private PreferenceManager preferenceManager;
    private int  district_id,taluka_id,village_id,farmer_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_community_farm_pond8);
        getSupportActionBar().setTitle("MB Community Farm Pond Form 8");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBCommunityFarmPond8Activity.this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        farmer_name = intent.getStringExtra("farmer_name");
        ids();
        functions();
    }

    private void ids(){
        //Textview
        mb_pond8_obsdate = (TextView) findViewById(R.id.mb_pond8_obsdate);
        mb_pond8_benificiary_name = (TextView) findViewById(R.id.mb_pond8_benificiary_name);
        mb_pond8_benificiary_name.setText(farmer_name);
        mb_pond8_villagetv = (TextView) findViewById(R.id.mb_pond8_villagetv);
        mb_pond8_talukatv = (TextView) findViewById(R.id.mb_pond8_talukatv);
        mb_pond8_districttv = (TextView) findViewById(R.id.mb_pond8_districttv);
        mb_pond8_surveyno = (TextView) findViewById(R.id.mb_pond8_surveyno);
        mb_pond8_vargvari = (TextView) findViewById(R.id.mb_pond8_vargvari);
        mb_pond8_bab1tv = (TextView) findViewById(R.id.mb_pond8_bab1tv);
        mb_pond8_bab2tv = (TextView) findViewById(R.id.mb_pond8_bab2tv);
        mb_pond8_bab3tv = (TextView) findViewById(R.id.mb_pond8_bab3tv);
        mb_pond8_previous_accepteddate = (TextView) findViewById(R.id.mb_pond8_previous_accepteddate);
        mb_pond8_previous_dimensions1tv = (TextView) findViewById(R.id.mb_pond8_previous_dimensions1tv);
        mb_pond8_previous_dimensions2tv = (TextView) findViewById(R.id.mb_pond8_previous_dimensions2tv);
        mb_pond8_previous_dimensions3tv = (TextView) findViewById(R.id.mb_pond8_previous_dimensions3tv);
        //Edittext
        mb_pond8_capacity = (EditText) findViewById(R.id.mb_pond8_capacity);
        mb_pond8_dimensions = (EditText) findViewById(R.id.mb_pond8_dimensions);
        mb_pond8_para1 = (EditText) findViewById(R.id.mb_pond8_para1);
        mb_pond8_para2 = (EditText) findViewById(R.id.mb_pond8_para2);
        mb_pond8_para3 = (EditText) findViewById(R.id.mb_pond8_para3);
        mb_pond8_para4 = (EditText) findViewById(R.id.mb_pond8_para4);
        mb_pond8_para5 = (EditText) findViewById(R.id.mb_pond8_para5);
        mb_pond8_para6 = (EditText) findViewById(R.id.mb_pond8_para6);
        mb_pond8_para7 = (EditText) findViewById(R.id.mb_pond8_para7);
        mb_pond8_para8 = (EditText) findViewById(R.id.mb_pond8_para8);
        mb_pond8_para9 = (EditText) findViewById(R.id.mb_pond8_para9);
        //Imageview
        //mb_pond8_obsdate_iv = (ImageView) findViewById(R.id.mb_pond8_obsdate_iv);
        //Radiogroup
        mb_pond8_rg = (RadioGroup) findViewById(R.id.mb_pond8_rg);
        //Radiobutton
        mb_pond8_yes = (RadioButton) findViewById(R.id.mb_pond8_yes);
        mb_pond8_no = (RadioButton) findViewById(R.id.mb_pond8_no);

        mb_pond8_save = (Button) findViewById(R.id.mb_pond8_save);
        mb_pond8_checkbox = (CheckBox) findViewById(R.id.mb_pond8_checkbox);
        mb_pond8_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        mb_pond8_obsdate.setText(mb_pond8_date);
    }

    private void functions(){

       /* mb_pond8_obsdate_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_pond8_date_service();
            }
        });*/

        mb_pond8_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond8_yes:
                        mb_pond8_yes.setChecked(true);
                        type = "1";
                        break;

                    case R.id.mb_pond8_no:
                        mb_pond8_no.setChecked(true);
                        type = "2";
                        break;
                }
            }
        });

        mb_pond8_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MBCommunityFarmPond8Activity.this,MBCommunityFarmPond9Activity.class);
                startActivity(intent);
                //mb_pond8_save_service();
            }
        });
    }

    private void mb_pond8_date_service(){

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        mb_pond8_datepicker = new DatePickerDialog(MBCommunityFarmPond8Activity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        mb_pond8_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        mb_pond8_obsdate.setText(mb_pond8_date);


                    }
                }, mYear, mMonth, mDay);

        mb_pond8_datepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        mb_pond8_datepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        mb_pond8_datepicker.show();
    }

    private void mb_pond8_save_service(){
        if(mb_pond8_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select दिनांक", Toast.LENGTH_SHORT).show();
        }else if(type.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "शेततळ्याच्या आकारमानानुसार शेततळे खोदकामाची मोजमापे, खोदाईच्या मार्गदर्शक सूचनेप्रमाणे व मापन पुस्तिकेतील नोंदी नुसार आहेत/नाहीत ?", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_capacity.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter क्षमता", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_dimensions.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter आकारमान", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para1.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter side length at one side", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para2.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter side length adjoining side", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para3.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter depth of cut", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para4.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter side slope", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para5.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter side length at bottom", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para6.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter bund height with free board", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para7.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter total height of the tank", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para8.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter top width of the bund", Toast.LENGTH_SHORT).show();
        }else if(mb_pond8_para9.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter bottom area", Toast.LENGTH_SHORT).show();
        }else if(!mb_pond8_checkbox.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept the terms",Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("datembcommpond8", mb_pond8_date);
                param.put("farmer_name", farmer_id);
                param.put("village_id", village_id);
                param.put("taluka_id", taluka_id);
                param.put("district_id", district_id);
                param.put("survey_no", "0");
                param.put("vargvari", "0");
                param.put("bab1", "0");
                param.put("bab2", "0");
                param.put("bab3", "0");
                param.put("previous_date", "0");
                param.put("pre_demin1", "0");
                param.put("pre_demin2", "0");
                param.put("pre_demin3", "0");
                param.put("rg", type);
                param.put("capacity", mb_pond8_capacity.getText().toString().trim());
                param.put("dimen", mb_pond8_dimensions.getText().toString().trim());
                param.put("para1", mb_pond8_para1.getText().toString().trim());
                param.put("para2", mb_pond8_para2.getText().toString().trim());
                param.put("para3", mb_pond8_para3.getText().toString().trim());
                param.put("para4", mb_pond8_para4.getText().toString().trim());
                param.put("para5", mb_pond8_para5.getText().toString().trim());
                param.put("para6", mb_pond8_para6.getText().toString().trim());
                param.put("para7", mb_pond8_para7.getText().toString().trim());
                param.put("para8", mb_pond8_para8.getText().toString().trim());
                param.put("para9", mb_pond8_para9.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_8_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Community Farm Pond Form 8");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
