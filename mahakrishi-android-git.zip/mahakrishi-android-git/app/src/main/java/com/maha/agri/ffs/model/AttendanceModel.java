/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class AttendanceModel {

    private int id;
    private String first_name;
    private String last_name;
    private String mobile;
    private String designation;
    private int is_selected;
    private JSONObject jsonObject;


    public AttendanceModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getId() {
        id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "id");
        return id;
    }

    public String getFirst_name() {
        first_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "first_name");
        return first_name;
    }

    public String getLast_name() {
        last_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "last_name");
        return last_name;
    }

    public String getMobile() {
        mobile = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "mobile");
        return mobile;
    }

    public String getDesignation() {
        designation = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "designation");
        return designation;
    }

    public int getIs_selected() {
        is_selected = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "is_selected");
        return is_selected;
    }

    public void setIs_selected(int is_selected) {
        this.is_selected = is_selected;
    }


}
