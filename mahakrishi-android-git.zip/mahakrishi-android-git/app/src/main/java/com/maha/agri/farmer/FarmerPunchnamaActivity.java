package com.maha.agri.farmer;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.abdeveloper.library.MultiSelectDialog;
import com.abdeveloper.library.MultiSelectModel;
import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerPunchnamaActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView farmer_punchnama_year,farmer_punchnama_district,farmer_punchnama_taluka,farmer_punchnama_village,farmer_punchnama_name_of_the_scheme,
            farmer_punchnama_season,farmer_punchnama_crop_type,farmer_punchnama_name_of_the_crop,farmer_punchnama_type_of_damage,
            farmer_punchnama_causes_of_damage,farmer_punchnama_nuksanicha_dinaak_tv,farmer_punchnama_horti_crop_type_tv;

    private RadioGroup sheticha_prakar_radio_group,neshirg_apati_rg,crop_insurance_rg;

    private RadioButton bagyati_radio_btn,jirayati_radio_btn,neshirg_apati_yes_radio_btn,neshirg_apati_no_radio_btn,
            crop_insu_yes_rb,crop_insu_no_rb;

    private EditText farmer_punchnama_edt_survey_no_group_no,farmer_panchnama_crop_name_edt,farmer_punchnama_lagwadi_ekkar_edt,
            farmer_punchnama_lagwadi_guntha_edt,farmer_punchnama_total_lagwadi, farmer_punchnama_pikvima_ekkar_edt,
            farmer_punchnama_pikvima_guntha_edt,farmer_punchnama_total_pikvima,farmer_punchnama_andajeet_ekkar_edt,
            farmer_punchnama_andajeet_guntha_edt,farmer_punchnama_total_baghadheet,farmer_punchnama_nuksanicha_takkewari_edt,
            farmer_punchnama_Specify_disease,farmer_punchnama_Specify_Pest;

    private Button farmer_punchnama_submit_btn;

    private LinearLayout yojna_ll,pikache_prakar_ll,farmer_panchnama_horti_type,rogache_naav_ll,keedicha_naav_ll;

    private ImageView farmer_punchnama_photo_1,farmer_punchnama_photo_2,farmer_punchnama_nuksanicha_dinaak_iv,nuksanicha_notice_dinaak_iv;

    private String crop_insurance_name;


    private JSONArray year_list, district_list, taluka_list, village_list, farm_type_list, crop_list, damage_reason_list, damage_type_list, scheme_list,
            season_list, crop_type_list,horti_crop_list;

    ArrayList<String> VillageName;
    ArrayList<String> DamageReason;
    ArrayList<MultiSelectModel> list_of_damage= new ArrayList<>();
    HashMap<Integer,String> village_map = new HashMap<>();

    private String yearname,district_name,taluka_name,village_name,farm_type_name,crop_list_name,damage_type_name,scheme_name,season_name,croptypename,
            farmer_year_name_str,damage_name;
    private String farmID="0";
    private String district_list_str,taluka_list_str,village_list_str,farmer_last_name,farmer_middle_name,farmer_first_name,edt_survey_no_group_no_str,
            farmer_fullname,currentTime,imagePath,imagePath1;
    private String  crop_insurance_ID = "",neshirg_apti_id = "";
    private int yearID = 0, districtID_int = 0,talukaID_int = 0,villageID_int = 0, croplistID = 0, damageReasonID = 0, damageTypeID = 0, schemeID = 0,
            seasonID = 0, croptypeID = 0, horti_crop_id = 0;


    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    static final Integer CAMERA1 = 0x6;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private File photoFile1 = null;
    private Transformation transformation;
    private int responseID;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String activityID = "";

    private int lagwadi_ekkar_str,lagwadi_guntha_str,pikvima_ekkar_str,pikvima_guntha_str,andajeet_ekkar_str,andajeet_guntha_str,nuksanicha_int;

    private LinearLayout farmer_damage_reason_ll, pik_vima_saranjheet_ll, farmer_panchanam_crop_name_ll,neshirg_apati_ll;
    View parentLayout;

    private int mYear, mMonth, mDay;
    private String nuksanicha_dinaak = "",nuksanicha_notice_dinaak,data;
    private DatePickerDialog nuksanidatePickerDialog,nuksani_notice_date_picker_dialog;

    private int one_ekkar = 100;
    private String total_lagwadi_str="0",total_pikvima_str="0",total_baghadheet_str="=0",nuksanicka_takkewari_str="0",lagwadi_ekkar_value="0",
            lagwadi_guntha_value="0",pikvima_ekkar_value="0",pikvima_guntha_value="0",andajeet_ekkar_value="0",andajeet_guntha_value = "0",
            nuksanicha_takkeri_str="0",Damage_reason_id ="0";
    private int total_lagwadi_int,total_pikvima_int,total_baghadheet_int;

    private SweetAlertDialog sweetAlertDialog;

    private ArrayList<Integer> damage_reason_selectedIds;
    private ArrayList<String> damage_reason_selectedNames;
    private String Damage_reason_name = "", first_image_url = "", second_image_url = "",damage_reason_id="";
    private AppLocationManager appLocationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_punchnama);
        getSupportActionBar().setTitle("पंचनामा");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerPunchnamaActivity.this);
        sharedPref = new SharedPref(FarmerPunchnamaActivity.this);
        parentLayout = findViewById(android.R.id.content);
        //farmer_fullname = preferenceManager.getPreferenceValues(Preference_Constant.FIRST_NAME + Preference_Constant.MIDDLE_NAME + Preference_Constant.LAST_NAME);
        //activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        farmer_last_name = preferenceManager.getPreferenceValues(Preference_Constant.LAST_NAME);
        farmer_middle_name = preferenceManager.getPreferenceValues(Preference_Constant.MIDDLE_NAME);
        farmer_first_name = preferenceManager.getPreferenceValues(Preference_Constant.FIRST_NAME);
        farmer_fullname = farmer_first_name + "  " + farmer_middle_name + "  " + farmer_last_name;

        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();

        if(isNetworkAvailable()){
            init();
        }else{
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void init(){
        //Spinner
        farmer_punchnama_year = (TextView) findViewById(R.id.farmer_punchnama_year);
        farmer_punchnama_year.setEnabled(false);
        farmer_punchnama_district = (TextView) findViewById(R.id.farmer_punchnama_district);
        farmer_punchnama_taluka = (TextView) findViewById(R.id.farmer_punchnama_taluka);
        farmer_punchnama_village = (TextView) findViewById(R.id.farmer_punchnama_village);
        farmer_punchnama_season = (TextView) findViewById(R.id.farmer_punchnama_season);
        farmer_punchnama_name_of_the_scheme = (TextView) findViewById(R.id.farmer_punchnama_name_of_the_scheme);
        farmer_punchnama_crop_type = (TextView) findViewById(R.id.farmer_punchnama_crop_type);
        farmer_punchnama_name_of_the_crop = (TextView) findViewById(R.id.farmer_punchnama_name_of_the_crop);
        farmer_punchnama_type_of_damage = (TextView) findViewById(R.id.farmer_punchnama_type_of_damage);
        farmer_punchnama_causes_of_damage = (TextView) findViewById(R.id.farmer_punchnama_causes_of_damage);
        farmer_punchnama_nuksanicha_dinaak_tv = (TextView)findViewById(R.id.farmer_punchnama_nuksanicha_dinaak_tv);
        farmer_punchnama_horti_crop_type_tv = (TextView)findViewById(R.id.farmer_punchnama_horti_crop_type_tv);

        //TextView
        //farmer_fullname_tv = (TextView) findViewById(R.id.txt_vw_full_name_of_farmer);

        //Edit Text
        farmer_punchnama_edt_survey_no_group_no = (EditText) findViewById(R.id.farmer_punchnama_edt_survey_no_group_no);
        farmer_panchnama_crop_name_edt = (EditText) findViewById(R.id.farmer_panchnama_crop_name_edt);
        farmer_punchnama_lagwadi_ekkar_edt = (EditText) findViewById(R.id.farmer_punchnama_lagwadi_ekkar_edt);
        farmer_punchnama_lagwadi_guntha_edt = (EditText) findViewById(R.id.farmer_punchnama_lagwadi_guntha_edt);
        farmer_punchnama_pikvima_ekkar_edt = (EditText) findViewById(R.id.farmer_punchnama_pikvima_ekkar_edt);
        farmer_punchnama_pikvima_guntha_edt = (EditText) findViewById(R.id.farmer_punchnama_pikvima_guntha_edt);
        farmer_punchnama_andajeet_ekkar_edt = (EditText) findViewById(R.id.farmer_punchnama_andajeet_ekkar_edt);
        farmer_punchnama_andajeet_guntha_edt = (EditText) findViewById(R.id.farmer_punchnama_andajeet_guntha_edt);
        farmer_punchnama_Specify_disease = (EditText) findViewById(R.id.farmer_punchnama_Specify_disease);
        farmer_punchnama_Specify_Pest = (EditText) findViewById(R.id.farmer_punchnama_Specify_Pest);
        farmer_punchnama_nuksanicha_takkewari_edt = (EditText)findViewById(R.id.farmer_punchnama_nuksanicha_takkewari_edt);
        farmer_punchnama_total_lagwadi = (EditText)findViewById(R.id.farmer_punchnama_total_lagwadi);
        farmer_punchnama_total_pikvima = (EditText)findViewById(R.id.farmer_punchnama_total_pikvima);
        farmer_punchnama_total_baghadheet = (EditText)findViewById(R.id.farmer_punchnama_total_baghadheet);

        //nuksanicha_suchna_dilecha_dinaak_tv = (TextView)findViewById(R.id.nuksanicha_suchna_dilecha_dinaak_tv);

        //RadioGroup and RadioButton
        crop_insurance_rg = (RadioGroup) findViewById(R.id.crop_insurance_rg);
        sheticha_prakar_radio_group = (RadioGroup)findViewById(R.id.sheticha_prakar_radio_group);
        neshirg_apati_rg = (RadioGroup)findViewById(R.id.neshirg_apati_rg);
        neshirg_apati_yes_radio_btn = (RadioButton)findViewById(R.id.neshirg_apati_yes_radio_btn) ;
        neshirg_apati_no_radio_btn = (RadioButton)findViewById(R.id.neshirg_apati_no_radio_btn);
        crop_insu_yes_rb = (RadioButton) findViewById(R.id.crop_insu_yes_radio_btn);
        crop_insu_no_rb = (RadioButton) findViewById(R.id.crop_insu_no_radio_btn);
        bagyati_radio_btn = (RadioButton)findViewById(R.id.bagyati_radio_btn);
        jirayati_radio_btn = (RadioButton)findViewById(R.id.jirayati_radio_btn);
        crop_insu_yes_rb.setChecked(false);
        crop_insu_no_rb.setChecked(false);
        bagyati_radio_btn.setChecked(false);
        jirayati_radio_btn.setChecked(false);
        neshirg_apati_yes_radio_btn.setChecked(false);
        neshirg_apati_no_radio_btn.setChecked(false);

        //Layout
        yojna_ll = (LinearLayout) findViewById(R.id.farmer_punchnama_yojna_ll);
        pikache_prakar_ll = (LinearLayout) findViewById(R.id.farmer_punchnama_pikache_prakar_ll);
        farmer_panchnama_horti_type = (LinearLayout) findViewById(R.id.farmer_panchnama_horti_type);
        rogache_naav_ll = (LinearLayout)findViewById(R.id.farmer_punchnama_rogache_naav_ll);
        keedicha_naav_ll = (LinearLayout)findViewById(R.id.farmer_punchnama_keedicha_naav_ll);
        farmer_damage_reason_ll = (LinearLayout)findViewById(R.id.farmer_damage_reason_ll);
        pik_vima_saranjheet_ll = (LinearLayout)findViewById(R.id.farmer_punchnama_pik_vima_sarancheet_ll);
        farmer_panchanam_crop_name_ll = (LinearLayout)findViewById(R.id.farmer_panchanam_crop_name_ll);
        neshirg_apati_ll = (LinearLayout)findViewById(R.id.farmer_punchnama_neshirg_apati_ll);

        //Button
        farmer_punchnama_submit_btn = (Button) findViewById(R.id.farmer_punchnama_submit_btn);

        farmer_punchnama_photo_1 = (ImageView)findViewById(R.id.farmer_panchnama_photo_1);
        farmer_punchnama_nuksanicha_dinaak_iv = (ImageView)findViewById(R.id.farmer_punchnama_nuksanicha_dinaak_iv);
        farmer_punchnama_photo_2 = (ImageView)findViewById(R.id.farmer_punchnama_photo_2);
        //nuksanicha_notice_dinaak_iv = (ImageView)findViewById(R.id.nuksanicha_notice_dinaak_iv);

        farmer_punchnama_nuksanicha_dinaak_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nuk_sani_date_Picker();
            }
        });

        currentTime = ApUtil.getCurrentTimeStamp();

        PunchnamaYearWebservice();
        District_Service();
        Farm_type_Service();


        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        year_list = new JSONArray();
        district_list = new JSONArray();
        taluka_list = new JSONArray();
        village_list = new JSONArray();
        DamageReason = new ArrayList<>();

        farmer_punchnama_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (year_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(year_list, 1,"Select Year", "name", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                } else {
                    PunchnamaYearWebservice();
                }
            }
        });

        farmer_punchnama_district.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(district_list == null) {
                    District_Service();
                }else{
                    AppUtility.getInstance().showListDialogIndex(district_list, 2, "Select District", "district_name", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                }
            }
        });

        farmer_punchnama_taluka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(taluka_list == null) {
                    Taluka_Service(districtID_int);
                }else{
                    AppUtility.getInstance().showListDialogIndex(taluka_list, 3, "Select Taluka", "taluka_name", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                }
            }
        });

        farmer_punchnama_village.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(village_list == null){
                    Village_Service(talukaID_int);
                }else{
                    AppUtility.getInstance().showListDialogIndex(village_list, 4, "Select Village", "village_name", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                }
            }
        });

        farmer_punchnama_name_of_the_scheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(scheme_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(scheme_list, 6, "Select Scheme", "name_mr", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                }else{
                    Scheme_Service();
                }
            }
        });

        farmer_punchnama_season.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    toast.show();
                } else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select scheme", Toast.LENGTH_SHORT);
                    toast.show();
                } else {
                    if (season_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(season_list, 7, "Select Season", "name_mr", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                    } else {
                        Season_Service(crop_insurance_ID, schemeID);
                    }
                }
            }
        });

        farmer_punchnama_crop_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(seasonID==0){
                    Toast toast= Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    if (crop_type_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(crop_type_list, 8, "Select crop type", "name_mr", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                    } else {
                        CropType_Service(seasonID);
                    }
                }
            }
        });

        farmer_punchnama_horti_crop_type_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(croptypeID==0){
                    Toast toast= Toast.makeText(getApplicationContext(), "Select crop type", Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    if (horti_crop_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(horti_crop_list, 15, "Select Horticulture type", "name_marathi", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                    } else {
                        Horti_crop_type_service(croptypeID);
                    }
                }
            }
        });

        farmer_punchnama_name_of_the_crop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select scheme", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }else if (seasonID == 0) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }else if (crop_insurance_ID.equalsIgnoreCase("0") && croptypeID == 0) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select crop type", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }else if(crop_list.length()==0){
                    Toast.makeText(FarmerPunchnamaActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();
                }else {
                    if (crop_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(crop_list, 9, "Select Crop", "crop_marathi", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                    }
                    else{
                        Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
                    }
                }
            }
        });

        farmer_punchnama_type_of_damage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast= Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else {
                    if (damage_type_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(damage_type_list, 11, "Select Damage type", "name_mr", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                    } else {
                        Damage_Type(crop_insurance_ID);

                    }
                }
            }
        });

        farmer_punchnama_causes_of_damage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*if(damage_reason_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(damage_reason_list, 10, "Select damage reason", "name_mr", "id", FarmerPunchnamaActivity.this, FarmerPunchnamaActivity.this);
                }else{
                    Damage_Reason();
                }*/
                MultiSelectDialog multiSelectDialog = new MultiSelectDialog()
                        .title("Select")
                        .titleSize(25)
                        .positiveText("Done")
                        .negativeText("Cancel")
                        .setMinSelectionLimit(1)
                        .setMaxSelectionLimit(list_of_damage.size())
                        .multiSelectList(list_of_damage)
                        .onSubmit(new MultiSelectDialog.SubmitCallbackListener() {
                            @Override
                            public void onSelected(ArrayList<Integer> selectedIds, ArrayList<String> selectedNames, String dataString) {
                                damage_reason_selectedIds = selectedIds;
                                damage_reason_id = String.valueOf(damage_reason_selectedIds);
                                damage_reason_selectedNames = selectedNames;
                                Damage_reason_name = dataString;
                                farmer_punchnama_causes_of_damage.setText(dataString);
                                if(selectedNames.contains("किडीचा प्रादुर्भाव") & selectedNames.contains("रोगाचा प्रादुर्भाव")){
                                    rogache_naav_ll.setVisibility(View.VISIBLE);
                                    keedicha_naav_ll.setVisibility(View.VISIBLE);
                                    farmer_punchnama_Specify_Pest.setText("");
                                    farmer_punchnama_Specify_disease.setText("");
                                }else if (selectedNames.contains("रोगाचा प्रादुर्भाव")){
                                    keedicha_naav_ll.setVisibility(View.GONE);
                                    rogache_naav_ll.setVisibility(View.VISIBLE);
                                    farmer_punchnama_Specify_Pest.setText("");
                                    farmer_punchnama_Specify_disease.setText("");
                                }else if(selectedNames.contains("किडीचा प्रादुर्भाव")){
                                    keedicha_naav_ll.setVisibility(View.VISIBLE);
                                    rogache_naav_ll.setVisibility(View.GONE);
                                    farmer_punchnama_Specify_Pest.setText("");
                                    farmer_punchnama_Specify_disease.setText("");
                                }else{
                                    keedicha_naav_ll.setVisibility(View.GONE);
                                    rogache_naav_ll.setVisibility(View.GONE);
                                    farmer_punchnama_Specify_Pest.setText("");
                                    farmer_punchnama_Specify_disease.setText("");
                                }
                            }

                            @Override
                            public void onCancel() {

                            }


                        });

                multiSelectDialog.show(getSupportFragmentManager(), "multiSelectDialog");
            }
        });

        sheticha_prakar_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.bagyati_radio_btn:
                        bagyati_radio_btn.setChecked(true);
                        farmID = "1";

                        break;

                    case R.id.jirayati_radio_btn:
                        jirayati_radio_btn.setChecked(true);
                        farmID = "2";
                        break;


                }
            }
        });

        crop_insurance_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.crop_insu_yes_radio_btn:
                        crop_insu_yes_rb.setChecked(true);
                        neshirg_apati_yes_radio_btn.setChecked(false);
                        neshirg_apati_no_radio_btn.setChecked(false);
                        crop_insurance_name = crop_insu_yes_rb.getText().toString();
                        crop_insurance_ID = "1";
                        yojna_ll.setVisibility(View.VISIBLE);
                        neshirg_apati_ll.setVisibility(View.VISIBLE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        pik_vima_saranjheet_ll.setVisibility(View.VISIBLE);
                        pikache_prakar_ll.setVisibility(View.GONE);
                        farmer_damage_reason_ll.setVisibility(View.GONE);
                        farmer_panchnama_horti_type.setVisibility(View.GONE);
                        farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
                        Scheme_Service();
                        Damage_Type(crop_insurance_ID);
                        Damage_Reason();
                        clear_data();
                        break;

                    case R.id.crop_insu_no_radio_btn:
                        crop_insu_no_rb.setChecked(true);
                        neshirg_apati_yes_radio_btn.setChecked(true);
                        neshirg_apati_no_radio_btn.setChecked(true);
                        crop_insurance_name = crop_insu_no_rb.getText().toString();
                        crop_insurance_ID = "0";
                        yojna_ll.setVisibility(View.GONE);
                        pik_vima_saranjheet_ll.setVisibility(View.GONE);
                        neshirg_apati_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        farmer_panchnama_horti_type.setVisibility(View.GONE);
                        pikache_prakar_ll.setVisibility(View.VISIBLE);
                        farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                        farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
                        clear_data();
                        schemeID = 0;
                        Season_Service(crop_insurance_ID,schemeID);
                        Damage_Type(crop_insurance_ID);
                        Damage_Reason();
                        break;
                }
            }
        });

        neshirg_apati_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.neshirg_apati_yes_radio_btn:
                        neshirg_apati_yes_radio_btn.setChecked(true);
                        neshirg_apti_id = "1";
                        farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        farmer_punchnama_causes_of_damage.setText("Select");

                        break;

                    case R.id.neshirg_apati_no_radio_btn:
                        neshirg_apati_no_radio_btn.setChecked(true);
                        neshirg_apti_id = "0";
                        farmer_damage_reason_ll.setVisibility(View.GONE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        farmer_punchnama_causes_of_damage.setText("Select");
                        break;


                }
            }
        });

        farmer_punchnama_photo_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    takeImageFromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }

                }

            }
        });

        farmer_punchnama_photo_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if((ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerPunchnamaActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    takeImageFromCameraUri1();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        farmer_punchnama_lagwadi_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                lagwadi_ekkar_value = farmer_punchnama_lagwadi_ekkar_edt.getText().toString().trim();
                if(!lagwadi_ekkar_value.equalsIgnoreCase("")){
                    lagwadi_ekkar_str = Integer.parseInt(s.toString());
                    total_lagwadi_str = String.valueOf(lagwadi_ekkar_str * one_ekkar + lagwadi_guntha_str);
                    total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                    farmer_punchnama_total_lagwadi.setText(total_lagwadi_str);

                }else {
                    farmer_punchnama_total_lagwadi.setText("");
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        farmer_punchnama_lagwadi_guntha_edt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                lagwadi_guntha_value = farmer_punchnama_lagwadi_guntha_edt.getText().toString();
                if (!lagwadi_guntha_value.equalsIgnoreCase("")) {
                    lagwadi_guntha_str = Integer.valueOf(s.toString());
                    if (lagwadi_guntha_str < 100) {
                        total_lagwadi_str = String.valueOf(lagwadi_ekkar_str * one_ekkar + lagwadi_guntha_str);
                        farmer_punchnama_total_lagwadi.setText(total_lagwadi_str);
                        total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                    } else {
                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        farmer_punchnama_lagwadi_guntha_edt.setText("");
                                        farmer_punchnama_total_lagwadi.setText("");
                                    }
                                })
                                .show();
                    }
                }else {
                    farmer_punchnama_total_lagwadi.setText("");
                }

            }
        });

        farmer_punchnama_pikvima_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pikvima_ekkar_value = farmer_punchnama_pikvima_ekkar_edt.getText().toString().trim();

                if (pikvima_ekkar_value.equalsIgnoreCase("")){
                    pikvima_ekkar_value="0";
                }

                else if(!pikvima_ekkar_value.equalsIgnoreCase("")){
                    pikvima_ekkar_str = Integer.parseInt(pikvima_ekkar_value);
                    total_pikvima_str = String.valueOf(pikvima_ekkar_str * one_ekkar + pikvima_guntha_str);
                    total_pikvima_int = Integer.valueOf(total_pikvima_str);
                    if (total_pikvima_int > total_lagwadi_int) {
                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता काम नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        farmer_punchnama_total_pikvima.setText("");
                                        farmer_punchnama_pikvima_ekkar_edt.setText("");
                                        pikvima_ekkar_str=0;
                                        farmer_punchnama_pikvima_guntha_edt.setText("");
                                        pikvima_guntha_str=0;
                                    }
                                })
                                .show();

                    } else {
                        pikvima_ekkar_str = Integer.parseInt(s.toString());
                        farmer_punchnama_total_pikvima.setText(total_pikvima_str);
                    }

                }else {
                    farmer_punchnama_total_pikvima.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {



            }
        });

        farmer_punchnama_pikvima_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pikvima_guntha_value = farmer_punchnama_pikvima_guntha_edt.getText().toString();

                if (pikvima_guntha_value.equalsIgnoreCase("")){
                    pikvima_guntha_str=0;
                }

                else if (!pikvima_guntha_value.equalsIgnoreCase("")) {

                    pikvima_guntha_str = Integer.parseInt(pikvima_guntha_value);

                    if (pikvima_guntha_str < 100) {
                        total_pikvima_str = String.valueOf(pikvima_ekkar_str * one_ekkar + pikvima_guntha_str);
                        total_pikvima_int = Integer.valueOf(total_pikvima_str);

                        if (total_pikvima_int > total_lagwadi_int) {
                            sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता काम नये");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            sDialog.dismissWithAnimation();
                                            farmer_punchnama_total_pikvima.setText("");
                                            farmer_punchnama_pikvima_ekkar_edt.setText("");
                                            farmer_punchnama_pikvima_guntha_edt.setText("");
                                            total_pikvima_int=0;
                                            pikvima_ekkar_str=0;
                                            pikvima_guntha_str=0;

                                        }
                                    })
                                    .show();

                        } else {
                            farmer_punchnama_total_pikvima.setText(total_pikvima_str);
                        }
                    } else {
                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        farmer_punchnama_total_pikvima.setText("");
                                        farmer_punchnama_pikvima_guntha_edt.setText("");
                                        pikvima_guntha_str=0;
                                    }
                                })
                                .show();
                    }

                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        farmer_punchnama_andajeet_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                andajeet_ekkar_value = farmer_punchnama_andajeet_ekkar_edt.getText().toString().trim();
                if(!andajeet_ekkar_value.equalsIgnoreCase("")){
                    andajeet_ekkar_str = Integer.parseInt(andajeet_ekkar_value);
                    total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                    total_baghadheet_int = Integer.valueOf(total_baghadheet_str);
                    if (total_baghadheet_int > total_lagwadi_int) {

                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा अंदाजीत बाधित क्षेत्र अधिक असता काम नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        farmer_punchnama_total_baghadheet.setText("");
                                        farmer_punchnama_andajeet_ekkar_edt.setText("");
                                        farmer_punchnama_andajeet_guntha_edt.setText("");
                                        andajeet_ekkar_str=0;
                                        andajeet_guntha_str=0;
                                    }
                                })
                                .show();

                    } else {
                        farmer_punchnama_total_baghadheet.setText(total_baghadheet_str);
                        //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                        //farmer_punchnama_nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");
                    }
                }else{
                    farmer_punchnama_total_baghadheet.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {



            }
        });

        farmer_punchnama_andajeet_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                andajeet_guntha_value = farmer_punchnama_andajeet_guntha_edt.getText().toString();


                if (!andajeet_guntha_value.equalsIgnoreCase("")) {
                    andajeet_guntha_str = Integer.parseInt(andajeet_guntha_value);
                    if (andajeet_guntha_str < 100) {
                        total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                        total_baghadheet_int = Integer.valueOf(total_baghadheet_str);

                        if (total_baghadheet_int > total_lagwadi_int) {

                            sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("एकून लागवडी खालील क्षेत्रा पेक्षा अंदाजीत बाधित क्षेत्र अधिक असता काम नये");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            sDialog.dismissWithAnimation();
                                            farmer_punchnama_total_baghadheet.setText("");
                                            farmer_punchnama_nuksanicha_takkewari_edt.setText("");
                                            farmer_punchnama_andajeet_ekkar_edt.setText("");
                                            farmer_punchnama_andajeet_guntha_edt.setText("");
                                            total_baghadheet_int=0;
                                            andajeet_ekkar_str=0;
                                            andajeet_guntha_str=0;
                                        }
                                    })
                                    .show();

                        } else {
                            farmer_punchnama_total_baghadheet.setText(total_baghadheet_str);
                            //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                            //farmer_punchnama_nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");

                        }
                    } else {

                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        farmer_punchnama_andajeet_guntha_edt.setText("");
                                        farmer_punchnama_nuksanicha_takkewari_edt.setText("");
                                    }
                                })
                                .show();

                    }

                }/*else {
                        farmer_punchnama_total_baghadheet.setText("");
                        farmer_punchnama_nuksanicha_takkewari_edt.setText("");
                    }*/
            }


            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        farmer_punchnama_nuksanicha_takkewari_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                nuksanicka_takkewari_str = farmer_punchnama_nuksanicha_takkewari_edt.getText().toString().trim();
                if (!nuksanicka_takkewari_str.equalsIgnoreCase("")) {
                    nuksanicha_int = Integer.valueOf(nuksanicka_takkewari_str);
                    if(nuksanicha_int > 100){
                        sweetAlertDialog = new SweetAlertDialog(FarmerPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("नुकसानिची टक्केवारी १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismiss();
                                farmer_punchnama_nuksanicha_takkewari_edt.setText("");
                            }
                        }).show();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        farmer_punchnama_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PunchnamaSave();
            }
        });

    }

    private void nuk_sani_date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        nuksanidatePickerDialog = new DatePickerDialog(FarmerPunchnamaActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        nuksanicha_dinaak = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        farmer_punchnama_nuksanicha_dinaak_tv.setText(nuksanicha_dinaak);


                    }
                }, mYear, mMonth, mDay);

        nuksanidatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        nuksanidatePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        nuksanidatePickerDialog.show();
    }

    private void clear_data() {

        season_list = new JSONArray();
        seasonID = 0;
        scheme_list = new JSONArray();
        schemeID = 0;
        crop_type_list = new JSONArray();
        croptypeID = 0;
        horti_crop_list = new JSONArray();
        horti_crop_id = 0;
        crop_list = new JSONArray();
        croplistID = 0;
        damage_type_list = new JSONArray();
        damageTypeID = 0;
        damage_reason_list = new JSONArray();
        damageReasonID = 0;

        farmer_punchnama_name_of_the_scheme.setText("Select");
        farmer_punchnama_season.setText("Select");
        farmer_punchnama_crop_type.setText("Select");
        farmer_punchnama_name_of_the_crop.setText("Select");
        farmer_punchnama_type_of_damage.setText("Select");
        farmer_punchnama_causes_of_damage.setText("Select");
        farmer_punchnama_horti_crop_type_tv.setText("Select");
        farmer_punchnama_lagwadi_ekkar_edt.setText("");
        farmer_punchnama_lagwadi_guntha_edt.setText("");
        farmer_punchnama_total_lagwadi.setText("");
        farmer_punchnama_pikvima_ekkar_edt.setText("");
        farmer_punchnama_pikvima_guntha_edt.setText("");
        farmer_punchnama_total_pikvima.setText("");
        farmer_punchnama_andajeet_ekkar_edt.setText("");
        farmer_punchnama_andajeet_guntha_edt.setText("");
        farmer_punchnama_total_baghadheet.setText("");
        farmer_punchnama_nuksanicha_takkewari_edt.setText("");
        farmer_panchnama_crop_name_edt.setText("");
        farmer_punchnama_nuksanicha_dinaak_tv.setText("dd-mm-yyyy");
        farmer_punchnama_photo_1.setImageResource(R.drawable.camera);
        farmer_punchnama_photo_2.setImageResource(R.drawable.camera);

    }


    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");
            photoFile1 = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImageFromCameraUri1() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");
            photoFile1 = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");
            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA1);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }else if (requestCode == CAMERA1) {
                onCameraActivityResult1();
            }
        }else{
            photoFile = null;
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile!=null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(farmer_punchnama_photo_1.getWidth(), farmer_punchnama_photo_1.getHeight())
                                .centerCrop()
                                .into(farmer_punchnama_photo_1);
                        uploadImageOnServer(imagePath);
                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void onCameraActivityResult1() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile1!=null) {

            if (photoFile1.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath1 = "file://" + photoFile1;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath1)
                                .transform(transformation)
                                .resize(farmer_punchnama_photo_2.getWidth(), farmer_punchnama_photo_2.getHeight())
                                .centerCrop()
                                .into(farmer_punchnama_photo_2);
                        uploadImageOnServer1(imagePath1);

                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile1);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private void PunchnamaYearWebservice(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_year_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void District_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_district_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void Taluka_Service(int districtID){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",districtID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_taluka_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void Village_Service(int talukaID){
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id",talukaID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Farm_type_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_farm_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void Scheme_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_scheme_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    private void Season_Service(String crop_insurance_ID,int schemeID){
        String crop_Iid;
        if(schemeID ==0){
            crop_Iid = "";
        }else {
            crop_Iid = String.valueOf(schemeID);
        }
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", "13");
            param.put("crop_insurance", crop_insurance_ID);
            param.put("panchnama_scheme_id", crop_Iid);
            param.put("primary_report_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);
    }

    private void CropType_Service(int seasonID){
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id","13");
            param.put("season_id","");
            param.put("primary_crop_id","");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropType(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);
    }


    private void Horti_crop_type_service(int croptypeID){
        JSONObject param = new JSONObject();
        try {
            param.put("id",croptypeID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_crop_type_sown_sublist(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 15);
    }

    private void Crop_list(int croptypeID,int panchname_scheme_id,int seasonID,int horti_crop_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", "13");
            param.put("crop_season_id", seasonID);
            param.put("crop_type", croptypeID);
            param.put("horti_crop_type_id", horti_crop_id);
            param.put("primary_report_id","");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id",panchname_scheme_id);
        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 9);
    }

    private void Damage_Reason(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_reason_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 10);
    }

    private void Damage_Type(String crop_insurance_ID){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_insurance",crop_insurance_ID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 11);
    }

    private void PunchnamaSave(){
        if(districtID_int==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select district", Toast.LENGTH_SHORT);
            toast.show();
        }else if(talukaID_int==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select taluka", Toast.LENGTH_SHORT);
            toast.show();
        }else if(villageID_int==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select village", Toast.LENGTH_SHORT);
            toast.show();
        }else if(farmer_punchnama_edt_survey_no_group_no.getText().toString().isEmpty()){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter survey or gut number", Toast.LENGTH_SHORT);
            toast.show();
        }else if (farmID.equalsIgnoreCase("0")) {
            Toast toast= Toast.makeText(getApplicationContext(), "Select farm type", Toast.LENGTH_SHORT);
            toast.show();
        }else if(crop_insurance_ID.isEmpty()){
            Toast toast= Toast.makeText(getApplicationContext(), "Select insurance", Toast.LENGTH_SHORT);
            toast.show();
        }else if(seasonID==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
            toast.show();
        }else if(croplistID==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select crop", Toast.LENGTH_SHORT);
            toast.show();
        }else if(farmer_punchnama_lagwadi_ekkar_edt.getText().toString().trim().isEmpty()){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter hector value", Toast.LENGTH_SHORT);
            toast.show();
        }else if(farmer_punchnama_andajeet_ekkar_edt.getText().toString().trim().isEmpty()){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter hector value", Toast.LENGTH_SHORT);
            toast.show();
        }else if(farmer_punchnama_nuksanicha_takkewari_edt.getText().toString().trim().isEmpty()){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter damage percentage", Toast.LENGTH_SHORT);
            toast.show();
        }else if(damageTypeID==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select damage type", Toast.LENGTH_SHORT);
            toast.show();
        }else if(nuksanicha_dinaak.equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter damage date", Toast.LENGTH_SHORT);
            toast.show();
        }else if(photoFile==null || photoFile1 == null){
            Toast toast= Toast.makeText(getApplicationContext(), "Capture Photo", Toast.LENGTH_SHORT);
            toast.show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("year_id", yearID);
                param.put("district_id", districtID_int);
                param.put("taluka_id", talukaID_int);
                param.put("farmer_name", farmer_fullname);
                param.put("village_id", villageID_int);
                param.put("crop_insurance", crop_insurance_ID);
                param.put("scheme_id", schemeID);
                param.put("season_id", seasonID);
                param.put("crop_type_id", croptypeID);
                param.put("horti_crop_id", horti_crop_id);
                param.put("crop_id", croplistID);
                param.put("farm_type_id", farmID);
                param.put("survey_no", farmer_punchnama_edt_survey_no_group_no.getText().toString());
                param.put("area_under_crop_acre", lagwadi_ekkar_value);
                param.put("area_under_crop_guntha", lagwadi_guntha_value);
                param.put("insured_area_under_crop_acre", pikvima_ekkar_value);
                param.put("insured_area_under_crop_guntha", pikvima_guntha_value);
                param.put("approxmate_area_acre", andajeet_ekkar_value);
                param.put("approxmate_area_guntha", andajeet_guntha_value);
                param.put("damage_type_id", damageTypeID);
                param.put("damage_reason_id", damage_reason_id);
                param.put("dmg_reason_name", Damage_reason_name);
                param.put("disease_name", farmer_punchnama_Specify_disease.getText().toString().trim());
                param.put("pest_name", farmer_punchnama_Specify_Pest.getText().toString().trim());
                param.put("nuksani_per", nuksanicka_takkewari_str);
                param.put("nuksani_date", nuksanicha_dinaak);
                param.put("nuksani_notice_date", "00-00-0000");
                param.put("neshirg_apti", neshirg_apti_id);
                param.put("total_lagwadi",total_lagwadi_str);
                param.put("total_pikvima",total_pikvima_str);
                param.put("total_baghadeet",total_baghadheet_str);
                param.put("other_crop_name",farmer_panchnama_crop_name_edt.getText().toString().trim());
                param.put("first_img_url",first_image_url);
                param.put("second_img_url",second_image_url);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_punchnama_save_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 12);

        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("lat",String.valueOf(lat));
            params.put("long",String.valueOf(lang));
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));

            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_punchnama_save_image_url(partBody, params);
            api.postRequest(responseCall, this, 13);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImageOnServer1(String imagePath1) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("lat",String.valueOf(lat));
            params.put("long",String.valueOf(lang));
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_punchnama_save_image_url(partBody, params);
            api.postRequest(responseCall, this, 14);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //year
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_list = jsonObject.getJSONArray("data");

                        }

                    } else {
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                        }

                    } else {
                    }
                } else

                    //taluka
                    if (i == 3) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                taluka_list = jsonObject.getJSONArray("data");
                            }


                        } else {
                        }
                    }else
                        //Village
                        if (i == 4) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    village_list = jsonObject.getJSONArray("data");
                                }
                            } else {
                                Toast.makeText(FarmerPunchnamaActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                            }

                        }

                        else
                            //Farm Type
                            if (i == 5) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        farm_type_list = jsonObject.getJSONArray("data");
                                        final int numberOfItemsInResp = farm_type_list.length();
                                        for (int j = 0; j < numberOfItemsInResp; j++) {
                                            JSONObject farm_type_json_object = farm_type_list.getJSONObject(j);
                                            farmID = farm_type_json_object.getString("id");
                                            farm_type_name = farm_type_json_object.getString("name_mr");
                                            if(farmID.equalsIgnoreCase("1")){
                                                bagyati_radio_btn.setText(farm_type_name);
                                            } else if(farmID.equalsIgnoreCase("2")){
                                                jirayati_radio_btn.setText(farm_type_name);
                                            }
                                            farmID = "0";
                                        }

                                    }

                                } else {
                                }
                            }
                            else
                                //Scheme Type
                                if (i == 6) {

                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                        if (responseModel.isStatus()) {
                                            scheme_list = jsonObject.getJSONArray("data");

                                        }
                                    } else {
                                    }
                                }

                                else
                                    //Season
                                    if (i == 7) {

                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                            if (responseModel.isStatus()) {
                                                season_list = jsonObject.getJSONArray("data");

                                            }

                                        } else {
                                        }
                                    }

                                    else
                                        //Crop Type
                                        if (i == 8) {

                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                if (responseModel.isStatus()) {
                                                    crop_type_list = jsonObject.getJSONArray("data");

                                                }

                                            } else {
                                            }
                                        }

                                        else
                            if (i == 9) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        crop_list = jsonObject.getJSONArray("data");
                                    }

                                } else {

                                }
                            }

                else
                //Damage Reason
                if (i == 10) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            damage_reason_list = jsonObject.getJSONArray("data");
                            final int numberOfItemsInResp = damage_reason_list.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject damage_json_object = damage_reason_list.getJSONObject(j);
                                Damage_reason_id = damage_json_object.getString("id");
                                damage_name = damage_json_object.getString("name_mr");
                                list_of_damage.add(new MultiSelectModel(Integer.valueOf(Damage_reason_id),damage_name));
                            }
                        }

                    } else {
                        Toast.makeText(FarmerPunchnamaActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                    }
                }

                else
                    //Damage Type
                    if (i == 11) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                damage_type_list = jsonObject.getJSONArray("data");


                            }

                        } else {
                            Toast.makeText(FarmerPunchnamaActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                        }
                    }

                    else
                        //Save Punchnama
                        if (i == 12) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    responseID = jsonObject.getInt("data");
                                    sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                            sweetAlertDialog.setTitleText("Farmer Panchnama");
                                            sweetAlertDialog.setContentText(jsonObject.getString("response"));
                                            sweetAlertDialog.setConfirmText("Ok");
                                            sweetAlertDialog.setCancelable(false);
                                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                @Override
                                                public void onClick(SweetAlertDialog sDialog) {
                                                    finish();
                                                }
                                            });
                                            sweetAlertDialog.show();

                                }

                            } else {
                                UIToastMessage.show(this, jsonObject.getString("response"));
                            }
                        }

                        else
                            //Save Punchnama image
                            if (i == 13) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        JSONObject data = jsonObject.getJSONObject("data");
                                        first_image_url = data.getString("file_url");
                                    }

                                }
                            }

                            else
                                //Save Punchnama image
                                if (i == 14) {

                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                        if (responseModel.isStatus()) {
                                            JSONObject data = jsonObject.getJSONObject("data");
                                            second_image_url = data.getString("file_url");
                                        }

                                    }
                                }

                                else   //Horticulture crop list
                                    if (i == 15) {

                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                            if (responseModel.isStatus()) {
                                                horti_crop_list = jsonObject.getJSONArray("data");

                                            }

                                        } else {
                                            Toast.makeText(FarmerPunchnamaActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                                        }
                                    }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            yearID = Integer.parseInt(s1);
            farmer_punchnama_year.setText(s);
            farmer_punchnama_year.setEnabled(false);
        }
        if (i == 2) {
            districtID_int = Integer.parseInt(s1);
            farmer_punchnama_district.setText(s);
            farmer_punchnama_taluka.setText("Select");
            farmer_punchnama_village.setText("Select");
            village_list = new JSONArray();
            Taluka_Service(districtID_int);
        }
        if (i == 3) {
            talukaID_int = Integer.parseInt(s1);
            farmer_punchnama_taluka.setText(s);
            farmer_punchnama_village.setText("Select");
            Village_Service(talukaID_int);
        }
        if (i == 4) {
            villageID_int = Integer.parseInt(s1);
            farmer_punchnama_village.setText(s);
        }

        if (i == 7) {
            seasonID = Integer.parseInt(s1);
            farmer_punchnama_season.setText(s);
            crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            CropType_Service(seasonID);
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            farmer_punchnama_crop_type.setText("Select");
            farmer_punchnama_name_of_the_crop.setText("Select");
            farmer_punchnama_horti_crop_type_tv.setText("Select");
            farmer_panchnama_horti_type.setVisibility(View.GONE);
            farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
            farmer_panchnama_crop_name_edt.setText("");
        }

        if (i == 6) {
            schemeID = Integer.parseInt(s1);
            farmer_punchnama_name_of_the_scheme.setText(s);
            horti_crop_list = new JSONArray();
            crop_list = new JSONArray();
            Season_Service(crop_insurance_ID,schemeID);
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            farmer_punchnama_season.setText("Select");
            farmer_punchnama_name_of_the_crop.setText("Select");
            farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
            farmer_panchnama_crop_name_edt.setText("");
        }

        if (i == 8) {
            croptypeID = Integer.parseInt(s1);
            farmer_punchnama_crop_type.setText(s);
            crop_list = new JSONArray();
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            farmer_punchnama_name_of_the_crop.setText("Select");
            farmer_punchnama_horti_crop_type_tv.setText("Select");
            farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
            farmer_panchnama_crop_name_edt.setText("");
            horti_crop_id = 0;

            if(croptypeID == 45){
                farmer_panchnama_horti_type.setVisibility(View.VISIBLE);
                horti_crop_list = new JSONArray();
                crop_list = new JSONArray();
                Horti_crop_type_service(croptypeID);
                Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
                farmer_punchnama_horti_crop_type_tv.setText("Select");
                farmer_punchnama_name_of_the_crop.setText("Select");
                farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
                farmer_panchnama_crop_name_edt.setText("");
            }else {
                farmer_panchnama_horti_type.setVisibility(View.GONE);
                horti_crop_list = new JSONArray();
                crop_list = new JSONArray();
                Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
                farmer_punchnama_name_of_the_crop.setText("Select");
                farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
                farmer_panchnama_crop_name_edt.setText("");
                horti_crop_id = 0;
            }
        }

        if (i == 9) {
            croplistID = Integer.parseInt(s1);
            farmer_punchnama_name_of_the_crop.setText(s);
            if(s.equalsIgnoreCase("इतर")){
                farmer_panchanam_crop_name_ll.setVisibility(View.VISIBLE);
            }else {
                farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
                farmer_panchnama_crop_name_edt.setText("");
            }
        }

        if (i == 11) {
            damageTypeID = Integer.parseInt(s1);
            farmer_punchnama_type_of_damage.setText(s);
        }

        if (i == 15) {
            horti_crop_id = Integer.parseInt(s1);
            farmer_punchnama_horti_crop_type_tv.setText(s);
            crop_list = new JSONArray();
            Crop_list(croptypeID,schemeID,seasonID,horti_crop_id);
            farmer_panchanam_crop_name_ll.setVisibility(View.GONE);
            farmer_punchnama_name_of_the_crop.setText("Select");
            farmer_panchnama_crop_name_edt.setText("");
        }
    }
}
