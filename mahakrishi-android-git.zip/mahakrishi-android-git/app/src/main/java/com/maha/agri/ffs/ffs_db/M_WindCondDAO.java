package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_WindCondDAO {


    @Query("SELECT * FROM M_WindCondEY")
    List<M_WindCondEY> getAll();

    @Query("SELECT * FROM M_WindCondEY WHERE uid IN (:userIds)")
    List<M_WindCondEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_WindCondEY WHERE uid = :id")
    List<M_WindCondEY> checkIdExists(int id);

    @Insert
    void insertAll(M_WindCondEY... mWindCondEYS);

    @Insert
    void insertOnlySingle(M_WindCondEY mWindCondEY);

}
