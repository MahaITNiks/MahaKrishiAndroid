package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateOtpActivity extends AppCompatActivity implements ApiCallbackCode {
    private Button generateOTP;
    private EditText mobile_number_edt;
    private String mobile_number;
    private JSONObject forgotpass_json_object;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_generate_otp);
        sharedPref = new SharedPref(GenerateOtpActivity.this);
        preferenceManager = new PreferenceManager(GenerateOtpActivity.this);
        init();
        default_confiq();


    }

    private void init(){
        generateOTP = (Button) findViewById(R.id.generateOTPbtn);
        mobile_number_edt = (EditText) findViewById(R.id.mobileNumEText);

    }

    private void default_confiq(){
        generateOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               generateotpWebservice();
            }
        });

    }

    private void generateotpWebservice(){

        if(mobile_number_edt.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter mobile number");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("mobile", mobile_number_edt.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.forgot_password(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                // District Response
                if (i == 1) {

                    if (jsonObject.getString("status").equals("200")) {
                        Intent intent = new Intent(GenerateOtpActivity.this,ForgotPasswordActivity.class);
                        intent.putExtra("mobile_number",mobile_number_edt.getText().toString().trim());
                        startActivity(intent);
                        finish();
                        forgotpass_json_object = jsonObject.getJSONObject("data");
                        //String otp = forgotpass_json_object.getString("otp");

                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }


                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
