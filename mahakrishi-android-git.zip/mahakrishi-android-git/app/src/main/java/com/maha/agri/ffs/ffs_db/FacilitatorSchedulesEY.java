/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class FacilitatorSchedulesEY {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int uid;
    private int host_farmer_id;
    private String farmer_name;
    private String host_farmer_mobile;
    private int plan_date;
    private int visit_number;
    private String village_name;
    private int plot_id;
    private String plot_name;
    private int crop_id;
    private String crop_name;
    private int cropping_system_id;
    private int is_completed;
    private int visit_count;
    private int inter_crop_id;
    private String inter_crop_name;
    private int inter_crop_visit_count;
    private String sdate;
    private String sday;
    private int date_of_sowing;
    private int method_of_sowing_id;
    private String method_of_sowing_name;
    private int crop_variety_id;
    private String crop_variety_name;
    private int control_date_of_sowing;
    private int control_method_of_sowing_id;
    private String control_method_of_sowing_name;
    private int control_crop_variety_id;
    private String control_crop_variety_name;
    private int irrigation_method_id;
    private String irrigation_method_name;
    private int control_irrigation_method_id;
    private String control_irrigation_method_name;



    public FacilitatorSchedulesEY() {}


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }


    public int getHost_farmer_id() {
        return host_farmer_id;
    }

    public void setHost_farmer_id(int host_farmer_id) {
        this.host_farmer_id = host_farmer_id;
    }

    public String getFarmer_name() {
        return farmer_name;
    }

    public void setFarmer_name(String farmer_name) {
        this.farmer_name = farmer_name;
    }

    public int getPlan_date() {
        return plan_date;
    }

    public void setPlan_date(int plan_date) {
        this.plan_date = plan_date;
    }

    public int getVisit_number() {
        return visit_number;
    }

    public void setVisit_number(int visit_number) {
        this.visit_number = visit_number;
    }

    public String getVillage_name() {
        return village_name;
    }

    public void setVillage_name(String village_name) {
        this.village_name = village_name;
    }

    public int getPlot_id() {
        return plot_id;
    }

    public void setPlot_id(int plot_id) {
        this.plot_id = plot_id;
    }

    public String getPlot_name() {
        return plot_name;
    }

    public void setPlot_name(String plot_name) {
        this.plot_name = plot_name;
    }

    public int getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(int crop_id) {
        this.crop_id = crop_id;
    }

    public String getCrop_name() {
        return crop_name;
    }

    public void setCrop_name(String crop_name) {
        this.crop_name = crop_name;
    }

    public int getCropping_system_id() {
        return cropping_system_id;
    }

    public void setCropping_system_id(int cropping_system_id) {
        this.cropping_system_id = cropping_system_id;
    }

    public int getIs_completed() {
        return is_completed;
    }

    public void setIs_completed(int is_completed) {
        this.is_completed = is_completed;
    }

    public String getSdate() {
        return sdate;
    }

    public void setSdate(String sdate) {
        this.sdate = sdate;
    }

    public String getSday() {
        return sday;
    }

    public void setSday(String sday) {
        this.sday = sday;
    }

    public String getHost_farmer_mobile() {
        return host_farmer_mobile;
    }

    public void setHost_farmer_mobile(String host_farmer_mobile) {
        this.host_farmer_mobile = host_farmer_mobile;
    }


    public int getVisit_count() {
        return visit_count;
    }

    public void setVisit_count(int visit_count) {
        this.visit_count = visit_count;
    }

    public int getInter_crop_id() {
        return inter_crop_id;
    }

    public void setInter_crop_id(int inter_crop_id) {
        this.inter_crop_id = inter_crop_id;
    }

    public String getInter_crop_name() {
        return inter_crop_name;
    }

    public void setInter_crop_name(String inter_crop_name) {
        this.inter_crop_name = inter_crop_name;
    }

    public int getInter_crop_visit_count() {
        return inter_crop_visit_count;
    }

    public void setInter_crop_visit_count(int inter_crop_visit_count) {
        this.inter_crop_visit_count = inter_crop_visit_count;
    }

    public int getDate_of_sowing() {
        return date_of_sowing;
    }

    public void setDate_of_sowing(int date_of_sowing) {
        this.date_of_sowing = date_of_sowing;
    }

    public int getMethod_of_sowing_id() {
        return method_of_sowing_id;
    }

    public void setMethod_of_sowing_id(int method_of_sowing_id) {
        this.method_of_sowing_id = method_of_sowing_id;
    }

    public String getMethod_of_sowing_name() {
        return method_of_sowing_name;
    }

    public void setMethod_of_sowing_name(String method_of_sowing_name) {
        this.method_of_sowing_name = method_of_sowing_name;
    }

    public int getCrop_variety_id() {
        return crop_variety_id;
    }

    public void setCrop_variety_id(int crop_variety_id) {
        this.crop_variety_id = crop_variety_id;
    }

    public String getCrop_variety_name() {
        return crop_variety_name;
    }

    public void setCrop_variety_name(String crop_variety_name) {
        this.crop_variety_name = crop_variety_name;
    }

    public int getControl_date_of_sowing() {
        return control_date_of_sowing;
    }

    public void setControl_date_of_sowing(int control_date_of_sowing) {
        this.control_date_of_sowing = control_date_of_sowing;
    }

    public int getControl_method_of_sowing_id() {
        return control_method_of_sowing_id;
    }

    public void setControl_method_of_sowing_id(int control_method_of_sowing_id) {
        this.control_method_of_sowing_id = control_method_of_sowing_id;
    }

    public String getControl_method_of_sowing_name() {
        return control_method_of_sowing_name;
    }

    public void setControl_method_of_sowing_name(String control_method_of_sowing_name) {
        this.control_method_of_sowing_name = control_method_of_sowing_name;
    }

    public int getControl_crop_variety_id() {
        return control_crop_variety_id;
    }

    public void setControl_crop_variety_id(int control_crop_variety_id) {
        this.control_crop_variety_id = control_crop_variety_id;
    }

    public String getControl_crop_variety_name() {
        return control_crop_variety_name;
    }

    public void setControl_crop_variety_name(String control_crop_variety_name) {
        this.control_crop_variety_name = control_crop_variety_name;
    }

    public int getIrrigation_method_id() {
        return irrigation_method_id;
    }

    public void setIrrigation_method_id(int irrigation_method_id) {
        this.irrigation_method_id = irrigation_method_id;
    }

    public String getIrrigation_method_name() {
        return irrigation_method_name;
    }

    public void setIrrigation_method_name(String irrigation_method_name) {
        this.irrigation_method_name = irrigation_method_name;
    }

    public int getControl_irrigation_method_id() {
        return control_irrigation_method_id;
    }

    public void setControl_irrigation_method_id(int control_irrigation_method_id) {
        this.control_irrigation_method_id = control_irrigation_method_id;
    }

    public String getControl_irrigation_method_name() {
        return control_irrigation_method_name;
    }

    public void setControl_irrigation_method_name(String control_irrigation_method_name) {
        this.control_irrigation_method_name = control_irrigation_method_name;
    }
}

