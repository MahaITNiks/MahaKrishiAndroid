package com.maha.agri.ochard_mapping;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.task_manager.TaskManagerActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateOrchardMappingActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button orchard_mapping_submit_btn, orchard_mapping_cancel_btn;
    private String genrate_orchard_mapping_data = "", first_name = "", middle_name = "", last_name = "", khata_number = "", mobile = "";
    private int district_id = 0, taluka_id = 0, revenue_id = 0, gram_panchayat_id = 0, village_id = 0, sajja_id = 0;
    private RecyclerView generate_orchard_mapping_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray add_more_data_json_array = new JSONArray();
    private JSONObject add_more_data_json_object;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_orchard_mapping);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Generate Orchard Mapping");
        preferenceManager = new PreferenceManager(GenerateOrchardMappingActivity.this);
        sharedPref = new SharedPref(GenerateOrchardMappingActivity.this);
        init();
        default_config();
    }

    ///
    private void init() {
        orchard_mapping_submit_btn = (Button) findViewById(R.id.orchard_generate_report_submit_btn);
        orchard_mapping_cancel_btn = (Button) findViewById(R.id.orchard_generate_report_cancel_btn);
        generate_orchard_mapping_rv = (RecyclerView) findViewById(R.id.generate_orchard_mapping_rv);

        orchard_mapping_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OrchardMappingSave();
            }
        });

        orchard_mapping_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void default_config() {

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        revenue_id = intent.getIntExtra("revenue_id", 0);
        gram_panchayat_id = intent.getIntExtra("gram_panchayat_id", 0);
        sajja_id = intent.getIntExtra("sajja_id", 0);
        village_id = intent.getIntExtra("village_id", 0);
        first_name = intent.getStringExtra("first_name");
        middle_name = intent.getStringExtra("middle_name");
        last_name = intent.getStringExtra("last_name");
        khata_number = intent.getStringExtra("khata_number");
        mobile = intent.getStringExtra("mobile");
        genrate_orchard_mapping_data = intent.getStringExtra("add_more_data");


        try {
            add_more_data_json_array = new JSONArray(genrate_orchard_mapping_data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        GenerateOrchardMappingAdapter generateOrchardMappingAdapter = new GenerateOrchardMappingAdapter(add_more_data_json_array, GenerateOrchardMappingActivity.this);
        generate_orchard_mapping_rv.setLayoutManager(new LinearLayoutManager(GenerateOrchardMappingActivity.this));
        generate_orchard_mapping_rv.setAdapter(generateOrchardMappingAdapter);
        generateOrchardMappingAdapter.notifyDataSetChanged();

    }

    private void OrchardMappingSave() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("division_id", "0");
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("revenue_id", revenue_id);
            param.put("gram_id", gram_panchayat_id);
            //above two line commented because we mapping same as cropsown so no need to send gram_id & revenue_id....................................
            param.put("sajja_id", sajja_id);
            param.put("village_id", village_id);
            param.put("first_name", first_name);
            param.put("middle_name", middle_name);
            param.put("last_name", last_name);
            param.put("khata_number", khata_number);
            param.put("mobile", mobile);
            param.put("multiple_data", add_more_data_json_array.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.orchard_mapping_save(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Orchard Mapping")
                                    .setContentText("Submitted Successfully")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Intent intent = new Intent(GenerateOrchardMappingActivity.this, TaskManagerActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    })
                                    .show();


                        }
                    }
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}