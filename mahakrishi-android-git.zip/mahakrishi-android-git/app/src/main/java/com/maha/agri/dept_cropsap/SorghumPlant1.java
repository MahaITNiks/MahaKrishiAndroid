package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SorghumPlant1 extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private Button sorghum_btn_save_continue,btn_add_pest_details_sorghum;
    private TextView dept_cropsap_sorghum_crop_plant_tv,sorghum_major_pest,sorghum_minor_pest,sorghum_generic_tv;
    private EditText sorghum_jassids_et,sorghum_generic_et,sorghum_defender_et;
    private ImageView sorghum_jassids_photo,sorghum_generic_photo;
    private LinearLayout sorghum_jassids_ll,sorghum_generic_ll;
    private RecyclerView add_more_pest_rv_sorghum;
    private TableLayout add_pest_titleTableLayout_sorghum;
    private SweetAlertDialog sweetAlertDialog;

    private int count = 1,generic_int,jassids_int;
    private int crop_cond_id = 0;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private int crop_id = 0;
    private int selected_pest_id = 0;
    private int sorghum_crop_id = 0;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private AppLocationManager locationManager;
    public double lat,lang;
    private JSONArray sorghum_crop_plant_list,sorghum_major_pest_list,sorghum_minor_pest_list;
    private String sorghum_crop_name,pest_name="",generic_et_str = "", jassid_et_str = "", def_str="";

    //Image
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private String imagePath1 = "",imagePath2 = "";
    private String image_1_file_name = "",image_2_file_name = "";
    private int district_id, taluka_id, village_id, farmer_id;
    private String type;

    private ArrayList<String> pest_list_names_sorghum=new ArrayList<String>();
    private ArrayList<LinearLayout> pest_list_layout_sorghum=new ArrayList<LinearLayout>();
    private ArrayList<EditText> pest_list_et_sorghum=new ArrayList<EditText>();
    private boolean flag=false;

    private JSONArray pest_details_json_array = new JSONArray();

    JSONObject shoot_fly_pest_json_obj = new JSONObject();
    JSONObject stem_borer_pest_json_obj = new JSONObject();
    JSONObject midge_fly_pest_json_obj = new JSONObject();
    JSONObject aphids_pest_json_obj = new JSONObject();
    JSONObject jassids_pest_json_obj = new JSONObject();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sorghum);
        getSupportActionBar().setTitle("Pest Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SorghumPlant1.this);
        sharedPref = new SharedPref(SorghumPlant1.this);
        locationManager = new AppLocationManager(this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        crop_cond_id = intent.getIntExtra("crop_cond",0);
        crop_growth_id = intent.getIntExtra("crop_growth_id",0);
        soil_moisture_id = intent.getIntExtra("soil_moisture_id",0);
        lat = locationManager.getLatitude();
        lang = locationManager.getLongitude();

        initView();
        setListners();
    }

    private void initView() {
        //Textview
        dept_cropsap_sorghum_crop_plant_tv = (TextView)findViewById(R.id.dept_cropsap_sorghum_crop_plant_tv);
        sorghum_major_pest = (TextView)findViewById(R.id.sorghum_major_pest);
        sorghum_minor_pest = (TextView)findViewById(R.id.sorghum_minor_pest);
        sorghum_generic_tv = (TextView)findViewById(R.id.sorghum_generic_tv);
        dept_cropsap_sorghum_crop_plant_tv.setEnabled(false);
        //Button
        sorghum_btn_save_continue = (Button)findViewById(R.id.sorghum_btn_save_continue);
        btn_add_pest_details_sorghum = (Button)findViewById(R.id.btn_add_pest_details_sorghum);
        //Edittext
        sorghum_jassids_et=(EditText)findViewById(R.id.sorghum_jassids_et);
        sorghum_generic_et=(EditText)findViewById(R.id.sorghum_generic_et);
        sorghum_defender_et=(EditText)findViewById(R.id.sorghum_defender_et);
        //Imageview
        sorghum_jassids_photo=(ImageView)findViewById(R.id.sorghum_jassids_photo);
        sorghum_generic_photo=(ImageView)findViewById(R.id.sorghum_generic_photo);
        //LL
        sorghum_jassids_ll = (LinearLayout) findViewById(R.id.sorghum_jassids_ll);
        sorghum_generic_ll = (LinearLayout) findViewById(R.id.sorghum_generic_ll);
        add_more_pest_rv_sorghum = (RecyclerView) findViewById(R.id.add_more_pest_rv_sorghum);
        add_pest_titleTableLayout_sorghum = (TableLayout) findViewById(R.id.add_pest_titleTableLayout_sorghum);

        sorghum_crop_plant_list = new JSONArray();
        sorghum_major_pest_list = new JSONArray();
        sorghum_minor_pest_list = new JSONArray();

        plant_service();
        major_pest_service();
        minor_pest_service();
        zero_pest_input();
        jassids_zero_input();

    }

    private void setListners() {

        pest_list_names_sorghum.add("JASSIDS");

        pest_list_et_sorghum.add(sorghum_jassids_et);

        pest_list_layout_sorghum.add(sorghum_jassids_ll);

        dept_cropsap_sorghum_crop_plant_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sorghum_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sorghum_crop_plant_list, 1, "Select plant", "plant_name", "plant_id", SorghumPlant1.this, SorghumPlant1.this);
                }
            }
        });

        sorghum_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sorghum_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sorghum_major_pest_list, 2, "Select Major Pest", "pest_eng_name", "id", SorghumPlant1.this, SorghumPlant1.this);
                }else{
                    major_pest_service();
                }
            }
        });

        sorghum_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sorghum_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sorghum_minor_pest_list, 3, "Select Minor Pest", "pest_eng_name", "id", SorghumPlant1.this, SorghumPlant1.this);
                }else{
                    minor_pest_service();
                }
            }
        });

        sorghum_jassids_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED )){
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        sorghum_generic_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SorghumPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED )){
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        btn_add_pest_details_sorghum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generic_et_str = sorghum_generic_et.getText().toString().trim();
                jassid_et_str = sorghum_jassids_et.getText().toString().trim();

                if(pest_name.equalsIgnoreCase("STEM BORER") || pest_name.equalsIgnoreCase("SHOOT FLY")
                        || pest_name.equalsIgnoreCase("APHIDS") || pest_name.equalsIgnoreCase("MIDGE FLY")){
                        if (generic_et_str.equalsIgnoreCase("")) {
                            Toast.makeText(SorghumPlant1.this, "Enter the number of pest present ", Toast.LENGTH_SHORT).show();
                        } else if (photoFile2 == null) {
                            Toast.makeText(SorghumPlant1.this, "Click photo of the pest", Toast.LENGTH_SHORT).show();
                        } else {
                            uploadImageOnServer();
                            add_pest_details(selected_pest_id, pest_name);
                        }
                }else if(pest_name.equalsIgnoreCase("JASSIDS")){
                    if(jassid_et_str.equalsIgnoreCase("")){
                        Toast.makeText(SorghumPlant1.this,"Enter the number of damage grade",Toast.LENGTH_SHORT).show();
                    }else if(photoFile1 == null){
                        Toast.makeText(SorghumPlant1.this,"Click photo of the damaged grade",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else{

                }
            }
        });

        sorghum_btn_save_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                def_str = sorghum_defender_et.getText().toString().trim();

                if(pest_details_json_array.length()>0) {
                    if(pest_details_json_array.toString().contains("SHOOT FLY") &&
                            pest_details_json_array.toString().contains("STEM BORER")) {
                    if (def_str.equalsIgnoreCase("")) {
                        Toast.makeText(SorghumPlant1.this, "Enter total defenders", Toast.LENGTH_SHORT).show();
                    } else {
                        save_sorghum_crop_data_service();
                    }
                }
                    else{
                        sweetAlertDialog = new SweetAlertDialog(SorghumPlant1.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Enter data for all major pests");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                            }
                        }).show();
                    }
                }else {
                    final Toast toast = Toast.makeText(SorghumPlant1.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 0);
                }
            }
        });
    }

    private void zero_pest_input(){
        sorghum_generic_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                generic_et_str = sorghum_generic_et.getText().toString().trim();
                if(!generic_et_str.equalsIgnoreCase("")){
                    generic_int = Integer.parseInt(generic_et_str);
                    if(generic_int == 0){
                        sorghum_generic_photo.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        sorghum_generic_photo.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void jassids_zero_input() {
        sorghum_jassids_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                jassid_et_str = sorghum_jassids_et.getText().toString().trim();
                if (!jassid_et_str.equalsIgnoreCase("")) {
                    jassids_int = Integer.parseInt(jassid_et_str);
                    if (jassids_int == 0) {
                        sorghum_jassids_photo.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id, pest_name);
                    } else {
                        sorghum_jassids_photo.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            if(type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }else if(type.equalsIgnoreCase("2")) {

                photoFile2 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
            photoFile2 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(sorghum_jassids_photo.getWidth(), sorghum_jassids_photo.getHeight())
                                    .centerCrop()
                                    .into(sorghum_jassids_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if (type.equalsIgnoreCase("2")) {

            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(sorghum_generic_photo.getWidth(), sorghum_generic_photo.getHeight())
                                    .centerCrop()
                                    .into(sorghum_generic_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else{

        }
    }

    private void plant_service() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_sorghum_plant_list();
        api.postRequest(responseCall, this, 1);
    }

    private void major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void add_pest_details(int sel_pest_id,String pest_name){

        try {
            if(pest_name.equalsIgnoreCase("SHOOT FLY")) {
                shoot_fly_pest_json_obj.put("pest_id", sel_pest_id);
                shoot_fly_pest_json_obj.put("pest_name", pest_name);
                shoot_fly_pest_json_obj.put("shoot_fly_pest_no", sorghum_generic_et.getText().toString().trim());
                shoot_fly_pest_json_obj.put("shoot_fly_pest_pic", imagePath2);
                shoot_fly_pest_json_obj.put("lat", String.valueOf(lat));
                shoot_fly_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(shoot_fly_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("STEM BORER")) {
                stem_borer_pest_json_obj.put("pest_id", sel_pest_id);
                stem_borer_pest_json_obj.put("pest_name", pest_name);
                stem_borer_pest_json_obj.put("stem_bor_pest_no", sorghum_generic_et.getText().toString().trim());
                stem_borer_pest_json_obj.put("stem_bor_pest_pic", imagePath2);
                stem_borer_pest_json_obj.put("lat", String.valueOf(lat));
                stem_borer_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(stem_borer_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("MIDGE FLY")) {
                midge_fly_pest_json_obj.put("pest_id", sel_pest_id);
                midge_fly_pest_json_obj.put("pest_name", pest_name);
                midge_fly_pest_json_obj.put("midge_fly_pest_no", sorghum_generic_et.getText().toString().trim());
                midge_fly_pest_json_obj.put("midge_fly_pest_pic", imagePath2);
                midge_fly_pest_json_obj.put("lat", String.valueOf(lat));
                midge_fly_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(midge_fly_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("APHIDS")) {
                aphids_pest_json_obj.put("pest_id", sel_pest_id);
                aphids_pest_json_obj.put("pest_name", pest_name);
                aphids_pest_json_obj.put("aphids_pest_no", sorghum_generic_et.getText().toString().trim());
                aphids_pest_json_obj.put("aphids_pest_pic", imagePath2);
                aphids_pest_json_obj.put("lat", String.valueOf(lat));
                aphids_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(aphids_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("JASSIDS")) {
                jassids_pest_json_obj.put("pest_id", sel_pest_id);
                jassids_pest_json_obj.put("pest_name", pest_name);
                jassids_pest_json_obj.put("jassids_pest_no", sorghum_jassids_et.getText().toString().trim());
                jassids_pest_json_obj.put("jassids_pest_pic", imagePath1);
                jassids_pest_json_obj.put("lat", String.valueOf(lat));
                jassids_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(jassids_pest_json_obj);
            }

            if(pest_details_json_array.length()>0){
                add_pest_titleTableLayout_sorghum.setVisibility(View.VISIBLE);
                add_more_pest_rv_sorghum.setVisibility(View.VISIBLE);
                add_more_pest_rv_sorghum.setLayoutManager(new LinearLayoutManager(SorghumPlant1.this));
                AddPestAdapter addPestAdapter = new AddPestAdapter(pest_details_json_array, SorghumPlant1.this);
                add_more_pest_rv_sorghum.setAdapter(addPestAdapter);
                addPestAdapter.notifyDataSetChanged();
                sorghum_jassids_ll.setVisibility(View.GONE);
                sorghum_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_sorghum.setVisibility(View.GONE);
                sorghum_major_pest.setText("Select");
                sorghum_minor_pest.setText("Select");
                sorghum_generic_photo.setImageResource(R.drawable.camera);
                sorghum_generic_et.setText("");
                sorghum_jassids_photo.setImageResource(R.drawable.camera);
                sorghum_jassids_et.setText("");
                photoFile1 = null;
                photoFile2 = null;
            }else{
                add_pest_titleTableLayout_sorghum.setVisibility(View.GONE);
                add_more_pest_rv_sorghum.setVisibility(View.GONE);
                final Toast toast = Toast.makeText(SorghumPlant1.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 0);
            }

            System.out.println(pest_details_json_array.toString());

        }catch (Exception e){

        }
    }


    private void uploadImageOnServer() {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;

                case "2":
                    File file2 = new File(photoFile2.getPath());
                    RequestBody reqFile2 = RequestBody.create(MediaType.parse("image/*"), file2);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file2.getName(), reqFile2);
                    break;
            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void save_sorghum_crop_data_service() {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("spot_id", count);
                param.put("crop_id", crop_id);
                param.put("crop_condition_id", crop_cond_id);
                param.put("crop_grow_id", crop_growth_id);
                param.put("soil_mois_id", soil_moisture_id);
                param.put("pest_details", pest_details_json_array.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sorghum_crop_plant_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sorghum_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sorghum_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if(type.equalsIgnoreCase("1")){
                                image_1_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("2")){
                                image_2_file_name = data.getString("file_url");
                            }
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(count<sorghum_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Sorghum");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        count++;
                                        dept_cropsap_sorghum_crop_plant_tv.setText("Plant" + " " + count);
                                        sorghum_major_pest.setText("Select");
                                        sorghum_minor_pest.setText("Select");
                                        pest_details_json_array = new JSONArray();
                                        sorghum_generic_ll.setVisibility(View.GONE);
                                        sorghum_jassids_ll.setVisibility(View.GONE);
                                        btn_add_pest_details_sorghum.setVisibility(View.GONE);
                                        add_pest_titleTableLayout_sorghum.setVisibility(View.GONE);
                                        add_more_pest_rv_sorghum.setVisibility(View.GONE);
                                        sorghum_defender_et.setText("");
                                        sweetAlertDialog.dismissWithAnimation();
                                    }
                                });
                                sweetAlertDialog.show();
                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Sorghum");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(SorghumPlant1.this, SorghumCropPheromoneActivity.class);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            sorghum_crop_id = Integer.parseInt(s1);
            sorghum_crop_name = s;
            dept_cropsap_sorghum_crop_plant_tv.setText(s);
        }
        if (i == 2) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            sorghum_major_pest.setText(s);
            sorghum_minor_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == sorghum_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(SorghumPlant1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                sorghum_generic_et.setText("");
                sorghum_jassids_et.setText("");
                sorghum_generic_photo.setImageResource(R.drawable.camera);
                sorghum_jassids_photo.setImageResource(R.drawable.camera);
                sorghum_generic_ll.setVisibility(View.GONE);
                sorghum_jassids_ll.setVisibility(View.GONE);
                btn_add_pest_details_sorghum.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_sorghum.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
        if (i == 3) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            sorghum_minor_pest.setText(s);
            sorghum_major_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == sorghum_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(SorghumPlant1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                sorghum_generic_et.setText("");
                sorghum_jassids_et.setText("");
                sorghum_generic_photo.setImageResource(R.drawable.camera);
                sorghum_jassids_photo.setImageResource(R.drawable.camera);
                sorghum_generic_ll.setVisibility(View.GONE);
                sorghum_jassids_ll.setVisibility(View.GONE);
                btn_add_pest_details_sorghum.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_sorghum.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }

    private void layout_View_Gone(String s) {
        if(pest_list_names_sorghum.contains(s)){
            sorghum_generic_ll.setVisibility(View.GONE);
            sorghum_generic_photo.setVisibility(View.GONE);
            sorghum_generic_tv.setText("");
            sorghum_generic_et.setText("");
            for(int i=0;i<pest_list_et_sorghum.size();i++){
                pest_list_et_sorghum.get(i).setText("");
            }

            for(int j=0;j<pest_list_names_sorghum.size();j++){
                if(pest_list_names_sorghum.get(j).equals(s)){
                    pest_list_layout_sorghum.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout_sorghum.get(j).setVisibility(View.GONE);
                    sorghum_generic_et.setText("");
                }
            }
        }
        else{
                String localstr = s;
                String localstr2;
                localstr2 = capitalizeWord(localstr);
                sorghum_generic_ll.setVisibility(View.VISIBLE);
                sorghum_generic_photo.setVisibility(View.VISIBLE);
                sorghum_generic_tv.setText(localstr2);
                sorghum_generic_et.setText("");
                for (int j = 0; j < pest_list_names_sorghum.size(); j++) {
                    pest_list_layout_sorghum.get(j).setVisibility(View.GONE);
                    pest_list_et_sorghum.get(j).setText("");
                }
        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(SorghumPlant1.this,SorghumGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}