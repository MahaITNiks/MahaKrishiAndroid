package com.maha.agri.activity.attendance;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class AttendanceCalendarAdapter extends RecyclerView.Adapter<AttendanceCalendarAdapter.MyViewHolder>  {
    private JSONArray task_manager_array_list;
    private int[] task_manager_background;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    //private String[] monthList;
    private JSONArray attendance_Month_filter_List;
    ArrayList<Boolean> clicked = new ArrayList<>();
    int index;
    private int selectedItem = -1;
    String monthFilter,month_year;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView month_selected_iv;
        private TextView calendar_single_title;
        private RelativeLayout month_filter_rl;



        public MyViewHolder(View itemView) {
            super(itemView);
            this.calendar_single_title = itemView.findViewById(R.id.calendar_single_text_view);
            this.month_filter_rl = itemView.findViewById(R.id.month_filter_rl);
            this.month_selected_iv = itemView.findViewById(R.id.month_selected_iv);

        }
    }

    /*public AttendanceCalendarAdapter(PreferenceManager preferenceManager, JSONArray task_manager_array_list,int[] task_manager_background, Context context) {
        this.preferencemanager = preferenceManager;
        this.task_manager_array_list = task_manager_array_list;
        this.task_manager_background = task_manager_background;
        this.context = context;

    }*/

    public AttendanceCalendarAdapter(Context context, JSONArray attendance_Month_filter_List,PreferenceManager preferenceManager) {
        this.context = context;
        this.attendance_Month_filter_List = attendance_Month_filter_List;
        this.preferencemanager = preferenceManager;


    }

    @Override
    public AttendanceCalendarAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_item, parent, false);

        AttendanceCalendarAdapter.MyViewHolder myViewHolder = new AttendanceCalendarAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final AttendanceCalendarAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = attendance_Month_filter_List.getJSONObject(listPosition);
            month_year = jsonObject.getString("month") + " " + jsonObject.getString("year");

            holder.calendar_single_title.setText(month_year);
            if(selectedItem==listPosition){
                holder.month_selected_iv.setVisibility(View.VISIBLE);


            }else{
                holder.month_selected_iv.setVisibility(View.GONE);
            }

            holder.month_filter_rl.setTag(listPosition);

            holder.month_filter_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                        //preferencemanager.putPreferenceIntValues(Preference_Constant.MONTH_FILTER_POS,index);
                    try {
                        monthFilter = attendance_Month_filter_List.getJSONObject(index).getString("month") + " -  " +  attendance_Month_filter_List.getJSONObject(index).getString("year");
                        preferencemanager.putPreferenceValues(Preference_Constant.MONTH_FILTER,monthFilter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                        /*Intent intent = new Intent(context, AttedanceCalenderActivity.class);
                        intent.putExtra("month_filter",monthFilter);
                        context.startActivity(intent);*/



                    if (selectedItem == listPosition) {
                        selectedItem=-1;

                    } else {
                        selectedItem = listPosition;

                    }
                    notifyDataSetChanged();

                }
            });


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return attendance_Month_filter_List.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private AttendanceCalendarAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final AttendanceCalendarAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
