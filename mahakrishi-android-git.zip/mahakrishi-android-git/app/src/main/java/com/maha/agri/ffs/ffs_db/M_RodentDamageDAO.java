package com.maha.agri.ffs.ffs_db;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_RodentDamageDAO {

    @Query("SELECT * FROM M_RodentDamageEY")
    List<M_RodentDamageEY> getAll();

    @Query("SELECT * FROM M_RodentDamageEY WHERE uid IN (:userIds)")
    List<M_RodentDamageEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_RodentDamageEY WHERE uid = :id")
    List<M_RodentDamageEY> checkIdExists(int id);

    @Insert
    void insertAll(M_RodentDamageEY... rodentDamageEYS);

    @Insert
    void insertOnlySingle(M_RodentDamageEY rodentDamageEY);
}
