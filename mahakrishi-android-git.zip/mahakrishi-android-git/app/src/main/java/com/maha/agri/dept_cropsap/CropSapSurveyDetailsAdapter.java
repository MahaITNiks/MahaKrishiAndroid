package com.maha.agri.dept_cropsap;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CropSapSurveyDetailsAdapter extends RecyclerView.Adapter<CropSapSurveyDetailsAdapter.ViewHolder> {

    private Context mContext;
    private JSONArray mDataArray;
    private JSONObject jsonObject;

    public CropSapSurveyDetailsAdapter(Context mContext, JSONArray jsonArray) {
        this.mContext = mContext;
        this.mDataArray = jsonArray;
    }

    @NonNull
    @Override
    public CropSapSurveyDetailsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.cropsap_survey_singleitem, viewGroup, false);
        return new CropSapSurveyDetailsAdapter.ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        try {
            jsonObject = mDataArray.getJSONObject(i);
            viewHolder.cropsap_farmer_filled_crop_name_tv.setText(jsonObject.getString("crop_english"));
            viewHolder.cropsap_farmer_filled_survey_tv.setText(jsonObject.getString("survey_no"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {


        private TextView cropsap_farmer_filled_crop_name_tv,cropsap_farmer_filled_survey_tv;
        private LinearLayout cropsap_survey_ll;

        public ViewHolder(View itemView) {
            super(itemView);

            cropsap_farmer_filled_crop_name_tv = itemView.findViewById(R.id.cropsap_farmer_filled_crop_name_tv);
            cropsap_farmer_filled_survey_tv = itemView.findViewById(R.id.cropsap_farmer_filled_survey_tv);
            cropsap_survey_ll = itemView.findViewById(R.id.cropsap_survey_ll);

        }

    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private CropSapSurveyDetailsAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CropSapSurveyDetailsAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
