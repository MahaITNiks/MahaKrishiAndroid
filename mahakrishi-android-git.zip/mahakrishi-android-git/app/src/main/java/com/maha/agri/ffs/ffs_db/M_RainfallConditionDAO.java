package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_RainfallConditionDAO {

    @Query("SELECT * FROM M_RainfallConditionEY")
    List<M_RainfallConditionEY> getAll();

    @Query("SELECT * FROM M_RainfallConditionEY WHERE uid IN (:userIds)")
    List<M_RainfallConditionEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_RainfallConditionEY WHERE uid = :id")
    List<M_RainfallConditionEY> checkIdExists(int id);

    @Insert
    void insertAll(M_RainfallConditionEY... m_rainfallCondition);

    @Insert
    void insertOnlySingle(M_RainfallConditionEY m_rainfallConditionEY);
}
