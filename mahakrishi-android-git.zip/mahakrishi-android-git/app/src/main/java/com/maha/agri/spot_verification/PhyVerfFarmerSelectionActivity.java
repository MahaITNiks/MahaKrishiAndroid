package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.maha.agri.R;
import com.maha.agri.adapter.PhyVerfFarmerSelectAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.ApiCallbackCode;

public class PhyVerfFarmerSelectionActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView phy_verf_farmer_select_rv;
    private String scheme_name,village_name,farmer_name,component_id="";
    private SearchView phy_verf_farmer_searchview;
    private JSONArray farmer_list;
    private int district_id = 0,taluka_id = 0,village_id = 0,scheme_id = 0;
    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phy_verf_farmer_selection);
        getSupportActionBar().setTitle("Application received");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(PhyVerfFarmerSelectionActivity.this);
        sharedPref = new SharedPref(PhyVerfFarmerSelectionActivity.this);
        Intent intent = getIntent();
        scheme_name = intent.getStringExtra("scheme_name");
        village_name = intent.getStringExtra("village_name");
        farmer_name = intent.getStringExtra("farmer_name");
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        component_id = intent.getStringExtra("component_id");
        scheme_id = intent.getIntExtra("scheme_id",0);
        //farmer_list_based_on_dtv();

        farmer_list = new JSONArray();

        phy_verf_farmer_select_rv = (RecyclerView) findViewById(R.id.phy_verf_farmer_select_rv);
        phy_verf_farmer_searchview = (SearchView) findViewById(R.id.phy_verf_farmer_searchview);
        phy_verf_farmer_select_rv.setLayoutManager(new LinearLayoutManager(this));

      //  functionality();
        testdummy();// created by shashank on ly for test
    }

    private void testdummy() {
        Intent intent = new Intent(PhyVerfFarmerSelectionActivity.this,DripAndSprinklerActivity.class);
        intent.putExtra("district_id",district_id);
        intent.putExtra("taluka_id",taluka_id);
        intent.putExtra("village_id",village_id);
        intent.putExtra("component_id",component_id);
        intent.putExtra("scheme_id",scheme_id);
        intent.putExtra("farmer_details",farmer_list.toString());
        intent.putExtra("position","0");
        startActivity(intent);
    }

    private void functionality(){
        phy_verf_farmer_select_rv.addOnItemTouchListener(new PhyVerfFarmerSelectAdapter.RecyclerTouchListener(this, phy_verf_farmer_select_rv, new PhyVerfFarmerSelectAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent intent = new Intent(PhyVerfFarmerSelectionActivity.this,DripAndSprinklerActivity.class);
                intent.putExtra("district_id",district_id);
                intent.putExtra("taluka_id",taluka_id);
                intent.putExtra("village_id",village_id);
                intent.putExtra("component_id",component_id);
                intent.putExtra("scheme_id",scheme_id);
                intent.putExtra("farmer_details",farmer_list.toString());
                intent.putExtra("position",position);
                startActivity(intent);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            farmer_list = data.getJSONArray("farmer_record");
                            phy_verf_farmer_select_rv.setAdapter(new PhyVerfFarmerSelectAdapter(farmer_list,this));
                        }
                    } else {
                        phy_verf_farmer_select_rv.setAdapter(null);
                        Toast.makeText(this,"Farmer not found",Toast.LENGTH_SHORT).show();
                    }

                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}