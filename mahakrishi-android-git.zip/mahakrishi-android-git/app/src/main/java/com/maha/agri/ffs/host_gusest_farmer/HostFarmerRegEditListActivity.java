/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.host_gusest_farmer;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.FarmerFilterAdapter;
import com.maha.agri.adapter.HostFarmerAdapter;
import com.maha.agri.adapter.HostFarmerEditAdapter;
import com.maha.agri.enums.HostFarmerMode;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppHelper;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class HostFarmerRegEditListActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {

    private PreferenceManager preferenceManager;
    private RecyclerView recyclerView;
    private RelativeLayout headerRelativeLayout;
    private AppSession session;
    private HostFarmerMode hostFarmerMode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_farmer_reg_list);
        preferenceManager = new PreferenceManager(HostFarmerRegEditListActivity.this);
        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        recyclerView = findViewById(R.id.recyclerView);
        headerRelativeLayout = findViewById(R.id.headerRelativeLayout);
    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setElevation(0);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        EventBus.getDefault().register(this);
        session = new AppSession(this);

        if (getIntent() != null) {
            hostFarmerMode = (HostFarmerMode) getIntent().getSerializableExtra("HostFarmerMode");
        }


        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (hostFarmerMode == HostFarmerMode.ADD) {
            fetchData();

        } else {
            fetchEditData();
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject) o;
        DebugLog.getInstance().d("onMultiRecyclerViewItemClick=" + jsonObject);

        if (i == 1) {
            Intent intent = new Intent(this, D_F_GuestFarmerRegisrationActivity.class);
            intent.putExtra("mDetails", jsonObject.toString());
            startActivity(intent);

        } else if (i == 2) {
            Intent intent = new Intent(this, EditHostFarmerActivity.class);
            intent.putExtra("mDetails", jsonObject.toString());
            startActivity(intent);

        } else if (i == 3) {

            Intent intent = new Intent(this, GuestFarmerEditListActivity.class);
            intent.putExtra("mDetails", jsonObject.toString());
            startActivity(intent);
        }

    }



    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFire(EventModel event) {

        if (event != null) {

            DebugLog.getInstance().d("onEventFire=" + event.getEvent());

            if (event.getEvent().equalsIgnoreCase("update_1")) {
                if (hostFarmerMode == HostFarmerMode.ADD) {
                    fetchData();
                } else {
                    fetchEditData();
                }
            }
        }
    };


    private void showFilterDialog() {

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_farmer_filter);


        ListView listView = dialog.findViewById(R.id.listView);

        FarmerFilterAdapter farmerFilterAdapter = new FarmerFilterAdapter(this, AppHelper.getInstance().getFarmerFilterOptions());
        listView.setAdapter(farmerFilterAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });


        Button cancelButton = dialog.findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        Button confirmButton = dialog.findViewById(R.id.updateButton);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dialog.show();
    }


    private void fetchData() {
        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("user_id",  preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            jsonObject.put("season_id", AppSettings.getInstance().getValue(this,ApConstants.kSLED_SEASON_ID,ApConstants.kSLED_SEASON_ID));
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            jsonObject.put("year", year);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.hostFarmerList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchEditData() {
        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("season_id", AppSettings.getInstance().getValue(this,ApConstants.kSLED_SEASON_ID,ApConstants.kSLED_SEASON_ID));
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            jsonObject.put("year", year);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchHostFarmerEditListRequest(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 2);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void updateLayout() {
        if (hostFarmerMode == HostFarmerMode.ADD) {
            headerRelativeLayout.setVisibility(View.VISIBLE);
        } else {
            headerRelativeLayout.setVisibility(View.GONE);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (i == 1 && jsonObject != null) {
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    JSONArray mDataArray = response.getData();

                    if (hostFarmerMode == HostFarmerMode.ADD) {
                        HostFarmerAdapter hostFarmerAdapter = new HostFarmerAdapter(this, this, mDataArray);
                        recyclerView.setAdapter(hostFarmerAdapter);
                    } else {
                        HostFarmerEditAdapter hostFarmerAdapter = new HostFarmerEditAdapter(this, this, mDataArray);
                        recyclerView.setAdapter(hostFarmerAdapter);
                    }
                    updateLayout();
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 2 && jsonObject != null) {
                ResponseModel response = new ResponseModel(jsonObject);

                updateLayout();

                if (response.isStatus()) {
                    JSONArray mDataArray = response.getData();

                    HostFarmerEditAdapter hostFarmerAdapter = new HostFarmerEditAdapter(this, this, mDataArray);
                    recyclerView.setAdapter(hostFarmerAdapter);

                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}

