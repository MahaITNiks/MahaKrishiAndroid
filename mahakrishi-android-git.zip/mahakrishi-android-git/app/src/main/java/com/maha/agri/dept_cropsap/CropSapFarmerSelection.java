package com.maha.agri.dept_cropsap;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSapFarmerSelection extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView sp_cropsap_farmer_selection_village,cropsap_plot_type;
    private TextView cropsap_selection_farmername;
    private RecyclerView cropsap_farmer_listing_rv;
    private Button cropsap_selection_save;
    private String data,village_name,district_name,taluka_name,farmer_name = "";
    private String divison_id_str = "",divison_name_str,circle_id_str = "", sajja_id_str = "",circle_name = "", sajja_name="",district_id_str="",
            taluka_id_str="",farmer_id_str="",plot_type_name="";
    private int district_id = 0,taluka_id = 0,divison_id = 0,circle_id = 0,sajja_id = 0,farmer_id = 0,village_id = 0,plot_type_id=0;
    private JSONArray plot_type_list,village_list,farmer_list,District_List;
    ArrayList<String> VillageName;
    HashMap<Integer,String> village_map = new HashMap<Integer, String>();

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap_farmer_selection);

        getSupportActionBar().setTitle("Farmer / Survey List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(CropSapFarmerSelection.this);
        sharedPref = new SharedPref(CropSapFarmerSelection.this);

        get_district_taluka();
        get_plot_type();

        ids();
        initialization();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void ids(){
        sp_cropsap_farmer_selection_village = (TextView) findViewById(R.id.sp_cropsap_farmer_select_village);
        cropsap_plot_type = (TextView) findViewById(R.id.cropsap_plot_type);
        cropsap_farmer_listing_rv = (RecyclerView) findViewById(R.id.cropsap_farmer_listing_rv);
        cropsap_farmer_listing_rv.setLayoutManager(new LinearLayoutManager(this));
        //cropsap_selection_save = (Button) findViewById(R.id.cropsap_select_save);
    }

    private void initialization(){

        /*data = AppSettings.getInstance().getValue(CropSapFarmerSelection.this, ApConstants.kLOGIN_DATA,"");
        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        VillageName = new ArrayList<>();
        final int numberOfItemsInResp = village_list.length();
        for (int j = 0; j < numberOfItemsInResp; j++) {
            JSONObject village_json_object = null;
            try {
                village_json_object = village_list.getJSONObject(j);
                village_id = village_json_object.getString("village_id");
                village_name = village_json_object.getString("village_name");
                VillageName.add(village_name);
                village_map.put(j, village_id);
                village_id = "";
                sp_cropsap_farmer_selection_village.setAdapter(new ArrayAdapter<String>(CropSapFarmerSelection.this, android.R.layout.simple_spinner_dropdown_item, VillageName));

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }*/

        farmer_list = new JSONArray();
        plot_type_list = new JSONArray();
        
        cropsap_plot_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(plot_type_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(village_list, 4, "Select Village", "village_name", "village_id", CropSapFarmerSelection.this, CropSapFarmerSelection.this);
                }else{
                    get_plot_type();
                }
            }
        });

        sp_cropsap_farmer_selection_village.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getVillageLocation();
                 if(village_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(village_list, 3, "Select Village", "village_name", "village_id", CropSapFarmerSelection.this, CropSapFarmerSelection.this);
                }else{
                    getVillageLocation();
                }
            }
        });

        /*sp_cropsap_farmer_selection_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = village_map.get(sp_cropsap_farmer_selection_village.getSelectedItemPosition());
                village_name = sp_cropsap_farmer_selection_village.getSelectedItem().toString();
                farmer_list_based_on_dtv(village_id);
                //cropsap_selection_farmername.setText("Select");
                farmer_id = 0;
                farmer_list = new JSONArray();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/

        cropsap_farmer_listing_rv.addOnItemTouchListener(new CropsapFarmerListingAdapter.RecyclerTouchListener(this, cropsap_farmer_listing_rv, new CropsapFarmerListingAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Intent intent = new Intent(CropSapFarmerSelection.this, CropSapSurveyDetails.class);
                intent.putExtra("village_id", village_id);
                intent.putExtra("village_name", village_name);
                intent.putExtra("farmer_id", farmer_id);
                intent.putExtra("farmer_name",farmer_name);
                intent.putExtra("district_id", district_id);
                intent.putExtra("taluka_id", taluka_id);
                startActivity(intent);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    private void get_district_taluka(){
        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void get_plot_type() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void farmer_list_based_on_dtv(int village_id){
        JSONObject param = new JSONObject();
        try {
            param.put("village_id",village_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_get_farmer_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                //district
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            District_List = jsonObject.getJSONArray("data");
                            for (int j = 0; j < District_List.length(); j++) {
                                JSONObject district_json_object = District_List.getJSONObject(j);
                                divison_id_str = district_json_object.getString("division_id");
                                divison_name_str = district_json_object.getString("division_name");
                                district_name = district_json_object.getString("district_name");
                                taluka_name = district_json_object.getString("taluka_name");
                                district_id_str = district_json_object.getString("district_id");
                                taluka_id_str = district_json_object.getString("taluka_id");
                                circle_id_str = district_json_object.getString("circle_id");
                                circle_name = district_json_object.getString("circle_name");
                                sajja_id_str = district_json_object.getString("sajja_id");
                                sajja_name = district_json_object.getString("sajja_name");

                                divison_id = Integer.valueOf(divison_id_str);
                                district_id = Integer.valueOf(district_id_str);
                                taluka_id = Integer.valueOf(taluka_id_str);
                                circle_id = Integer.valueOf(circle_id_str);
                                sajja_id = Integer.valueOf(sajja_id_str);

                                getVillageLocation();
                            }
                        }
                    }
                }
                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            plot_type_list = jsonObject.getJSONArray("data");
                        }
                    }
                }
                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j < farmer_list.length(); j++) {
                                JSONObject farmer_json_object = farmer_list.getJSONObject(j);
                                farmer_id_str = farmer_json_object.getString("id");
                                farmer_id = Integer.parseInt(farmer_id_str);
                            }
                            cropsap_farmer_listing_rv.setAdapter(new CropsapFarmerListingAdapter(farmer_list,this));
                        }

                    }else{
                        cropsap_farmer_listing_rv.setAdapter(null);
                        Toast toast= Toast.makeText(getApplicationContext(), "Farmer list not found", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                        toast.show();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 4) {
            plot_type_id = Integer.parseInt(s1);
            plot_type_name = s;
            cropsap_plot_type.setText(plot_type_name);
            farmer_list = new JSONArray();
            village_list = new JSONArray();
            sp_cropsap_farmer_selection_village.setText("Select");
            getVillageLocation();
        }
        if (i == 3) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            sp_cropsap_farmer_selection_village.setText(village_name);
            farmer_list = new JSONArray();
            farmer_list_based_on_dtv(village_id);
        }
    }
}
