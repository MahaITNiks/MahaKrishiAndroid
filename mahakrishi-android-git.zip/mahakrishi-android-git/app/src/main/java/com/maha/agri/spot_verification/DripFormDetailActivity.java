package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DripFormDetailActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {
    /*Intent get details*/
    private Intent intent;
    private String form_details;
    private int form_position;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    /*ID calling*/
    private TextView spot_verification_drip_select_tv;
    /*As per bill*/
    private EditText billBatchNoEt,billCMLEt,billQtyEt,billPriceUnitEt,billTotalTV,actualTotalTV;
    /*Actual*/
    private EditText actualBatchNoEt,actualCMLEt,actualQtyEt,actualPriceUnitEt;
    /*Save and Reset*/
    private Button spot_verification_bill_data_save_btn,spot_verification_bill_data_reset_btn;
    private JSONArray drip_form_details_list,item_description_rate_list,filled_data;
    private String Drip_bill_id="";
    private int type_id;
    private int village_id,farmer_id,district_id,takula_id;
    private String billBatchNoEtstr = "",billQtyEtstr = "",billPriceUnitEtstr = "",asperbill_total_price = "";
    private int billBatchNoEtint = 0,billQtyEtint = 0,billPriceUnitEtint = 0;

    private String actualBatchNoEtstr = "",actualQtyEtstr = "",actualPriceUnitEtstr = "",actual_total_price = "",type_name = "",type_id_str = "";
    private int actualBatchNoEtint= 0 ,actualQtyEtint = 0 ,actualPriceUnitEtint = 0;

    private int total_as_per_bill,total_actual,item_description_code = 0;;
    private String item_code = "", asper_bill_rate = "";
    private int manuf_code = 0;
    private int scheme_id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drip_form_detail);
        getSupportActionBar().setTitle("Item list");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DripFormDetailActivity.this);
        sharedPref = new SharedPref(DripFormDetailActivity.this);
        try {
            getIntentDetails();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        init();
        default_config();
        get_field_drip_bill_data();
    }

    private void getIntentDetails() throws JSONException {
        intent=getIntent();
        //form_details=intent.getStringExtra("form_details");
        form_position=intent.getIntExtra("form_position",0);
        village_id=intent.getIntExtra("village_id",0);
        takula_id=intent.getIntExtra("takula_id",0);
        farmer_id=intent.getIntExtra("farmer_id",0);
        district_id=intent.getIntExtra("district_id",0);
        item_code = intent.getStringExtra("item_code");
        manuf_code = intent.getIntExtra("manuf_code",0);
        scheme_id = intent.getIntExtra("scheme_id",0);
        //JSONArray jsonArray= new JSONArray(form_details);
        //JSONObject jsonObject= jsonArray.getJSONObject(form_position);
        //Drip_bill_id=jsonObject.getString("id");
        //getSupportActionBar().setTitle(jsonObject.getString("name"));

    }

    private void init() {
        spot_verification_drip_select_tv=(TextView)findViewById(R.id.spot_verification_drip_select_tv);
        /*As per bill*/
        billBatchNoEt=(EditText)findViewById(R.id.billBatchNoEt);
        billCMLEt=(EditText)findViewById(R.id.billCMLEt);
        billQtyEt=(EditText)findViewById(R.id.billQtyEt);
        billPriceUnitEt=(EditText)findViewById(R.id.billPriceUnitEt);
        billTotalTV=(EditText) findViewById(R.id.billTotalTV);
        /*Actual*/
        actualBatchNoEt=(EditText)findViewById(R.id.actualBatchNoEt);
        actualCMLEt=(EditText)findViewById(R.id.actualCMLEt);
        actualQtyEt=(EditText)findViewById(R.id.actualQtyEt);
        actualPriceUnitEt=(EditText)findViewById(R.id.actualPriceUnitEt);
        actualTotalTV=(EditText) findViewById(R.id.actualTotalTV);
        drip_form_details_list = new JSONArray();
        item_description_rate_list = new JSONArray();
        filled_data = new JSONArray();
        /*Button*/
        spot_verification_bill_data_save_btn=(Button)findViewById(R.id.spot_verification_bill_data_save_btn);
        spot_verification_bill_data_reset_btn=(Button)findViewById(R.id.spot_verification_bill_data_reset_btn);

        drip_form_details_list= new JSONArray();
    }

    private void default_config() {

        spot_verification_drip_select_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drip_form_details_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(drip_form_details_list, 1, "Select", "item_desc", "comp_code", DripFormDetailActivity.this, DripFormDetailActivity.this);
                }
            }
        });

        spot_verification_bill_data_save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drip_final_save_form();
            }
        });

        spot_verification_bill_data_reset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                spot_verification_drip_select_tv.setEnabled(true);
                billBatchNoEt.setEnabled(true);
                billCMLEt.setEnabled(true);
                billQtyEt.setEnabled(true);
                billPriceUnitEt.setEnabled(true);
                billTotalTV.setEnabled(true);
                actualBatchNoEt.setEnabled(true);
                actualCMLEt.setEnabled(true);
                actualQtyEt.setEnabled(true);
                actualPriceUnitEt.setEnabled(true);
                actualTotalTV.setEnabled(true);
                spot_verification_bill_data_save_btn.setEnabled(true);
                spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.button_color));

            }
        });

        get_filled_data();

    }

    private void get_field_drip_bill_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("item_code",item_code);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString()); // CHANGE URL AND DELETE
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.spot_veri_desc_list(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void rate_data(){
        JSONObject param = new JSONObject();
        try {
            param.put("item_code", item_code);
            param.put("manuf_code", manuf_code);
            param.put("comp_code", item_description_code);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.spot_veri_rate_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void drip_final_save_form() {
        billBatchNoEtstr=billBatchNoEt.getText().toString().trim();
        billQtyEtstr=billQtyEt.getText().toString().trim();
        billPriceUnitEtstr=billPriceUnitEt.getText().toString().trim();
        actualBatchNoEtstr=actualBatchNoEt.getText().toString().trim();
        actualQtyEtstr=actualQtyEt.getText().toString().trim();
        actualPriceUnitEtstr=actualPriceUnitEt.getText().toString().trim();
        if(type_name.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Please select value",Toast.LENGTH_LONG).show();
        }else if(billBatchNoEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter batch number for bill",Toast.LENGTH_LONG).show();
        }else if(billCMLEt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter CML number for bill",Toast.LENGTH_LONG).show();
        }else if(billQtyEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter quantity number for bill",Toast.LENGTH_LONG).show();
        }else if(billPriceUnitEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter price unit for bill",Toast.LENGTH_LONG).show();
        }else if(billTotalTV.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter total value for bill",Toast.LENGTH_LONG).show();
        }else if(actualBatchNoEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter batch number for actual",Toast.LENGTH_LONG).show();
        }else if(actualCMLEt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter CML number for actual",Toast.LENGTH_LONG).show();
        }else if(actualQtyEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter quantity number for actual",Toast.LENGTH_LONG).show();
        }else if(actualPriceUnitEtstr.equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter price unit for actual",Toast.LENGTH_LONG).show();
        }else if(actualTotalTV.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(DripFormDetailActivity.this,"Enter total value for actual",Toast.LENGTH_LONG).show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("district_id", district_id);
                param.put("taluka_id", takula_id);
                param.put("village_id", village_id);
                param.put("scheme_id", scheme_id);
                param.put("item_code", item_code);
                param.put("component_code", item_description_code);
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

                param.put("drip_bill_id", Drip_bill_id);
                param.put("type", type_id);
                param.put("batch_no_as_bill", billBatchNoEt.getText().toString().trim());
                param.put("cml_no_as_bill", billCMLEt.getText().toString().trim());
                param.put("quantity_as_bill", billQtyEt.getText().toString().trim());
                param.put("price_unit_as_bill", asper_bill_rate);
                param.put("total_as_bill", billTotalTV.getText().toString().trim());

                param.put("batch_no_actual", actualBatchNoEt.getText().toString().trim());
                param.put("cml_no_actual", actualCMLEt.getText().toString().trim());
                param.put("quantity_actual", actualQtyEt.getText().toString().trim());
                param.put("price_unit_actual", actualPriceUnitEt.getText().toString().trim());
                param.put("total_actual", actualTotalTV.getText().toString().trim());
                param.put("item_type_id", "1");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.spot_verification_drip_bill_against_id_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 3);

        }
    }

    private void get_filled_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("drip_bill_id",Drip_bill_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.spot_verification_drip_bill_list_against_id(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            drip_form_details_list= jsonObject.getJSONArray("data");
                        }

                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            item_description_rate_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= item_description_rate_list.length(); j++) {
                                JSONObject rate_json_object = item_description_rate_list.getJSONObject(j);
                                asper_bill_rate = rate_json_object.getString("item_mrp");
                                billPriceUnitEt.setText(asper_bill_rate);

                            }
                        }
                    }else {
                        Toast.makeText(DripFormDetailActivity.this,"Rate of that particular component is not found",Toast.LENGTH_LONG).show();
                    }
                }

                if(i == 3){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(DripFormDetailActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setContentText("Submitted Successfully")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    }).show();
                        }

                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            filled_data = jsonObject.getJSONArray("data");
                            for(int j = 0;j<filled_data.length();j++){
                                JSONObject filled_json_object = filled_data.getJSONObject(j);
                                type_name = filled_json_object.getString("type_name");
                                billBatchNoEtstr = filled_json_object.getString("asperbill_batch_no");
                                billQtyEtstr = filled_json_object.getString("asperbill_quantity");
                                billPriceUnitEtstr = filled_json_object.getString("asperbill_unit_rate");
                                asperbill_total_price = filled_json_object.getString("asperbill_total_price");
                                actualBatchNoEtstr = filled_json_object.getString("actual_batch_no");
                                actualQtyEtstr = filled_json_object.getString("actual_quantity");
                                actualPriceUnitEtstr = filled_json_object.getString("actual_unit_rate");
                                actual_total_price = filled_json_object.getString("actual_total_price");
                                set_filled_data();
                            }
                        }

                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i==1){
            item_description_code = Integer.parseInt(s1);
            type_name = s;
            spot_verification_drip_select_tv.setText(type_name);
            rate_data();
            /*As Per Bill*/
            billBatchNoEt.setText("");
            billCMLEt.setText("");
            billQtyEt.setText("");
            billPriceUnitEt.setText("");
            billTotalTV.setText("");
            /*Actual*/
            actualBatchNoEt.setText("");
            actualCMLEt.setText("");
            actualQtyEt.setText("");
            actualPriceUnitEt.setText("");
            actualTotalTV.setText("");
        }

    }

    private void set_filled_data(){
        if(!type_name.equalsIgnoreCase("")&&!billBatchNoEtstr.equalsIgnoreCase("")&&!billQtyEtstr.equalsIgnoreCase("")&&
                !billPriceUnitEtstr.equalsIgnoreCase("")&&!asperbill_total_price.equalsIgnoreCase("")
                &&!actualBatchNoEtstr.equalsIgnoreCase("") &&!actualQtyEtstr.equalsIgnoreCase("")
                &&!actualPriceUnitEtstr.equalsIgnoreCase("")&&!actual_total_price.equalsIgnoreCase("")){
            spot_verification_drip_select_tv.setText(type_name);
            /*As per bill*/
            billBatchNoEt.setText(billBatchNoEtstr);
            billQtyEt.setText(billQtyEtstr);
            billPriceUnitEt.setText(billPriceUnitEtstr);
            billTotalTV.setText(asperbill_total_price);
            /*Actual*/
            actualBatchNoEt.setText(actualBatchNoEtstr);
            actualQtyEt.setText(actualQtyEtstr);
            actualPriceUnitEt.setText(actualPriceUnitEtstr);
            actualTotalTV.setText(actual_total_price);
            spot_verification_drip_select_tv.setEnabled(false);
            billBatchNoEt.setEnabled(false);
            billQtyEt.setEnabled(false);
            billPriceUnitEt.setEnabled(false);
            billTotalTV.setEnabled(false);
            actualBatchNoEt.setEnabled(false);
            actualQtyEt.setEnabled(false);
            actualPriceUnitEt.setEnabled(false);
            actualTotalTV.setEnabled(false);
            spot_verification_bill_data_save_btn.setEnabled(false);
            spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.grey_button_backy));
        }else {
            spot_verification_drip_select_tv.setEnabled(true);
            billBatchNoEt.setEnabled(true);
            billQtyEt.setEnabled(true);
            billPriceUnitEt.setEnabled(true);
            billTotalTV.setEnabled(true);
            actualBatchNoEt.setEnabled(true);
            actualQtyEt.setEnabled(true);
            actualPriceUnitEt.setEnabled(true);
            actualTotalTV.setEnabled(true);
            spot_verification_bill_data_save_btn.setEnabled(true);
            spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.button_color));
        }
    }
}
