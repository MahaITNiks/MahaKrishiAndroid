package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CottonPlant1 extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView dept_cropsap_cotton_crop_plant_tv;
    private EditText  section_four_edt;

    //private Spinner sp_crop_plant;
    private ImageView  dept_cropsap_new_section_four_photo;
    private Button cropsap_cotton_save_continue_btn;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private int district_id, taluka_id, village_id, farmer_id,crop_id;
    private int crop_cond_id = 0,generic_int,white_fly_int,thrips_int,semilooper_int;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private String currentTime;
    private AppLocationManager locationManager;

    //Image
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private File photoFile3 = null;
    private File photoFile4 = null;
    private File photoFile5 = null;
    private File photoFile6 = null;
    public double lat,lang;
    int count = 1;
    // New
    private String crop_cotton_plant_name = "", pest_name = "",generic_str="",white_fly_str="",thrips_str="",semilooper_str="";
    private int crop_cotton_plant_id = 0,cotton_selected_pest_id = 0;
    private TextView cotton_major_pest,cotton_minor_pest;
    private JSONArray cotton_crop_plant_list,cotton_major_pest_list,cotton_minor_pest_list;

    private LinearLayout ll_Whitefly_No_Plant_Cotton,ll_Thrips_No_Plant_Cotton,ll_Pink_Spotted_American_Combined_Cotton,ll_Spodoptera_Cotton,ll_Semilooper_Cotton,ll_Generic_Layout_Major_and_Minor_Pest_Cotton,ll_Defender_Cotton;
    private EditText et_Whitefly_No_Plant_Cotton,et_Thrips_No_Plant_Cotton,et_no_Spodoptera1_Cotton,et_no_Spodoptera2_Cotton,et_no_semilooper_Cotton,et_no_Generic_Layout_Minor_Major_Pest_Cotton,et_Defender_Cotton,defender_cotton;
    private ArrayList<String> pest_list_names_cotton=new ArrayList<String>();
    private ArrayList<LinearLayout> pest_list_layout_cotton=new ArrayList<LinearLayout>();
    private ArrayList<ImageView> pest_image_list_layout_cotton=new ArrayList<ImageView>();
    private ArrayList<String> pest_image_list_names_cotton = new ArrayList<String>();
    private ArrayList<File> pest_image_photoFile_cotton = new ArrayList<File>();
    private ArrayList<EditText> pest_list_et_cotton=new ArrayList<EditText>();
    private boolean flag_cotton=false;

    private TextView Generic_Layout_Major_and_Minor_Pest_tv_Cotton;
    private Button btn_add_pest_details_cotton;
    private TableLayout add_pest_titleTableLayout_cotton;
    private RecyclerView add_more_pest_rv_cotton;

    private JSONObject cotton_aphids_pest_json_obj = new JSONObject();
    private JSONObject cotton_leafhopper_pest_json_obj = new JSONObject();
    private JSONObject cotton_whitefly_pest_json_obj = new JSONObject();
    private JSONObject cotton_thrips_pest_json_obj = new JSONObject();
    private JSONObject cotton_mealybug_pest_json_obj = new JSONObject();
    private JSONObject cotton_spodotera_pest_json_obj = new JSONObject();
    private JSONObject cotton_leafroller_pest_json_obj = new JSONObject();
    private JSONObject cotton_redcottonbug_pest_json_obj = new JSONObject();
    private JSONObject cotton_duskybottonbug_pest_json_obj = new JSONObject();
    private JSONObject cotton_semilooper_pest_json_obj = new JSONObject();
    private JSONObject cotton_redmites_pest_json_obj = new JSONObject();
    private JSONObject cotton_pink_pest_json_obj = new JSONObject();
    private JSONObject cotton_spotted_pest_json_obj = new JSONObject();
    private JSONObject cotton_american_pest_json_obj = new JSONObject();

    private JSONArray pest_details_json_array_cotton = new JSONArray();

    private ImageView photo_Whitefly_No_Plant_Cotton,photo_Thrips_No_Plant_Cotton,photo1_spodoptera_Cotton,photo2_spodoptera_Cotton,photo_semilooper_Cotton,photo_Generic_Layout_Minor_Pest_Cotton;
    private String imagePath1="", imagePath2="", imagePath3="", imagePath4="", imagePath5="", imagePath6 = "",imagePath7 = "", imagePath8 = "",type;
    private String image_1_file_name="",image_2_file_name = "",image_3_file_name = "",image_4_file_name = "",image_5_file_name = "",image_6_file_name = "",image_7_file_name = "",image_8_file_name = "";
    private SweetAlertDialog sweetAlertDialog;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_cotton);
        getSupportActionBar().setTitle("Pest Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(CottonPlant1.this);
        sharedPref = new SharedPref(CottonPlant1.this);
        locationManager = new AppLocationManager(this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        initView();
        setListners();
    }

    private void initView() {

        //Textview
        dept_cropsap_cotton_crop_plant_tv = (TextView) findViewById(R.id.dept_cropsap_cotton_crop_plant_tv);
        dept_cropsap_cotton_crop_plant_tv.setEnabled(false);
        cotton_major_pest=(TextView)findViewById(R.id.cotton_major_pest);
        cotton_minor_pest=(TextView)findViewById(R.id.cotton_minor_pest);
        Generic_Layout_Major_and_Minor_Pest_tv_Cotton=(TextView)findViewById(R.id.Generic_Layout_Major_and_Minor__Pest_tv_Cotton);


        //Edittext
        section_four_edt = (EditText) findViewById(R.id.section_four_edt);
        et_Whitefly_No_Plant_Cotton=(EditText)findViewById(R.id.et_Whitefly_No_Plant_Cotton);
        et_Thrips_No_Plant_Cotton=(EditText)findViewById(R.id.et_Thrips_No_Plant_Cotton);
        et_no_Spodoptera1_Cotton=(EditText)findViewById(R.id.et_no_Spodoptera1_Cotton);
        et_no_Spodoptera2_Cotton=(EditText)findViewById(R.id.et_no_Spodoptera2_Cotton);
        et_no_semilooper_Cotton=(EditText)findViewById(R.id.et_no_semilooper_Cotton);
        et_no_Generic_Layout_Minor_Major_Pest_Cotton=(EditText)findViewById(R.id.et_no_Generic_Layout_Minor_Major_Pest_Cotton);
        et_Defender_Cotton=(EditText)findViewById(R.id.et_Defender_Cotton);
        defender_cotton=(EditText)findViewById(R.id.defender_cotton);

        //LL
        ll_Whitefly_No_Plant_Cotton=(LinearLayout)findViewById(R.id.ll_Whitefly_No_Plant_Cotton);
        ll_Thrips_No_Plant_Cotton=(LinearLayout)findViewById(R.id.ll_Thrips_No_Plant_Cotton);
        ll_Generic_Layout_Major_and_Minor_Pest_Cotton=(LinearLayout)findViewById(R.id.ll_Generic_Layout_Major_and_Minor_Pest_Cotton);
        ll_Pink_Spotted_American_Combined_Cotton=(LinearLayout)findViewById(R.id.ll_Pink_Spotted_American_Combined_Cotton);
        ll_Spodoptera_Cotton=(LinearLayout)findViewById(R.id.ll_Spodoptera_Cotton);
        ll_Semilooper_Cotton=(LinearLayout)findViewById(R.id.ll_Semilooper_Cotton);
        ll_Defender_Cotton=(LinearLayout)findViewById(R.id.ll_Defender_Cotton);

        //Imageview
        dept_cropsap_new_section_four_photo = (ImageView) findViewById(R.id.dept_cropsap_new_section_four_photo);
        photo_Whitefly_No_Plant_Cotton=(ImageView)findViewById(R.id.photo_Whitefly_No_Plant_Cotton);
        photo_Thrips_No_Plant_Cotton=(ImageView)findViewById(R.id.photo_Thrips_No_Plant_Cotton);
        photo1_spodoptera_Cotton=(ImageView)findViewById(R.id.photo1_spodoptera_Cotton);
        photo2_spodoptera_Cotton=(ImageView)findViewById(R.id.photo2_spodoptera_Cotton);
        photo_semilooper_Cotton=(ImageView)findViewById(R.id.photo_semilooper_Cotton);
        photo_Generic_Layout_Minor_Pest_Cotton=(ImageView)findViewById(R.id.photo_Generic_Layout_Minor_Pest_Cotton);

        //Button
        cropsap_cotton_save_continue_btn = (Button) findViewById(R.id.cropsap_cotton_save_continue_btn);
        btn_add_pest_details_cotton=(Button)findViewById(R.id.btn_add_pest_details_cotton);

        // Table, Row and Recycler
        add_pest_titleTableLayout_cotton=(TableLayout)findViewById(R.id.add_pest_titleTableLayout_cotton);
        add_more_pest_rv_cotton=(RecyclerView)findViewById(R.id.add_more_pest_rv_cotton);

        currentTime = ApUtil.getCurrentTimeStamp();
        cotton_crop_plant_list = new JSONArray();
        cotton_major_pest_list = new JSONArray();
        cotton_minor_pest_list = new JSONArray();
        plant_service();
        cotton_major_pest_service();
        cotton_minor_pest_service();
        initLayouts();
        zero_pest_input();
        thrips_zero_input();
        white_fly_pest_input();
        semilooper_zero_input();

    }

    private void initLayouts() {

        pest_list_names_cotton.add("WHITE FLY");
        pest_list_names_cotton.add("THRIPS");
        pest_list_names_cotton.add("SPODOPTERA");
        pest_list_names_cotton.add("SEMILOOPER");

        pest_list_et_cotton.add(et_Whitefly_No_Plant_Cotton);
        pest_list_et_cotton.add(et_Thrips_No_Plant_Cotton);
        pest_list_et_cotton.add(et_no_Spodoptera1_Cotton);
        pest_list_et_cotton.add(et_no_Spodoptera2_Cotton);
        pest_list_et_cotton.add(et_no_semilooper_Cotton);

        pest_list_layout_cotton.add(ll_Whitefly_No_Plant_Cotton);
        pest_list_layout_cotton.add(ll_Thrips_No_Plant_Cotton);
        pest_list_layout_cotton.add(ll_Spodoptera_Cotton);
        pest_list_layout_cotton.add(ll_Semilooper_Cotton);

        pest_image_list_layout_cotton.add(photo_Whitefly_No_Plant_Cotton);
        pest_image_list_layout_cotton.add(photo_Thrips_No_Plant_Cotton);
        pest_image_list_layout_cotton.add(photo1_spodoptera_Cotton);
        pest_image_list_layout_cotton.add(photo2_spodoptera_Cotton);
        pest_image_list_layout_cotton.add(photo_semilooper_Cotton);
        pest_image_list_layout_cotton.add(photo_Generic_Layout_Minor_Pest_Cotton);
        /*Not added generic*/

        pest_image_list_names_cotton.add(imagePath1);
        pest_image_list_names_cotton.add(imagePath2);
        pest_image_list_names_cotton.add(imagePath3);
        pest_image_list_names_cotton.add(imagePath4);
        pest_image_list_names_cotton.add(imagePath5);
        pest_image_list_names_cotton.add(imagePath6);

        /* GENERIC pest_image_list_names_cotton.add(image_6_file_name);*/
        pest_image_photoFile_cotton.add(photoFile1);
        pest_image_photoFile_cotton.add(photoFile2);
        pest_image_photoFile_cotton.add(photoFile3);
        pest_image_photoFile_cotton.add(photoFile4);
        pest_image_photoFile_cotton.add(photoFile5);
        pest_image_photoFile_cotton.add(photoFile6);

    }

    private void setListners() {
        dept_cropsap_cotton_crop_plant_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cotton_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(cotton_crop_plant_list, 1, "Select plant", "crop_plant_name", "id", CottonPlant1.this, CottonPlant1.this);
                }
            }
        });

        cotton_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (cotton_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(cotton_major_pest_list, 2, "Select Major Pest", "pest_eng_name", "id", CottonPlant1.this, CottonPlant1.this);
                }else{
                    cotton_major_pest_service();
                }
            }
        });

        cotton_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (cotton_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(cotton_minor_pest_list, 3, "Select Minor Pest", "pest_eng_name", "id", CottonPlant1.this, CottonPlant1.this);
                }else{
                    cotton_minor_pest_service();
                }
            }
        });

        // Photo Take
        photo_Whitefly_No_Plant_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        photo_Thrips_No_Plant_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        photo1_spodoptera_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "3";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        photo2_spodoptera_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "4";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        photo_semilooper_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "5";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        photo_Generic_Layout_Minor_Pest_Cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(CottonPlant1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "6";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });
        // Photos Over

        btn_add_pest_details_cotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String et_no_Generic_Layout_Minor_Major_Pest_Cotton_str= et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim();
                String et_Whitefly_No_Plant_Cotton_str = et_Whitefly_No_Plant_Cotton.getText().toString().trim();
                String et_Thrips_No_Plant_Cotton_str=et_Thrips_No_Plant_Cotton.getText().toString().trim();
                String et_no_Spodoptera1_Cotton_str=et_no_Spodoptera1_Cotton.getText().toString().trim();
                String et_no_Spodoptera2_Cotton_str=et_no_Spodoptera2_Cotton.getText().toString().trim();
                String et_no_semilooper_Cotton_str=et_no_semilooper_Cotton.getText().toString().trim();

                //Generic
                if(pest_name.equalsIgnoreCase("APHIDS") || pest_name.equalsIgnoreCase("LEAF HOPPER") || pest_name.equalsIgnoreCase("MEALY BUG")
                        || pest_name.equalsIgnoreCase("LEAF ROLLER") || pest_name.equalsIgnoreCase("RED COTTON BUG") || pest_name.equalsIgnoreCase("DUSKY COTTON BUG")
                        || pest_name.equalsIgnoreCase("RED MITES") || pest_name.equalsIgnoreCase("PINK BOLLWORM") || pest_name.equalsIgnoreCase("SPOTTED BOLLWORM") || pest_name.equalsIgnoreCase("AMERICAN BOLLWORM") ){

                    if(et_no_Generic_Layout_Minor_Major_Pest_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of pest present ",Toast.LENGTH_SHORT).show();
                    }else if(imagePath6.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of the pest",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImagenServer();
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }
                }
                // White
                else if(pest_name.equalsIgnoreCase("WHITE FLY")){
                    if(et_Whitefly_No_Plant_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of plants with damage",Toast.LENGTH_SHORT).show();
                    }else if(imagePath1.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of the damaged plants",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImagenServer();
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }
                }
                //Thrips
                else if(pest_name.equalsIgnoreCase("THRIPS")){
                    if(et_Thrips_No_Plant_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of plants with damage",Toast.LENGTH_SHORT).show();
                    }else if(imagePath2.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of the damaged plants",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImagenServer();
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }
                }
                //Spodoptera
                else if(pest_name.equalsIgnoreCase("SPODOPTERA")){
                    if(et_no_Spodoptera1_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of Gregarious Larvae",Toast.LENGTH_SHORT).show();
                    }
                    else if(imagePath3.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of Gregarious Larvae",Toast.LENGTH_SHORT).show();
                    }
                    else if(et_no_Spodoptera2_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of Solitary Larvae",Toast.LENGTH_SHORT).show();
                    }else if(imagePath4.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of Solitary Larvae",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        uploadImagenServer();
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }
                }
                //Semilooper
                else if(pest_name.equalsIgnoreCase("SEMILOOPER")){
                    if(et_no_semilooper_Cotton_str.equalsIgnoreCase("")){
                        Toast.makeText(CottonPlant1.this,"Enter the number of pest present",Toast.LENGTH_SHORT).show();
                    }else if(imagePath5.isEmpty()){
                        Toast.makeText(CottonPlant1.this,"Click photo of pest present",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImagenServer();
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }
                }

            }
        });

        cropsap_cotton_save_continue_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String defender_soyabean_str=defender_cotton.getText().toString();
                if(pest_details_json_array_cotton.length()>0) {
                    if(pest_details_json_array_cotton.toString().contains("APHIDS") &&
                            pest_details_json_array_cotton.toString().contains("LEAF HOPPER") &&
                            pest_details_json_array_cotton.toString().contains("WHITE FLY") &&
                            pest_details_json_array_cotton.toString().contains("THRIPS") &&
                            pest_details_json_array_cotton.toString().contains("PINK BOLLWORM") &&
                            pest_details_json_array_cotton.toString().contains("SPOTTED BOLLWORM") &&
                            pest_details_json_array_cotton.toString().contains("AMERICAN BOLLWORM")) {
                    if (defender_soyabean_str.isEmpty()) {
                        Toast.makeText(CottonPlant1.this, "Enter Defender", Toast.LENGTH_SHORT).show();
                    } else {
                        save_cotton_crop_data_service();
                    }
                }else{
                        sweetAlertDialog = new SweetAlertDialog(CottonPlant1.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Enter data for all major pests");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                            }
                        }).show();
                }
                }else {
                    final Toast toast = Toast.makeText(CottonPlant1.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 0);
                }
            }
        });
    }

    private void zero_pest_input(){
        et_no_Generic_Layout_Minor_Major_Pest_Cotton.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                generic_str = et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim();
                if(!generic_str.equalsIgnoreCase("")){
                    generic_int = Integer.parseInt(generic_str);
                    if(generic_int == 0){
                        photo_Generic_Layout_Minor_Pest_Cotton.setVisibility(View.GONE);
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }else{
                        photo_Generic_Layout_Minor_Pest_Cotton.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void white_fly_pest_input(){
        et_Whitefly_No_Plant_Cotton.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                white_fly_str = et_Whitefly_No_Plant_Cotton.getText().toString().trim();
                if(!white_fly_str.equalsIgnoreCase("")){
                    white_fly_int = Integer.parseInt(white_fly_str);
                    if(white_fly_int == 0){
                        photo_Whitefly_No_Plant_Cotton.setVisibility(View.GONE);
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }else{
                        photo_Whitefly_No_Plant_Cotton.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void thrips_zero_input(){
        et_Thrips_No_Plant_Cotton.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                thrips_str = et_Thrips_No_Plant_Cotton.getText().toString().trim();
                if(!thrips_str.equalsIgnoreCase("")){
                    thrips_int = Integer.parseInt(thrips_str);
                    if(thrips_int == 0){
                        photo_Thrips_No_Plant_Cotton.setVisibility(View.GONE);
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }else{
                        photo_Thrips_No_Plant_Cotton.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void semilooper_zero_input(){
        et_no_semilooper_Cotton.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                semilooper_str = et_no_semilooper_Cotton.getText().toString().trim();
                if(!semilooper_str.equalsIgnoreCase("")){
                    semilooper_int = Integer.parseInt(semilooper_str);
                    if(semilooper_int == 0){
                        photo_semilooper_Cotton.setVisibility(View.GONE);
                        add_pest_details_cotton(cotton_selected_pest_id,pest_name);
                    }else{
                        photo_semilooper_Cotton.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void add_pest_details_cotton(int cotton_selected_pest_id, String pest_name) {

        try{
            switch (pest_name) {
                case "APHIDS":
                    cotton_aphids_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_aphids_pest_json_obj.put("pest_name", pest_name);
                    cotton_aphids_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_aphids_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_aphids_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_aphids_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_aphids_pest_json_obj);
                    resetforms();
                    break;
                case "LEAF HOPPER":
                    cotton_leafhopper_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_leafhopper_pest_json_obj.put("pest_name", pest_name);
                    cotton_leafhopper_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_leafhopper_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_leafhopper_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_leafhopper_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_leafhopper_pest_json_obj);
                    resetforms();
                    break;
                case "WHITE FLY":
                    cotton_whitefly_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_whitefly_pest_json_obj.put("pest_name", pest_name);
                    cotton_whitefly_pest_json_obj.put("spo_gre_lar_pic", imagePath1);
                    cotton_whitefly_pest_json_obj.put("spo_gre_lar_no", et_Whitefly_No_Plant_Cotton.getText().toString().trim());
                    cotton_whitefly_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_whitefly_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_whitefly_pest_json_obj);
                    resetforms();
                    break;
                case "THRIPS":
                    cotton_thrips_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_thrips_pest_json_obj.put("pest_name", pest_name);
                    cotton_thrips_pest_json_obj.put("spo_gre_lar_pic", imagePath2);
                    cotton_thrips_pest_json_obj.put("spo_gre_lar_no", et_Thrips_No_Plant_Cotton.getText().toString().trim());
                    cotton_thrips_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_thrips_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_thrips_pest_json_obj);
                    resetforms();
                    break;
                case "MEALY BUG":
                    cotton_mealybug_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_mealybug_pest_json_obj.put("pest_name", pest_name);
                    cotton_mealybug_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_mealybug_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_mealybug_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_mealybug_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_mealybug_pest_json_obj);
                    resetforms();
                    break;
                case "SPODOPTERA":
                    cotton_spodotera_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_spodotera_pest_json_obj.put("pest_name", pest_name);
                    cotton_spodotera_pest_json_obj.put("spo_gre_lar_pic", imagePath3);
                    cotton_spodotera_pest_json_obj.put("spo_gre_lar_no", et_no_Spodoptera1_Cotton.getText().toString().trim());
                    cotton_spodotera_pest_json_obj.put("spo_gre_lar_pic", imagePath4);
                    cotton_spodotera_pest_json_obj.put("spo_gre_lar_no", et_no_Spodoptera2_Cotton.getText().toString().trim());
                    cotton_spodotera_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_spodotera_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_spodotera_pest_json_obj);
                    resetforms();
                    break;
                case "LEAF ROLLER":
                    cotton_leafroller_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_leafroller_pest_json_obj.put("pest_name", pest_name);
                    cotton_leafroller_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_leafroller_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_leafroller_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_leafroller_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_leafroller_pest_json_obj);
                    resetforms();
                    break;
                case "RED COTTON BUG":
                    cotton_redcottonbug_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_redcottonbug_pest_json_obj.put("pest_name", pest_name);
                    cotton_redcottonbug_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_redcottonbug_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_redcottonbug_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_redcottonbug_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_redcottonbug_pest_json_obj);
                    resetforms();
                    break;
                case "DUSKY COTTON BUG":
                    cotton_duskybottonbug_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_duskybottonbug_pest_json_obj.put("pest_name", pest_name);
                    cotton_duskybottonbug_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_duskybottonbug_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_duskybottonbug_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_duskybottonbug_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_duskybottonbug_pest_json_obj);
                    resetforms();
                    break;
                case "SEMILOOPER":
                    cotton_semilooper_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_semilooper_pest_json_obj.put("pest_name", pest_name);
                    cotton_semilooper_pest_json_obj.put("spo_gre_lar_pic", imagePath5);
                    cotton_semilooper_pest_json_obj.put("spo_gre_lar_no", et_no_Spodoptera1_Cotton.getText().toString().trim());
                    cotton_semilooper_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_semilooper_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_semilooper_pest_json_obj);
                    resetforms();
                    break;
                case "RED MITES":
                    cotton_redmites_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_redmites_pest_json_obj.put("pest_name", pest_name);
                    cotton_redmites_pest_json_obj.put("spo_gre_lar_pic", imagePath6);
                    cotton_redmites_pest_json_obj.put("spo_gre_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_redmites_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_redmites_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_redmites_pest_json_obj);
                    resetforms();
                    break;
                case "PINK BOLLWORM":
                    cotton_pink_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_pink_pest_json_obj.put("pest_name", pest_name);
                    cotton_pink_pest_json_obj.put("pink_lar_pic", imagePath6);
                    cotton_pink_pest_json_obj.put("pink_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_pink_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_pink_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_pink_pest_json_obj);
                    resetforms();
                    break;
                case "SPOTTED BOLLWORM":
                    cotton_spotted_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_spotted_pest_json_obj.put("pest_name", pest_name);
                    cotton_spotted_pest_json_obj.put("spotted_lar_pic", imagePath6);
                    cotton_spotted_pest_json_obj.put("spotted_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_spotted_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_spotted_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_spotted_pest_json_obj);
                    resetforms();
                    break;
                case "AMERICAN BOLLWORM":
                    cotton_american_pest_json_obj.put("pest_id", cotton_selected_pest_id);
                    cotton_american_pest_json_obj.put("pest_name", pest_name);
                    cotton_american_pest_json_obj.put("american_lar_pic", imagePath6);
                    cotton_american_pest_json_obj.put("american_lar_no", et_no_Generic_Layout_Minor_Major_Pest_Cotton.getText().toString().trim());
                    cotton_american_pest_json_obj.put("lat", String.valueOf(lat));
                    cotton_american_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array_cotton.put(cotton_american_pest_json_obj);
                    resetforms();
                    break;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if(pest_details_json_array_cotton.length()>0){
            add_pest_titleTableLayout_cotton.setVisibility(View.VISIBLE);
            add_more_pest_rv_cotton.setVisibility(View.VISIBLE);
            add_more_pest_rv_cotton.setLayoutManager(new LinearLayoutManager(CottonPlant1.this));
            AddPestAdapter addPestAdapter = new AddPestAdapter(pest_details_json_array_cotton, CottonPlant1.this);
            add_more_pest_rv_cotton.setAdapter(addPestAdapter);
            addPestAdapter.notifyDataSetChanged();
            resetforms();
            ll_Whitefly_No_Plant_Cotton.setVisibility(View.GONE);
            ll_Thrips_No_Plant_Cotton.setVisibility(View.GONE);
            ll_Spodoptera_Cotton.setVisibility(View.GONE);
            ll_Semilooper_Cotton.setVisibility(View.GONE);
            ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.GONE);
            btn_add_pest_details_cotton.setVisibility(View.GONE);
        }else{
            add_pest_titleTableLayout_cotton.setVisibility(View.GONE);
            add_more_pest_rv_cotton.setVisibility(View.GONE);
            final Toast toast = Toast.makeText(CottonPlant1.this, "Not allowed to add data", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(toast::cancel, 0);
        }
    }

    private void resetforms() {
        //Image Reset & File Path
        cotton_major_pest.setText("Select");
        cotton_minor_pest.setText("Select");

        et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
        photo_Generic_Layout_Minor_Pest_Cotton.setImageDrawable(getResources().getDrawable(R.drawable.camera));
        imagePath6="";
        imagePath1="";
        imagePath2="";
        imagePath3="";
        imagePath4="";
        imagePath5="";
        photoFile6=null;
        photoFile1=null;
        photoFile2=null;
        photoFile3=null;
        photoFile4=null;
        photoFile5=null;


        for(int i=0;i<pest_image_list_layout_cotton.size();i++){
            pest_image_list_layout_cotton.get(i).setImageDrawable(getResources().getDrawable(R.drawable.camera));
        }
        for(int i=0;i<pest_list_et_cotton.size();i++){
            pest_list_et_cotton.get(i).setText("");
        }
        for(int i=0;i<pest_image_list_names_cotton.size();i++){
            pest_image_list_names_cotton.set(i,"");
        }
        for(int i=0;i<pest_image_photoFile_cotton.size();i++){
            pest_image_photoFile_cotton.set(i,null);
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(CottonPlant1.this,CottonGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            // White fly
            if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");
                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else { photoURI = Uri.fromFile(photoFile1); }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");m.invoke(null);
                    } catch (Exception e) { e.printStackTrace(); }
                }startActivityForResult(intent, CAMERA);
            }

            //Thrips
            else if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");
                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
            //Spodoptera 1
            if (type.equalsIgnoreCase("3")) {
                photoFile3 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile3);
                } else {
                    photoURI = Uri.fromFile(photoFile3);
                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
            //Spodoptera 2
            if (type.equalsIgnoreCase("4")) {
                photoFile4 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile4);
                } else {
                    photoURI = Uri.fromFile(photoFile4);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
            //Semilooper
            if (type.equalsIgnoreCase("5")) {
                photoFile5 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile5);
                } else {
                    photoURI = Uri.fromFile(photoFile5);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
            //Generic
            if (type.equalsIgnoreCase("6")) {
                photoFile6 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile6);
                } else {
                    photoURI = Uri.fromFile(photoFile6);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
            photoFile2 = null;
            photoFile3 = null;
            photoFile4 = null;
            photoFile5 = null;
            photoFile6 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;
        //White
        if (type.equalsIgnoreCase("1")) {
            if (photoFile1 != null) {
                if (photoFile1.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(photo_Whitefly_No_Plant_Cotton.getWidth(), photo_Whitefly_No_Plant_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo_Whitefly_No_Plant_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        //Thrips
        if (type.equalsIgnoreCase("2")) {
            if (photoFile2 != null) {
                if (photoFile2.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(photo_Thrips_No_Plant_Cotton.getWidth(), photo_Thrips_No_Plant_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo_Thrips_No_Plant_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        //Spodoptera 1
        if (type.equalsIgnoreCase("3")) {
            if (photoFile3 != null) {
                if (photoFile3.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile3, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath3 = "file://" + photoFile3;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath3)
                                    .resize(photo1_spodoptera_Cotton.getWidth(), photo1_spodoptera_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo1_spodoptera_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile3);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        //Spodoptera 2
        if (type.equalsIgnoreCase("4")) {
            if (photoFile4 != null) {
                if (photoFile4.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile4, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath4 = "file://" + photoFile4;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath4)
                                    .resize(photo2_spodoptera_Cotton.getWidth(), photo2_spodoptera_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo2_spodoptera_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile4);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        //Semilooper
        if (type.equalsIgnoreCase("5")) {
            if (photoFile5 != null) {
                if (photoFile5.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile5, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath5 = "file://" + photoFile5;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath5)
                                    .resize(photo_semilooper_Cotton.getWidth(), photo_semilooper_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo_semilooper_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile5);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        //Generic
        if (type.equalsIgnoreCase("6")) {
            if (photoFile6 != null) {
                if (photoFile6.exists()) {
                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile6, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath6 = "file://" + photoFile6;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath6)
                                    .resize(photo_Generic_Layout_Minor_Pest_Cotton.getWidth(), photo_Generic_Layout_Minor_Pest_Cotton.getHeight())
                                    .centerCrop()
                                    .into(photo_Generic_Layout_Minor_Pest_Cotton);
                            uploadImagenServer();
                        }
                    }, 0);

                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile6);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void plant_service() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_cotton_plant_list();
        api.postRequest(responseCall, this, 1);
    }

    private void cotton_major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",15);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void cotton_minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void uploadImagenServer() {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;

                case "2":
                    File file2 = new File(photoFile2.getPath());
                    RequestBody reqFile2 = RequestBody.create(MediaType.parse("image/*"), file2);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file2.getName(), reqFile2);
                    break;

                case "3":
                    File file3 = new File(photoFile3.getPath());
                    RequestBody reqFile3 = RequestBody.create(MediaType.parse("image/*"), file3);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file3.getName(), reqFile3);
                    break;

                case "4":
                    File file4 = new File(photoFile4.getPath());
                    RequestBody reqFile4 = RequestBody.create(MediaType.parse("image/*"), file4);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file4.getName(), reqFile4);
                    break;

                case "5":
                    File file5 = new File(photoFile5.getPath());
                    RequestBody reqFile5 = RequestBody.create(MediaType.parse("image/*"), file5);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file5.getName(), reqFile5);
                    break;

                case "6":
                    File file6 = new File(photoFile6.getPath());
                    RequestBody reqFile6 = RequestBody.create(MediaType.parse("image/*"), file6);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file6.getName(), reqFile6);
                    break;

            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void save_cotton_crop_data_service() {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("spot_id", count);
                param.put("crop_id", crop_id);
                param.put("crop_condition_id", crop_cond_id);
                param.put("crop_grow_id", crop_growth_id);
                param.put("soil_mois_id", soil_moisture_id);
                param.put("total_defender", defender_cotton.getText().toString().trim());
                param.put("pest_details", pest_details_json_array_cotton.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }



    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            cotton_crop_plant_list = jsonObject.getJSONArray("data");
                        }
                    }
                }
                // Major pest
                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            cotton_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                //Minor pest
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            cotton_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }


                // Photo Upload
                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data  = jsonObject.getJSONObject("data");
                            if(type.equalsIgnoreCase("1")){
                                image_1_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("2")){
                                image_2_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("3")){
                                image_3_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("4")){
                                image_4_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("5")){
                                image_5_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("6")){
                                image_6_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("7")){
                                image_7_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("8")){
                                image_8_file_name = data.getString("file_url");
                            }
                        }
                    }
                }

                // Save
                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(count<cotton_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Cotton");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant no" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        count++;
                                        dept_cropsap_cotton_crop_plant_tv.setText("Plant no" + " " + count);
                                        cotton_major_pest.setText("Select");
                                        cotton_minor_pest.setText("Select");
                                        sweetAlertDialog.dismissWithAnimation();
                                        pest_details_json_array_cotton= new JSONArray();
                                        // All reset
                                        for(int j=0;j<pest_list_names_cotton.size();j++){
                                            pest_list_layout_cotton.get(j).setVisibility(View.GONE);
                                            et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
                                            ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.GONE);
                                        }

                                        resetforms();

                                        add_pest_titleTableLayout_cotton.setVisibility(View.GONE);
                                        btn_add_pest_details_cotton.setVisibility(View.GONE);
                                        add_more_pest_rv_cotton.setVisibility(View.GONE);
                                        defender_cotton.setText("");
                                    }
                                });
                                sweetAlertDialog.show();
                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Cotton");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant no" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(CottonPlant1.this, CottonCropPheromoneActivity.class);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_cotton_plant_id = Integer.parseInt(s1);
            crop_cotton_plant_name=s;
            dept_cropsap_cotton_crop_plant_tv.setText(s);
        }

        if (i == 2) {
            cotton_selected_pest_id = Integer.parseInt(s1);
            pest_name=s;
            cotton_major_pest.setText(s);
            cotton_minor_pest.setText("Select");
            if(pest_details_json_array_cotton.toString().contains(pest_name) == cotton_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(CottonPlant1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
                et_Whitefly_No_Plant_Cotton.setText("");
                et_Thrips_No_Plant_Cotton.setText("");
                et_no_semilooper_Cotton.setText("");
                et_no_Spodoptera1_Cotton.setText("");
                et_no_Spodoptera2_Cotton.setText("");
                photo_Generic_Layout_Minor_Pest_Cotton.setImageResource(R.drawable.camera);
                photo_Whitefly_No_Plant_Cotton.setImageResource(R.drawable.camera);
                photo_Thrips_No_Plant_Cotton.setImageResource(R.drawable.camera);
                photo1_spodoptera_Cotton.setImageResource(R.drawable.camera);
                photo2_spodoptera_Cotton.setImageResource(R.drawable.camera);
                photo_semilooper_Cotton.setImageResource(R.drawable.camera);
                ll_Whitefly_No_Plant_Cotton.setVisibility(View.GONE);
                ll_Thrips_No_Plant_Cotton.setVisibility(View.GONE);
                ll_Spodoptera_Cotton.setVisibility(View.GONE);
                ll_Semilooper_Cotton.setVisibility(View.GONE);
                ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.GONE);
                btn_add_pest_details_cotton.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_cotton.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }

        if (i ==3) {
            cotton_selected_pest_id = Integer.parseInt(s1);
            pest_name=s;
            cotton_minor_pest.setText(s);
            cotton_major_pest.setText("Select");
            if(pest_details_json_array_cotton.toString().contains(pest_name) == cotton_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(CottonPlant1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
                et_Whitefly_No_Plant_Cotton.setText("");
                et_Thrips_No_Plant_Cotton.setText("");
                et_no_semilooper_Cotton.setText("");
                et_no_Spodoptera1_Cotton.setText("");
                et_no_Spodoptera2_Cotton.setText("");
                photo_Generic_Layout_Minor_Pest_Cotton.setImageResource(R.drawable.camera);
                photo_Whitefly_No_Plant_Cotton.setImageResource(R.drawable.camera);
                photo_Thrips_No_Plant_Cotton.setImageResource(R.drawable.camera);
                photo1_spodoptera_Cotton.setImageResource(R.drawable.camera);
                photo2_spodoptera_Cotton.setImageResource(R.drawable.camera);
                photo_semilooper_Cotton.setImageResource(R.drawable.camera);
                ll_Whitefly_No_Plant_Cotton.setVisibility(View.GONE);
                ll_Thrips_No_Plant_Cotton.setVisibility(View.GONE);
                ll_Spodoptera_Cotton.setVisibility(View.GONE);
                ll_Semilooper_Cotton.setVisibility(View.GONE);
                ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.GONE);
                btn_add_pest_details_cotton.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_cotton.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }

    private void layout_View_Gone(String s) {
        if(pest_list_names_cotton.contains(s)){
            ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.GONE);
            Generic_Layout_Major_and_Minor_Pest_tv_Cotton.setText("");
            for(int i=0;i<pest_list_et_cotton.size();i++){
                pest_list_et_cotton.get(i).setText("");
            }

            for(int j=0;j<pest_list_names_cotton.size();j++){
                if(pest_list_names_cotton.get(j).equals(s)){
                    pest_list_layout_cotton.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout_cotton.get(j).setVisibility(View.GONE);
                    et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
                }
            }
        }
        else{
            String localstr=s;
            String localstr2;
            localstr2= capitalizeWord(localstr);
            ll_Generic_Layout_Major_and_Minor_Pest_Cotton.setVisibility(View.VISIBLE);
            Generic_Layout_Major_and_Minor_Pest_tv_Cotton.setText(localstr2);
            et_no_Generic_Layout_Minor_Major_Pest_Cotton.setText("");
            for(int j=0;j<pest_list_names_cotton.size();j++){
                pest_list_layout_cotton.get(j).setVisibility(View.GONE);
                pest_list_et_cotton.get(j).setText("");
            }
        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }
}
