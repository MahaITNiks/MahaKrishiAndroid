package com.maha.agri.activity.common;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class LoginActivity extends AppCompatActivity implements ApiCallbackCode {

    private EditText userNameEText;
    private EditText passEText;
    private Button loginBtn, register_btn;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private TextView login_version;
    private JSONArray jsonArray;
    private DBHandler dbHandler;

    JSONObject login_Data, work_location_obj;

    String work_location_string, type, is_login;
    private ImageView viewPass;
    private TextView forgotPasstxt;
    boolean flag;
    int setPtype;
    String version_name="",update_desc,version_code="",package_name="";
    int version_code_int;
    Context context;
    PackageManager packageManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        preferenceManager = new PreferenceManager(LoginActivity.this);
        sharedPref = new SharedPref(LoginActivity.this);
        dbHandler = new DBHandler(this);

        /*context = getApplicationContext();
        packageManager = context.getPackageManager();
        package_name = context.getPackageName();

        try {
            version_name = packageManager.getPackageInfo(package_name, 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        login_version = (TextView) findViewById(R.id.login_version);
        login_version.setText("V - " + version_name);
        version_code = String.valueOf(version_code_int);*/

        PackageManager packageManager = this.getPackageManager();
        PackageInfo packageInfo = null;
        try {
            packageInfo =packageManager.getPackageInfo(getPackageName(),0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        version_name = packageInfo.versionName;
        version_code_int = packageInfo.versionCode;

        login_version = (TextView) findViewById(R.id.login_version);

        if (APIServices.BASE_API.contains("http://uatmahakrushi")) {
            login_version.setText("P   V - " + version_name);
        } else {
            login_version.setText("T   V - " + version_name);
        }
        version_code = String.valueOf(version_code_int);

        forceupdate();

        Intent intent = getIntent();
        type = intent.getStringExtra("type");
        is_login = intent.getStringExtra("islogin");

        String user = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);

        if (!TextUtils.isEmpty(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)) && !(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)).equalsIgnoreCase("userId")) {
            DashboardbyRole_ID(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
        }

        /*if(is_login.equalsIgnoreCase("true")&&type.equalsIgnoreCase("farmer")){
            if (!TextUtils.isEmpty(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)) && !(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)).equalsIgnoreCase("userId")) {
                DashboardbyRole_ID(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            }

        } else if(is_login.equalsIgnoreCase("true")&&type.equalsIgnoreCase("department")){
            if (!TextUtils.isEmpty(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)) && !(preferenceManager.getPreferenceValues(Preference_Constant.USER_ID)).equalsIgnoreCase("userId")) {
                DashboardbyRole_ID(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            }
        }*/


        initialization();
        defaultConfig();
    }

    private void initialization() {

        userNameEText = (EditText) findViewById(R.id.userNameEText);
        passEText = (EditText) findViewById(R.id.passEText);
        loginBtn = (Button) findViewById(R.id.loginBtn);
        //register_btn = (Button) findViewById(R.id.registerBtn);
        viewPass = (ImageView) findViewById(R.id.viewPassIview);
        forgotPasstxt = (TextView) findViewById(R.id.forgotpasstv);
    }

    private void defaultConfig() {
        setPtype = 1;

        viewPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setPtype == 1) {
                    setPtype = 0;
                    passEText.setTransformationMethod(null);
                    if (passEText.getText().length() > 0) {
                        passEText.setSelection(passEText.getText().length());
                        viewPass.setImageResource(R.drawable.notviewpass);
                    }
                } else {
                    setPtype = 1;
                    passEText.setTransformationMethod(new PasswordTransformationMethod());
                    if (passEText.getText().length() > 0) {
                        passEText.setSelection(passEText.getText().length());
                        viewPass.setImageResource(R.drawable.viewpass);
                    }
                }

            }
        });

        forgotPasstxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, GenerateOtpActivity.class);
                startActivity(intent);
            }
        });


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginBtnAction();

            }
        });


    }

    private void restartActivity() {
        finish();
        startActivity(getIntent());
    }

    private void loginBtnAction() {
        //String user = userNameEText.getText().toString().trim();
        //String pass = passEText.getText().toString().trim();

        if (userNameEText.getText().toString().trim().equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter user name");
        } else if (!AppUtility.getInstance().isValidPhoneNumber(userNameEText.getText().toString().trim())) {
            UIToastMessage.show(this, "Enter valid user name");
        } else if (passEText.getText().toString().trim().equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter password");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("mob", userNameEText.getText().toString().trim());
                param.put("pass", passEText.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.oauthRequest(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);

        }
    }

    private void forceupdate() {

        JSONObject param = new JSONObject();
        try {
            param.put("version_no", version_name);
            param.put("version_code", version_code);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.check_version(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    try {
                        if (jsonObject.getString("response").equals("Login Success")) {
                            login_Data = jsonObject.getJSONObject("data");

                            if (login_Data.getString("work_location").equalsIgnoreCase("null")) {
                                AppSettings.getInstance().setValue(this, ApConstants.kUSER_ID, login_Data.getString("id"));
                                preferenceManager.putPreferenceValues(Preference_Constant.USER_ID, login_Data.getString("id"));
                                preferenceManager.putPreferenceValues(Preference_Constant.ROLE_ID, login_Data.getString("role_id"));
                                preferenceManager.putPreferenceValues(Preference_Constant.FIRST_NAME, login_Data.getString("first_name"));
                                preferenceManager.putPreferenceValues(Preference_Constant.MIDDLE_NAME, login_Data.getString("middle_name"));
                                DashboardbyRole_ID(login_Data.getString("role_id"));
                            } else {

                                JSONArray work_location = login_Data.getJSONArray("work_location");
                                if (work_location != null) {
                                    for (int j = 0; j < work_location.length(); j++) {
                                        JSONObject work_location_obj = work_location.getJSONObject(j);
                                        work_location_string = work_location_obj.getString("work_location_name");
                                    }
                                    dbHandler.insertlogindata(login_Data.getString("id"),login_Data.getString("last_name"),login_Data.getString("first_name"),
                                            login_Data.getString("middle_name"),login_Data.getString("email"),login_Data.getString("mobile"),
                                            login_Data.getString("role_id"),login_Data.getString("role_desg"),login_Data.getString("role_desg_short"),
                                            login_Data.getString("junior_role_id"),login_Data.getString("profile_pic"),login_Data.getString("logged_in"),
                                            login_Data.getString("salutation_name"),login_Data.getString("usertype"),login_Data.getString("aadhar_no"),
                                            login_Data.getString("primary_job_category"),login_Data.getString("job_category"),login_Data.getString("work_location"),
                                            login_Data.getString("count_location"),login_Data.getString("sajjaDetails"), login_Data.getString("villages_location"));

                                }
                            }


                            //work_location_obj = work_location.getJSONObject(0);
                            AppSettings.getInstance().setValue(this, ApConstants.kUSER_ID, login_Data.getString("id"));
                            AppSettings.getInstance().setValue(this, ApConstants.kLOGIN_DATA, login_Data.toString());
                            preferenceManager.putPreferenceValues(Preference_Constant.FIRST_NAME, login_Data.getString("first_name"));
                            preferenceManager.putPreferenceValues(Preference_Constant.MIDDLE_NAME, login_Data.getString("middle_name"));
                            preferenceManager.putPreferenceValues(Preference_Constant.LAST_NAME, login_Data.getString("last_name"));
                            preferenceManager.putPreferenceValues(Preference_Constant.EMAIL, login_Data.getString("email"));
                            preferenceManager.putPreferenceValues(Preference_Constant.MOBILE_NUMBER, login_Data.getString("mobile"));
                            preferenceManager.putPreferenceValues(Preference_Constant.ROLE_DESIGNATION, login_Data.getString("role_desg"));
                            preferenceManager.putPreferenceValues(Preference_Constant.JUNIER_ROLE_ID, login_Data.getString("junior_role_id"));
                            preferenceManager.putPreferenceValues(Preference_Constant.PROFILE_PIC, login_Data.getString("profile_pic"));
                            preferenceManager.putPreferenceValues(Preference_Constant.USER_ID, login_Data.getString("id"));
                            preferenceManager.putPreferenceValues(Preference_Constant.ROLE_ID, login_Data.getString("role_id"));
                            preferenceManager.putPreferenceValues(Preference_Constant.PRIMARY_JOB_CATEGORY, login_Data.getString("primary_job_category"));
                            preferenceManager.putPreferenceValues(Preference_Constant.JOB_CATEGORY, login_Data.getString("job_category"));
                            preferenceManager.putPreferenceValues(Preference_Constant.CIRCLE_ASSIGN, work_location_string);
                            DashboardbyRole_ID(login_Data.getString("role_id"));
                        }
                        else
                        {
                            UIToastMessage.show(this, jsonObject.getString("response"));
                        }
                    } catch (JSONException ex) {
                        ex.printStackTrace();
                    }
                }

           /*     if(i == 2){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            //Toast.makeText(this,"No Update Required",Toast.LENGTH_SHORT).show();
                        }else{

                        }
                        }else{
                        update_desc = jsonObject.getString("response");
                        new AlertDialog.Builder(LoginActivity.this)
                                .setTitle("Update your app")
                                .setMessage(update_desc)
                                .setCancelable(false)

                                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {

                                        final String appPackageName = getPackageName();
                                        try {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                                            finish();
                                        } catch (android.content.ActivityNotFoundException anfe) {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                                            finish();
                                        }
                                    }
                                })

                                .show();
                    }
                }*/

                /*if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                            try {
                                jsonArray = jsonObject.getJSONArray("version_check");
                                for (int j = 0; j < jsonArray.length(); j++) {
                                    JSONObject update_object = jsonArray.getJSONObject(j);
                                    update_desc = update_object.getString("fld_description");

                                }
                            } catch (JSONException e) {
                                //e.printStackTrace();
                            }

                            new AlertDialog.Builder(LoginActivity.this)
                                    .setTitle("Update your app")
                                    .setMessage(update_desc)
                                    .setCancelable(false)

                                    .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                            final String appPackageName = getPackageName();
                                            try {
                                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                                                finish();
                                            } catch (android.content.ActivityNotFoundException anfe) {
                                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                                                finish();
                                            }

                                        }
                                    })

                                    .show();
                    }else{
                            restartActivity();
                        }
                    } else {

                    }
                }*/
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    private void DashboardbyRole_ID(String role_id) {

        switch (role_id) {
            case "1":
                /*Intent intent = new Intent(LoginActivity.this,SwitchProfileActivity.class);
                startActivity(intent);
                finishAffinity();*/
                Intent intent = new Intent(LoginActivity.this,SwitchProfileActivity.class);
                startActivity(intent);
                finishAffinity();
                break;

            /*case "2":
                Intent intent2 = new Intent(LoginActivity.this, ASDashboardActivity.class);
                startActivity(intent2);
                finishAffinity();
                break;

            case "3":
                Intent intent3 = new Intent(LoginActivity.this, CAODashboardActivity.class);
                startActivity(intent3);
                finishAffinity();
                break;

            case "4":
                Intent intent4 = new Intent(LoginActivity.this, TAODashboardActivity.class);
                startActivity(intent4);
                finishAffinity();
                break;

            case "5":
                Intent intent5 = new Intent(LoginActivity.this, SDAODashboardActivity.class);
                startActivity(intent5);
                finishAffinity();
                break;

            case "6":
                Intent intent6 = new Intent(LoginActivity.this, DSAODashboardActivity.class);
                startActivity(intent6);
                finishAffinity();
                break;

            case "7":
                Intent intent7 = new Intent(LoginActivity.this, RJDAActivity.class);
                startActivity(intent7);
                finishAffinity();
                break;

            case "12":
                Intent intent12 = new Intent(LoginActivity.this, FarmerDashboardActivity.class);
                startActivity(intent12);
                finishAffinity();
                break;*/

            default:
                UIToastMessage.show(this, "You are not valid user for this application");
                break;
        }

        /*
        if (role_id.equalsIgnoreCase("1")) {
            Intent intent = new Intent(LoginActivity.this, AADashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("2")) {

            Intent intent = new Intent(LoginActivity.this, ASDashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("3")) {
            Intent intent = new Intent(LoginActivity.this, CAODashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("4")) {
            Intent intent = new Intent(LoginActivity.this, TAODashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("5")) {
            Intent intent = new Intent(LoginActivity.this, SDAODashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("6")) {
            Intent intent = new Intent(LoginActivity.this, DSAODashboardActivity.class);
            startActivity(intent);
            finishAffinity();
        }

        if (role_id.equalsIgnoreCase("7")) {
            Intent intent = new Intent(LoginActivity.this, RJDAActivity.class);
            startActivity(intent);
            finishAffinity();

        }

        if (role_id.equalsIgnoreCase("12")) {
            Intent intent = new Intent(LoginActivity.this, FarmerDashboardActivity.class);
            startActivity(intent);
            finishAffinity();

        }*/

    }

    /*@Override
    protected void onResume() {
        ApUtil.autoLogOut(this,true);
        super.onResume();
    }*/

}
