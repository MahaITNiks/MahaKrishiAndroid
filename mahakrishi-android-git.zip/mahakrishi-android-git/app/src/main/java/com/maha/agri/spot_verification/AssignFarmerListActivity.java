package com.maha.agri.spot_verification;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AssignFarmerListActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private JSONArray district_list,scheme_list,village_list,sajja_List;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String district_name,taluka_name,button="1",scheme_name="",farmer_name="";
    private String divison_id_str = "",circle_id_str = "", sajja_id_str = "", divison_name_str = "", district_id_str = "",
            taluka_id_str = "",circle_name = "", sajja_name="",component_list="",component_id = "";

    private LinearLayout phy_veri_sajja_list_linear_layout,phy_veri_sajja_linear_layout;
    private TextView spot_verification_scheme_name_tv,phy_verf_tile_district,phy_verf_tile_taluka,phy_verf_tile_circle,phy_veri_sajja_list_name_tv,phy_verf_tile_saja,phy_veri_village_name;
    private Button dept_spot_verification_next_btn;

    String data,village_name;

    private int district_id = 0,divison_id = 0,sajja_id = 0,circle_id = 0;
    private int taluka_id = 0;
    private int scheme_id = 0,farmer_id=0;
    private int village_id = 0,position;
    private String type = "";
    private String role_id = "",role_chare_id = "",role_officer_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_farmer_list);
        getSupportActionBar().setTitle("Spot Verification");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(AssignFarmerListActivity.this);
        sharedPref = new SharedPref(AssignFarmerListActivity.this);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);
        role_chare_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID);
        role_officer_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID);
        circle_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        sajja_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        circle_name = preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_NAME);
        Intent intent = getIntent();
        type = intent.getStringExtra("type");
        try {
            component_list = intent.getStringExtra("component_list");
            position = intent.getIntExtra("position",0);
            JSONArray jsonArray = new JSONArray(component_list);
            JSONObject jsonObject = jsonArray.getJSONObject(position);
            component_id = jsonObject.getString("id");
        }catch (Exception e){
            e.printStackTrace();
        }
        IdCalling();
        default_Config();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        spot_verification_scheme_name_tv = (TextView) findViewById(R.id.spot_verification_scheme_name_tv);
        phy_verf_tile_district = (TextView) findViewById(R.id.phy_verf_tile_district);
        phy_verf_tile_taluka = (TextView) findViewById(R.id.phy_verf_tile_taluka);
        phy_verf_tile_circle = (TextView) findViewById(R.id.phy_verf_tile_circle);
        phy_veri_sajja_list_name_tv = (TextView)findViewById(R.id.phy_veri_sajja_list_name_tv);
        phy_verf_tile_saja = (TextView) findViewById(R.id.phy_verf_tile_saja);
        phy_veri_village_name = (TextView) findViewById(R.id.phy_veri_village_name);
        dept_spot_verification_next_btn = (Button)findViewById(R.id.dept_spot_verification_next_btn);
        phy_veri_sajja_linear_layout = (LinearLayout)findViewById(R.id.phy_veri_sajja_linear_layout);
        phy_veri_sajja_list_linear_layout = (LinearLayout)findViewById(R.id.phy_veri_sajja_list_linear_layout);

        sajja_List = new JSONArray();
        village_list = new JSONArray();
        scheme_list = new JSONArray();

        Scheme_Service();
    }

    private void default_Config() {

        if(role_chare_id.equalsIgnoreCase("1")&&role_officer_id.equalsIgnoreCase("2")){
            phy_veri_sajja_linear_layout.setVisibility(View.GONE);
            phy_veri_sajja_list_linear_layout.setVisibility(View.VISIBLE);
            phy_verf_tile_circle.setText(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_NAME));
            get_district_taluka();
            getSajjaLocation();
            phy_veri_sajja_list_name_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (sajja_List.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(sajja_List, 2, "Select Saja", "sajja_name", "sajja_id", AssignFarmerListActivity.this, AssignFarmerListActivity.this);
                    }
                }
            });

            phy_veri_village_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 3, "Select Village", "village_name", "village_id", AssignFarmerListActivity.this, AssignFarmerListActivity.this);
                    }
                }
            });

        }else{
            phy_veri_sajja_linear_layout.setVisibility(View.VISIBLE);
            phy_veri_sajja_list_linear_layout.setVisibility(View.GONE);
            phy_verf_tile_circle.setText(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_NAME));
            phy_verf_tile_saja.setText(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_NAME));
            get_district_taluka();
            phy_veri_village_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 4, "Select Village", "village_name", "village_id", AssignFarmerListActivity.this, AssignFarmerListActivity.this);
                    }
                }
            });
        }

        spot_verification_scheme_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if (scheme_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(scheme_list, 5, "Select Scheme", "scheme_name", "id", AssignFarmerListActivity.this, AssignFarmerListActivity.this);
                    }
            }
        });

        dept_spot_verification_next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(village_id == 0){
                    Toast.makeText(AssignFarmerListActivity.this,"Select Village",Toast.LENGTH_SHORT).show();
                }else if(scheme_id == 0){
                    Toast.makeText(AssignFarmerListActivity.this,"Select Scheme",Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(AssignFarmerListActivity.this, PhyVerfFarmerSelectionActivity.class);
                    intent.putExtra("district_id",district_id);
                    intent.putExtra("taluka_id",taluka_id);
                    intent.putExtra("village_id",village_id);
                    intent.putExtra("scheme_name",scheme_name);
                    intent.putExtra("scheme_id",scheme_id);
                    intent.putExtra("village_name",village_name);
                    intent.putExtra("farmer_name",farmer_name);
                    intent.putExtra("component_id",component_id);
                    startActivity(intent);
                }
            }
        });

    }

    private void get_district_taluka(){

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void getSajjaLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_sajja_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
            param.put("sajja_id", preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_village_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void normalVillageList() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("sajja_id", sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Scheme_Service(){
        JSONObject param = new JSONObject();
        try {
            param.put("scheme_title_id",component_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_scheme_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //district
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                            if (district_list.length() > 0) {
                                for (int j = 0; j <= district_list.length(); j++) {
                                    JSONObject district_json_object = district_list.getJSONObject(j);
                                    divison_id_str = district_json_object.getString("division_id");
                                    divison_name_str = district_json_object.getString("division_name");
                                    district_name = district_json_object.getString("district_name");
                                    taluka_name = district_json_object.getString("taluka_name");
                                    district_id_str = district_json_object.getString("district_id");
                                    taluka_id_str = district_json_object.getString("taluka_id");
                                    //circle_id_str = district_json_object.getString("circle_id");
                                    //circle_name = district_json_object.getString("circle_name");
                                    //sajja_id_str = district_json_object.getString("sajja_id");
                                    //sajja_name = district_json_object.getString("sajja_name");

                                    divison_id = Integer.valueOf(divison_id_str);
                                    district_id = Integer.valueOf(district_id_str);
                                    taluka_id = Integer.valueOf(taluka_id_str);
                                    //circle_id = Integer.valueOf(circle_id_str);
                                    //sajja_id = Integer.valueOf(sajja_id_str);

                                    phy_verf_tile_district.setText(district_name);
                                    phy_verf_tile_taluka.setText(taluka_name);
                                    //phy_verf_tile_circle.setText(circle_name);
                                    //phy_verf_tile_saja.setText(sajja_name);
                                    getVillageLocation();
                                }
                            }else{
                                new AlertDialog.Builder(AssignFarmerListActivity.this)
                                        .setTitle("Error!")
                                        .setMessage("You have not been assigned any villages against your saja, please contact Taluka office ")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                finish();
                                            }
                                        }).show();
                            }
                        }

                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sajja_List = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            scheme_list = jsonObject.getJSONArray("data");
                        }
                    }else {
                        //Toast.makeText(AssignFarmerListActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                    }
                }
            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 2) {
            sajja_id = Integer.parseInt(s1);
            sajja_name = s;
            phy_veri_sajja_list_name_tv.setText(sajja_name);
            normalVillageList();
            phy_veri_village_name.setText("Select");
        }

        if (i == 3) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            phy_veri_village_name.setText(village_name);
        }

        if (i == 4) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            phy_veri_village_name.setText(village_name);
        }

        if (i == 5) {
            scheme_id = Integer.parseInt(s1);
            scheme_name = s;
            spot_verification_scheme_name_tv.setText(scheme_name);
        }
    }

}
