package com.maha.agri.cropsowingreport;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;

import android.os.Bundle;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.common.LoginActivity;
import com.maha.agri.activity.user_dashboard.AA.AADashboardActivity;
import com.maha.agri.dept_cropsap.ChickPeaRow;
import com.maha.agri.history.DeptCropSowingReportHistoryActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.panchnama.PrimaryReportActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSowingReportActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private LinearLayout csr_sajja_linear_layout, csr_sajja_list_linear_layout, village_list_linear_layout, village_list_linear_layout_as,
            csr_other_crop_ll, field_crop_type_ll;
    private TableLayout crop_sowing_titleTableLayout;
    private SearchableSpinner sp_village;
    private SweetAlertDialog sweetAlertDialog;
    private RecyclerView sowing_report_add_more_rv;
    JSONArray dist_tal_list, Sajja_List, village_list, Seasons_List, CropTypeList, CropTypeSownSubList, field_type_list, CropNameList, areaReasonList,
            assigned_location_list, calculation_list, date_list, pre_calculation_list;
    private JSONArray multiple_crop_field_add = new JSONArray();

    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String activityID = "";
    private TextView ns_cropSR_district_name_tv;

    private TextView ns_cropSR_tal_name_tv;
    private int ns_cropSR_seasonid = 0;

    private TextView ns_cropSR_croptype_tv;
    private String ns_cropSR_croptypeIDStr = "0";
    private int ns_cropSR_croptypeID = 0;

    private TextView ns_cropSR_horticulture_tv, csr_last_week, csr_current_week, sown_area_edt, ns_reason_tv, ns_cropSR_field_tv;
    private int ns_cropSR_horticultureID = 0, field_type_id = 0;

    private TextView ns_cropSR_cropsown_tv, sp_season, financial_year_tv;
    private String ns_cropSR_cropsown, ns_cropSR_cropsownIDStr = "0", field_type_name = "", field_type_str = "";

    private String crop_name_str = "", ns_cropSR_season_name = "";
    private int crop_name_str_int = 0;

    private String reasontext = "";
    private EditText natural_sown_area_edt, csr_other_crop_edt;
    private Button ns_cropSR_addfield_btn;

    private LinearLayout horticulture_crop_type_ll, crop_sowing_report_crop_sown_ll, select_reason_ll;

    JSONObject getVillageLocation;
    private Button generate_sowing_report_btn;
    private String role_id = "", current_week = "", last_week = "", current_week1y = "", current_week2y = "",
            last_week1y = "", last_week2y = "", current_date = "", last_week_area_str = "";
    Double last_week_area_dlb = 0.0;
    private TextView ns_cropSR_sajja_name_tv, ns_cropSR_sajja_list_name_tv, sp_ns_cropSR_village_name;

    //location variable
    private String divison_id_str = "", ns_cropSR_district_id = "", ns_cropSR_talukaID = "", circle_id_str = "", sajja_id_str = "", role_chare_id = "", role_officer_id = "",
            divison_name_str = "", ns_cropSR_district_name = "", ns_cropSR_taluka_name = "", circle_name = "", sajja_name = "", village_name = "";
    private int divison_id = 0, district_id = 0, taluka_id = 0, circle_id = 0, sajja_id = 0, village_id = 0;

    int crop_id_stored = 0, village_id_stored = 0;

    private Date current_date1;
    private Calendar calendar = Calendar.getInstance();
    SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd-MMM-yyyy");
    SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
    private int selectedvillage_id = 0;
    private boolean isCropPresent = false;
    private boolean isSownAreaExceeding = false;
    private String geo_area = "", cul_area = "", total_area_upto_last_week = "", total_area_in_current_week = "", natural_area = "", natural_area_total = "0";
    private Double geographical_area = 0.0;
    private double total_sown_area = 0.0, current_total_area = 0.0, cummulative_natural_area_total = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sowing_report);

        getSupportActionBar().setTitle("Crop Sowing Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(CropSowingReportActivity.this);
        sharedPref = new SharedPref(CropSowingReportActivity.this);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        preferenceManager.putPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_CROP_TYPE_ID, ns_cropSR_croptypeIDStr);
        preferenceManager.putPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_HORTI_ID, ns_cropSR_cropsownIDStr);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);
        role_chare_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID);
        role_officer_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID);
        circle_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        sajja_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        current_date1_service();
        initialization();
        Seasons_Service();
        // Crop_type_Service();
        reasons_Service();
        default_confiq();
    }

    private void initialization() {
        financial_year_tv = (TextView) findViewById(R.id.financial_year_tv);
        ns_cropSR_district_name_tv = (TextView) findViewById(R.id.ns_cropSR_district_name_tv);
        ns_cropSR_tal_name_tv = (TextView) findViewById(R.id.ns_cropSR_taluka_name_tv);
        sp_ns_cropSR_village_name = (TextView) findViewById(R.id.sp_ns_cropSR_village_name);
        sp_season = (TextView) findViewById(R.id.sp_ns_cropSR_season);
        csr_last_week = (TextView) findViewById(R.id.csr_last_week);
        csr_current_week = (TextView) findViewById(R.id.crs_current_week);
        ns_cropSR_croptype_tv = (TextView) findViewById(R.id.ns_cropSR_croptype_tv);
        ns_cropSR_horticulture_tv = (TextView) findViewById(R.id.ns_cropSR_horticulture_tv);
        ns_cropSR_field_tv = (TextView) findViewById(R.id.ns_cropSR_field_tv);
        ns_cropSR_cropsown_tv = (TextView) findViewById(R.id.ns_cropSR_cropsown_tv);
        ns_cropSR_sajja_name_tv = (TextView) findViewById(R.id.ns_cropSR_sajja_name_tv);
        ns_cropSR_sajja_list_name_tv = (TextView) findViewById(R.id.ns_cropSR_sajja_list_name_tv);

        sown_area_edt = (TextView) findViewById(R.id.sown_area_edt);


        sown_area_edt.setEnabled(false);
        natural_sown_area_edt = (EditText) findViewById(R.id.natural_sown_area_edt);
        csr_other_crop_edt = (EditText) findViewById(R.id.csr_other_crop_edt);

        ns_cropSR_addfield_btn = (Button) findViewById(R.id.ns_cropSR_addfield_btn);
        generate_sowing_report_btn = (Button) findViewById(R.id.generate_sowing_report_btn);

        sowing_report_add_more_rv = (RecyclerView) findViewById(R.id.sowing_report_add_more_rv);

        crop_sowing_titleTableLayout = (TableLayout) findViewById(R.id.crop_sowing_titleTableLayout);

        horticulture_crop_type_ll = (LinearLayout) findViewById(R.id.horticulture_crop_type_ll);
        field_crop_type_ll = (LinearLayout) findViewById(R.id.field_crop_type_ll);


        crop_sowing_report_crop_sown_ll = (LinearLayout) findViewById(R.id.crop_sowing_report_crop_sown_ll);

        csr_sajja_linear_layout = (LinearLayout) findViewById(R.id.csr_sajja_linear_layout);
        csr_sajja_list_linear_layout = (LinearLayout) findViewById(R.id.csr_sajja_list_linear_layout);
        village_list_linear_layout = (LinearLayout) findViewById(R.id.village_list_linear_layout);
        csr_other_crop_ll = (LinearLayout) findViewById(R.id.csr_other_crop_ll);


        select_reason_ll = (LinearLayout) findViewById(R.id.select_reason_ll);
        ns_reason_tv = (TextView) findViewById(R.id.ns_reason_tv);


        natural_sown_area_edt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        current_date1 = calendar.getTime();
        current_date = simpleDateFormat1.format(current_date1);

        Sajja_List = new JSONArray();
        village_list = new JSONArray();
        CropNameList = new JSONArray();
        Seasons_List = new JSONArray();
        CropTypeList = new JSONArray();
        CropTypeSownSubList = new JSONArray();
        field_type_list = new JSONArray();
        areaReasonList = new JSONArray();

        sp_season.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedvillage_id == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Select Village", Toast.LENGTH_SHORT).show();
                } else if (Seasons_List.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(Seasons_List, 2, "Select Season", "name", "id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                } else {
                    Seasons_Service();
                }
            }
        });

        ns_cropSR_croptype_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ns_cropSR_seasonid == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Select Season", Toast.LENGTH_SHORT).show();
                } else if (CropTypeList.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(CropTypeList, 3, "Select Crop Type", "name", "id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                } else {
                    Crop_type_Service();
                }
            }
        });

        ns_cropSR_horticulture_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CropTypeSownSubList.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(CropTypeSownSubList, 4, "Select Horticulture Type", "crop_type", "field_crop_id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                } else {
                    Crop_type_sown_sub_list();
                }
            }
        });

        ns_cropSR_field_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (field_type_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(field_type_list, 9, "Select Field Crop Type", "crop_type", "id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                } else {
                    field_crop_type_service();
                }
            }
        });

        ns_cropSR_cropsown_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CropNameList.length() == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();
                } else {
                    if (CropNameList.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(CropNameList, 5, "Select Crop", "crop_english", "id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                    } else {
                        Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
                    }
                }
            }
        });

        if (role_chare_id.equalsIgnoreCase("1") && role_officer_id.equalsIgnoreCase("2")) {
            csr_sajja_linear_layout.setVisibility(View.GONE);
            csr_sajja_list_linear_layout.setVisibility(View.VISIBLE);
            get_district_taluka();
            getSajjaLocation();
            ns_cropSR_sajja_list_name_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Sajja_List.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(Sajja_List, 7, "Select Saja", "sajja_name", "sajja_id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                    }
                }
            });

            sp_ns_cropSR_village_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 14, "Select Village", "village_name", "village_id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                    }
                }
            });

        } else {
            csr_sajja_linear_layout.setVisibility(View.VISIBLE);
            csr_sajja_list_linear_layout.setVisibility(View.GONE);
            ns_cropSR_sajja_name_tv.setText(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_NAME));
            get_district_taluka();
            sp_ns_cropSR_village_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 12, "Select Village", "village_name", "village_id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                    }
                }
            });
        }


        ns_reason_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (areaReasonList.length() == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Reasons not available", Toast.LENGTH_SHORT).show();
                } else {
                    if (areaReasonList.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(areaReasonList, 15, "Select Reason", "name", "id", CropSowingReportActivity.this, CropSowingReportActivity.this);
                    } else {
                        reasons_Service();
                    }
                }
            }
        });


        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        SimpleDateFormat mf = new SimpleDateFormat("MMM");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.csr_history_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.csr_history:
                Intent intent = new Intent(CropSowingReportActivity.this, DeptCropSowingReportHistoryActivity.class);
                startActivity(intent);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void default_confiq() {

        ns_cropSR_addfield_btn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                //natural_area = natural_sown_area_edt.getText().toString().trim();
                //cummulative_natural_area_total = natural_area_total + natural_area;
                if (selectedvillage_id == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Please select village", Toast.LENGTH_SHORT).show();
                } else if (crop_name_str_int == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Please select crop", Toast.LENGTH_SHORT).show();
                } else if (crop_name_str.equalsIgnoreCase("OTHER")) {
                    if (csr_other_crop_edt.getText().toString().trim().equalsIgnoreCase("")) {
                        Toast.makeText(CropSowingReportActivity.this, "Please Enter crop name", Toast.LENGTH_SHORT).show();
                    } else if (natural_sown_area_edt.getText().toString().equalsIgnoreCase("")) {
                        Toast.makeText(CropSowingReportActivity.this, "Please Enter Area in Current week", Toast.LENGTH_SHORT).show();
                    } else {
                        crop_name_str = csr_other_crop_edt.getText().toString().trim();
                        add_multiple_crop_array(ns_cropSR_seasonid,selectedvillage_id, village_name, field_type_id, ns_cropSR_horticultureID, crop_name_str_int, crop_name_str, sown_area_edt.getText().toString(), natural_sown_area_edt.getText().toString().trim(), "OTHER");

                    }
                } else if (natural_sown_area_edt.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(CropSowingReportActivity.this, "Please Enter Area in Current week", Toast.LENGTH_SHORT).show();
                } else {

                    if (natural_sown_area_edt.getText().toString().length() > 0) {
                        double temp_natural = Double.parseDouble(natural_sown_area_edt.getText().toString());
                        double temp_sown_area_edt = Double.parseDouble(sown_area_edt.getText().toString());
                        if ((temp_natural < temp_sown_area_edt) && (reasontext.length() == 0)) {
                            Toast.makeText(CropSowingReportActivity.this, "Please select reason", Toast.LENGTH_SHORT).show();
                            select_reason_ll.setVisibility(View.VISIBLE);
                            ns_reason_tv.setFocusable(true);
                        } else {
                            add_multiple_crop_array(ns_cropSR_seasonid,selectedvillage_id, village_name, field_type_id, ns_cropSR_horticultureID, crop_name_str_int, crop_name_str, sown_area_edt.getText().toString(), natural_sown_area_edt.getText().toString().trim(), "LIST");
                            crop_name_str_int = 0;
                        }
                    }
                }
            }
        });

        generate_sowing_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedvillage_id == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Select Village", Toast.LENGTH_SHORT).show();
                } else if (ns_cropSR_seasonid == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Select Season", Toast.LENGTH_SHORT).show();
                } else if (ns_cropSR_croptypeID == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Select Crop type", Toast.LENGTH_SHORT).show();
                } else if (multiple_crop_field_add.length() == 0) {
                    Toast.makeText(CropSowingReportActivity.this, "Add details for at least one crop", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(CropSowingReportActivity.this, GenerateSowingReportActivity.class);
                    intent.putExtra("add_multiple_crop_array", multiple_crop_field_add.toString());
                    intent.putExtra("divison_id", divison_id);
                    intent.putExtra("add_multiple_crop_array", multiple_crop_field_add.toString());
                    intent.putExtra("district_name", ns_cropSR_district_name);
                    intent.putExtra("district_id", district_id);
                    intent.putExtra("taluka_name", ns_cropSR_taluka_name);
                    intent.putExtra("taluka_id", taluka_id);
                    intent.putExtra("sajja_name", sajja_name);
                    intent.putExtra("sajja_id", sajja_id);
                    intent.putExtra("season_name", ns_cropSR_season_name);
                    intent.putExtra("season_id", ns_cropSR_seasonid);
                    intent.putExtra("crop_type_id", ns_cropSR_croptypeID);
                    intent.putExtra("horti_type_id", ns_cropSR_horticultureID);
                    intent.putExtra("field_type", field_type_str);
                    intent.putExtra("current_week1", current_week1y);
                    intent.putExtra("current_week2", current_week2y);
                    intent.putExtra("last_week1", last_week1y);
                    intent.putExtra("last_week2", last_week2y);
                    startActivity(intent);
                }
            }
        });


    }

    private void current_date1_service() {
        current_date1 = calendar.getTime();
        current_week1y = simpleDateFormat1.format(current_date1);
        meteorological_week();
    }

    private void add_multiple_crop_array(int crop_season_id, int village_id, String village_name, int field_type_id, int horti_type_id, int crop_sown_id, String crop_sown_name, String sown_area, String natural_sown_area, String type) {
        String sum = "";
        double val = 0.0;
        JSONObject multiple_crop_field_add_json_object = new JSONObject();
        try {
            multiple_crop_field_add_json_object.put("village_id", village_id);
            multiple_crop_field_add_json_object.put("village_name", village_name);
            multiple_crop_field_add_json_object.put("field_type_id", field_type_id);
            multiple_crop_field_add_json_object.put("horti_type_id", horti_type_id);
            multiple_crop_field_add_json_object.put("crop_sown_id", crop_sown_id);
            multiple_crop_field_add_json_object.put("crop_sown_name", crop_sown_name);
            multiple_crop_field_add_json_object.put("area_last_week", sown_area);
            multiple_crop_field_add_json_object.put("area_current_week", natural_sown_area);
            multiple_crop_field_add_json_object.put("type", type);
            multiple_crop_field_add_json_object.put("crop_season_id", crop_season_id);
            multiple_crop_field_add_json_object.put("reason", reasontext);
            isCropPresent = false;

            for (int i = 0; i < multiple_crop_field_add.length(); i++) {
                JSONObject multiple_data_json_object = multiple_crop_field_add.getJSONObject(i);
                crop_id_stored = Integer.parseInt(multiple_data_json_object.getString("crop_sown_id"));
                village_id_stored = Integer.parseInt(multiple_data_json_object.getString("village_id"));
                String crop_name_stored = multiple_data_json_object.getString("crop_sown_name");
                String crop_type = multiple_data_json_object.getString("type");
                String Crop_name = csr_other_crop_edt.getText().toString().trim();
                if (crop_type.equalsIgnoreCase("LIST")) {
                    if (village_id_stored == selectedvillage_id && crop_id_stored == crop_name_str_int) {
                        isCropPresent = true;
                        break;
                    }
                } else if (crop_type.equalsIgnoreCase("OTHER")) {
                    if (village_id_stored == selectedvillage_id && crop_name_stored.equalsIgnoreCase(Crop_name)) {
                        isCropPresent = true;
                        break;
                    }
                }

            }
            if (isCropPresent != true) {
                multiple_crop_field_add.put(multiple_crop_field_add_json_object);
            } else {
                Toast.makeText(CropSowingReportActivity.this, "Selected crop is already added in this village", Toast.LENGTH_SHORT).show();
            }

            for (int i = 0; i < multiple_crop_field_add.length(); i++) {
                sum = multiple_crop_field_add.getJSONObject(i).getString("area_current_week");
                val = val + Double.valueOf(sum);
            }
            cummulative_natural_area_total = total_sown_area + val;
            if (cummulative_natural_area_total > geographical_area) {
                multiple_crop_field_add.remove(multiple_crop_field_add.length() - 1);
                new AlertDialog.Builder(CropSowingReportActivity.this)
                        .setTitle("Warning")
                        .setMessage("Sown area is exceeding the geographical area of the village")
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                natural_sown_area_edt.setText("0.0");
                                ns_cropSR_cropsown_tv.setText("Select");
                                sown_area_edt.setText("0.0");
                                ns_reason_tv.setText("Select");

                            }
                        }).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (multiple_crop_field_add.length() > 0) {
            sowing_report_add_more_rv.setLayoutManager(new LinearLayoutManager(CropSowingReportActivity.this));
            CropSownAddMoreAdapter cropsownaddmoreadapter1 = new CropSownAddMoreAdapter(preferenceManager, multiple_crop_field_add, CropSowingReportActivity.this);
            sowing_report_add_more_rv.setAdapter(cropsownaddmoreadapter1);
            cropsownaddmoreadapter1.notifyDataSetChanged();
            Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
            ns_cropSR_cropsown_tv.setText("Select");
            ns_reason_tv.setText("Select");
            csr_other_crop_ll.setVisibility(View.GONE);
            crop_sown_id = 0;
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
            csr_other_crop_edt.setText("");
        } else {

        }

    }


    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Seasons_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("panchnama_scheme_id", "");
            param.put("primary_report_id", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    private void reasons_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);

        } catch (Exception e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchReasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 16);
    }


    private void Crop_type_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            // param.put("season_id", "");//ns_cropSR_seasonid// commented by shashank 14 july 2021
            param.put("season_id", ns_cropSR_seasonid != 0 ? String.valueOf(ns_cropSR_seasonid) : "");
            param.put("primary_crop_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropType(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
        Log.i("Crop_type_Service", ns_cropSR_seasonid + "");
    }

    private void Crop_type_sown_sub_list() {
        JSONObject param = new JSONObject();
        try {
            param.put("id", ns_cropSR_croptypeID);
            param.put("crop_season_id", ns_cropSR_seasonid);
            param.put("activity_id", activityID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_crop_type_sown_sublist(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void field_crop_type_service() {
        JSONObject param = new JSONObject();
        try {
            param.put("id", ns_cropSR_croptypeID);
            param.put("crop_season_id", ns_cropSR_seasonid);
            param.put("activity_id", activityID);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.field_crop_type(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 9);
    }

    private void Crop_type_sown_sub_crop_list(int ns_cropSR_croptypeID, int ns_cropSR_horticultureID, String field_type_str) {
        JSONObject param = new JSONObject();
        try {


            if (ns_cropSR_horticultureID != 0) {
                field_type_str = String.valueOf(ns_cropSR_horticultureID);
            }
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id", ns_cropSR_seasonid);
            param.put("crop_type", ns_cropSR_croptypeID);
           // param.put("horti_crop_type_id", ns_cropSR_horticultureID);
            param.put("fieldsubmenu_id", field_type_str);
            param.put("primary_report_id", "");
            param.put("panchname_scheme_id", "0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void calculation_last_week() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("district_id", ns_cropSR_district_id);
            param.put("taluka_id", ns_cropSR_talukaID);
            param.put("sajja_id", sajja_id);
            param.put("season_id", ns_cropSR_seasonid);
            param.put("village_id", selectedvillage_id);
            param.put("crop_type_id", ns_cropSR_croptypeID);
            param.put("start_current_week", current_week1y);
            param.put("end_current_week", current_week2y);
            param.put("current_date", current_date);
            param.put("horti_type_id", ns_cropSR_horticultureID);
            param.put("field_crop_id", field_type_id);
            param.put("crop_sown_id", crop_name_str_int);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.get_crop_calculated_area_value(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 10);
    }

    private void meteorological_week() {
        JSONObject param = new JSONObject();
        try {
            param.put("current_date", current_week1y);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.meteorological_week(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 11);
    }

    private void getSajjaLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_sajja_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);

    }

    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
            param.put("sajja_id", preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_village_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 12);
    }

    private void get_geo_cul_area() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("divison_id", divison_id);
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("circle_id", circle_id);
            param.put("sajja_id", sajja_id);
            param.put("village_id", selectedvillage_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.get_geo_cul_area_village_mapping_area(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 13);
    }

    private void normalVillageList() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("sajja_id", sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 14);
    }

    private void area_of_all_crop() {
        JSONObject param = new JSONObject();
        try {
            param.put("season_id", ns_cropSR_seasonid);
            param.put("village_id", selectedvillage_id);
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.get_csr_season_sown_area(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 15);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {
            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dist_tal_list = jsonObject.getJSONArray("data");
                            if (dist_tal_list.length() > 0) {
                                for (int j = 0; j <= dist_tal_list.length(); j++) {
                                    JSONObject district_json_object = dist_tal_list.getJSONObject(j);
                                    divison_id_str = district_json_object.getString("division_id");
                                    divison_name_str = district_json_object.getString("division_name");
                                    ns_cropSR_district_id = district_json_object.getString("district_id");
                                    ns_cropSR_district_name = district_json_object.getString("district_name");
                                    ns_cropSR_talukaID = district_json_object.getString("taluka_id");
                                    ns_cropSR_taluka_name = district_json_object.getString("taluka_name");
                                    divison_id = Integer.valueOf(divison_id_str);
                                    district_id = Integer.valueOf(ns_cropSR_district_id);
                                    taluka_id = Integer.valueOf(ns_cropSR_talukaID);
                                    ns_cropSR_district_name_tv.setText(ns_cropSR_district_name);
                                    ns_cropSR_tal_name_tv.setText(ns_cropSR_taluka_name);

                                    getVillageLocation();
                                }
                            } else {
                                new AlertDialog.Builder(CropSowingReportActivity.this)
                                        .setTitle("Error!")
                                        .setMessage("You have not been assigned any villages against your saja, please contact Taluka office ")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                finish();
                                            }
                                        }).show();
                            }
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Seasons_List = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            CropTypeList = jsonObject.getJSONArray("data");
                        }
                    } else {
                        CropTypeList = new JSONArray();
                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            CropTypeSownSubList = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            CropNameList = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 6) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Crop Sowing Report")
                                    .setContentText("Submitted Successfully")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    }
                }

                if (i == 7) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Sajja_List = jsonObject.getJSONArray("data");
                        }
                    }
                }
                /*if (i == 8) {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                village_list = jsonObject.getJSONArray("data");
                            }
                        }
                }*/

                if (i == 9) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            field_type_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 10) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            calculation_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= calculation_list.length(); j++) {
                                JSONObject data_json_object = calculation_list.getJSONObject(j);
                                last_week_area_dlb = data_json_object.getDouble("total");
                                last_week_area_str = String.valueOf(last_week_area_dlb);
                                sown_area_edt.setText(last_week_area_str);// commented by shashank, just for testing...
                            }
                        }
                    }
                }

                if (i == 11) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            date_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= date_list.length(); j++) {
                                JSONObject data_json_object = date_list.getJSONObject(j);
                                current_week1y = data_json_object.getString("start_current_week");
                                current_week2y = data_json_object.getString("end_current_week");
                                last_week1y = data_json_object.getString("start_lastweek");
                                last_week2y = data_json_object.getString("end_lastweek");
                                current_week = current_week1y + " / " + current_week2y;
                                csr_current_week.setText(current_week);
                                last_week = last_week1y + " / " + last_week2y;
                                csr_last_week.setText(last_week);
                            }
                        }
                    }
                }

                if (i == 12) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 13) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONArray data = jsonObject.getJSONArray("data");
                            final int length = data.length();
                            for (int j = 0; j < length; j++) {
                                JSONObject data_json_object = data.getJSONObject(j);
                                geo_area = data_json_object.getString("geographical_area");
                                cul_area = data_json_object.getString("cultivated_area");
                                geographical_area = Double.valueOf(geo_area);
                                ns_cropSR_addfield_btn.setEnabled(true);
                            }
                        }
                    } else {
                        new AlertDialog.Builder(CropSowingReportActivity.this)
                                .setTitle("Warning")
                                .setMessage("You haven't filled geographical area in Village Mapping Module")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        ns_cropSR_addfield_btn.setEnabled(false);
                                        sp_ns_cropSR_village_name.setText("Select");
                                        selectedvillage_id = 0;


                                    }
                                }).show();
                        //Toast.makeText(CropSowingReportActivity.this, "You haven't filled geographical area for Village Mapping Area", Toast.LENGTH_SHORT).show();
                    }
                }

                if (i == 14) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 15) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            total_area_upto_last_week = jsonObject.getString("area_last_week");
                            if (!total_area_upto_last_week.equalsIgnoreCase("null")) {
                                total_sown_area = Double.parseDouble(total_area_upto_last_week);
                            } else {
                                total_sown_area = 0.0;
                            }

                            Crop_type_Service();

                        }
                    }
                }

                if (i == 16) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            areaReasonList = jsonObject.getJSONArray("data");
                        }
                    }
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 2) {
            ns_cropSR_seasonid = Integer.parseInt(s1);
            ns_cropSR_season_name = s;
            sp_season.setText(ns_cropSR_season_name);
            area_of_all_crop();
            ns_cropSR_croptype_tv.setText("Select");
            ns_cropSR_horticulture_tv.setText("Select");
            ns_cropSR_field_tv.setText("Select");
            horticulture_crop_type_ll.setVisibility(View.GONE);
            field_crop_type_ll.setVisibility(View.GONE);
            ns_cropSR_cropsown_tv.setText("Select");
            CropTypeSownSubList = new JSONArray();
            CropNameList = new JSONArray();
            field_type_list = new JSONArray();
            csr_other_crop_ll.setVisibility(View.GONE);
            csr_other_crop_edt.setText("");
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
        }
        if (i == 3) {
            ns_cropSR_croptypeID = Integer.parseInt(s1);
            ns_cropSR_croptype_tv.setText(s);
            CropTypeSownSubList = new JSONArray();
            field_type_list = new JSONArray();
            CropNameList = new JSONArray();
            ns_cropSR_horticulture_tv.setText("Select");
            ns_cropSR_field_tv.setText("Select");
            ns_cropSR_cropsown_tv.setText("Select");
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
            //last_year_sown_area_edt.setText("");
            csr_other_crop_ll.setVisibility(View.GONE);
            csr_other_crop_edt.setText("");
            ns_cropSR_horticultureID = 0;
            field_type_str = "";
            crop_name_str_int = 0;

            if (ns_cropSR_croptypeID == 45) {   //  holticulture crops
                horticulture_crop_type_ll.setVisibility(View.VISIBLE);
                field_crop_type_ll.setVisibility(View.GONE);
                Crop_type_sown_sub_list();
                CropTypeSownSubList = new JSONArray();
                field_type_list = new JSONArray();
                CropNameList = new JSONArray();
            } else if (ns_cropSR_croptypeID == 43) { // fields crop
                horticulture_crop_type_ll.setVisibility(View.GONE);
                field_crop_type_ll.setVisibility(View.VISIBLE);
                field_crop_type_service();
                CropTypeSownSubList = new JSONArray();
                field_type_list = new JSONArray();
                CropNameList = new JSONArray();
                crop_name_str_int = 0;
            } else {
                CropTypeSownSubList = new JSONArray();
                field_type_list = new JSONArray();
                CropNameList = new JSONArray();
                horticulture_crop_type_ll.setVisibility(View.GONE);
                field_crop_type_ll.setVisibility(View.GONE);
                Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
            }
        }
        if (i == 4) {
            ns_cropSR_horticultureID = Integer.parseInt(s1);
            ns_cropSR_cropsown = s;
            ns_cropSR_horticulture_tv.setText(s);
            ns_cropSR_cropsown_tv.setText("Select");
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
            csr_other_crop_edt.setText("");
            csr_other_crop_ll.setVisibility(View.GONE);
            CropNameList = new JSONArray();
            Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
            if (ns_cropSR_cropsown.equalsIgnoreCase("Fruits")) {
                Intent crop_sown_report_sub_activity = new Intent(CropSowingReportActivity.this, CropSowingReportSubTypeActivity.class);
                crop_sown_report_sub_activity.putExtra("divison_id", divison_id);
                crop_sown_report_sub_activity.putExtra("district_id", district_id);
                crop_sown_report_sub_activity.putExtra("taluka_id", taluka_id);
                crop_sown_report_sub_activity.putExtra("sajja_id", sajja_id);
                crop_sown_report_sub_activity.putExtra("village_name", village_name);
                crop_sown_report_sub_activity.putExtra("village_id", selectedvillage_id);
                crop_sown_report_sub_activity.putExtra("season_id", ns_cropSR_seasonid);
                crop_sown_report_sub_activity.putExtra("crop_type_id", ns_cropSR_croptypeID);
                crop_sown_report_sub_activity.putExtra("horti_type_id", ns_cropSR_horticultureID);
                crop_sown_report_sub_activity.putExtra("current_week", current_week);
                crop_sown_report_sub_activity.putExtra("last_week", last_week);
                ns_cropSR_horticulture_tv.setText("Select");
                startActivity(crop_sown_report_sub_activity);
            } else {
                Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
            }
        }

        if (i == 9) {
            field_type_id = Integer.parseInt(s1);
            field_type_name = s;
            ns_cropSR_field_tv.setText(s);
            field_type_str = String.valueOf(field_type_id);
            CropNameList = new JSONArray();
            ns_cropSR_cropsown_tv.setText("Select");
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
            csr_other_crop_ll.setVisibility(View.GONE);
            csr_other_crop_edt.setText("");
            Crop_type_sown_sub_crop_list(ns_cropSR_croptypeID, ns_cropSR_horticultureID, field_type_str);
        }
        if (i == 5) {
            crop_name_str_int = Integer.parseInt(s1);
            crop_name_str = s;
            ns_cropSR_cropsown_tv.setText(crop_name_str);
            calculation_last_week();

            if (crop_name_str.equalsIgnoreCase("OTHER")) {
                csr_other_crop_ll.setVisibility(View.VISIBLE);
            } else {
                csr_other_crop_ll.setVisibility(View.GONE);
                csr_other_crop_edt.setText("");
            }
            sown_area_edt.setText("0.0");
            natural_sown_area_edt.setText("");
            //last_year_sown_area_edt.setText("");

        }

        if (i == 7) {
            sajja_id = Integer.parseInt(s1);
            sajja_name = s;
            ns_cropSR_sajja_list_name_tv.setText(sajja_name);
            normalVillageList();
            sp_ns_cropSR_village_name.setText("Select");
        }

        if (i == 12) {
            selectedvillage_id = Integer.parseInt(s1);
            village_name = s;
            sp_ns_cropSR_village_name.setText(village_name);
            get_geo_cul_area();
            sp_season.setText("Select");
            ns_cropSR_croptype_tv.setText("Select");
            ns_cropSR_horticulture_tv.setText("Select");
            ns_cropSR_field_tv.setText("Select");
            ns_cropSR_cropsown_tv.setText("Select");
            csr_other_crop_edt.setText("");
            natural_sown_area_edt.setText("");
        }

        if (i == 14) {
            selectedvillage_id = Integer.parseInt(s1);
            village_name = s;
            sp_ns_cropSR_village_name.setText(village_name);
            get_geo_cul_area();
            sp_season.setText("Select");
            ns_cropSR_croptype_tv.setText("Select");
            ns_cropSR_horticulture_tv.setText("Select");
            ns_cropSR_field_tv.setText("Select");
            ns_cropSR_cropsown_tv.setText("Select");
            csr_other_crop_edt.setText("");
            natural_sown_area_edt.setText("");
        }

        if (i == 15) {
            reasontext = s;
            ns_reason_tv.setText(reasontext);
        }
    }
}
