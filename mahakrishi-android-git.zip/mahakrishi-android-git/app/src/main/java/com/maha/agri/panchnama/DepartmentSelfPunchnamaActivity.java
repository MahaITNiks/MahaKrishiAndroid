package com.maha.agri.panchnama;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.abdeveloper.library.MultiSelectDialog;
import com.abdeveloper.library.MultiSelectModel;
import com.maha.agri.BuildConfig;
import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DepartmentSelfPunchnamaActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    static final Integer CAMERA = 0x5;
    static final Integer CAMERA1 = 0x6;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    ArrayList<String> VillageName;
    HashMap<Integer, String> village_map = new HashMap<>();
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    View parentLayout;
    private ArrayList<Integer> damage_reason_selectedIds = new ArrayList<>();
    private ArrayList<String> damage_reason_selectedNames = new ArrayList<>();
    ArrayList<MultiSelectModel> list_of_damage = new ArrayList<>();
    private TextView sp_pikache_naav, sp_year, sp_hungam, sp_yojna, sp_pikache_prakar, sp_nuksanicha_prakar, sp_nuksanicha_karan,
            dept_self_panchnama_horti_crop_type_tv;
    private TextView dept_panchnama_district_tv, dept_panchnama_taluka_tv, dept_panchnama_sajja_name_tv,dept_panchnama_village_tv, nuksanicha_dinaak_tv;
    private RadioGroup crop_insurance_rg, sheticha_prakar_radio_group, dept_neshirg_apati_rg;
    private RadioButton crop_insu_yes_rb, crop_insu_no_rb, bagyati_radio_btn, jirayati_radio_btn, dept_neshirg_apati_yes_radio_btn,
            dept_neshirg_apati_no_radio_btn;
    private EditText lagwadi_ekkar_edt, lagwadi_guntha_edt, pikvima_ekkar_edt, pikvima_guntha_edt, andajeet_ekkar_edt, andajeet_guntha_edt,
            edt_survey_no_group_no, txt_vw_Specify_disease, dept_txt_vw_Specify_Pest,
            nuksanicha_takkewari_edt, total_lagwadi, total_pikvima, total_baghadheet;
    private Button dept_punchnama_submit_btn;
    private LinearLayout yojna_ll, pikache_prakar_ll, rogache_naav_ll, keedicha_naav_ll;
    private ImageView dept_panchnama_photo, nuksanicha_dinaak_iv, dept_panchnama_photo_1;
    private String crop_insurance_name,nesargik_apati_id="";
    private JSONArray year_list, district_list, village_list, farm_type_list, crop_list, damage_reason_list, damage_type_list, scheme_list,
            season_list, crop_type_list, horti_crop_list;
    private String yearname, division_name = "", district_name = "", taluka_name = "", circle_name = "", sajja_name = "", village_name = "", farm_type_name, currentTime, farmID = "0";
    private String role_id = "", divisionID = "0", districtID = "0", talukaID = "0",circleID = "0", sajjaID = "0", villageID = "0", crop_insurance_ID = "",Damage_reason_name="",damage_reason_id="";
    private int divison_id = 0,district_id = 0, taluka_id = 0,circle_id = 0, sajja_id = 0,village_id = 0;
    private int yearID = 0, croplistID = 0, damageReasonID = 0, damageTypeID = 0, schemeID = 0, seasonID = 0, croptypeID = 0, horti_crop_id = 0;
    private String imagePath = "", imagePath1 = "";
    private File photoFile = null;
    private File photoFile1 = null;
    private Transformation transformation;
    private int responseID;
    private String activityID = "";
    private int lagwadi_ekkar_str, lagwadi_guntha_str, pikvima_ekkar_str, pikvima_guntha_str, andajeet_ekkar_str, andajeet_guntha_str, nuksanicha_int;
    private LinearLayout pik_vima_saranjheet_ll, dept_neshirg_apati_ll, dept_farmer_damage_reason_ll, dept_self_panchnama_horti_type,dept_self_panchanam_crop_name_ll;
    private String data;
    private int mYear, mMonth, mDay;
    private String nuksanicha_dinaak = "";
    private DatePickerDialog nuksanidatePickerDialog;
    private int one_ekkar = 100;
    private String total_lagwadi_str = "0", total_pikvima_str = "0", total_baghadheet_str = "=0", nuksanicka_takkewari_str = "0", lagwadi_ekkar_value = "0",
            lagwadi_guntha_value = "0", pikvima_ekkar_value = "0", pikvima_guntha_value = "0", andajeet_ekkar_value = "0", andajeet_guntha_value = "0",
            nuksanicha_takkeri_str = "0", Damage_reason_id = "0", damage_name,img_one_url = "", img_two_url = "";
    private int total_lagwadi_int, total_pikvima_int, total_baghadheet_int;
    private SweetAlertDialog sweetAlertDialog;
    private EditText dept_self_panchnama_crop_name_edt;
    private AppLocationManager appLocationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_self_punchnama);
        getSupportActionBar().setTitle("Department Panchnama");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DepartmentSelfPunchnamaActivity.this);
        sharedPref = new SharedPref(DepartmentSelfPunchnamaActivity.this);
        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();
        parentLayout = findViewById(android.R.id.content);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);

        if (isNetworkAvailable()) {
            init();
        } else {
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void init() {
        //Spinner
        sp_year = findViewById(R.id.sp_dept_self_year);
        sp_year.setEnabled(false);
        dept_panchnama_sajja_name_tv = (TextView)findViewById(R.id.panchnama_sajja_name_tv);
        dept_panchnama_village_tv = (TextView)findViewById(R.id.panchnama_village_tv);
        sp_hungam = findViewById(R.id.sp_dept_self_season);
        sp_yojna = findViewById(R.id.sp_dept_name_of_the_scheme);
        sp_pikache_prakar = findViewById(R.id.sp_dept_self_crop_type);
        sp_pikache_naav = findViewById(R.id.sp_dept_self_name_of_the_crop);
        sp_nuksanicha_prakar = findViewById(R.id.sp_dept_self_type_of_damage);
        sp_nuksanicha_karan = findViewById(R.id.sp_dept_self_causes_of_damage);
        dept_self_panchnama_horti_crop_type_tv = findViewById(R.id.dept_self_panchnama_horti_crop_type_tv);

        //TextView
        nuksanicha_dinaak_tv = findViewById(R.id.dept_self_nuksanicha_dinaak_tv);
        //nuksanicha_suchna_dilecha_dinaak_tv = (TextView)findViewById(R.id.dept_self_nuksanicha_suchna_dilecha_dinaak_tv);
        //Edit Text
        edt_survey_no_group_no = findViewById(R.id.dept_edt_survey_no_group_no);
        lagwadi_ekkar_edt = findViewById(R.id.dept_lagwadi_ekkar_edt);
        lagwadi_guntha_edt = findViewById(R.id.dept_lagwadi_guntha_edt);
        pikvima_ekkar_edt = findViewById(R.id.dept_pikvima_ekkar_edt);
        pikvima_guntha_edt = findViewById(R.id.dept_pikvima_guntha_edt);
        andajeet_ekkar_edt = findViewById(R.id.dept_andajeet_ekkar_edt);
        andajeet_guntha_edt = findViewById(R.id.dept_andajeet_guntha_edt);
        txt_vw_Specify_disease = findViewById(R.id.dept_txt_vw_Specify_disease);
        dept_txt_vw_Specify_Pest = findViewById(R.id.dept_txt_vw_Specify_Pest);
        nuksanicha_takkewari_edt = findViewById(R.id.dept_nuksanicha_takkewari_edt);
        total_lagwadi = findViewById(R.id.dept_self_total_lagwadi);
        total_pikvima = findViewById(R.id.dept_self_total_pikvima);
        total_baghadheet = findViewById(R.id.dept_self_total_badheet);
        dept_self_panchnama_crop_name_edt = (EditText)findViewById(R.id.dept_self_panchnama_crop_name_edt);

        //RadioGroup and RadioButton
        crop_insurance_rg = findViewById(R.id.dept_crop_insurance_rg);
        sheticha_prakar_radio_group = findViewById(R.id.dept_self_sheticha_prakar_radio_group);
        dept_neshirg_apati_rg = findViewById(R.id.dept_neshirg_apati_rg);
        dept_neshirg_apati_yes_radio_btn = findViewById(R.id.dept_neshirg_apati_yes_radio_btn);
        dept_neshirg_apati_no_radio_btn = findViewById(R.id.dept_neshirg_apati_no_radio_btn);
        crop_insu_yes_rb = findViewById(R.id.dept_crop_insu_yes_radio_btn);
        crop_insu_no_rb = findViewById(R.id.dept_crop_insu_no_radio_btn);
        bagyati_radio_btn = findViewById(R.id.dept_self_bagyati_radio_btn);
        jirayati_radio_btn = findViewById(R.id.dept_self_jirayati_radio_btn);
        crop_insu_yes_rb.setChecked(false);
        crop_insu_no_rb.setChecked(false);
        bagyati_radio_btn.setChecked(false);
        jirayati_radio_btn.setChecked(false);
        dept_neshirg_apati_yes_radio_btn.setChecked(false);
        dept_neshirg_apati_no_radio_btn.setChecked(false);

        //Layout
        yojna_ll = findViewById(R.id.dept_yojna_ll);
        pikache_prakar_ll = findViewById(R.id.dept_pikache_prakar_ll);
        dept_self_panchnama_horti_type = findViewById(R.id.dept_self_panchnama_horti_type);
        rogache_naav_ll = findViewById(R.id.dept_rogache_naav_ll);
        keedicha_naav_ll = findViewById(R.id.dept_keedicha_naav_ll);
        pik_vima_saranjheet_ll = findViewById(R.id.pik_vima_sarancheet_ll);
        dept_neshirg_apati_ll = findViewById(R.id.dept_neshirg_apati_ll);
        dept_farmer_damage_reason_ll = findViewById(R.id.dept_farmer_damage_reason_ll);
        dept_self_panchanam_crop_name_ll = findViewById(R.id.dept_self_panchanam_crop_name_ll);

        //Button
        dept_punchnama_submit_btn = findViewById(R.id.dept_submit_btn);

        //Image View
        dept_panchnama_photo = findViewById(R.id.dept_panchnama_photo);
        nuksanicha_dinaak_iv = findViewById(R.id.dept_self_nuksanicha_dinaak_iv);
        dept_panchnama_photo_1 = findViewById(R.id.dept_panchnama_photo_1);
        //nuksanicha_notice_dinaak_iv = (ImageView)findViewById(R.id.dept_self_nuksanicha_notice_dinaak_iv);

        dept_panchnama_district_tv = findViewById(R.id.dept_panchnama_district_tv);
        dept_panchnama_taluka_tv = findViewById(R.id.dept_panchnama_taluka_tv);

        nuksanicha_dinaak_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nuk_sani_date_Picker();
            }
        });


        PunchnamaYearWebservice();
        get_district_taluka();
        Farm_type_Service();

        data = AppSettings.getInstance().getValue(DepartmentSelfPunchnamaActivity.this, ApConstants.kLOGIN_DATA, "");

        currentTime = ApUtil.getCurrentTimeStamp();

        VillageName = new ArrayList<>();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        year_list = new JSONArray();

        if(role_id.equalsIgnoreCase("1")){
            village_list = new JSONArray();
            dept_panchnama_village_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    village_web_service();
                    if(village_list.length()>0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 16, "Select Village", "village_name", "village_id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                    }
                }
            });
        }

        sp_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (year_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(year_list, 1, "Select Year", "name", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                } else {
                    PunchnamaYearWebservice();
                }
            }
        });

        sp_yojna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (scheme_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(scheme_list, 6, "Select Scheme", "name_mr", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                } else {
                    Scheme_Service();
                }
            }
        });


        sp_hungam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select scheme", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else {
                    if (season_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(season_list, 7, "Select Season", "name_mr", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                    } else {
                        Season_Service(crop_insurance_ID, schemeID);
                    }
                }
            }
        });

        sp_pikache_prakar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_type_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(crop_type_list, 8, "Select Crop type", "name_mr", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                } else {
                    CropType_Service(seasonID);
                }

            }
        });

        dept_self_panchnama_horti_crop_type_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (croptypeID == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select crop type", Toast.LENGTH_SHORT);
                    toast.show();
                } else {
                    if (horti_crop_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(horti_crop_list, 15, "Select Horticulture type", "name_marathi", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                    } else {
                        Horti_crop_type_service(croptypeID);
                    }
                }
            }
        });

        sp_pikache_naav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else if (crop_insurance_ID.equalsIgnoreCase("1") && schemeID == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select scheme", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else if (seasonID == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else if (crop_insurance_ID.equalsIgnoreCase("0") && croptypeID == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select crop type", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                }else if(crop_list.length()==0){
                    Toast.makeText(DepartmentSelfPunchnamaActivity.this, "Crop not available", Toast.LENGTH_SHORT).show();
                }else {
                    if (crop_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(crop_list, 9, "Select Crop", "crop_marathi", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                    } else {
                        Crop_list(croptypeID,seasonID,horti_crop_id,schemeID);
                    }
                }
            }
        });

        sp_nuksanicha_prakar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_insurance_ID.equalsIgnoreCase("")) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select crop insurance is available or not", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.show();
                } else {
                    if (damage_type_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(damage_type_list, 11, "Select Damage type", "name_mr", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                    } else {
                        Damage_Type(crop_insurance_ID);

                    }
                }
            }
        });

        sp_nuksanicha_karan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*if (damage_reason_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(damage_reason_list, 10, "Select Damage reason", "name_mr", "id", DepartmentSelfPunchnamaActivity.this, DepartmentSelfPunchnamaActivity.this);
                } else {
                    Damage_Reason();
                }*/
                MultiSelectDialog multiSelectDialog = new MultiSelectDialog()
                        .title("Select")
                        .titleSize(25)
                        .positiveText("Done")
                        .negativeText("Cancel")
                        .setMinSelectionLimit(1)
                        .setMaxSelectionLimit(list_of_damage.size())
                        .multiSelectList(list_of_damage)
                        .onSubmit(new MultiSelectDialog.SubmitCallbackListener() {
                            @Override
                            public void onSelected(ArrayList<Integer> selectedIds, ArrayList<String> selectedNames, String dataString) {
                                damage_reason_selectedIds = selectedIds;
                                damage_reason_id = String.valueOf(damage_reason_selectedIds);
                                damage_reason_selectedNames = selectedNames;
                                Damage_reason_name = dataString;
                                sp_nuksanicha_karan.setText(dataString);
                                if(selectedNames.contains("किडीचा प्रादुर्भाव") & selectedNames.contains("रोगाचा प्रादुर्भाव")){
                                    rogache_naav_ll.setVisibility(View.VISIBLE);
                                    keedicha_naav_ll.setVisibility(View.VISIBLE);
                                    dept_txt_vw_Specify_Pest.setText("");
                                    txt_vw_Specify_disease.setText("");
                                }else if(selectedNames.contains("रोगाचा प्रादुर्भाव")) {
                                    keedicha_naav_ll.setVisibility(View.GONE);
                                    rogache_naav_ll.setVisibility(View.VISIBLE);
                                    dept_txt_vw_Specify_Pest.setText("");
                                    txt_vw_Specify_disease.setText("");
                                }else if (selectedNames.contains("किडीचा प्रादुर्भाव")) {
                                    keedicha_naav_ll.setVisibility(View.VISIBLE);
                                    rogache_naav_ll.setVisibility(View.GONE);
                                    dept_txt_vw_Specify_Pest.setText("");
                                    txt_vw_Specify_disease.setText("");
                                }else{
                                    rogache_naav_ll.setVisibility(View.GONE);
                                    keedicha_naav_ll.setVisibility(View.GONE);
                                    dept_txt_vw_Specify_Pest.setText("");
                                    txt_vw_Specify_disease.setText("");
                                }
                            }

                            @Override
                            public void onCancel() {

                            }
                        });

                multiSelectDialog.show(getSupportFragmentManager(), "multiSelectDialog");
            }
        });

        sheticha_prakar_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.dept_self_bagyati_radio_btn:
                        bagyati_radio_btn.setChecked(true);
                        farmID = "1";
                        break;

                    case R.id.dept_self_jirayati_radio_btn:
                        jirayati_radio_btn.setChecked(true);
                        farmID = "2";
                        break;
                }
            }
        });

        crop_insurance_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.dept_crop_insu_yes_radio_btn:

                        crop_insu_yes_rb.setChecked(true);
                        dept_neshirg_apati_yes_radio_btn.setChecked(false);
                        dept_neshirg_apati_no_radio_btn.setChecked(false);
                        crop_insurance_name = crop_insu_yes_rb.getText().toString();
                        crop_insurance_ID = "1";
                        yojna_ll.setVisibility(View.VISIBLE);
                        dept_neshirg_apati_ll.setVisibility(View.VISIBLE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        pik_vima_saranjheet_ll.setVisibility(View.VISIBLE);
                        pikache_prakar_ll.setVisibility(View.GONE);
                        dept_farmer_damage_reason_ll.setVisibility(View.GONE);
                        dept_self_panchnama_horti_type.setVisibility(View.GONE);
                        dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
                        clear_data();
                        Scheme_Service();
                        Damage_Type(crop_insurance_ID);
                        Damage_Reason();
                        break;

                    case R.id.dept_crop_insu_no_radio_btn:

                        crop_insu_no_rb.setChecked(true);
                        dept_neshirg_apati_yes_radio_btn.setChecked(true);
                        dept_neshirg_apati_no_radio_btn.setChecked(true);
                        crop_insurance_name = crop_insu_no_rb.getText().toString();
                        crop_insurance_ID = "0";
                        nesargik_apati_id = "";
                        yojna_ll.setVisibility(View.GONE);
                        pik_vima_saranjheet_ll.setVisibility(View.GONE);
                        dept_neshirg_apati_ll.setVisibility(View.GONE);
                        rogache_naav_ll.setVisibility(View.GONE);
                        keedicha_naav_ll.setVisibility(View.GONE);
                        dept_self_panchnama_horti_type.setVisibility(View.GONE);
                        pikache_prakar_ll.setVisibility(View.VISIBLE);
                        dept_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                        dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
                        clear_data();
                        schemeID = 0;
                        Season_Service(crop_insurance_ID, schemeID);
                        Damage_Type(crop_insurance_ID);
                        Damage_Reason();
                        break;
                }
            }
        });

            dept_neshirg_apati_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch (checkedId) {
                        case R.id.dept_neshirg_apati_yes_radio_btn:
                            dept_neshirg_apati_yes_radio_btn.setChecked(true);
                            nesargik_apati_id = "1";
                            dept_farmer_damage_reason_ll.setVisibility(View.VISIBLE);
                            keedicha_naav_ll.setVisibility(View.GONE);
                            rogache_naav_ll.setVisibility(View.GONE);
                            sp_nuksanicha_karan.setText("Select");
                            break;

                        case R.id.dept_neshirg_apati_no_radio_btn:
                            dept_neshirg_apati_no_radio_btn.setChecked(true);
                            nesargik_apati_id = "0";
                            dept_farmer_damage_reason_ll.setVisibility(View.GONE);
                            keedicha_naav_ll.setVisibility(View.GONE);
                            rogache_naav_ll.setVisibility(View.GONE);
                            sp_nuksanicha_karan.setText("Select");
                            break;
                    }
                }
            });

        dept_panchnama_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        dept_panchnama_photo_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(DepartmentSelfPunchnamaActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri1();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        lagwadi_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                lagwadi_ekkar_value = lagwadi_ekkar_edt.getText().toString().trim();
                if (!lagwadi_ekkar_value.equalsIgnoreCase("")) {
                    lagwadi_ekkar_str = Integer.parseInt(s.toString());
                    total_lagwadi_str = String.valueOf((lagwadi_ekkar_str * one_ekkar) + lagwadi_guntha_str);
                    total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                    total_lagwadi.setText(total_lagwadi_str);
                } else {
                    total_lagwadi.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        lagwadi_guntha_edt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                lagwadi_guntha_value = lagwadi_guntha_edt.getText().toString();
                if (!lagwadi_guntha_value.equalsIgnoreCase("")) {
                    lagwadi_guntha_str = Integer.valueOf(s.toString());
                    if (lagwadi_guntha_str < 100) {
                        total_lagwadi_str = String.valueOf(lagwadi_ekkar_str * one_ekkar + lagwadi_guntha_str);
                        total_lagwadi.setText(total_lagwadi_str);
                        total_lagwadi_int = Integer.valueOf(total_lagwadi_str);
                    } else {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                lagwadi_guntha_edt.setText("");
                                total_lagwadi.setText("");
                            }
                        })
                                .show();
                    }
                } else {
                    total_lagwadi.setText("");
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        });

        pikvima_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pikvima_ekkar_value = pikvima_ekkar_edt.getText().toString().trim();

                if (pikvima_ekkar_value.equalsIgnoreCase("")) {
                    pikvima_ekkar_value = "0";
                } else if (!pikvima_ekkar_value.equalsIgnoreCase("")) {
                    pikvima_ekkar_str = Integer.parseInt(pikvima_ekkar_value);
                    total_pikvima_str = String.valueOf(pikvima_ekkar_str * one_ekkar + pikvima_guntha_str);
                    total_pikvima_int = Integer.valueOf(total_pikvima_str);
                    if (total_pikvima_int > total_lagwadi_int) {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकूण लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता कामा नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                total_pikvima.setText("");
                                pikvima_ekkar_edt.setText("");
                                pikvima_ekkar_str = 0;
                                pikvima_guntha_edt.setText("");
                                pikvima_guntha_str = 0;

                            }
                        }).show();


                    } else {
                        pikvima_ekkar_str = Integer.parseInt(s.toString());
                        total_pikvima.setText(total_pikvima_str);
                    }

                } else {
                    total_pikvima.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        pikvima_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pikvima_guntha_value = pikvima_guntha_edt.getText().toString();

                if (pikvima_guntha_value.equalsIgnoreCase("")) {
                    pikvima_guntha_str = 0;
                } else if (!pikvima_guntha_value.equalsIgnoreCase("")) {

                    pikvima_guntha_str = Integer.parseInt(pikvima_guntha_value);

                    if (pikvima_guntha_str < 100) {
                        total_pikvima_str = String.valueOf((pikvima_ekkar_str * one_ekkar) + pikvima_guntha_str);
                        total_pikvima_int = Integer.valueOf(total_pikvima_str);

                        if (total_pikvima_int > total_lagwadi_int) {
                            sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("एकूण लागवडी खालील क्षेत्रा पेक्षा पिक विमा संरक्षीत क्षेत्र अधिक असता कामा नये");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    total_pikvima.setText("");
                                    total_pikvima_int = 0;
                                    pikvima_ekkar_edt.setText("");
                                    pikvima_ekkar_str = 0;
                                    pikvima_guntha_edt.setText("");
                                    pikvima_guntha_str = 0;

                                }
                            }).show();


                        } else {
                            total_pikvima.setText(total_pikvima_str);
                        }
                    } else {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                total_pikvima.setText("");
                                pikvima_guntha_edt.setText("");
                                pikvima_guntha_str = 0;
                            }
                        }).show();

                    }

                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        andajeet_ekkar_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                andajeet_ekkar_value = andajeet_ekkar_edt.getText().toString().trim();
                if (!andajeet_ekkar_value.equalsIgnoreCase("")) {
                    andajeet_ekkar_str = Integer.parseInt(andajeet_ekkar_value);
                    total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                    total_baghadheet_int = Integer.valueOf(total_baghadheet_str);

                    if (total_baghadheet_int > total_lagwadi_int) {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("एकूण लागवडी खालील क्षेत्रा पेक्षा बाधित क्षेत्र अधिक असता कामा नये");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                total_baghadheet.setText("");
                                andajeet_ekkar_edt.setText("");
                                andajeet_ekkar_str = 0;
                                andajeet_guntha_edt.setText("");
                                andajeet_guntha_str = 0;

                            }
                        }).show();


                    } else {
                        total_baghadheet.setText(total_baghadheet_str);
                        //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                        //nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");
                    }
                } else {
                    total_baghadheet.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

        andajeet_guntha_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                andajeet_guntha_value = andajeet_guntha_edt.getText().toString();

                if (!andajeet_guntha_value.equalsIgnoreCase("")) {
                    andajeet_guntha_str = Integer.parseInt(andajeet_guntha_value);
                    if (andajeet_guntha_str < 100) {
                        total_baghadheet_str = String.valueOf(andajeet_ekkar_str * one_ekkar + andajeet_guntha_str);
                        total_baghadheet_int = Integer.valueOf(total_baghadheet_str);

                        if (total_baghadheet_int > total_lagwadi_int) {
                            sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                            sweetAlertDialog.setContentText("एकूण लागवडी खालील क्षेत्रा पेक्षा बाधित क्षेत्र अधिक असता कामा नये");
                            sweetAlertDialog.setConfirmText("ठीक आहे");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    total_baghadheet.setText("");
                                    total_baghadheet_int = 0;
                                    andajeet_ekkar_edt.setText("");
                                    andajeet_ekkar_str = 0;
                                    andajeet_guntha_edt.setText("");
                                    andajeet_guntha_str = 0;

                                }
                            }).show();


                        } else {
                            total_baghadheet.setText(total_baghadheet_str);
                            //nuksanicka_takkewari_str = String.valueOf(total_baghadheet_int * 100 / total_lagwadi_int);
                            //nuksanicha_takkewari_edt.setText(nuksanicka_takkewari_str + "%");

                        }
                    } else {

                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("गुंठा १०० पेक्षा कमी असला पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                total_baghadheet.setText("");
                                andajeet_guntha_edt.setText("");
                                andajeet_guntha_str = 0;
                                //nuksanicha_takkewari_edt.setText("");
                            }
                        }).show();

                    }

                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        nuksanicha_takkewari_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                nuksanicka_takkewari_str = nuksanicha_takkewari_edt.getText().toString().trim();
                if (!nuksanicka_takkewari_str.equalsIgnoreCase("")) {
                    nuksanicha_int = Integer.valueOf(nuksanicka_takkewari_str);
                    if (nuksanicha_int > 100) {
                        sweetAlertDialog = new SweetAlertDialog(DepartmentSelfPunchnamaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("नुकसानीची टक्केवारी १००% पेक्षा कमी असली पाहिजे");
                        sweetAlertDialog.setConfirmText("ठीक आहे");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismiss();
                                nuksanicha_takkewari_edt.setText("");
                            }
                        }).show();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        dept_punchnama_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PunchnamaSave();
            }
        });

    }

    private void nuk_sani_date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        nuksanidatePickerDialog = new DatePickerDialog(DepartmentSelfPunchnamaActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        nuksanicha_dinaak = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        nuksanicha_dinaak_tv.setText(nuksanicha_dinaak);
                    }
                }, mYear, mMonth, mDay);

        nuksanidatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        nuksanidatePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        nuksanidatePickerDialog.show();
    }

    private void clear_data() {

        season_list = new JSONArray();
        seasonID = 0;
        scheme_list = new JSONArray();
        schemeID = 0;
        crop_type_list = new JSONArray();
        croptypeID = 0;
        horti_crop_list = new JSONArray();
        horti_crop_id = 0;
        crop_list = new JSONArray();
        croplistID = 0;
        damage_type_list = new JSONArray();
        damageTypeID = 0;
        damage_reason_list = new JSONArray();
        damageReasonID = 0;
        list_of_damage = new ArrayList<>();
        sp_yojna.setText("Select");
        sp_hungam.setText("Select");
        sp_pikache_prakar.setText("Select");
        sp_pikache_naav.setText("Select");
        sp_nuksanicha_prakar.setText("Select");
        sp_nuksanicha_karan.setText("Select");
        dept_self_panchnama_horti_crop_type_tv.setText("Select");
        lagwadi_ekkar_edt.setText("");
        lagwadi_guntha_edt.setText("");
        total_lagwadi.setText("");
        pikvima_ekkar_edt.setText("");
        pikvima_guntha_edt.setText("");
        total_pikvima.setText("");
        andajeet_ekkar_edt.setText("");
        andajeet_guntha_edt.setText("");
        lagwadi_ekkar_edt.setText("");
        total_baghadheet.setText("");
        nuksanicha_takkewari_edt.setText("");
        dept_self_panchnama_crop_name_edt.setText("");
        nuksanicha_dinaak_tv.setText("dd/mm/yyyy");
        dept_panchnama_photo.setImageResource(R.drawable.camera);
        dept_panchnama_photo_1.setImageResource(R.drawable.camera);
    }

    /*private void nuk_sani_notice_date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        nuksani_notice_date_picker_dialog = new DatePickerDialog(DepartmentSelfPunchnamaActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        nuksanicha_notice_dinaak = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        nuksanicha_suchna_dilecha_dinaak_tv.setText(nuksanicha_notice_dinaak);


                    }
                }, mYear, mMonth, mDay);

        nuksani_notice_date_picker_dialog.getDatePicker().setMinDate(System.currentTimeMillis());
        nuksani_notice_date_picker_dialog.show();
    }*/


    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");
            photoFile1 = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    private void takeImageFromCameraUri1() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");
            photoFile1 = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");
            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA1);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            } else if (requestCode == CAMERA1) {
                onCameraActivityResult1();
            }
        }else{
            photoFile = null;
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(dept_panchnama_photo.getWidth(), dept_panchnama_photo.getHeight())
                                .centerCrop()
                                .into(dept_panchnama_photo);
                        uploadImageOnServer(imagePath);

                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(DepartmentSelfPunchnamaActivity.this, "Click photo", Toast.LENGTH_SHORT).show();
        }
    }

    public void onCameraActivityResult1() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (photoFile1.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath1 = "file://" + photoFile1;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath1)
                                .transform(transformation)
                                .resize(dept_panchnama_photo_1.getWidth(), dept_panchnama_photo_1.getHeight())
                                .centerCrop()
                                .into(dept_panchnama_photo_1);
                        uploadImageOnServer1(imagePath1);

                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile1);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }


    private void PunchnamaYearWebservice() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_year_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void village_web_service() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 16);

    }


    private void Farm_type_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_farm_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void Scheme_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_scheme_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    private void Season_Service(String crop_insurance_ID, int schemeID) {
        String crop_Iid;
        if (schemeID == 0) {
            crop_Iid = "";
        } else {
            crop_Iid = String.valueOf(schemeID);
        }
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("crop_insurance", crop_insurance_ID);
            param.put("panchnama_scheme_id", crop_Iid);
            param.put("primary_report_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);
    }

    private void CropType_Service(int seasonID) {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("season_id", "");
            param.put("primary_crop_id", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropType(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);
    }

    private void Horti_crop_type_service(int croptypeID) {
        JSONObject param = new JSONObject();
        try {
            param.put("id", croptypeID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_crop_type_sown_sublist(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 15);
    }

    private void Crop_list(int croptypeID, int seasonID, int horti_crop_id, int panchname_scheme_id) {
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id", seasonID);
            param.put("crop_type", croptypeID);
            param.put("horti_crop_type_id", horti_crop_id);
            param.put("primary_report_id","");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id",panchname_scheme_id);

        } catch (Exception e) {

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 9);
    }

    private void Damage_Reason() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_reason_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 10);
    }

    private void Damage_Type(String crop_insurance_ID) {
        JSONObject param = new JSONObject();
        try {
            param.put("crop_insurance", crop_insurance_ID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_damage_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 11);
    }

    private void PunchnamaSave() {

        if (village_id == 0) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select village", Toast.LENGTH_SHORT);
            toast.show();
        } else if (edt_survey_no_group_no.getText().toString().isEmpty()) {
            Toast toast = Toast.makeText(getApplicationContext(), "Enter survey or gut number", Toast.LENGTH_SHORT);
            toast.show();
        } else if (farmID.equalsIgnoreCase("0")) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select farm type", Toast.LENGTH_SHORT);
            toast.show();
        } else if (crop_insurance_ID.isEmpty()) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select insurance", Toast.LENGTH_SHORT);
            toast.show();
        } else if (seasonID == 0) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
            toast.show();
        } else if (croplistID == 0) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select crop", Toast.LENGTH_SHORT);
            toast.show();
        } else if (lagwadi_ekkar_edt.getText().toString().trim().isEmpty()) {
            Toast toast = Toast.makeText(getApplicationContext(), "Enter hector value", Toast.LENGTH_SHORT);
            toast.show();
        } else if (andajeet_ekkar_edt.getText().toString().trim().isEmpty()) {
            Toast toast = Toast.makeText(getApplicationContext(), "Enter hector value", Toast.LENGTH_SHORT);
            toast.show();
        } else if (nuksanicha_takkewari_edt.getText().toString().trim().isEmpty()) {
            Toast toast = Toast.makeText(getApplicationContext(), "Enter damage percentage", Toast.LENGTH_SHORT);
            toast.show();
        } else if (damageTypeID == 0) {
            Toast toast = Toast.makeText(getApplicationContext(), "Select damage type", Toast.LENGTH_SHORT);
            toast.show();
        } else if (nuksanicha_dinaak.equalsIgnoreCase("")) {
            Toast toast = Toast.makeText(getApplicationContext(), "Enter damage date", Toast.LENGTH_SHORT);
            toast.show();
        } else if (photoFile == null || photoFile1 == null) {
            Toast toast = Toast.makeText(getApplicationContext(), "Capture Photo", Toast.LENGTH_SHORT);
            toast.show();
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("year_id", yearID);
                param.put("division_id",divisionID);
                param.put("district_id", districtID);
                param.put("taluka_id", talukaID);
                param.put("circle_id", circleID);
                param.put("sajja_id", sajjaID);
                param.put("village_id", village_id);
                param.put("crop_insurance", crop_insurance_ID);
                param.put("scheme_id", schemeID);
                param.put("season_id", seasonID);
                param.put("crop_type_id", croptypeID);
                param.put("horti_crop_id", horti_crop_id);
                param.put("crop_id", croplistID);
                param.put("farm_type_id", farmID);
                param.put("survey_no", edt_survey_no_group_no.getText().toString().trim());
                param.put("area_under_crop_acre", lagwadi_ekkar_value);
                param.put("area_under_crop_guntha", lagwadi_guntha_value);
                param.put("insured_area_under_crop_acre", pikvima_ekkar_value);
                param.put("insured_area_under_crop_guntha", pikvima_guntha_value);
                param.put("approxmate_area_acre", andajeet_ekkar_value);
                param.put("approxmate_area_guntha", andajeet_guntha_value);
                param.put("damage_type_id", damageTypeID);
                param.put("damage_reason_id", damage_reason_id);
                param.put("dmg_reason_name", Damage_reason_name);
                param.put("disease_name", txt_vw_Specify_disease.getText().toString().trim());
                param.put("pest_name", dept_txt_vw_Specify_Pest.getText().toString().trim());
                param.put("nuksani_per", nuksanicka_takkewari_str);
                param.put("nuksani_date", nuksanicha_dinaak);
                param.put("neshrig_apati_id", nesargik_apati_id);
                param.put("nuksani_notice_date", "00-00-0000");
                param.put("total_lagwadi", total_lagwadi_str);
                param.put("total_pikvima", total_pikvima_str);
                param.put("total_baghadeet", total_baghadheet_str);
                param.put("img_one", img_one_url);
                param.put("img_two", img_two_url);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_self_punchnama_form_submit_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 12);
        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));
            params.put("lat", String.valueOf(lat));
            params.put("lon", String.valueOf(lang));
            params.put("district_id", districtID);
            params.put("taluka_id", talukaID);
            params.put("village_id", villageID);


            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_self_punchnama_image_form_submit_url(partBody, params);
            api.postRequest(responseCall, this, 13);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImageOnServer1(String imagePath1) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));
            params.put("lat", String.valueOf(lat));
            params.put("lon", String.valueOf(lang));
            params.put("district_id", districtID);
            params.put("taluka_id", talukaID);
            params.put("village_id", villageID);

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_self_punchnama_image_form_submit_url(partBody, params);
            api.postRequest(responseCall, this, 14);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //year
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_list = jsonObject.getJSONArray("data");

                        }
                    } else {
                    }
                }

                //District Taluka
                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= district_list.length(); j++) {
                                JSONObject district_json_object = district_list.getJSONObject(j);
                                divisionID = district_json_object.getString("division_id");
                                districtID = district_json_object.getString("district_id");
                                talukaID = district_json_object.getString("taluka_id");
                                circleID = district_json_object.getString("circle_id");
                                sajjaID = district_json_object.getString("sajja_id");

                                division_name = district_json_object.getString("division_name");
                                district_name = district_json_object.getString("district_name");
                                taluka_name = district_json_object.getString("taluka_name");
                                circle_name = district_json_object.getString("circle_name");
                                sajja_name = district_json_object.getString("sajja_name");

                                divison_id = Integer.valueOf(divisionID);
                                district_id = Integer.valueOf(districtID);
                                taluka_id = Integer.valueOf(talukaID);
                                circle_id = Integer.valueOf(circleID);
                                sajja_id = Integer.valueOf(sajjaID);

                                dept_panchnama_district_tv.setText(district_name);
                                dept_panchnama_taluka_tv.setText(taluka_name);
                                dept_panchnama_sajja_name_tv.setText(sajja_name);

                                village_web_service();
                            }
                        }
                    } else {
                    }
                } else
                    //Farm Type
                    if (i == 5) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                farm_type_list = jsonObject.getJSONArray("data");
                                final int numberOfItemsInResp = farm_type_list.length();
                                for (int j = 0; j < numberOfItemsInResp; j++) {
                                    JSONObject farm_type_json_object = farm_type_list.getJSONObject(j);
                                    farmID = farm_type_json_object.getString("id");
                                    farm_type_name = farm_type_json_object.getString("name_mr");
                                    if (farmID.equalsIgnoreCase("1")) {
                                        bagyati_radio_btn.setText(farm_type_name);
                                    } else if (farmID.equalsIgnoreCase("2")) {
                                        jirayati_radio_btn.setText(farm_type_name);
                                    }
                                    farmID = "0";

                                }

                            }
                        } else {
                        }
                    } else
                        //Scheme Type
                        if (i == 6) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    scheme_list = jsonObject.getJSONArray("data");


                                }

                            } else {

                            }
                        } else
                            //Season
                            if (i == 7) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        season_list = jsonObject.getJSONArray("data");

                                    }
                                } else {

                                }
                            } else
                                //Crop Type
                                if (i == 8) {

                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                        if (responseModel.isStatus()) {
                                            crop_type_list = jsonObject.getJSONArray("data");

                                        }

                                    } else {

                                    }
                                } else if (i == 9) {

                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                        if (responseModel.isStatus()) {
                                            crop_list = jsonObject.getJSONArray("data");

                                        }

                                    }

                                } else
                                    //Damage Reason
                                    if (i == 10) {

                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                            if (responseModel.isStatus()) {
                                                damage_reason_list = jsonObject.getJSONArray("data");
                                                final int numberOfItemsInResp = damage_reason_list.length();
                                                for (int j = 0; j < numberOfItemsInResp; j++) {
                                                    JSONObject damage_json_object = damage_reason_list.getJSONObject(j);
                                                    Damage_reason_id = damage_json_object.getString("id");
                                                    damage_name = damage_json_object.getString("name_mr");
                                                    list_of_damage.add(new MultiSelectModel(Integer.valueOf(Damage_reason_id), damage_name));
                                                }


                                            }

                                        } else {

                                        }
                                    } else
                                        //Damage Type
                                        if (i == 11) {

                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                if (responseModel.isStatus()) {
                                                    damage_type_list = jsonObject.getJSONArray("data");

                                                }

                                            } else {

                                            }
                                        } else
                                            //Save Punchnama
                                            if (i == 12) {

                                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                                    if (responseModel.isStatus()) {
                                                        responseID = jsonObject.getInt("data");
                                                        sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                                                sweetAlertDialog.setContentText(jsonObject.getString("response"));
                                                                sweetAlertDialog.setConfirmText("Ok");
                                                                sweetAlertDialog.setCancelable(false);
                                                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                                                    @Override
                                                                    public void onClick(SweetAlertDialog sDialog) {
                                                                        finish();
                                                                    }
                                                                });
                                                                sweetAlertDialog.show();
                                                    }

                                                } else {

                                                }
                                            } else
                                                //Save Punchnama image
                                                if (i == 13) {

                                                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                        ResponseModel responseModel = new ResponseModel(jsonObject);
                                                        if (responseModel.isStatus()) {
                                                            JSONObject data = jsonObject.getJSONObject("data");
                                                            img_one_url = data.getString("file_url");
                                                        }

                                                    } else {
                                                    }
                                                } else
                                                    //Save Punchnama image
                                                    if (i == 14) {

                                                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                            ResponseModel responseModel = new ResponseModel(jsonObject);
                                                            if (responseModel.isStatus()) {
                                                                JSONObject data = jsonObject.getJSONObject("data");
                                                                img_two_url = data.getString("file_url");
                                                            }

                                                        } else{

                                                        }
                                                    } else   //Damage Type
                                                        if (i == 15) {

                                                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                                                if (responseModel.isStatus()) {
                                                                    horti_crop_list = jsonObject.getJSONArray("data");

                                                                }

                                                            } else {
                                                                Toast.makeText(DepartmentSelfPunchnamaActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                                                            }
                                                        }

                                                        else   //Village
                                                            if (i == 16) {

                                                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                                                    if (responseModel.isStatus()) {
                                                                        village_list = jsonObject.getJSONArray("data");

                                                                    }

                                                                } else {
                                                                    Toast.makeText(DepartmentSelfPunchnamaActivity.this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                                                                }
                                                            }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            yearID = Integer.parseInt(s1);
            sp_year.setText(s);
            sp_year.setEnabled(false);
        }
        if (i == 7) {
            seasonID = Integer.parseInt(s1);
            sp_hungam.setText(s);
            crop_type_list = new JSONArray();
            crop_list = new JSONArray();
            Crop_list(croptypeID, seasonID, horti_crop_id,schemeID);
            CropType_Service(seasonID);
            sp_pikache_prakar.setText("Select");
            dept_self_panchnama_horti_type.setVisibility(View.GONE);
            dept_self_panchnama_horti_crop_type_tv.setText("Select");
            sp_pikache_naav.setText("Select");
            dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
            dept_self_panchnama_crop_name_edt.setText("");


        }
        if (i == 6) {
            schemeID = Integer.parseInt(s1);
            sp_yojna.setText(s);
            crop_list = new JSONArray();
            Season_Service(crop_insurance_ID, schemeID);
            sp_hungam.setText("Select");
            sp_pikache_naav.setText("Select");
            dept_self_panchnama_horti_crop_type_tv.setText("Select");
            dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
            dept_self_panchnama_crop_name_edt.setText("");
        }
        if (i == 8) {
            croptypeID = Integer.parseInt(s1);
            sp_pikache_prakar.setText(s);
            crop_list = new JSONArray();
            Crop_list(croptypeID, seasonID, horti_crop_id,schemeID);
            sp_pikache_naav.setText("Select");
            dept_self_panchnama_horti_crop_type_tv.setText("Select");
            dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
            dept_self_panchnama_crop_name_edt.setText("");
            horti_crop_id = 0;

            if (croptypeID == 45) {
                dept_self_panchnama_horti_type.setVisibility(View.VISIBLE);
                horti_crop_list = new JSONArray();
                crop_list = new JSONArray();
                Horti_crop_type_service(croptypeID);
                Crop_list(croptypeID, seasonID, horti_crop_id,schemeID);
                dept_self_panchnama_horti_crop_type_tv.setText("Select");
                sp_pikache_naav.setText("Select");
                dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
                dept_self_panchnama_crop_name_edt.setText("");
            } else {
                dept_self_panchnama_horti_type.setVisibility(View.GONE);
                horti_crop_list = new JSONArray();
                crop_list = new JSONArray();
                Crop_list(croptypeID, seasonID, horti_crop_id,schemeID);
                sp_pikache_naav.setText("Select");
                dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
                dept_self_panchnama_crop_name_edt.setText("");
                horti_crop_id = 0;
            }
        }

        if (i == 9) {
            croplistID = Integer.parseInt(s1);
            sp_pikache_naav.setText(s);
            if(s.equalsIgnoreCase("इतर")){
                dept_self_panchanam_crop_name_ll.setVisibility(View.VISIBLE);
            }else {
                dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
                dept_self_panchnama_crop_name_edt.setText("");
            }
        }

        if (i == 11) {
            damageTypeID = Integer.parseInt(s1);
            sp_nuksanicha_prakar.setText(s);
        }

        if (i == 10) {
            damageReasonID = Integer.parseInt(s1);
            sp_nuksanicha_karan.setText(s);
            if (damageReasonID == 3) {
                rogache_naav_ll.setVisibility(View.VISIBLE);
                keedicha_naav_ll.setVisibility(View.GONE);
            } else if (damageReasonID == 4) {
                keedicha_naav_ll.setVisibility(View.VISIBLE);
                rogache_naav_ll.setVisibility(View.GONE);
            }
        }

        if (i == 15) {
            horti_crop_id = Integer.parseInt(s1);
            dept_self_panchnama_horti_crop_type_tv.setText(s);
            crop_list = new JSONArray();
            Crop_list(croptypeID, seasonID, horti_crop_id,schemeID);
            sp_pikache_naav.setText("Select");
            dept_self_panchanam_crop_name_ll.setVisibility(View.GONE);
            dept_self_panchnama_crop_name_edt.setText("");
        }

        if (i == 16) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            dept_panchnama_village_tv.setText(village_name);
        }

    }
}

