package com.maha.agri.spot_verification;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class TurmericPlantationActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView select_plantation,plantation_tur_straw_farmer_name,plantation_tur_straw_village,plantation_tur_straw_taluka,plantation_tur_straw_district,
            plantation_tur_straw_gut_no,plantation_tur_straw_crop_name,plantation_tur_straw_proposed_area;

    private EditText plantation_tur_straw_vaan,plantation_tur_straw_actual_area,plantation_tur_straw_row1,plantation_tur_straw_row2,plantation_tur_straw_row3,
            plantation_tur_straw_row4,plantation_tur_straw_row5,plantation_tur_straw_row6,plantation_tur_straw_row7,plantation_tur_straw_row8,plantation_tur_straw_total;

    private Spinner plantation_tur_straw_sowing_arrangements;
    private RadioGroup plantation_tur_straw_rg;
    private RadioButton plantation_tur_straw_yes_rb,plantation_tur_straw_no_rb;
    private CheckBox accept_terms;
    private LinearLayout select_plantation_ll;
    private Button plantation_tur_straw_save;
    private SweetAlertDialog sweetAlertDialog;

    private JSONArray plantation_list;
    private int plantation_id = 0;
    private String plantation_name = "",type="0",sowing_arr="";
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turmeric_plantation);
        getSupportActionBar().setTitle("Plantation");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(TurmericPlantationActivity.this);

        ids();
        functions();
    }

    private void ids(){
        //Textview
        plantation_tur_straw_farmer_name = (TextView) findViewById(R.id.plantation_tur_straw_farmer_name);
        select_plantation = (TextView) findViewById(R.id.select_plantation);
        plantation_tur_straw_village = (TextView) findViewById(R.id.plantation_tur_straw_village);
        plantation_tur_straw_taluka = (TextView) findViewById(R.id.plantation_tur_straw_taluka);
        plantation_tur_straw_district = (TextView) findViewById(R.id.plantation_tur_straw_district);
        plantation_tur_straw_gut_no = (TextView) findViewById(R.id.plantation_tur_straw_gut_no);
        plantation_tur_straw_crop_name = (TextView) findViewById(R.id.plantation_tur_straw_crop_name);
        plantation_tur_straw_proposed_area = (TextView) findViewById(R.id.plantation_tur_straw_proposed_area);
        plantation_tur_straw_sowing_arrangements = (Spinner) findViewById(R.id.plantation_tur_straw_sowing_arrangements);

        //Edittext
        plantation_tur_straw_vaan = (EditText) findViewById(R.id.plantation_tur_straw_vaan);
        plantation_tur_straw_actual_area = (EditText) findViewById(R.id.plantation_tur_straw_actual_area);
        plantation_tur_straw_row1 = (EditText) findViewById(R.id.plantation_tur_straw_row1);
        plantation_tur_straw_row2 = (EditText) findViewById(R.id.plantation_tur_straw_row2);
        plantation_tur_straw_row3 = (EditText) findViewById(R.id.plantation_tur_straw_row3);
        plantation_tur_straw_row4 = (EditText) findViewById(R.id.plantation_tur_straw_row4);
        plantation_tur_straw_row5 = (EditText) findViewById(R.id.plantation_tur_straw_row5);
        plantation_tur_straw_row6 = (EditText) findViewById(R.id.plantation_tur_straw_row6);
        plantation_tur_straw_row7 = (EditText) findViewById(R.id.plantation_tur_straw_row7);
        plantation_tur_straw_row8 = (EditText) findViewById(R.id.plantation_tur_straw_row8);
        plantation_tur_straw_total = (EditText) findViewById(R.id.plantation_tur_straw_total);

        //Radio
        plantation_tur_straw_rg = (RadioGroup) findViewById(R.id.plantation_tur_straw_rg);
        plantation_tur_straw_yes_rb = (RadioButton) findViewById(R.id.plantation_tur_straw_yes_rb);
        plantation_tur_straw_no_rb = (RadioButton) findViewById(R.id.plantation_tur_straw_no_rb);

        accept_terms = (CheckBox) findViewById(R.id.accept_terms);

        plantation_tur_straw_save = (Button) findViewById(R.id.plantation_tur_straw_save);

        select_plantation_ll = (LinearLayout) findViewById(R.id.select_plantation_ll);

        plantation_list_service();
    }

    private void functions(){

        plantation_list = new JSONArray();

        select_plantation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(plantation_list,1,"Select Plantation","name","id",TurmericPlantationActivity.this,TurmericPlantationActivity.this);
            }
        });

        plantation_tur_straw_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.plantation_tur_straw_yes_rb:
                        plantation_tur_straw_yes_rb.setChecked(true);
                        type = "1";
                        break;

                    case R.id.plantation_tur_straw_no_rb:
                        plantation_tur_straw_no_rb.setChecked(true);
                        type = "2";
                        break;
                }
            }
        });

        plantation_tur_straw_sowing_arrangements.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sowing_arr = plantation_tur_straw_sowing_arrangements.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        plantation_tur_straw_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                plantation_save();
            }
        });
    }

    private void plantation_list_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.plantation_list();
        api.postRequest(responseCall, this, 1);
    }

    private void data_reset(){
        plantation_tur_straw_vaan.setText("");
        plantation_tur_straw_actual_area.setText("");
        plantation_tur_straw_yes_rb.setChecked(false);
        plantation_tur_straw_no_rb.setChecked(false);
        plantation_tur_straw_sowing_arrangements.setSelection(0);
        plantation_tur_straw_row1.setText("");
        plantation_tur_straw_row2.setText("");
        plantation_tur_straw_row3.setText("");
        plantation_tur_straw_row4.setText("");
        plantation_tur_straw_row5.setText("");
        plantation_tur_straw_row6.setText("");
        plantation_tur_straw_row7.setText("");
        plantation_tur_straw_row8.setText("");
        plantation_tur_straw_total.setText("");
        accept_terms.setChecked(false);
    }

    private void plantation_save(){
        if(plantation_tur_straw_vaan.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter vaan", Toast.LENGTH_SHORT).show();
        }else if(plantation_tur_straw_actual_area.getText().toString().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter actual area", Toast.LENGTH_SHORT);
            toast.show();
        }else if(type.equalsIgnoreCase("0")){
            Toast toast= Toast.makeText(getApplicationContext(), "पसिंचनाच्या उपलब्ध सोयी पुरेशा आहेत काय ?", Toast.LENGTH_SHORT);
            toast.show();
        }else if(sowing_arr.equalsIgnoreCase("Select")){
            Toast.makeText(getApplicationContext(), "Select सिंचनाची उपलब्ध सुविधा", Toast.LENGTH_SHORT).show();
        }else if(plantation_tur_straw_row1.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for जमिन तयार करणे", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row2.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for लागवड साहित्य", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row3.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for पाणी पुरबठयासाठी ठिबक / तुषार सिंचन संच", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row4.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for सेंद्रीय खते / रासायनिक खते (तपशिलवार)", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row5.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for सकिटकनाशके/ बुरशीनाशके", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row6.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for रोपवाटीका करण्याकरिता लागलेली मजूरी", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row7.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter cost for इतर किरकोळ खर्च", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_row8.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter एकूण खर्च", Toast.LENGTH_SHORT);
            toast.show();
        }else if(plantation_tur_straw_total.getText().toString().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter अंतिम देय रक्कम रु.", Toast.LENGTH_SHORT);
            toast.show();
        }else if(!accept_terms.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept the terms",Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("plantation_id", plantation_id);
                param.put("farmer_name_dbt", "0");
                param.put("village_id_dbt", "0");
                param.put("taluka_id_dbt", "0");
                param.put("district_id_dbt", "0");
                param.put("gut_no", "0");
                param.put("crop_name", plantation_tur_straw_crop_name.getText().toString().trim());
                param.put("vaan", plantation_tur_straw_vaan.getText().toString().trim());
                param.put("proposed_area_dbt", "0");
                param.put("actual_area", plantation_tur_straw_actual_area.getText().toString().trim());
                param.put("sowing_arr_rb", type);
                param.put("sowing_arr", sowing_arr);
                param.put("row1", plantation_tur_straw_row1.getText().toString().trim());
                param.put("row2", plantation_tur_straw_row2.getText().toString().trim());
                param.put("row3", plantation_tur_straw_row3.getText().toString().trim());
                param.put("row4", plantation_tur_straw_row4.getText().toString().trim());
                param.put("row5", plantation_tur_straw_row5.getText().toString().trim());
                param.put("row6", plantation_tur_straw_row6.getText().toString().trim());
                param.put("row7", plantation_tur_straw_row7.getText().toString().trim());
                param.put("table_total", plantation_tur_straw_row8.getText().toString().trim());
                param.put("total", plantation_tur_straw_total.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.plantation_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            plantation_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText(plantation_name + " Plantation");
                                sweetAlertDialog.setContentText("Data saved successfully");
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            plantation_id = Integer.parseInt(s1);
            plantation_name = s;
            select_plantation.setText(plantation_name);

            if(plantation_name.equalsIgnoreCase("Turmeric")){
                select_plantation_ll.setVisibility(View.VISIBLE);
                data_reset();
                plantation_tur_straw_crop_name.setText("हळद");

            }
            else if(plantation_name.equalsIgnoreCase("Strawberry")){
                select_plantation_ll.setVisibility(View.VISIBLE);
                data_reset();
                plantation_tur_straw_crop_name.setText("स्रवबेरी");
            }
            else{
                select_plantation_ll.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
