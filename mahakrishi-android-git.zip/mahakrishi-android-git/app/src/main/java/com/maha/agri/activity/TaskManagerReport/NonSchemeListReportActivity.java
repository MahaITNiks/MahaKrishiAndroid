package com.maha.agri.activity.TaskManagerReport;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.TaskManagerAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class NonSchemeListReportActivity extends AppCompatActivity implements ApiCallbackCode {
    /*private String[] count = {"1","2","3","4","5","6","7","8","9","10"};
    private String[] schemelist = {"Peek Pahani","Panchnama","Attending Gram Sabha","Publicity Work","Valuation","Crop Insurance","Meetings","Insurance Related Work","Pension Related Work","Others"};*/
    private RecyclerView nonschemerv;
    private int  nonschemeId;
    private JSONArray nonschemeList;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private String activityId;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_scheme_list_report);
        preferenceManager = new PreferenceManager(NonSchemeListReportActivity.this);
        sharedPref = new SharedPref(NonSchemeListReportActivity.this);
        getSupportActionBar().setTitle("Non-Scheme Activity List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        intent = getIntent();
        activityId = intent.getStringExtra("activityId");
        init();
        default_config();
        getNonSchemeListWebservice();
}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    private void init(){
        nonschemerv = (RecyclerView) findViewById(R.id.non_scheme_recyclerView);
        nonschemerv.setLayoutManager(new LinearLayoutManager(this));
        nonschemerv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));

    }

    private void default_config(){

        nonschemerv.addOnItemTouchListener(new TaskManagerAdapter.RecyclerTouchListener(this, nonschemerv, new TaskManagerAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                try {
                    JSONObject jsonObject = nonschemeList.getJSONObject(position);
                    String id = jsonObject.getString("id");
                    Intent intent = new Intent(NonSchemeListReportActivity.this,TaskManagerDetails.class);
                    intent.putExtra("activityId",id);
                    startActivity(intent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }


            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }


    private void getNonSchemeListWebservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("typeId","2");
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeListReportTypes(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            nonschemeList = jsonObject.getJSONArray("data");
                            nonschemerv.setAdapter(new SchemeReportAdapter(this,nonschemeList,preferenceManager));
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    }
