package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.adapter.CustomerHiringAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CustomerHiringCenterActivity extends AppCompatActivity implements ApiCallbackCode {
    private TextView chc_obsdate,chc_name,chc_address,chc_mobileno,chc_pravarg,chc_bill_amt_app,chc_parivahan_regdate;
    private EditText chc_centername,chc_moneyhelp_amt,chc_tool_realname,chc_reg_name,chc_bill_amt_actual,chc_exp_manpower,chc_tool_bankamt,
            chc_bankamt_paidself,chc_bank_loanamt,chc_othermatters,chc_parivahan_regno;
    private Button chc_addmore,chc_save;
    private TableLayout titleTableLayout;
    private LinearLayout chc_parivahan_yes_ll,chc_parivahan_no_ll;
    private ImageView chc_regdateiv,chc_photo;
    private RecyclerView chc_rv;
    private RadioGroup chc_rg1,chc_rg2,chc_rg3,chc_toolmaint_rg,chc_abhilekh_rg,chc_parivahan_rg;
    private RadioButton chc_r1_yes,chc_r1_no,chc_r2_yes,chc_r2_no,chc_r3_yes,chc_r3_no,chc_toolmaint_yes,chc_toolmaint_no,chc_abhilekh_yes,chc_abhilekh_no,
            chc_yes_parivahan,chc_no_parivahan;
    private PreferenceManager preferenceManager;
    private String chc_obs_date,rg1="0",rg2="",rg3="",toolmaint="",abhilekh="",parivahan="",parivahan_date="",type="";
    private int mYear, mMonth, mDay;
    private JSONArray multiple_field_add = new JSONArray();
    private SweetAlertDialog sweetAlertDialog;
    private DatePickerDialog parivahanDateDialog;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    static final Integer CAMERA = 0x5;
    String imagePath,currentTime;
    private Transformation transformation;

    private AppLocationManager locationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_hiring_center);
        getSupportActionBar().setTitle("Customer Hiring Center");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(CustomerHiringCenterActivity.this);

        ids();
        functionality();
    }

    private void ids(){
        //Textview
        chc_obsdate = (TextView) findViewById(R.id.chc_obsdate);
        chc_name = (TextView) findViewById(R.id.chc_name);
        chc_address = (TextView) findViewById(R.id.chc_address);
        chc_mobileno = (TextView) findViewById(R.id.chc_mobileno);
        chc_pravarg = (TextView) findViewById(R.id.chc_pravarg);
        chc_bill_amt_app = (TextView) findViewById(R.id.chc_bill_amt_app);
        chc_parivahan_regdate = (TextView) findViewById(R.id.chc_parivahan_regdate);
        //Edittext
        chc_centername = (EditText) findViewById(R.id.chc_centername);
        chc_moneyhelp_amt = (EditText) findViewById(R.id.chc_moneyhelp_amt);
        chc_tool_realname = (EditText) findViewById(R.id.chc_tool_realname);
        chc_reg_name = (EditText) findViewById(R.id.chc_reg_name);
        chc_bill_amt_actual = (EditText) findViewById(R.id.chc_bill_amt_actual);
        chc_exp_manpower = (EditText) findViewById(R.id.chc_exp_manpower);
        chc_tool_bankamt = (EditText) findViewById(R.id.chc_tool_bankamt);
        chc_bankamt_paidself = (EditText) findViewById(R.id.chc_bankamt_paidself);
        chc_bank_loanamt = (EditText) findViewById(R.id.chc_bank_loanamt);
        chc_othermatters = (EditText) findViewById(R.id.chc_othermatters);
        chc_parivahan_regno = (EditText) findViewById(R.id.chc_parivahan_regno);
        //Radiogroup and Radiobuttons
        chc_rg1 = (RadioGroup) findViewById(R.id.chc_rg1);
        chc_rg2 = (RadioGroup) findViewById(R.id.chc_rg2);
        chc_rg3 = (RadioGroup) findViewById(R.id.chc_rg3);
        chc_toolmaint_rg = (RadioGroup) findViewById(R.id.chc_toolmaint_rg);
        chc_abhilekh_rg = (RadioGroup) findViewById(R.id.chc_abhilekh_rg);
        chc_parivahan_rg = (RadioGroup) findViewById(R.id.chc_parivahan_rg);
        chc_r1_yes = (RadioButton) findViewById(R.id.chc_r1_yes);
        chc_r2_yes = (RadioButton) findViewById(R.id.chc_r2_yes);
        chc_r3_yes = (RadioButton) findViewById(R.id.chc_r3_yes);
        chc_r1_no = (RadioButton) findViewById(R.id.chc_r1_no);
        chc_r2_no = (RadioButton) findViewById(R.id.chc_r2_no);
        chc_r3_no = (RadioButton) findViewById(R.id.chc_r3_no);
        chc_toolmaint_yes = (RadioButton) findViewById(R.id.chc_toolmaint_yes);
        chc_toolmaint_no = (RadioButton) findViewById(R.id.chc_toolmaint_no);
        chc_abhilekh_yes = (RadioButton) findViewById(R.id.chc_abhilekh_yes);
        chc_abhilekh_no = (RadioButton) findViewById(R.id.chc_abhilekh_no);
        chc_yes_parivahan = (RadioButton) findViewById(R.id.chc_yes_parivahan);
        chc_no_parivahan = (RadioButton) findViewById(R.id.chc_no_parivahan);
        //Others
        chc_addmore = (Button) findViewById(R.id.chc_addmore);
        chc_save = (Button) findViewById(R.id.chc_save);
        titleTableLayout = (TableLayout) findViewById(R.id.chc_titleTableLayout);
        chc_rv = (RecyclerView) findViewById(R.id.chc_rv);
        chc_parivahan_no_ll = (LinearLayout) findViewById(R.id.chc_parivahan_no_ll);
        chc_parivahan_yes_ll = (LinearLayout) findViewById(R.id.chc_parivahan_yes_ll);
        chc_regdateiv = (ImageView) findViewById(R.id.chc_regdateiv);
        chc_photo = (ImageView) findViewById(R.id.chc_photo);

        chc_obs_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        chc_obsdate.setText(chc_obs_date);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
        locationManager = new AppLocationManager(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void functionality() {

        chc_regdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regdate_date_picker();
            }
        });

        chc_addmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chc_tool_realname.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(CustomerHiringCenterActivity.this,"Enter औजाराचे तांत्रीक नाव",Toast.LENGTH_SHORT).show();
                }else if(chc_reg_name.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(CustomerHiringCenterActivity.this,"Enter प्रकल्पात नमुद केलेले नाव",Toast.LENGTH_SHORT).show();
                }else if(chc_bill_amt_actual.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(CustomerHiringCenterActivity.this,"Enter बीलानुसार खरेदीची रक्कम (प्रत्यक्षात)",Toast.LENGTH_SHORT).show();
                }else{
                    add_multiple_array(chc_tool_realname.getText().toString(),chc_reg_name.getText().toString(),chc_bill_amt_actual.getText().toString().trim());
                }
            }
        });

        chc_rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_r1_yes:
                        chc_r1_yes.setChecked(true);
                        rg1 = "1";
                        break;

                    case R.id.chc_r1_no:
                        chc_r1_no.setChecked(true);
                        rg1 = "2";
                        break;

                }
            }
        });

        chc_rg2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_r2_yes:
                        chc_r2_yes.setChecked(true);
                        rg2 = "1";
                        break;

                    case R.id.chc_r2_no:
                        chc_r2_no.setChecked(true);
                        rg2 = "2";
                        break;

                }
            }
        });

        chc_rg3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_r3_yes:
                        chc_r3_yes.setChecked(true);
                        rg3 = "1";
                        break;

                    case R.id.chc_r3_no:
                        chc_r3_no.setChecked(true);
                        rg3 = "2";
                        break;

                }
            }
        });

        chc_toolmaint_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_toolmaint_yes:
                        chc_toolmaint_yes.setChecked(true);
                        toolmaint = "1";
                        break;

                    case R.id.chc_toolmaint_no:
                        chc_toolmaint_no.setChecked(true);
                        toolmaint = "2";
                        break;

                }
            }
        });

        chc_abhilekh_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_abhilekh_yes:
                        chc_abhilekh_yes.setChecked(true);
                        abhilekh = "1";
                        break;

                    case R.id.chc_abhilekh_no:
                        chc_abhilekh_no.setChecked(true);
                        abhilekh = "2";
                        break;

                }
            }
        });

        chc_parivahan_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.chc_yes_parivahan:
                        chc_yes_parivahan.setChecked(true);
                        chc_parivahan_yes_ll.setVisibility(View.VISIBLE);
                        chc_parivahan_no_ll.setVisibility(View.GONE);
                        parivahan_date = "0";
                        chc_parivahan_regdate.setText("dd/mm/yyyy");
                        parivahan = "1";
                        break;

                    case R.id.chc_no_parivahan:
                        chc_no_parivahan.setChecked(true);
                        chc_parivahan_yes_ll.setVisibility(View.GONE);
                        chc_parivahan_no_ll.setVisibility(View.VISIBLE);
                        chc_parivahan_regno.setText("");
                        parivahan = "0";
                        break;

                }
            }
        });

        chc_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(CustomerHiringCenterActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(CustomerHiringCenterActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(CustomerHiringCenterActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    type ="1";
                    takeImageFromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }

        });

        chc_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chc_save_service();
            }
        });
    }

    private void regdate_date_picker(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        parivahanDateDialog = new DatePickerDialog(CustomerHiringCenterActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        parivahan_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        chc_parivahan_regdate.setText(parivahan_date);


                    }
                }, mYear, mMonth, mDay);

        parivahanDateDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

        parivahanDateDialog.show();
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(chc_photo.getWidth(), chc_photo.getHeight())
                                    .centerCrop()
                                    .into(chc_photo);
                            uploadImageOnServer(imagePath);

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", "1");
            params.put("taluka_id", "1");
            params.put("village_id", "1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.customer_hiring_center_save_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void add_multiple_array(String realname_str,String reg_name_str,String bill_actual_amt_str){

        JSONObject multiple_crop_field_add_json_object = new JSONObject();
        try {
            multiple_crop_field_add_json_object.put("real_name", realname_str);
            multiple_crop_field_add_json_object.put("reg_name", reg_name_str);
            multiple_crop_field_add_json_object.put("bill_amt_app", "1234");
            multiple_crop_field_add_json_object.put("bill_amt_actual", bill_actual_amt_str);
            multiple_field_add.put(multiple_crop_field_add_json_object);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (multiple_field_add.length() > 0) {
            chc_rv.setLayoutManager(new LinearLayoutManager(CustomerHiringCenterActivity.this));
            CustomerHiringAdapter customerHiringAdapter = new CustomerHiringAdapter(preferenceManager, multiple_field_add, CustomerHiringCenterActivity.this);
            chc_rv.setAdapter(customerHiringAdapter);
            customerHiringAdapter.notifyDataSetChanged();
            chc_tool_realname.setText("");
            chc_reg_name.setText("");
            chc_bill_amt_actual.setText("");

        } else {
            final Toast toast = Toast.makeText(CustomerHiringCenterActivity.this, "Enter data for above fields", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);
        }
    }

    private void chc_save_service(){
        if(chc_centername.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter संस्थेचे नाव",Toast.LENGTH_SHORT).show();
        }else if(chc_moneyhelp_amt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter अर्थसहाय्याची रक्कम",Toast.LENGTH_SHORT).show();
        }else if(multiple_field_add == null){
            Toast.makeText(CustomerHiringCenterActivity.this,"Add data for प्रस्तावीत प्रकल्पातील औजारे बॅन्कचा तपशील",Toast.LENGTH_SHORT).show();
        }else if(rg1.equalsIgnoreCase("0")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Select औजारे सुरक्षीत व सुस्थितीत ठेवण्यासाठी व्यवस्था/शेड",Toast.LENGTH_SHORT).show();
        }else if(chc_exp_manpower.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter अनुभवी व प्रशिक्षीत मनुष्यबळ (संख्या)",Toast.LENGTH_SHORT).show();
        }else if(toolmaint.equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"औजारे देखभाल व दुरुस्तीसाठी व्यवस्था करण्यात आली आहे काय?",Toast.LENGTH_SHORT).show();
        }else if(abhilekh.equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"अभिलेख जतन करुन ठेवण्यासाठी करण्यात आलेली आहे काय?",Toast.LENGTH_SHORT).show();
        }else if(parivahan.equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"यंत्र /औजाराची परिवहन विभागाकडे नोंदणी करण्यात आली आहे काय?",Toast.LENGTH_SHORT).show();
        }else if(chc_tool_bankamt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter औजारे बॅन्क स्थापनेसाठी खरेदी केलेल्या औजारांची एकूण रक्कम",Toast.LENGTH_SHORT).show();
        }else if(rg2.equalsIgnoreCase("0")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Select यंत्रसामुग्री व औजारे सुस्थितीत प्राप्त झाल्याबाबत लाभधारकाची लेखी सहमती",Toast.LENGTH_SHORT).show();
        }else if(rg3.equalsIgnoreCase("0")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Select माफक दराने सेवा-सुविधा पुरवठ्याबाबत लाभधारकाची लेखी सहमती",Toast.LENGTH_SHORT).show();
        }else if(chc_bankamt_paidself.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter अनुदान वजाजाता लाभधारकाने स्वनिधीतून भरलेली रक्कम ₹",Toast.LENGTH_SHORT).show();
        }else if(chc_bank_loanamt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter संयुक्त तपासणी पथकाने अनुदान रकमेसाठी केलेली शिफारस ₹",Toast.LENGTH_SHORT).show();
        }else if(chc_othermatters.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(CustomerHiringCenterActivity.this,"Enter इतर अनुषंगीक मुद्दे",Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("obs_date", chc_obs_date);
                param.put("name", chc_name.getText().toString().trim());
                param.put("address", chc_address.getText().toString().trim());
                param.put("mobile_no", chc_mobileno.getText().toString().trim());
                param.put("pravarg",chc_pravarg.getText().toString().trim());
                param.put("center_name", chc_centername.getText().toString().trim());
                param.put("money_helped", chc_moneyhelp_amt.getText().toString().trim());
                param.put("multiple_array", multiple_field_add.toString());
                param.put("rg1", rg1);
                param.put("tool_maint", toolmaint);
                param.put("exp_manpower", chc_exp_manpower.getText().toString().trim());
                param.put("abhilekh", abhilekh);
                param.put("parivahan", parivahan);
                param.put("parivahan_regno", chc_parivahan_regno.getText().toString().trim());
                param.put("parivahan_regdate", parivahan_date);
                param.put("tool_bankamt", chc_tool_bankamt.getText().toString().trim());
                param.put("rg2", rg2);
                param.put("rg3", rg3);
                param.put("bankamt_paidself", chc_bankamt_paidself.getText().toString().trim());
                param.put("bank_loanamt", chc_bank_loanamt.getText().toString().trim());
                param.put("other_matters", chc_othermatters.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.customer_hiring_center_save_details(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{

                if(i == 1){

                    if(jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setCancelable(false);
                            sweetAlertDialog.setTitleText("Customer Hiring Center");
                            sweetAlertDialog.setContentText("Submitted Successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    Intent intent = new Intent(CustomerHiringCenterActivity.this, DripAndSprinklerActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }

                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}