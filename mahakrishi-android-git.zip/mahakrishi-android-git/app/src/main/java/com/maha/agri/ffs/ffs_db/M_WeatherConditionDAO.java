package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_WeatherConditionDAO {

    @Query("SELECT * FROM M_WeatherConditionEY")
    List<M_WeatherConditionEY> getAll();

    @Query("SELECT * FROM M_WeatherConditionEY WHERE uid IN (:userIds)")
    List<M_WeatherConditionEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_WeatherConditionEY WHERE uid = :id")
    List<M_WeatherConditionEY> checkIdExists(int id);

    @Insert
    void insertAll(M_WeatherConditionEY... m_weatherCondition);

    @Insert
    void insertOnlySingle(M_WeatherConditionEY m_weatherConditionEY);
}
