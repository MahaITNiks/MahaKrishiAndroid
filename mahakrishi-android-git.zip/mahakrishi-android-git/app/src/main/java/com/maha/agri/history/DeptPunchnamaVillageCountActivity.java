package com.maha.agri.history;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DeptPunchnamaVillageCountActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView dept_punchnama_village_list_count_rv;
    private JSONArray dept_punchnama_village_count_list;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private JSONArray village_list;
    private String data,village_id,village_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dept_punchnama_village_count);

        getSupportActionBar().setTitle("Primary Report History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DeptPunchnamaVillageCountActivity.this);
        sharedPref = new SharedPref(DeptPunchnamaVillageCountActivity.this);

        IdCalling();

        if (isNetworkAvailable()){
            get_primary_report_count_against_village_save();

        }else {
        }


    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling() {
        dept_punchnama_village_list_count_rv = (RecyclerView) findViewById(R.id.dept_punchnama_village_list_count_rv);
        dept_punchnama_village_list_count_rv.setLayoutManager(new GridLayoutManager(this, 2));
        data = AppSettings.getInstance().getValue(DeptPunchnamaVillageCountActivity.this, ApConstants.kLOGIN_DATA,"");

    }


    private void get_primary_report_count_against_village_save() {

        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
            for (int j = 0; j < village_list.length(); j++) {
                JSONObject village_json_object = null;
                try {
                    village_json_object = village_list.getJSONObject(j);
                    village_id = AppUtility.getInstance().componentSeparatedByCommaJSONArray(village_list,"village_id");
                    village_name = village_json_object.getString("village_name");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("village_id",village_id);

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.primary_report_count_against_village_save(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            dept_punchnama_village_count_list = jsonObject.getJSONArray("data");
                            dept_punchnama_village_list_count_rv.setAdapter(new DeptPunchnamaVillageCountAdapter(preferenceManager,dept_punchnama_village_count_list,this));

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
