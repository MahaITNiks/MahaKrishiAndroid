package com.maha.agri.web_services;


public interface APIServices {

   /* String BASE_API = "http://uat-mahakrishi-api.mahaitgov.in/v19/";
    String MASTER_API_URL = BASE_API + "masterService/";
    String API_URL = BASE_API + "kdpService/";
    String REPORT_API_URL = BASE_API + "reportService/";
    String ASSIGNED_VILLAGE_BASE_URL = BASE_API + "cmskdpService/";
    String MB_RECORDING_BASE_URL = BASE_API + "appmbrecordingService/";
    String CROPSAP_NEW_BASE_URL = BASE_API + "cropSapNewController/";
    String SV_MECHANIZATION_BASE_URL = BASE_API + "mechanismController/";
    String PHY_VERI_URL = BASE_API + "pvwbcisService/";
    String SPOT_VERIFICATION_URL = BASE_API + "spotverification/";
    String ORCHARD_MAPPING_URL = BASE_API + "orchardMapping/";*/

    //mahait production url   mahkrushi new web tommarow 15/06/2022
   // String BASE_API = "http://krishi-helpdesk.com/v19/";

    String BASE_API = "http://uatmahakrushi.mahaitgov.in/v19/";
    String MASTER_API_URL = BASE_API + "masterService/";
    String API_URL = BASE_API + "kdpService/";
    String REPORT_API_URL = BASE_API + "reportService/";
    String ASSIGNED_VILLAGE_BASE_URL = BASE_API + "cmskdpService/";
    String MB_RECORDING_BASE_URL = BASE_API + "appmbrecordingService/";
    String CROPSAP_NEW_BASE_URL = BASE_API + "cropSapNewController/";
    String SV_MECHANIZATION_BASE_URL = BASE_API + "mechanismController/";
    String PHY_VERI_URL = BASE_API + "pvwbcisService/";
    String SPOT_VERIFICATION_URL = BASE_API + "spotverification/";
    String ORCHARD_MAPPING_URL = BASE_API + "orchardMapping/";
    // Common


    String kMasterSeason = "masterService/get-season-list-on-activity-id"; // Season for Master crop list
    String kMasterCropType = "masterService/get-croptype-by-activityid-seasonid"; // Crop Type for Master crop list
    String kMasterCrop = "masterService/get-crop-by-activity-season-ctype-field-htype"; // Master crop list
    String kMasterCropVariety = "masterService/get-cropvariety-from-crop-id"; // Master crop list
    String kMasterCropPestList = "masterService/get-pest-name-cropid"; //CropSap Pest List
    String kMasterCropIrrigationList = "masterService/get-irrigation-on-crop-id"; //CropSap Irrigation List
    String kMasterCropGrowthList = "masterService/get-crop-growth-on-crop-id"; //CropSap Crop Growth List
    String kReasons = "masterService/get-reasonslist-cropsown"; // Season for Master crop list


    /* Facilitator */
    /***** Post Urls ****/

    // get Event Type List
    String AUTH_URL = API_URL + "login";
    String UPDATE_URL = API_URL + "update-profile";
    String UPDATE_APP = API_URL + "check-version-avail";
    String UPDATE_PROFILE_PIC_URL = API_URL + "update-profile-picture";
    String ASSIGNED_VILLAGE_URL = ASSIGNED_VILLAGE_BASE_URL + "get-assigned-villages";
    String ASSIGNED_LOCATION_URL = API_URL + "lower-list-of-locations-and-officer";
    String ATTENDANCE_USER_DETAILS_URL = API_URL + "user-details-for-calendar";
    String OFFLINECHECKINANDOUT_URL = API_URL + "offline-checkin-checkout";
    String OFFLINE_IMG_UPLOAD = API_URL + "offline-upload-image";
    String AB_REASON_URL = API_URL + "absent-reason";
    String TASK_MANAGER_TYPES_URL = API_URL + "task-manager-types";
    String SCHEME_lIST_URL = API_URL + "task-manager-scheme-list";
    String SCHEME_lIST_TYPES_URL = API_URL + "task-manager-scheme-activities";
    String TASK_MANAGER_ADD_SCHEME_WORK = API_URL + "task-manager-add-scheme-work";
    String SCHEME_RELATED_WORK_PIC = API_URL + "task-manager-add-scheme-work-image";
    String ATTENDANCE_MONTH_FILTER_URL = API_URL + "month-filter";

    // For Report
    String TASK_MANAGER_TYPES_REPORT_URL = API_URL + "report-task-manager-types";
    String SCHEME_lIST_REPORT_URL = API_URL + "report-task-manager-scheme-list";
    String SCHEME_lIST_REPORT_TYPES_URL = API_URL + "report-task-manager-scheme-activities";
    String TASK_MANAGER_REPORT_DETAILS = API_URL + "report-task-manager-activities-list";

    //For Forgot Password
    String FORGOT_PASSWORD = API_URL + "forgot-password";
    String RESEND_OTP = API_URL + "resend-otp";
    String VALIDATE_OTP = API_URL + "validate-otp";
    String CHANGE_PASSWORD = API_URL + "change-password";

    //For Approve Attendance
    String APPROVE_ATTENDANCE = API_URL + "approve-attendance";
    String APPROVE_ATTENDANCE_SAVE = API_URL + "approve-attendance-save";
    String APPROVE_ATTENDANCE_USER_LIST = API_URL + "approve-list-of-lower-officers";
    String APPROVE_ATTENDANCE_MONTH_FILTER = API_URL + "approve-month-filter";
    String APPROVE_ATTENDANCE_DAYS_YEARWISE = API_URL + "approved-days-view-yearwise";

    //For Offline Task Manager
    String TASK_MANAGER_TYPES_OFFLINE_URL = API_URL + "offline-task-manager-types";
    String SCHEME_lIST_OFFLINE_URL = API_URL + "offline-task-manager-scheme-list";
    String SCHEME_lIST_ACTIVITY_OFFLINE_URL = API_URL + "offline-task-manager-scheme-activities";
    String TASK_MANAGER_SCHEME_WORK_OFFLINE_URL = API_URL + "offline-task-manager-scheme-work";
    String ADD_WORK_DETAILS_OFFLINE_URL = API_URL + "offline-task-manager-add-scheme-work";
    String ADD_WORK_DETAILS_IMAGE_OFFLINE_URL = API_URL + "offline-task-manager-add-scheme-work-image";


    //For Farmer Registration
    String FARMER_REGISTRAION_URL = API_URL + "farmer-registartion";
    String FARMER_DASHBOARD_URL = API_URL + "farmer-categories";
    String FARMER_MAGAZINE_URL = API_URL + "farmer-magazine-months";
    // Farmer Categories
    String FARMER_CATEGORIES_URL = API_URL + "farmer-magazine-categories";

    String FARMER_MAGAZINE_PDF_URL = API_URL + "farmer-magazine-get-pdf-by-month-year";
    String FARMER_VERIFY_MOBILE_NUMBER = API_URL + "farmer-registration-verify-mobile-no";
    String FARMER_VERIFY_OTP = API_URL + "farmer-registartion-verify-otp";

    //For Farmer Cropsap
    String FARMER_DISTRICT_URL = API_URL + "get-districts";
    String FARMER_TALUKA_URL = API_URL + "get-taluka-from-district";
    String FARMER_VILLAGE_URL = API_URL + "get-village-from-taluka";
    String FARMER_SEASONS_URL = API_URL + "seasons";
    String FARMER_CROP_SEASON_URL = API_URL + "get-crops-from-season";
    String FARMER_CROPSAP_SAVE_URL = API_URL + "farmer-save-cropsap";
    String FARMER_CROPSAP_UPLOAD_IMAGE_URL = API_URL + "farmer-cropsap-save-image";

    //For Farmer Punchnama
    String FARMER_PUNCHNAMA_YEAR_URL = API_URL + "panchnama-farmer-year";
    String FARMER_PUNCHNAMA_FARM_TYPE_URL = API_URL + "panchnama-farm-type";
    String FARMER_PUNCHNAMA_SCHEME_URL = API_URL + "panchnama-scheme";
    String FARMER_PUNCHNAMA_SEASON_URL = API_URL + "panchnama-season";
    String FARMER_PUNCHNAMA_CROP_TYPE_URL = API_URL + "panchnama-crop-type";
    String FARMER_PUNCHNAMA_CROP_LIST_URL = API_URL + "panchnama-crop-list";
    String FARMER_PUNCHNAMA_DAMAGE_TYPE_URL = API_URL + "panchnama-damage-type";
    String FARMER_PUNCHNAMA_DAMAGE_REASON_URL = API_URL + "panchnama-damage-reason";
    String FARMER_PUNCHNAMA_SAVE_URL = API_URL + "panchnama-farmer-save";
    String FARMER_PUNCHNAMA_SAVE_IMAGE_URL = API_URL + "panchnama-farmer-save-image";

    //For Department Punchnama
    String DEPT_PUNCHNAMA_TYPE_URL = API_URL + "panchnama-type";
    String DEPT_PUNCHNAMA_CLAIMS_URL = API_URL + "panchnama-list";
    String DEPT_PUNCHNAMA_SAVE_URL = API_URL + "panchnama-department-save";
    String DEPT_SELF_PUNCHNAMA_SAVE_URL = API_URL + "panchnama-login-department-save";
    String DEPT_SELF_PUNCHNAMA_SAVE_IMAGE_URL = API_URL + "panchnama-login-department-save-image";

    //For Department CropSap
    String FARMER_CROPSAP_DETAILS_FOR_DEPT_URL = API_URL + "department-login-list-of-farmers-based-on-cropsap";
    String DEPARTMENT_SAVE_CROPSAP_DETAILS_URL = API_URL + "department-login-save-cropsap";
    String DEPARTMENT_SAVE_CROPSAP_IMAGE_URL = API_URL + "department-login-save-cropsap_image";

    //Department Cropsap New
    String DEPARTMENT_CROPSAP_NEW_SEASON_URL = CROPSAP_NEW_BASE_URL + "session-list";
    String DEPARTMENT_CROPSAP_FARMER_LIST = CROPSAP_NEW_BASE_URL + "get-farmer";
    String DEPARTMENT_CROPSAP_FARMER_CROP_LIST = CROPSAP_NEW_BASE_URL + "get-farmer-crop-survey";
    String DEPARTMENT_PRE_CROPSAP_MASTER_FORM_SAVE = CROPSAP_NEW_BASE_URL + "pre-master-data";
    String DEPARTMENT_CROPSAP_NEW_CROPLIST_BASED_ON_SEASON_URL = CROPSAP_NEW_BASE_URL + "crop-list-based-session";
    String DEPARTMENT_CROPSAP_NEW_CROPVARIETY_BASED_ON_CROP_URL = CROPSAP_NEW_BASE_URL + "cropvariety-list-based-crop";
    String DEPARTMENT_CROPSAP_NEW_CROPGROWTH_BASED_ON_CROP_URL = CROPSAP_NEW_BASE_URL + "cropgrowth-list-based-crop";
    String DEPARTMENT_CROPSAP_NEW_CROPIRRIGATION_BASED_ON_CROP_URL = CROPSAP_NEW_BASE_URL + "cropirrigation-list-based-crop";
    String DEPARTMENT_CROPSAP_NEW_SOIL_TYPE_URL = CROPSAP_NEW_BASE_URL + "soil-type-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_CONDITION_URL = CROPSAP_NEW_BASE_URL + "crop-condition-list";
    String DEPARTMENT_CROPSAP_NEW_SOIL_MOISTURE_URL = CROPSAP_NEW_BASE_URL + "soil-moisture-list";
    String DEPARTMENT_CROPSAP_NEW_MINOR_PEST_URL = CROPSAP_NEW_BASE_URL + "minor-pest-list";
    String DEPARTMENT_CROPSAP_NEW_FARMER_LIST_URL = CROPSAP_NEW_BASE_URL + "fammer-list";
    String DEPARTMENT_CROPSAP_NEW_MASTER_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-sap-master-save";
    String DEPARTMENT_CROPSAP_NEW_MASTER_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-sap-master-img-save";

    //Department cropsap - crop = cotton
    String DEPARTMENT_CROPSAP_NEW_CROP_COTTON_PLANT_LIST = CROPSAP_NEW_BASE_URL + "plant-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_COTTON_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-cotton-save";
    String DEPARTMENT_CROPSAP_NEW_CROP_COTTON_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-cotton-save-image";
    //Cropsap Cotton crop last form
    String DEPARTMENT_CROPSAP_NEW_CROP_COTTON_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-cotton-save-ls-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_COTTON_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-cotton-last-step-save";

    //Department cropsap - crop = Sugarcane
    String DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SPOT_LIST = CROPSAP_NEW_BASE_URL + "spot-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-sugarcane-save";
    String DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-sugarcane-save-image";

    //Cropsap Sugarcane crop last form
    String DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-sugarcane-ls-save-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_SUGARCANE_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-sugarcane-last-step-save";

    //Department cropsap - crop = Pigeonpea
    String DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_PLANT_LIST = CROPSAP_NEW_BASE_URL + "pigeonpea-plant-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-pigeonpea-save-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-pigeonpea-save";

    //Cropsap Pigeonpea crop last form
    String DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-pigeonpea-save-ls-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_PIGEONPEA_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-pigeonpea-last-step-save";

    //Department cropsap - crop = Chickpeapea
    String DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_PLANT_LIST = CROPSAP_NEW_BASE_URL + "chickpea-spot-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-chikpea-save-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-chikpea-save";

    //Cropsap Chickpea crop last form
    String DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-chikpea-save-ls-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_CHICKPEA_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-chikpea-last-step-save";

    //Department cropsap - crop = Rice
    String DEPARTMENT_CROPSAP_NEW_CROP_RICE_SPOT_LIST = CROPSAP_NEW_BASE_URL + "rice-squre-meter-list";

    //For Department Demonstration
    String DEPARTMENT_DEMON_PURPOSE_URL = API_URL + "demonstration-list-of-purpose";
    String DEPARTMENT_DEMON_INPUT_URL = API_URL + "demonstration-list-of-input";
    String DEPARTMENT_DEMON_LIMIT_URL = API_URL + "demonstration-list-of-limit";
    String DEPARTMENT_DEMON_UNIT_URL = API_URL + "demonstration-list-of-unit";
    String DEPARTMENT_DEMON_SAVE_MASTER_STEP_ONE_URL = API_URL + "demonstration-step1-save-master-configuration";
    String DEPARTMENT_DEMON_EDIT_MASTER_STEP_ONE_URL = API_URL + "demonstration-step1-edit-master-configuration";
    String DEPARTMENT_DEMON_SAVE_MASTER_STEP_TWO_URL = API_URL + "demonstration-step2-save";

    //Farmer CropSap History
    String FARMER_CROPSAP_HISTORY_COUNT = API_URL + "farmer-cropsap-total-count";
    String FARNER_CROPSAP_HISTORY_CROP_LIST_COUNT = API_URL + "farmer-cropsap-crop-list-with-count";
    String FARNER_CROPSAP_HISTORY_BASED_ON_CROP = API_URL + "farmer-cropsap-list-based_on_crop";

    //Farmer CropSap History
    String DEPARTMENT_CROPSAP_HISTORY_COUNT = API_URL + "department-login-cropsap-total-count";
    String DEPARTMENT_CROPSAP_HISTORY_CROP_LIST_COUNT = API_URL + "department-login-cropsap-crop-list-with-count";
    String DEPARTMENT_CROPSAP_HISTORY_BASED_ON_CROP = API_URL + "department-login-cropsap-list-based_on_crop";
    String DEPARTMENT_LOGIN_FARMER_CROPSAP_HISTORY_COUNT = API_URL + "department-cropsap-total-count";

    //Farmer Punchnama History
    String FARMER_PUNCHNAMA_HISTORY_COUNT = API_URL + "farmer-panchnama-total-count";
    String FARMER_PUNCHNAMA_CROP_LIST_WITH_COUNT = API_URL + "farmer-panchnama-crop-list-with-count";
    String FARMER_PUNCHNAMA_LIST_BASED_ON_CROP = API_URL + "farmer-panchnama-list-based-on-crop";

    //Department Punchnama History
    String DEPARTMENT_PUNCHNAMA_HISTORY_COUNT = API_URL + "department-login-panchnama-total-count";
    String DEPARTMENT_PUNCHNAMA_HISTORY_CROP_LIST_COUNT = API_URL + "department-login-panchnama-crop-list-with-count";
    String DEPARTMENT_PUNCHNAMA_LIST_BASED_ON_CROP = API_URL + "department-login-panchnama-list-based-on-crop";

    //Department Work Location
    String DEPARTMENT_LOGIN_GET_DISTRICT_TALUKA = API_URL + "department-login-get-district-taluka";
    String DEPARTMENT_LOGIN_GET_VILLAGES = MASTER_API_URL + "get-village-list-app";

    //Primary Report Save
    String PRIMARY_REPORT_VILLAGE_WISE_CROP_DATA = MASTER_API_URL + "get-p-report";
    String PRIMARY_REPORT_SAVE = API_URL + "department-panchnama-primary-report-save";

    //fOR MB Recording
    String MB_SOIL_REPORT_LIST = MB_RECORDING_BASE_URL + "MBrecording-step-list";
    String FARMER_LIST_MB_RECORDING = MB_RECORDING_BASE_URL + "get-farmer-list";
    String SCHEME_MB_RECORDING = MB_RECORDING_BASE_URL + "mbrecording-scheme";
    String FARMER_REGISTRATION_MB_RECORDING = MB_RECORDING_BASE_URL + "MBrecording-farmer-registration";
    String SOIL_REGISTRATION_MB_RECORDING = MB_RECORDING_BASE_URL + "MBrecording-step-save";
    String IMAGE_MB_RECORDING = MB_RECORDING_BASE_URL + "farmer-mbrecord-save-image";
    String COMPONENT_LIST = MB_RECORDING_BASE_URL + "MBrecording-construction-list";

    //MB Recording BFFLY
    String MB_RECORDING_BFFLY_FRUITS = MB_RECORDING_BASE_URL + "mbrecording-bffly-fruits";
    String MB_RECORDING_BFFLY_YEARS = MB_RECORDING_BASE_URL + "mbrecording-bffly-years";
    String MB_RECORDING_BFFLY_FORM1_SAVE = MB_RECORDING_BASE_URL + "mbrecording-bffly-form1-save";
    String MB_RECORDING_BFFLY_FORM2_SAVE = MB_RECORDING_BASE_URL + "mbrecording-bffly-form-2";
    String MB_RECORDING_BFFLY_FORM2_IS_COMPLETED = MB_RECORDING_BASE_URL + "mbrecording-bffly-form-check-iscompleted";
    String MB_RECORDING_BFFLY_FORM3_SAVE = MB_RECORDING_BASE_URL + "mbrecording-bffly-form-3-save";
    String MB_RECORDING_BFFLY_FORM4_SAVE = MB_RECORDING_BASE_URL + "mbrecording-bffly-form-4-save";
    String MB_RECORDING_BFFLY_FORM5_SAVE = MB_RECORDING_BASE_URL + "mbrecording-bffly-form-5-save";

    //sprinkler list
    String SPRINKLER_LIST = SV_MECHANIZATION_BASE_URL + "sprinkler-list";
    String SPRINKLE_SAVE = SV_MECHANIZATION_BASE_URL + "sprinkler-save-data";

    //Primary Report History
    String PRIMARY_REPORT_TOTAL_COUNT_ = API_URL + "department-panchnama-primary-report-count";
    String PRIMARY_REPORT_COUNT_AGAINST_VILLAGE_SAVE = API_URL + "department-panchnama-primary-report-list";
    String PRIMARY_REPORT_DETAILS = API_URL + "department-panchnama-primary-report-details";

    //Final Report
    String DEPARTMENT_PUNCHNAMA_FINAL_REPORT_LIST = API_URL + "department-panchnama-final-report-list";
    String DEPARTMENT_PUNCHNAMA_FINAL_REPORT_PDF = REPORT_API_URL + "get-pdf-report";

    // String kCrops = "farmService/crops";
    // String kCrops = "get-demo-crop-list"; // For Demo crop list
    // String kCrops = "masterService/get-crop-master-list"; // For Master crop list
    String kCrops = "masterService/get-crop-by-sole-id"; // For Master crop list

    // To add Demo or FFS Plan
    String kPlanAreaUrl = BASE_API + "kdpService/demonstrationcellingamt-list";
    String kPlanUrl = BASE_API + "kdpService/demonstrationffs-plan";
    String kPlanListUrl = BASE_API + "kdpService/demonstrationffs-planlist";

    // For Host farmer registration
    String kDemoSchemeList = BASE_API + "cmsCropmaster/crop-s-list";
    String kHostFarmerRegistration = BASE_API + "kdpService/demonstrationffs-hostfarmer";
    String kHostFarmerList = "farmer-demonstration-or-ffs-list";
    String kHostFarmerUpdate = "facilitatorService/host-farmer-edit-save";
    String kCropsVerity = "get-variety-list";
    String kCropsVerityById = "get-cropvariety-from-crop-id";

    // For guest farmer reg
    String kGuestRegistration = BASE_API + "kdpService/demonstrationffs-guestfarmer";
    String kGuestFarmerList = "gest-farmer-list";

    // demonstrationffs-plan
    // FOR FFS
    // get-season-list-on-activity-id
    String kVillagePlot = "facilitatorService/villages-plot-of-facilitator";
    String kHostFarmerEditList = "facilitatorService/host-farmer-list-for-edit";
    String kSocialCat = BASE_API + "userService/social-categories";
    String kIrrigation = BASE_API + "farmService/sources-of-irrigation";
    String kSoilTypes = BASE_API + "farmService/soil-types";
    String kUpdateGuestFarmer = "facilitatorService/guest-farmer-edit-save";

    // For Shedule Detail
    String kSchedules = "get-schedule-visit-list";

    //For Crop Sowing Report
    String CROP_SOWING_REPORT_CROP_TYPE = API_URL + "crop-type-sown-master-list";
    String CROP_SOWING_REPORT_CROP_TYPE_SOWN_SUB_LIST = API_URL + "crop-type-sown-sub-list";
    String CROP_SOWING_REPORT_FIELD_CROP_TYPE_SOWN_LIST = BASE_API + "masterService/field-crop-sown-sub-list";
    String CROP_SOWING_REPORT_VILLAGE_WISE_CROP_DATA = MASTER_API_URL + "get-cs-report";
    String CROP_SOWING_REPORT_SUBMIT = API_URL + "crop-sowning-reports";
    String CROP_SOWING_REPORT_AREA_CALCULATION = API_URL + "get-crop-calculated-area-value";
    String CROP_SOWING_REPORT_METEOROLOGICAL_WEEK = API_URL + "crop-sowning-reports-metrological-week";
    String CROP_SOWING_REPORT_GEO_CUL_AREA = API_URL + "get-cropsowing-village-mapping-area";
    String CROP_SOWING_SEASON_SOWN_AREA = API_URL + "get-season-sown-area";

    //Crop Sowing Report History
    String CROP_SOWING_REPORT_HISTORY_METEROLOGICAL_WEEK = API_URL + "get-crop-sowning-reports-metrological";
    String CROP_SOWING_REPORT_VILLAGE_HISTORY_COUNT = API_URL + "get-crop-village-crop-count-week";
    String CROP_SOWING_REPORT_HISTORY_LIST = API_URL + "department-showing-report-list";
    String CROP_SOWING_REPORT_HISTORY_DETAILS = API_URL + "get-total-cropsowing-details-week-village-userid";

    //Consolidate Report
    String CONSOLIDATE_REPORT_SAVE = API_URL + "consolidated-report-save";
    String CONSOLIDATE_REPORT_IMG_SAVE = API_URL + "consolidated-report-image-save";

    // For Crop Sowing farmer Report
    String CROP_SOWING_REPORT_CROP_TYPE_SOWN_SUB_CROP_LIST = API_URL + "crop-type-sown-sub-crop-list";
    String CROP_SOWING_REPORT_FARMER_YEAR_OF_PLATATION = API_URL + "year-list";
    String CROP_SOWING_REPORT_FARMER_SCHEME_NAMES = API_URL + "csr-scheme";

    // Farmer SAVE
    String FARMER_REPORT_SAVE = API_URL + "csr-farmerwise-report-save";
    String FARMER_REPORT_IMG_SAVE = API_URL + "csr-farmerwise-image-save";

    //For Physical Verification
    String PHYSICAL_VERIFICATION_FARMER_LIST = MB_RECORDING_BASE_URL + "get-farmer-list";
    String PHYSICAL_VERIFICATION_COMPONENT_LIST = SV_MECHANIZATION_BASE_URL + "get-pv-scheme-title";
    String PHYSICAL_VERIFICATION_SCHEME_LIST = SV_MECHANIZATION_BASE_URL + "get-pv-scheme-name";
    String PHYSICAL_VERIFICATION_ASSIGN_FARMER_LIST = CROPSAP_NEW_BASE_URL + "get-new-farmer-list";
    String PHYSICAL_VERIFICATION_FORM_LIST = SV_MECHANIZATION_BASE_URL + "get-tile-form";
    String PHYSICAL_VERIFICATION_MANUFACTURE_LIST = API_URL + "get-manufacture-list-filterby-district";
    String PHYSICAL_VERIFICATION_DEALER_LIST = API_URL + "get-dealer-list-filterby";

    //Spot Verification drip
    String SPOT_VERIFICATION_DRIP_FETCH_DATA = SV_MECHANIZATION_BASE_URL + "drip-list";
    String SPOT_VERIFICATION_ITEM_LIST = API_URL + "get-item-list-product-type";
    String SPOT_VERIFICATION_DESC_LIST = API_URL + "get-comp-item-list";
    String SPOT_VERIFICATION_RATE_LIST = API_URL + "get-item-rate-list-filterby";
    String SPOT_VERIFICATION_DRIP_SYSTEM_TYPE = SPOT_VERIFICATION_URL + "system-type";
    String SPOT_VERIFICATION_DRIP_SPACING = SPOT_VERIFICATION_URL + "spacing";
    String SPOT_VERIFICATION_DRIP_FORM_SAVE = SPOT_VERIFICATION_URL + "drill-pre-data-save";
    String SPOT_VERIFICATION_DRIP_LISTING_DATA = SV_MECHANIZATION_BASE_URL + "drip-bill-list";
    String SPOT_VERIFICATION_DRIP_BILL_AGAINST_ID_DATA = SV_MECHANIZATION_BASE_URL + "drip-bill-list-against-id";
    String DRIP_FETCH_DETAILS = SV_MECHANIZATION_BASE_URL + "drip-bill-list-against-id";
    String SPOT_VERIFICATION_DRIP_BILL_AGAINST_ID_SAVE_DATA = PHY_VERI_URL + "ds_form_save";
    String SPOT_VERIFICATION_DRIP_BILL_LIST_SAVE = SV_MECHANIZATION_BASE_URL + "dripBillSaveList";
    //Spot Verification sprinkler
    String SPOT_VERIFICATION_SPRINKLER_TYPE_LIST = SPOT_VERIFICATION_URL + "get-sprinkler-type-list";
    String SPOT_VERIFICATION_SPRINKLER_TYPE_SPACING = SPOT_VERIFICATION_URL + "get-sprinkler-type-spacing";
    String SPOT_VERIFICATION_SPRINKLER_LISTING_DATA = SV_MECHANIZATION_BASE_URL + "sprinkler-bill-list";
    String SPRINKLER_FETCH_DETAILS = SV_MECHANIZATION_BASE_URL + "sprinkler-bill-list-against-id";
    String SPOT_VERIFICATION_SPRINKLER_BILL_AGAINST_ID_SAVE_DATA = SV_MECHANIZATION_BASE_URL + "sprinkler-bill-save-against-id ";
    String SPOT_VERIFICATION_SPRINKLER_BILL_LIST_SAVE = SV_MECHANIZATION_BASE_URL + "sprinklerBillSaveList";
    String PLANTATION_LIST = SPOT_VERIFICATION_URL + "plantation-list";
    String PLANTATION_SAVE = SPOT_VERIFICATION_URL + "plantation-save";
    String REJUVENATION_SAVE = SPOT_VERIFICATION_URL + "rejuvenation-save";
    String MECH_MIDH_SAVE = SPOT_VERIFICATION_URL + "mechanism-save-midhScheme";
    String MECH_MIDH_IMG_SAVE = SPOT_VERIFICATION_URL + "mechanism-save-image-by-midhScheme";
    String MB_COMMUNITY_FARM_POND_LIST = SPOT_VERIFICATION_URL + "mb-community-pond-list";
    String MB_COMMUNITY_FARM_POND_SAVE = SPOT_VERIFICATION_URL + "mb-community-pond";
    String MB_COMMUNITY_FARM_POND_IS_COMPLETED = SPOT_VERIFICATION_URL + "mbcommunity-pond-form-check-iscompleted";
    String MB_COMMUNITY_POND_8 = SPOT_VERIFICATION_URL + "mb-community-pond-8-save";
    String MB_COMMUNITY_POND_9 = SPOT_VERIFICATION_URL + "mb-community-pond-9-save";
    String MB_COMMUNITY_POND_9_IMAGE = SPOT_VERIFICATION_URL + "mb-community-pond-9-img";
    String MB_FARMER_POND = SPOT_VERIFICATION_URL + "mb-farmer-pond-save";
    String MB_FARMER_POND_IMAGE = SPOT_VERIFICATION_URL + "mb-farmer-pond-img";


    // For Pre showing
    String kPreShowingVisit = "pre-showing-visit";
    String kPreShowingImg_Upload = "upload-activity-img";
    String kPreShowingDetailInsert = "pre-showing-details-insert";
    String kShowingDetailInsert = "save-sowing-visit";
    String kGetShowingDetail = "get-sowing-visit";

    //Demonstration Technology
    String DEMO_TECHNOLOGY_IMAGES = API_URL + "upload-technology-demo-img";
    String DEMO_PACKAGE = API_URL + "demonstrationpackage";
    String DEMO_INPUT_TECHNOLOGY = API_URL + "demonstration-input-list";
    String DEMO_MASTER_PACKAGE_DETAIL = API_URL + "DemonstrationMasterPackageDetail";

    //Demonstration AESA
    String DEMO_AESA_BIOLOGICAL_PEST = API_URL + "get-pest-list";
    String DEMO_AESA_METHOD_OF_SOWING = API_URL + "get-methodOfSowing-list";
    String DEMO_AESA_BIOLOGICAL_DEFENDER = API_URL + "get-defender-list";
    String DEMO_AESA_DISEASE_TYPE = API_URL + "get-crop-disease";
    String DEMO_AESA_DISEASE_SEVERITY = API_URL + "get-disease-type-severity";
    String DEMO_AESA_SOIL_CONDITION = API_URL + "get-soil-condition";
    String DEMO_AESA_WEATHER_CONDITION = API_URL + "get-weather-condition";
    String DEMO_AESA_WEED_TYPE_INTENSITY = API_URL + "get-weeds-type-intensity";
    String DEMO_AESA_WIND_CONDITION = API_URL + "get-wind-condition";
    String DEMO_AESA_RODENT_DAMAGE = API_URL + "get-rodent-damage";
    String DEMO_AESA_IRRIGATION_METHOD = API_URL + "get-irrigationMethod-list";

    //Demonstration Attendance
    String GUEST_FARMER_LIST = API_URL + "gest-farmer-list";
    String GET_FARMER_LIST = API_URL + "farmer-list";

    String DEMO_ATTENDANCE_SAVE = API_URL + "demo-attendance-save";

    // To add FFS DATA
    String kD_F_EVENT_SAVE = "visit-input-save";

    // FFS Technology
    String kFFS_TECH_LIST = "get-techDemos-against-crop";

    // FFS Observation
    String kIRRIGATION_LIST = "get-irrigationMethod-list";
    String kSHOWING_LIST = "get-methodOfSowing-list";
    String kPEST_LIST = "get-pest-list";
    String kDEFENDER_LIST = "get-defender-list";
    String kCROP_VERITY_LIST = "get-variety-list";
    String kDISEASE_LIST = "get-crop-disease";
    String kDISEASE_SEVERITY_LIST = "get-disease-type-severity";
    String kRODANT_DAMAGE_LIST = "get-rodent-damage";
    String kSOIL_CONDITION_LIST = "get-soil-condition";
    String kWEATHER_LIST = "get-weather-condition";
    String kWEED_TYPE_LIST = "get-weeds-type-intensity";
    String kWIND_CONDITION_LIST = "get-wind-condition";
    String kRAIN_CONDITION_LIST = "get-rainfall-condition";

    // String kRAIN_FAIL_LIST = "get-techDemos-against-crop";

    //Sorghum S O R G H U M
    // GET PLANT LIST
    String dept_cropsap_sorghum_plant_list = CROPSAP_NEW_BASE_URL + "sorghum-plant-list";

    // SAVE data
    String dept_cropsap_sorghum_plant_save = CROPSAP_NEW_BASE_URL + "crop-sorghum-save";

    // SAVE IMAGE
    String dept_cropsap_sorghum_plant_saveimage = CROPSAP_NEW_BASE_URL + "crop-sorghum-save-image";

    // Last form
    String DEPARTMENT_CROPSAP_NEW_CROP_SORGHUM_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-sorghum-ls-save-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_SORGHUM_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-sorghum-last-step-save";


    //Maize M A I Z E
    // GET PLANT LIST
    String dept_cropsap_maize_spot_list = CROPSAP_NEW_BASE_URL + "maize-plant-list";

    // SAVE data
    String dept_cropsap_maize_spot_save = CROPSAP_NEW_BASE_URL + "crop-maize-save";

    // SAVE IMAGE
    String dept_cropsap_maize_spot_saveimage = CROPSAP_NEW_BASE_URL + "crop-maize-save-image";
    // Last form
    String DEPARTMENT_CROPSAP_NEW_CROP_MAIZE_LAST_FORM_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-maize-save-ls-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_MAIZE_LAST_FORM_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-maize-last-step-save";

    //  S O Y A B E A N
    //                                    L i s t
    String DEPT_CROPSAP_SOYABEAN_SPOT_LIST = CROPSAP_NEW_BASE_URL + "soybean-spot-list";

    //                                    SAVE DATA
    String DEPT_CROPSAP_SOYABEAN_SPOT_DATA = CROPSAP_NEW_BASE_URL + "crop-sap-add-major-minor-data";

    //                                    SAVE IMAGE
    String DEPT_CROPSAP_SOYABEAN_SPOT_SAVEIMAGE = CROPSAP_NEW_BASE_URL + "crop-sap-upload-major-minor-img";


    //Spot Verificiation- Farmer Mechnization
    String SPOT_FARMER_MECH_IMAGE_SAVE = SV_MECHANIZATION_BASE_URL + "mechanism-save-image";
    String SPOT_FARMER_MECH_SAVE = SV_MECHANIZATION_BASE_URL + "mechanism-master-save";
    String SPOT_GET_FARMER_MECH_DETAILS = SV_MECHANIZATION_BASE_URL + "mechanism-list";

    //Customer Hiring Center
    String SPOT_CUSTOMER_HIRING_CENTER_SAVE_IMAGE = SV_MECHANIZATION_BASE_URL + "customer-hiring-save-image";
    String SPOT_CUSTOMER_HIRING_CENTER_SAVE_DETAILS = SV_MECHANIZATION_BASE_URL + "customer-hiring-save-form";

    //Department cropsap - crop = Soyabean
    String DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_PLANT_LIST = CROPSAP_NEW_BASE_URL + "soybean-spot-list";
    String DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_SAVE_IMAGE_URL = CROPSAP_NEW_BASE_URL + "crop-soybean-save-ls-image";
    String DEPARTMENT_CROPSAP_NEW_CROP_SOYABEAN_SAVE_URL = CROPSAP_NEW_BASE_URL + "crop-soybean-last-step-save";

    //Physical verification - WBCIS
    String PHY_VERI_YEAR_URL = PHY_VERI_URL + "get-year-list";
    String PHY_VERI_DISTRICT_URL = PHY_VERI_URL + "get-district-list";
    String PHY_VERI_TALUKA_URL = PHY_VERI_URL + "get-taluka-list";
    String PHY_VERI_REVENUE_URL = PHY_VERI_URL + "get-rc-list";
    String PHY_VERI_GRAM_PANCHAYAT_URL = PHY_VERI_URL + "get-gp-list";
    String PHY_VERI_VILLAGE_URL = PHY_VERI_URL + "get-village-list";
    String PHY_VERI_SEASON_URL = PHY_VERI_URL + "get-season-list";
    String PHY_VERI_CROP_URL = PHY_VERI_URL + "get-crop-list";
    String PHY_VERI_SAVE_URL = PHY_VERI_URL + "save-form-data";
    String PHY_VERI_SAVE_IMAGE_URL = PHY_VERI_URL + "save-image";

    //Orchard Mapping
    String ORCHARD_MAPPING_SAVE = ORCHARD_MAPPING_URL + "orchard-mapping-save";
    String ORCHARD_MAPPING_SAVE_IMG = ORCHARD_MAPPING_URL + "orchard-mapping-save-image";
    String ORCHARD_MAPPING_DISTRICT_TALUKA = PHY_VERI_URL + "login-get-district-taluka";
    String ORCHARD_SURVEY_LIST_URL = ORCHARD_MAPPING_URL + "orchard-mapping-survey-list";
    String REMOVE_ORCHARD_SURVEY_FROM_LIST_URL = ORCHARD_MAPPING_URL + "remove-orchard-mapping-survey";
    String ORCHARD_MOBILE_EXISTS = ORCHARD_MAPPING_URL + "orchard_mobile_exists";


    //Village Mapping Area
    String VILLAGE_MAPPING_AREA_SAVE = API_URL + "village-mapping-area-cropsowing";
    String VILLAGE_MAPPING_AREA_GET_FILLED_DATA = API_URL + "get-village-mapping-area-cropsowing";

    //Assigned Charge
    String ASSIGNED_CHARGE = API_URL + "get-user-charge";
    String ASSIGNED_LOCATION_CHARGE = MASTER_API_URL + "get-location-charge";
    String ASSIGNED_SAJJA_LIST = MASTER_API_URL + "get-sajja-location";
    String ASSIGNED_VILLAGE_LIST = MASTER_API_URL + "get-village-location";
    String ADDITIONAL_CHARGE_VILLAGE_LIST = MASTER_API_URL + "get-village-list-additional-charge";


    String UPDATE_APP_NEW = API_URL + "get-app";
    //  http://uatmahakrushi.mahaitgov.in/v19/kdpService/get-app


}
