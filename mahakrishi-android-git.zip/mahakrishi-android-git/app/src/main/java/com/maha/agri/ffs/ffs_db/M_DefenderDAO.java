/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_DefenderDAO {

    @Query("SELECT * FROM M_DefenderEY")
    List<M_DefenderEY> getAll();

    @Query("SELECT * FROM M_DefenderEY WHERE pest_id = :pestId")
    List<M_DefenderEY> getDefenders(int pestId);


    @Query("SELECT * FROM M_DefenderEY WHERE uid IN (:userIds)")
    List<M_DefenderEY> loadAllByIds(int[] userIds);

    @Insert
    void insertAll(M_DefenderEY... mDefenderEYS);

    @Insert
    void insertOnlySingle(M_DefenderEY mDefenderEY);

}
