package com.maha.agri.dept_cropsap;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.maha.agri.R;

public class CropSapAddFarmerSurveyActivity extends AppCompatActivity {
    private Button cropsap_addfarmer_btn,cropsap_farmer_survey_list_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap_add_farmer_survey);
        getSupportActionBar().setTitle("CROPSAP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        cropsap_addfarmer_btn = (Button) findViewById(R.id.cropsap_addfarmer_btn);
        cropsap_farmer_survey_list_btn = (Button) findViewById(R.id.cropsap_farmer_survey_list_btn);

        cropsap_addfarmer_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CropSapAddFarmerSurveyActivity.this,CropSapActivityNew.class);
                startActivity(intent);
            }
        });

        cropsap_farmer_survey_list_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CropSapAddFarmerSurveyActivity.this,CropSapFarmerSelection.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
