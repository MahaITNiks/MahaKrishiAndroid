package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class PigeonpeaSerial1 extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView crop_plant_pigeonpeatv,pigeonpea_major_pest,pigeonpea_minor_pest,pigeonpea_generic_tv;
    private LinearLayout pigeonpea_generic_ll;
    private EditText pigeonpea_generic_et,pigeonpea_defender_et;
    private ImageView pigeonpea_generic_photo;
    private Button btn_save_continue_pigeonpea,btn_add_pest_details_pigeonpea;
    private TableLayout add_pest_titleTableLayout_pigeonpea;
    private RecyclerView add_more_pest_rv_pigeonpea;
    private SweetAlertDialog sweetAlertDialog;

    private int count = 1,generic_int;
    private int crop_cond_id = 0;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private int crop_id = 0;
    private int selected_pest_id = 0;

    private int district_id, taluka_id, village_id, farmer_id;
    private String pigeonpea_crop_name,pest_name="";
    private JSONArray pigeonpea_crop_plant_list,pigeonpea_major_pest_list,pigeonpea_minor_pest_list;
    private int crop_pigeonpea_plant_id = 0;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private String imagePath1 = "";
    private String image_1_file_name = "";
    private AppLocationManager locationManager;
    public double lat,lang;
    private String type = "",generic_et_str="",def_str="";

    private ArrayList<String> pest_list_names_pigeonpea=new ArrayList<String>();
    private ArrayList<LinearLayout> pest_list_layout_pigeonpea=new ArrayList<LinearLayout>();
    private ArrayList<EditText> pest_list_et_pigeonpea=new ArrayList<EditText>();
    private boolean flag=false;

    private JSONArray pest_details_json_array = new JSONArray();

    JSONObject pod_borer_pest_json_obj = new JSONObject();
    JSONObject plume_moth_pest_json_obj = new JSONObject();
    JSONObject pod_fly_pest_json_obj = new JSONObject();
    JSONObject spotted_pod_pest_json_obj = new JSONObject();
    JSONObject pod_bug_pest_json_obj = new JSONObject();
    JSONObject stem_weevil_pest_json_obj = new JSONObject();
    JSONObject blister_beetle_pest_json_obj = new JSONObject();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_pigeonpea);
        preferenceManager = new PreferenceManager(PigeonpeaSerial1.this);
        sharedPref = new SharedPref(PigeonpeaSerial1.this);
        locationManager = new AppLocationManager(this);
        getSupportActionBar().setTitle("Pest Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ids();
        initialization();

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        crop_cond_id = intent.getIntExtra("crop_cond",0);
        crop_growth_id = intent.getIntExtra("crop_growth_id",0);
        soil_moisture_id = intent.getIntExtra("soil_moisture_id",0);
        lat = locationManager.getLatitude();
        lang = locationManager.getLongitude();

    }

    private void ids() {
        //Textview
        crop_plant_pigeonpeatv = (TextView) findViewById(R.id.dept_cropsap_plant_pigeonpeatv);
        pigeonpea_major_pest = (TextView) findViewById(R.id.pigeonpea_major_pest);
        pigeonpea_minor_pest = (TextView) findViewById(R.id.pigeonpea_minor_pest);
        pigeonpea_generic_tv = (TextView) findViewById(R.id.pigeonpea_generic_tv);
        crop_plant_pigeonpeatv.setEnabled(false);
        //Edittext
        pigeonpea_generic_et = (EditText) findViewById(R.id.pigeonpea_generic_et);
        pigeonpea_defender_et = (EditText) findViewById(R.id.pigeonpea_defender_et);
        //Imageview
        pigeonpea_generic_photo = (ImageView) findViewById(R.id.pigeonpea_generic_photo);
        //LL
        pigeonpea_generic_ll = (LinearLayout) findViewById(R.id.pigeonpea_generic_ll);
        add_more_pest_rv_pigeonpea = (RecyclerView) findViewById(R.id.add_more_pest_rv_pigeonpea);
        add_pest_titleTableLayout_pigeonpea = (TableLayout) findViewById(R.id.add_pest_titleTableLayout_pigeonpea);
        //Button
        btn_save_continue_pigeonpea = (Button)findViewById(R.id.btn_save_continue_pigeonpea);
        btn_add_pest_details_pigeonpea = (Button)findViewById(R.id.btn_add_pest_details_pigeonpea);

        pigeonpea_crop_plant_list = new JSONArray();
        pigeonpea_major_pest_list = new JSONArray();
        pigeonpea_minor_pest_list = new JSONArray();

        pigeonpea_plant_list();
        major_pest_service();
        minor_pest_service();
        zero_pest_input();
    }

    private void initialization(){

        crop_plant_pigeonpeatv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pigeonpea_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(pigeonpea_crop_plant_list, 1, "Select Plant", "plant_name", "plant_id", PigeonpeaSerial1.this, PigeonpeaSerial1.this);
                }
            }
        });

        pigeonpea_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pigeonpea_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(pigeonpea_major_pest_list, 2, "Select Major Pest", "pest_eng_name", "id", PigeonpeaSerial1.this, PigeonpeaSerial1.this);
                }else{
                    major_pest_service();
                }
            }
        });

        pigeonpea_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pigeonpea_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(pigeonpea_minor_pest_list, 3, "Select Minor Pest", "pest_eng_name", "id", PigeonpeaSerial1.this, PigeonpeaSerial1.this);
                }else{
                    minor_pest_service();
                }
            }
        });

        pigeonpea_generic_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(PigeonpeaSerial1.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(PigeonpeaSerial1.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(PigeonpeaSerial1.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(PigeonpeaSerial1.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_add_pest_details_pigeonpea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generic_et_str = pigeonpea_generic_et.getText().toString().trim();

                if(pest_name.equalsIgnoreCase("POD BORER") || pest_name.equalsIgnoreCase("PLUME MOTH")
                        || pest_name.equalsIgnoreCase("POD FLY") || pest_name.equalsIgnoreCase("SPOTTED POD BORER (LEAVES + FLOWER WEBBING)")
                        || pest_name.equalsIgnoreCase("POD BUG") || pest_name.equalsIgnoreCase("STEM WEEVIL")
                        || pest_name.equalsIgnoreCase("BLISTER BEETLE")){
                    if(generic_et_str.equalsIgnoreCase("")){
                        Toast.makeText(PigeonpeaSerial1.this,"Enter the number of pest present ",Toast.LENGTH_SHORT).show();
                    }else if(photoFile1 == null){
                        Toast.makeText(PigeonpeaSerial1.this,"Click photo of the pest",Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImageOnServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else{

                }
            }
        });

        btn_save_continue_pigeonpea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                def_str = pigeonpea_defender_et.getText().toString().trim();
                if(pest_details_json_array.toString().contains("POD BORER") &&
                        pest_details_json_array.toString().contains("PLUME MOTH") &&
                        pest_details_json_array.toString().contains("POD FLY") &&
                        pest_details_json_array.toString().contains("SPOTTED POD BORER (LEAVES + FLOWER WEBBING)")) {
                if(pest_details_json_array.length()>0) {

                    if (def_str.equalsIgnoreCase("")) {
                        Toast.makeText(PigeonpeaSerial1.this, "Enter total defenders", Toast.LENGTH_SHORT).show();
                    } else {
                        save_pigeonpea_data();
                    }
                }else{
                    sweetAlertDialog = new SweetAlertDialog(PigeonpeaSerial1.this, SweetAlertDialog.WARNING_TYPE);
                    sweetAlertDialog.setContentText("Enter data for all major pests");
                    sweetAlertDialog.setConfirmText("OK");
                    sweetAlertDialog.setCanceledOnTouchOutside(false);
                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                        }
                    }).show();
                }
                }else {
                    final Toast toast = Toast.makeText(PigeonpeaSerial1.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 0);
                }
            }
        });
    }

    private void zero_pest_input(){
        pigeonpea_generic_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                generic_et_str = pigeonpea_generic_et.getText().toString().trim();
                if(!generic_et_str.equalsIgnoreCase("")){
                    generic_int = Integer.parseInt(generic_et_str);
                    if(generic_int == 0){
                        pigeonpea_generic_photo.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        pigeonpea_generic_photo.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
                photoFile1 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");
                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pigeonpea_generic_photo.getWidth(), pigeonpea_generic_photo.getHeight())
                                    .centerCrop()
                                    .into(pigeonpea_generic_photo);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
    }

    private void pigeonpea_plant_list() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.pigeonpea_plant_list();
        api.postRequest(responseCall, this, 1);
    }

    private void major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void uploadImageOnServer() {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;
            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void add_pest_details(int sel_pest_id,String pest_name){

        try {
            if(pest_name.equalsIgnoreCase("POD BORER")) {
                pod_borer_pest_json_obj.put("pest_id", sel_pest_id);
                pod_borer_pest_json_obj.put("pest_name", pest_name);
                pod_borer_pest_json_obj.put("pod_borer_pest_no", pigeonpea_generic_et.getText().toString().trim());
                pod_borer_pest_json_obj.put("pod_borer_pest_pic", image_1_file_name);
                pod_borer_pest_json_obj.put("lat", String.valueOf(lat));
                pod_borer_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(pod_borer_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("PLUME MOTH")) {
                plume_moth_pest_json_obj.put("pest_id", sel_pest_id);
                plume_moth_pest_json_obj.put("pest_name", pest_name);
                plume_moth_pest_json_obj.put("plume_moth_pest_no", pigeonpea_generic_et.getText().toString().trim());
                plume_moth_pest_json_obj.put("plume_moth_pest_pic", image_1_file_name);
                plume_moth_pest_json_obj.put("lat", String.valueOf(lat));
                plume_moth_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(plume_moth_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("POD FLY")) {
                pod_fly_pest_json_obj.put("pest_id", sel_pest_id);
                pod_fly_pest_json_obj.put("pest_name", pest_name);
                pod_fly_pest_json_obj.put("pod_fly_pest_no", pigeonpea_generic_et.getText().toString().trim());
                pod_fly_pest_json_obj.put("pod_fly_pest_pic", image_1_file_name);
                pod_fly_pest_json_obj.put("lat", String.valueOf(lat));
                pod_fly_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(pod_fly_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("SPOTTED POD BORER (LEAVES + FLOWER WEBBING)")) {
                spotted_pod_pest_json_obj.put("pest_id", sel_pest_id);
                spotted_pod_pest_json_obj.put("pest_name", pest_name);
                spotted_pod_pest_json_obj.put("spotted_pod_pest_no", pigeonpea_generic_et.getText().toString().trim());
                spotted_pod_pest_json_obj.put("spotted_pod_pest_pic", image_1_file_name);
                spotted_pod_pest_json_obj.put("lat", String.valueOf(lat));
                spotted_pod_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(spotted_pod_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("POD BUG")) {
                pod_bug_pest_json_obj.put("pest_id", sel_pest_id);
                pod_bug_pest_json_obj.put("pest_name", pest_name);
                pod_bug_pest_json_obj.put("pod_bug_pest_no", pigeonpea_generic_et.getText().toString().trim());
                pod_bug_pest_json_obj.put("pod_bug_pest_pic", image_1_file_name);
                pod_bug_pest_json_obj.put("lat", String.valueOf(lat));
                pod_bug_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(pod_bug_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("STEM WEEVIL")) {
                stem_weevil_pest_json_obj.put("pest_id", sel_pest_id);
                stem_weevil_pest_json_obj.put("pest_name", pest_name);
                stem_weevil_pest_json_obj.put("stem_weevil_pest_no", pigeonpea_generic_et.getText().toString().trim());
                stem_weevil_pest_json_obj.put("stem_weevil_pest_pic", image_1_file_name);
                stem_weevil_pest_json_obj.put("lat", String.valueOf(lat));
                stem_weevil_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(stem_weevil_pest_json_obj);
            }else if(pest_name.equalsIgnoreCase("BLISTER BEETLE")) {
                blister_beetle_pest_json_obj.put("pest_id", sel_pest_id);
                blister_beetle_pest_json_obj.put("pest_name", pest_name);
                blister_beetle_pest_json_obj.put("blister_beetle_pest_no", pigeonpea_generic_et.getText().toString().trim());
                blister_beetle_pest_json_obj.put("blister_beetle_pest_pic", image_1_file_name);
                blister_beetle_pest_json_obj.put("lat", String.valueOf(lat));
                blister_beetle_pest_json_obj.put("long", String.valueOf(lang));
                pest_details_json_array.put(blister_beetle_pest_json_obj);
            }

            if(pest_details_json_array.length()>0){
                add_pest_titleTableLayout_pigeonpea.setVisibility(View.VISIBLE);
                add_more_pest_rv_pigeonpea.setVisibility(View.VISIBLE);
                add_more_pest_rv_pigeonpea.setLayoutManager(new LinearLayoutManager(PigeonpeaSerial1.this));
                AddPestAdapter addPestAdapter = new AddPestAdapter(pest_details_json_array, PigeonpeaSerial1.this);
                add_more_pest_rv_pigeonpea.setAdapter(addPestAdapter);
                addPestAdapter.notifyDataSetChanged();
                pigeonpea_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_pigeonpea.setVisibility(View.GONE);
                pigeonpea_major_pest.setText("Select");
                pigeonpea_minor_pest.setText("Select");
                pigeonpea_generic_photo.setImageResource(R.drawable.camera);
                pigeonpea_generic_et.setText("");
                photoFile1 = null;
            }else{
                add_pest_titleTableLayout_pigeonpea.setVisibility(View.GONE);
                add_more_pest_rv_pigeonpea.setVisibility(View.GONE);
                final Toast toast = Toast.makeText(PigeonpeaSerial1.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 0);
            }

            System.out.println(pest_details_json_array.toString());

        }catch (Exception e){

        }
    }

    private void save_pigeonpea_data() {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("spot_id", count);
                param.put("crop_id", crop_id);
                param.put("crop_condition_id", crop_cond_id);
                param.put("crop_grow_id", crop_growth_id);
                param.put("soil_mois_id", soil_moisture_id);
                param.put("pest_details", pest_details_json_array.toString());
                param.put("total_defender", pigeonpea_defender_et.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(PigeonpeaSerial1.this,PigeonpeaGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null) {

            try {

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            pigeonpea_crop_plant_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            pigeonpea_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }
                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            pigeonpea_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if(type.equalsIgnoreCase("1")){
                                image_1_file_name = data.getString("file_url");
                            }
                        }
                    }
                }

                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            if(count<pigeonpea_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Pigeonpea/Tur");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        count++;
                                        crop_plant_pigeonpeatv.setText("Plant" + " " + count);
                                        pigeonpea_major_pest.setText("Select");
                                        pigeonpea_minor_pest.setText("Select");
                                        pest_details_json_array = new JSONArray();
                                        pigeonpea_generic_ll.setVisibility(View.GONE);
                                        btn_add_pest_details_pigeonpea.setVisibility(View.GONE);
                                        add_pest_titleTableLayout_pigeonpea.setVisibility(View.GONE);
                                        add_more_pest_rv_pigeonpea.setVisibility(View.GONE);
                                        pigeonpea_defender_et.setText("");
                                        sweetAlertDialog.dismissWithAnimation();
                                    }
                                });
                                sweetAlertDialog.show();
                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Pigeonpea/Tur");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Plant" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(PigeonpeaSerial1.this, PigeonpeaCropPheromoneActivity.class);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_pigeonpea_plant_id = Integer.parseInt(s1);
            pigeonpea_crop_name = s;
            crop_plant_pigeonpeatv.setText(s);

        }
        if (i == 2) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            pigeonpea_major_pest.setText(s);
            pigeonpea_minor_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == pigeonpea_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(PigeonpeaSerial1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                pigeonpea_generic_et.setText("");
                pigeonpea_generic_photo.setImageResource(R.drawable.camera);
                pigeonpea_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_pigeonpea.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_pigeonpea.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
        if (i == 3) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            pigeonpea_minor_pest.setText(s);
            pigeonpea_major_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == pigeonpea_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(PigeonpeaSerial1.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                pigeonpea_generic_et.setText("");
                pigeonpea_generic_photo.setImageResource(R.drawable.camera);
                pigeonpea_generic_ll.setVisibility(View.GONE);
                btn_add_pest_details_pigeonpea.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_pigeonpea.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }

    private void layout_View_Gone(String s) {
        if(pest_list_names_pigeonpea.contains(s)){
            pigeonpea_generic_ll.setVisibility(View.GONE);
            pigeonpea_generic_photo.setVisibility(View.GONE);
            pigeonpea_generic_tv.setText("");
            pigeonpea_generic_et.setText("");
            for(int i=0;i<pest_list_et_pigeonpea.size();i++){
                pest_list_et_pigeonpea.get(i).setText("");
            }

            for(int j=0;j<pest_list_names_pigeonpea.size();j++){
                if(pest_list_names_pigeonpea.get(j).equals(s)){
                    pest_list_layout_pigeonpea.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout_pigeonpea.get(j).setVisibility(View.GONE);
                }
            }
        }
        else{
            String localstr=s;
            String localstr2;
            localstr2= capitalizeWord(localstr);
            pigeonpea_generic_ll.setVisibility(View.VISIBLE);
            pigeonpea_generic_photo.setVisibility(View.VISIBLE);
            pigeonpea_generic_tv.setText(localstr2);
            pigeonpea_generic_et.setText("");
            for(int j=0;j<pest_list_names_pigeonpea.size();j++){
                pest_list_layout_pigeonpea.get(j).setVisibility(View.GONE);
            }
        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }
}


