package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;

import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import com.maha.agri.BuildConfig;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SoyabeanCrop extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private String type = "",generic_str="",white_fly_str="",jassids_str="",spodop_str1="",spodop_str2="";
    private TextView soybean_major_pest,soybean_minor_pest;
    private RecyclerView add_more_pest_rv;
    private TableLayout add_pest_titleTableLayout;

    private int count = 1, generic_int, white_fly_int,jassids_int;
    private int crop_cond_id = 0;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private int crop_id = 0;
    private int selected_pest_id = 0;

    /* Z A D E */
    TextView dept_cropsap_soyabean_crop_plant_tv;
    //Image
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private File photoFile3 = null;
    private File photoFile7 = null;
    private File photoFile8 = null;

    JSONObject spo_pest_json_obj = new JSONObject();
    JSONObject semi_pest_json_obj = new JSONObject();
    JSONObject heli_pest_json_obj = new JSONObject();
    JSONObject girdle_pest_json_obj = new JSONObject();
    JSONObject stem_pest_json_obj = new JSONObject();
    JSONObject hairy_pest_json_obj = new JSONObject();
    JSONObject aphids_pest_json_obj = new JSONObject();
    JSONObject leaf_minor_pest_json_obj = new JSONObject();
    JSONObject white_fly_pest_json_obj = new JSONObject();
    JSONObject jassid_pest_json_obj = new JSONObject();

    private ImageView dept_cropsap_soyabean_photo1,dept_cropsap_soyabean_photo2,photo_White_fly,photo_Jassids,photo_Generic_Layout_Minor_Pest;

    private String imagePath1 = "", imagePath2 = "", imagePath3 = "",imagePath7 = "", imagePath8 = "";
    private String image_1_file_name = "",image_2_file_name = "",image_3_file_name = "",image_7_file_name = "",image_8_file_name = "";
    public double lat,lang;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private int district_id, taluka_id, village_id, farmer_id;

    private AppLocationManager locationManager;

    private JSONArray soyabean_crop_plant_list,soybean_major_pest_list,soybean_minor_pest_list;
    private JSONArray pest_details_json_array = new JSONArray();

    private int crop_soyabean_plant_id = 0;
    private String crop_soyabean_plant_name = "", pest_name = "";
    private Button btn_add_pest_details,cropsap_soyabean_save_continue_btn;

    private LinearLayout soybean_major_pest_ll,soybean_minor_pest_ll;
        //Major
        private LinearLayout ll_Spodoptera;
        private EditText et_no_Spodoptera1,et_no_Spodoptera2,et_no_semilooper,et_no_Girdle_beetle,et_no_Stem_fly_Infested_Plants,et_no_White_fly,et_no_Jassids,et_no_Generic_Layout_Major_and_Minor_Pest;
        private ArrayList<String> pest_list_names=new ArrayList<String>();
        private ArrayList<LinearLayout> pest_list_layout=new ArrayList<LinearLayout>();
        private ArrayList<ImageView> pest_image_list_layout=new ArrayList<ImageView>();
        private ArrayList<String> pest_image_list_names = new ArrayList<String>();
        private ArrayList<EditText> pest_list_et=new ArrayList<EditText>();
        protected ArrayList<String> filled_pest = new ArrayList<String>();
        //Minor
        private LinearLayout ll_White_fly,ll_Jassids,ll_Generic_Layout_Major_and_Minor__Pest,ll_Defender_Soybean;

        private TextView Generic_Layout_Major_and_Minor__Pest_tv;
        private boolean flag_soybean=false;
        private EditText defender_soyabean;

        private SweetAlertDialog sweetAlertDialog;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_soyabean);
        getSupportActionBar().setTitle("Pest Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(SoyabeanCrop.this);
        sharedPref = new SharedPref(SoyabeanCrop.this);
        locationManager = new AppLocationManager(this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        crop_cond_id = intent.getIntExtra("crop_cond",0);
        crop_growth_id = intent.getIntExtra("crop_growth_id",0);
        soil_moisture_id = intent.getIntExtra("soil_moisture_id",0);
        lat = locationManager.getLatitude();
        lang = locationManager.getLongitude();
        initView();
        setListners();
    }

    private void initView() {
        // TEXT VIEW
        dept_cropsap_soyabean_crop_plant_tv=(TextView)findViewById(R.id.dept_cropsap_soyabean_crop_plant_tv);
        soybean_major_pest=(TextView)findViewById(R.id.soybean_major_pest);
        soybean_minor_pest=(TextView)findViewById(R.id.soybean_minor_pest);
        dept_cropsap_soyabean_crop_plant_tv.setEnabled(false);

        //Linear Layout
        soybean_major_pest_ll = (LinearLayout) findViewById(R.id.soybean_major_pest_ll);
        soybean_minor_pest_ll = (LinearLayout) findViewById(R.id.soybean_minor_pest_ll);

            // major pest
        ll_Spodoptera=(LinearLayout)findViewById(R.id.ll_Spodoptera);

        //minor pest
        ll_White_fly=(LinearLayout)findViewById(R.id.ll_White_fly);
        ll_Jassids=(LinearLayout)findViewById(R.id.ll_Jassids);

        // Edit text
        et_no_Spodoptera1=(EditText)findViewById(R.id.et_no_Spodoptera1);
        et_no_Spodoptera2=(EditText)findViewById(R.id.et_no_Spodoptera2);
        et_no_White_fly=(EditText)findViewById(R.id.et_no_White_fly);
        et_no_Jassids=(EditText)findViewById(R.id.et_no_Jassids);

        et_no_Generic_Layout_Major_and_Minor_Pest=(EditText)findViewById(R.id.et_no_Generic_Layout_Major_and_Minor_Pest);

        Generic_Layout_Major_and_Minor__Pest_tv=(TextView)findViewById(R.id.Generic_Layout_Major_and_Minor__Pest_tv);

        ll_Generic_Layout_Major_and_Minor__Pest=(LinearLayout)findViewById(R.id.ll_Generic_Layout_Major_and_Minor__Pest);

        //Spodoptera photo 1 & 2
        dept_cropsap_soyabean_photo1=(ImageView)findViewById(R.id.dept_cropsap_soyabean_photo1);
        dept_cropsap_soyabean_photo2=(ImageView)findViewById(R.id.dept_cropsap_soyabean_photo2);
        photo_Generic_Layout_Minor_Pest=(ImageView)findViewById(R.id.photo_Generic_Layout_Minor_Pest);
        photo_White_fly=(ImageView)findViewById(R.id.photo_White_fly);
        photo_Jassids=(ImageView)findViewById(R.id.photo_Jassids);

        add_pest_titleTableLayout = (TableLayout)findViewById(R.id.add_pest_titleTableLayout);
        add_more_pest_rv = (RecyclerView)findViewById(R.id.add_more_pest_rv);
        btn_add_pest_details = (Button)findViewById(R.id.btn_add_pest_details);
        cropsap_soyabean_save_continue_btn=(Button)findViewById(R.id.btn_save_cont_soya);
        defender_soyabean=(EditText)findViewById(R.id.defender_soyabean);

        soybean_minor_pest_list = new JSONArray();
        soybean_major_pest_list = new JSONArray();
        pest_details_json_array = new JSONArray();

        plant_service();
        major_pest_service();
        minor_pest_service();
        zero_pest_input();
        jassids_zero_input();
        white_fly_pest_input();
    }


    private void setListners() {

        pest_list_names.add("SPODOPTERA");
        pest_list_names.add("WHITE FLY");
        pest_list_names.add("JASSIDS");;

        pest_list_layout.add(ll_Spodoptera);
        pest_list_layout.add(ll_White_fly);
        pest_list_layout.add(ll_Jassids);

        //EditText Layouts
        pest_list_et.add(et_no_Spodoptera1);
        pest_list_et.add(et_no_Spodoptera2);
        pest_list_et.add(et_no_White_fly);
        pest_list_et.add(et_no_Jassids);

        pest_image_list_layout.add(dept_cropsap_soyabean_photo1);
        pest_image_list_layout.add(dept_cropsap_soyabean_photo2);
        pest_image_list_layout.add(photo_White_fly);
        pest_image_list_layout.add(photo_Jassids);

        pest_image_list_names.add(image_1_file_name);
        pest_image_list_names.add(image_2_file_name);
        pest_image_list_names.add(image_7_file_name);
        pest_image_list_names.add(image_8_file_name);

        dept_cropsap_soyabean_crop_plant_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (soyabean_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(soyabean_crop_plant_list, 1, "Select Spot", "spot_name", "spot_id", SoyabeanCrop.this, SoyabeanCrop.this);
                }
            }
        });

        soybean_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (soybean_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(soybean_major_pest_list, 2, "Select Major Pest", "pest_eng_name", "id", SoyabeanCrop.this, SoyabeanCrop.this);
                }else{
                    major_pest_service();
                }
            }
        });

        soybean_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (soybean_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(soybean_minor_pest_list, 3, "Select Minor Pest", "pest_eng_name", "id", SoyabeanCrop.this, SoyabeanCrop.this);
                }else{
                    minor_pest_service();
                }
            }
        });

        dept_cropsap_soyabean_photo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        dept_cropsap_soyabean_photo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        photo_Generic_Layout_Minor_Pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "3";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        photo_White_fly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "7";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        photo_Jassids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(SoyabeanCrop.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "8";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_add_pest_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                generic_str = et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim();
                spodop_str1 = et_no_Spodoptera1.getText().toString().trim();
                spodop_str2 = et_no_Spodoptera2.getText().toString().trim();
                white_fly_str = et_no_White_fly.getText().toString().trim();
                jassids_str = et_no_Jassids.getText().toString().trim();

                if(pest_name.equalsIgnoreCase("SEMILOOPER") || pest_name.equalsIgnoreCase("HELICOVERPA POD BORER") ||
                        pest_name.equalsIgnoreCase("GIRDLE BEETLE") || pest_name.equalsIgnoreCase("STEM FLY") ||
                        pest_name.equalsIgnoreCase("HAIRY CATERPILLAR") || pest_name.equalsIgnoreCase("APHIDS")
                        || pest_name.equalsIgnoreCase("LEAF MINOR")) {
                    if (generic_str.equalsIgnoreCase("")) {
                        Toast.makeText(SoyabeanCrop.this, "Enter the number of pest present ", Toast.LENGTH_SHORT).show();
                    }else if (photoFile3 == null) {
                        Toast.makeText(SoyabeanCrop.this, "Click photo of the pest", Toast.LENGTH_SHORT).show();
                    } else {
                        uploadImagenServer();
                        add_pest_details(selected_pest_id, pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("SPODOPTERA")){
                    if(spodop_str1.isEmpty()){
                        Toast.makeText(SoyabeanCrop.this, "Enter Gregarious Larvae", Toast.LENGTH_SHORT).show();
                    }
                    else if(photoFile1 == null){
                        Toast.makeText(SoyabeanCrop.this, "Click Image of Gregarious Larvae", Toast.LENGTH_SHORT).show();
                    }
                    else if(spodop_str2.isEmpty()){
                        Toast.makeText(SoyabeanCrop.this, "Enter Solitary Larvae", Toast.LENGTH_SHORT).show();
                    }
                    else if(photoFile2 == null){
                        Toast.makeText(SoyabeanCrop.this, "Click Image of Solitary Larvae", Toast.LENGTH_SHORT).show();
                    }else{
                        uploadImagenServer();
                        add_pest_details(selected_pest_id, pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("WHITE FLY")){
                    if(white_fly_str.isEmpty()){
                        Toast.makeText(SoyabeanCrop.this,"Enter no of pest present",Toast.LENGTH_SHORT).show();
                    }
                    else if(Integer.parseInt(white_fly_str)>3){
                        Toast.makeText(SoyabeanCrop.this,"Total Leaves not exceed more than 3",Toast.LENGTH_SHORT).show();
                    }
                    else if(photoFile7 == null){
                        Toast.makeText(SoyabeanCrop.this,"Click image of the pest",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        uploadImagenServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }else if(pest_name.equalsIgnoreCase("JASSIDS")){
                    if(jassids_str.isEmpty()){
                        Toast.makeText(SoyabeanCrop.this,"Enter no of pest present",Toast.LENGTH_SHORT).show();
                    }
                    else if(photoFile8 == null){
                        Toast.makeText(SoyabeanCrop.this,"Click image of the pest",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        uploadImagenServer();
                        add_pest_details(selected_pest_id,pest_name);
                    }
                }
                else{

                }
            }
        });

        cropsap_soyabean_save_continue_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String defender_soyabean_str=defender_soyabean.getText().toString();
                if(pest_details_json_array.length()>0) {
                    if(pest_details_json_array.toString().contains("SPODOPTERA") &&
                            pest_details_json_array.toString().contains("SEMILOOPER") &&
                            pest_details_json_array.toString().contains("HELICOVERPA POD BORER") &&
                            pest_details_json_array.toString().contains("GIRDLE BEETLE") &&
                            pest_details_json_array.toString().contains("STEM FLY")) {
                        if (defender_soyabean_str.isEmpty()) {
                            Toast.makeText(SoyabeanCrop.this, "Enter total defender", Toast.LENGTH_SHORT).show();
                        } else {
                            save_soyabean_crop_data_service();
                        }
                    }else{
                        sweetAlertDialog = new SweetAlertDialog(SoyabeanCrop.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Enter data for all major pests");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                            }
                        }).show();
                    }
                }else {
                    final Toast toast = Toast.makeText(SoyabeanCrop.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 2000);
                }
            }
        });
    }

    private void zero_pest_input(){
        et_no_Generic_Layout_Major_and_Minor_Pest.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                 generic_str = et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim();
                if(!generic_str.equalsIgnoreCase("")){
                    generic_int = Integer.parseInt(generic_str);
                    if(generic_int == 0){
                        photo_Generic_Layout_Minor_Pest.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        photo_Generic_Layout_Minor_Pest.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void white_fly_pest_input(){
        et_no_White_fly.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                white_fly_str = et_no_White_fly.getText().toString().trim();
                if(!white_fly_str.equalsIgnoreCase("")){
                    white_fly_int = Integer.parseInt(white_fly_str);
                    if(white_fly_int == 0){
                        photo_White_fly.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        photo_White_fly.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void jassids_zero_input(){
        et_no_Jassids.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                jassids_str = et_no_Jassids.getText().toString().trim();
                if(!jassids_str.equalsIgnoreCase("")){
                    jassids_int = Integer.parseInt(jassids_str);
                    if(jassids_int == 0){
                        photo_Jassids.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        photo_Jassids.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    private void add_pest_details(int sel_pest_id,String pest_name){

        try {
            // SPODOPTERA
            if(pest_name.equalsIgnoreCase("SPODOPTERA")) {
                    spo_pest_json_obj.put("pest_id", sel_pest_id);
                    spo_pest_json_obj.put("pest_name", pest_name);
                    spo_pest_json_obj.put("spo_gre_lar_no", et_no_Spodoptera1.getText().toString().trim());
                    spo_pest_json_obj.put("spo_gre_lar_pic", image_1_file_name);
                    spo_pest_json_obj.put("spo_soli_lar_no", et_no_Spodoptera2.getText().toString().trim());
                    spo_pest_json_obj.put("spo_soli_lar_pic", image_2_file_name);
                    spo_pest_json_obj.put("lat", String.valueOf(lat));
                    spo_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(spo_pest_json_obj);
            }

            //SEMILOOPER
            else if(pest_name.equalsIgnoreCase("SEMILOOPER")) {
                    semi_pest_json_obj.put("pest_id", sel_pest_id);
                    semi_pest_json_obj.put("pest_name", pest_name);
                    semi_pest_json_obj.put("semi_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    semi_pest_json_obj.put("semi_pest_pic", image_3_file_name);
                    semi_pest_json_obj.put("lat", String.valueOf(lat));
                    semi_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(semi_pest_json_obj);

            //HELICOVERPA POD BORER
            }else if(pest_name.equalsIgnoreCase("HELICOVERPA POD BORER")) {
                    heli_pest_json_obj.put("pest_id", sel_pest_id);
                    heli_pest_json_obj.put("pest_name", pest_name);
                    heli_pest_json_obj.put("heli_cover_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    heli_pest_json_obj.put("heli_cover_pest_pic", image_3_file_name);
                    heli_pest_json_obj.put("lat", String.valueOf(lat));
                    heli_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(heli_pest_json_obj);

            //GIRDLE BEETLE
            }else if(pest_name.equalsIgnoreCase("GIRDLE BEETLE")) {
                    girdle_pest_json_obj.put("pest_id", sel_pest_id);
                    girdle_pest_json_obj.put("pest_name", pest_name);
                    girdle_pest_json_obj.put("girdle_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    girdle_pest_json_obj.put("girdle_pest_pic", image_3_file_name);
                    girdle_pest_json_obj.put("lat", String.valueOf(lat));
                    girdle_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(girdle_pest_json_obj);

            // STEM FLY
            }else if(pest_name.equalsIgnoreCase("STEM FLY")) {
                    stem_pest_json_obj.put("pest_id", sel_pest_id);
                    stem_pest_json_obj.put("pest_name", pest_name);
                    stem_pest_json_obj.put("stem_fly_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    stem_pest_json_obj.put("stem_fly_pest_pic", image_3_file_name);
                    stem_pest_json_obj.put("lat", String.valueOf(lat));
                    stem_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(stem_pest_json_obj);

            // HAIRY CATEPILLAR
            }else if(pest_name.equalsIgnoreCase("HAIRY CATERPILLAR")) {
                    hairy_pest_json_obj.put("pest_id", sel_pest_id);
                    hairy_pest_json_obj.put("pest_name", pest_name);
                    hairy_pest_json_obj.put("hairy_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    hairy_pest_json_obj.put("hairy_pest_pic", image_3_file_name);
                    hairy_pest_json_obj.put("lat", String.valueOf(lat));
                    hairy_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(hairy_pest_json_obj);

            //APHIDS
            }else if(pest_name.equalsIgnoreCase("APHIDS")) {
                    aphids_pest_json_obj.put("pest_id", sel_pest_id);
                    aphids_pest_json_obj.put("pest_name", pest_name);
                    aphids_pest_json_obj.put("aphids_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    aphids_pest_json_obj.put("aphids_pest_pic", image_3_file_name);
                    aphids_pest_json_obj.put("lat", String.valueOf(lat));
                    aphids_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(aphids_pest_json_obj);

            // LEAF MINOR
            }else if(pest_name.equalsIgnoreCase("LEAF MINOR")) {
                    leaf_minor_pest_json_obj.put("pest_id", sel_pest_id);
                    leaf_minor_pest_json_obj.put("pest_name", pest_name);
                    leaf_minor_pest_json_obj.put("leaf_minor_pest_no", et_no_Generic_Layout_Major_and_Minor_Pest.getText().toString().trim());
                    leaf_minor_pest_json_obj.put("leaf_minor_pest_pic", image_3_file_name);
                    leaf_minor_pest_json_obj.put("lat", String.valueOf(lat));
                    leaf_minor_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(leaf_minor_pest_json_obj);

            //WHITE
            }else if(pest_name.equalsIgnoreCase("WHITE FLY")) {
                    white_fly_pest_json_obj.put("pest_id", sel_pest_id);
                    white_fly_pest_json_obj.put("pest_name", pest_name);
                    white_fly_pest_json_obj.put("white_fly_leaves_no", et_no_White_fly.getText().toString().trim());
                    white_fly_pest_json_obj.put("white_fly_leaves_pic", image_7_file_name);
                    white_fly_pest_json_obj.put("lat", String.valueOf(lat));
                    white_fly_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(white_fly_pest_json_obj);

            //JASSID
            }else if(pest_name.equalsIgnoreCase("JASSIDS")) {
                    jassid_pest_json_obj.put("pest_id", sel_pest_id);
                    jassid_pest_json_obj.put("pest_name", pest_name);
                    jassid_pest_json_obj.put("jassid_damage_grade_no", et_no_Jassids.getText().toString().trim());
                    jassid_pest_json_obj.put("jassid_damage_grade_pic", image_8_file_name);
                    jassid_pest_json_obj.put("lat", String.valueOf(lat));
                    jassid_pest_json_obj.put("long", String.valueOf(lang));
                    pest_details_json_array.put(jassid_pest_json_obj);
            }

            if(pest_details_json_array.length()>0){
                add_pest_titleTableLayout.setVisibility(View.VISIBLE);
                add_more_pest_rv.setVisibility(View.VISIBLE);
                add_more_pest_rv.setLayoutManager(new LinearLayoutManager(SoyabeanCrop.this));
                AddPestAdapter addPestAdapter = new AddPestAdapter(pest_details_json_array, SoyabeanCrop.this);
                add_more_pest_rv.setAdapter(addPestAdapter);
                addPestAdapter.notifyDataSetChanged();
                ll_White_fly.setVisibility(View.GONE);
                ll_Spodoptera.setVisibility(View.GONE);
                ll_Jassids.setVisibility(View.GONE);
                ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.GONE);
                btn_add_pest_details.setVisibility(View.GONE);
                soybean_major_pest.setText("Select");
                soybean_minor_pest.setText("Select");
                photo_Generic_Layout_Minor_Pest.setImageResource(R.drawable.camera);
                et_no_Generic_Layout_Major_and_Minor_Pest.setText("");
                dept_cropsap_soyabean_photo1.setImageResource(R.drawable.camera);
                et_no_Spodoptera1.setText("");
                dept_cropsap_soyabean_photo2.setImageResource(R.drawable.camera);
                et_no_Spodoptera2.setText("");
                photo_White_fly.setImageResource(R.drawable.camera);
                et_no_White_fly.setText("");
                photo_Jassids.setImageResource(R.drawable.camera);
                et_no_Jassids.setText("");
                photoFile1 = null;
                photoFile2 = null;
                photoFile3 = null;
                photoFile7 = null;
                photoFile8 = null;
            }else{
                add_pest_titleTableLayout.setVisibility(View.GONE);
                add_more_pest_rv.setVisibility(View.GONE);
                /*final Toast toast = Toast.makeText(SoyabeanCrop.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 0);*/
            }

            System.out.println("Soyabean :"+filled_pest);

        }catch (Exception e){

        }

    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);

                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("3")) {
                photoFile3 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile3);
                } else {
                    photoURI = Uri.fromFile(photoFile3);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("7")) {
                photoFile7 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile7);
                } else {
                    photoURI = Uri.fromFile(photoFile7);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("8")) {
                photoFile8 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile8);
                } else {
                    photoURI = Uri.fromFile(photoFile8);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }

    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
            photoFile2 = null;
            photoFile3 = null;
            photoFile7 = null;
            photoFile8 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(dept_cropsap_soyabean_photo1.getWidth(), dept_cropsap_soyabean_photo1.getHeight())
                                    .centerCrop()
                                    .into(dept_cropsap_soyabean_photo1);

                        }
                        }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("2")) {
            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(dept_cropsap_soyabean_photo2.getWidth(), dept_cropsap_soyabean_photo2.getHeight())
                                    .centerCrop()
                                    .into(dept_cropsap_soyabean_photo2);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("3")) {

            if (photoFile3 != null) {

                if (photoFile3.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile3, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath3 = "file://" + photoFile3;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath3)
                                    .resize(photo_Generic_Layout_Minor_Pest.getWidth(), photo_Generic_Layout_Minor_Pest.getHeight())
                                    .centerCrop()
                                    .into(photo_Generic_Layout_Minor_Pest);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile3);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else if(type.equalsIgnoreCase("7")) {

            if (photoFile7 != null) {

                if (photoFile7.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile7, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath7 = "file://" + photoFile7;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath7)
                                    .resize(photo_White_fly.getWidth(), photo_White_fly.getHeight())
                                    .centerCrop()
                                    .into(photo_White_fly);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile7);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("8")) {

            if (photoFile8 != null) {

                if (photoFile8.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile8, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath8 = "file://" + photoFile8;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath8)
                                    .resize(photo_Jassids.getWidth(), photo_Jassids.getHeight())
                                    .centerCrop()
                                    .into(photo_Jassids);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile8);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void plant_service() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soya_spot_list();
        api.postRequest(responseCall, this, 1);
    }
    private void major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }
    private void minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void uploadImagenServer() {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;

                case "2":
                    File file2 = new File(photoFile2.getPath());
                    RequestBody reqFile2 = RequestBody.create(MediaType.parse("image/*"), file2);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file2.getName(), reqFile2);
                    break;

                case "3":
                    File file3 = new File(photoFile3.getPath());
                    RequestBody reqFile3 = RequestBody.create(MediaType.parse("image/*"), file3);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file3.getName(), reqFile3);
                    break;

                case "4":
                    File file7 = new File(photoFile7.getPath());
                    RequestBody reqFile7 = RequestBody.create(MediaType.parse("image/*"), file7);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file7.getName(), reqFile7);
                    break;

                case "5":
                    File file8 = new File(photoFile8.getPath());
                    RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file8);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file8.getName(), reqFile);
                    break;
            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void save_soyabean_crop_data_service() {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("spot_id", count);
                param.put("crop_id", crop_id);
                param.put("crop_condition_id", crop_cond_id);
                param.put("crop_grow_id", crop_growth_id);
                param.put("soil_mois_id", soil_moisture_id);
                param.put("total_defender", defender_soyabean.getText().toString().trim());
                param.put("pest_details", pest_details_json_array.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(SoyabeanCrop.this, SoyabeanGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            soyabean_crop_plant_list = jsonObject.getJSONArray("data");

                        }

                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            soybean_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            soybean_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }


                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data  = jsonObject.getJSONObject("data");
                            if(type.equalsIgnoreCase("1")){
                                image_1_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("2")){
                                image_2_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("3")){
                                image_3_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("7")){
                                image_7_file_name = data.getString("file_url");
                            }else if(type.equalsIgnoreCase("8")){
                                image_8_file_name = data.getString("file_url");
                            }
                        }
                    }
                }


                if (i == 5) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(count<soyabean_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Soybean");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Spot" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(SweetAlertDialog sDialog) {
                                                count++;
                                                dept_cropsap_soyabean_crop_plant_tv.setText("Spot" + " " + count);
                                                soybean_major_pest.setText("Select");
                                                soybean_minor_pest.setText("Select");
                                                sweetAlertDialog.dismissWithAnimation();
                                                pest_details_json_array= new JSONArray();
                                                ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.GONE);
                                                ll_Spodoptera.setVisibility(View.GONE);
                                                ll_Jassids.setVisibility(View.GONE);
                                                ll_White_fly.setVisibility(View.GONE);
                                                add_pest_titleTableLayout.setVisibility(View.GONE);
                                                btn_add_pest_details.setVisibility(View.GONE);
                                                add_more_pest_rv.setVisibility(View.GONE);
                                                defender_soyabean.setText("");

                                            }
                                        });
                                sweetAlertDialog.show();

                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Soybean");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Spot" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(SoyabeanCrop.this, SoyabeanCropPheromoneActivity.class);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }

                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            crop_soyabean_plant_id = Integer.parseInt(s1);
            crop_soyabean_plant_name=s;
            dept_cropsap_soyabean_crop_plant_tv.setText(s);
        }

        if (i == 2) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            soybean_major_pest.setText(s);
            soybean_minor_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == soybean_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(SoyabeanCrop.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_no_Generic_Layout_Major_and_Minor_Pest.setText("");
                et_no_Jassids.setText("");
                et_no_Spodoptera1.setText("");
                et_no_Spodoptera2.setText("");
                et_no_White_fly.setText("");
                photo_Generic_Layout_Minor_Pest.setImageResource(R.drawable.camera);
                photo_Jassids.setImageResource(R.drawable.camera);
                photo_White_fly.setImageResource(R.drawable.camera);
                dept_cropsap_soyabean_photo1.setImageResource(R.drawable.camera);
                dept_cropsap_soyabean_photo2.setImageResource(R.drawable.camera);
                ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.GONE);
                ll_Jassids.setVisibility(View.GONE);
                ll_Spodoptera.setVisibility(View.GONE);
                ll_White_fly.setVisibility(View.GONE);
                btn_add_pest_details.setVisibility(View.GONE);
            }else{
                btn_add_pest_details.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }

        }

        if (i ==3) {
            selected_pest_id = Integer.parseInt(s1);
            pest_name = s;
            soybean_minor_pest.setText(s);
            soybean_major_pest.setText("Select");
            if(pest_details_json_array.toString().contains(pest_name) == soybean_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(SoyabeanCrop.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_no_Generic_Layout_Major_and_Minor_Pest.setText("");
                et_no_Jassids.setText("");
                et_no_Spodoptera1.setText("");
                et_no_Spodoptera2.setText("");
                et_no_White_fly.setText("");
                photo_Generic_Layout_Minor_Pest.setImageResource(R.drawable.camera);
                photo_Jassids.setImageResource(R.drawable.camera);
                photo_White_fly.setImageResource(R.drawable.camera);
                dept_cropsap_soyabean_photo1.setImageResource(R.drawable.camera);
                dept_cropsap_soyabean_photo2.setImageResource(R.drawable.camera);
                ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.GONE);
                ll_Jassids.setVisibility(View.GONE);
                ll_Spodoptera.setVisibility(View.GONE);
                ll_White_fly.setVisibility(View.GONE);
                btn_add_pest_details.setVisibility(View.GONE);
            }else{
                btn_add_pest_details.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }


    private void layout_View_Gone(String s) {

        //Image Reset & File Path
        for(int i=0;i<pest_image_list_layout.size();i++){
            pest_image_list_layout.get(i).setImageDrawable(getResources().getDrawable(R.drawable.camera));
            pest_image_list_names.get(i).equals("");
        }


        if(pest_list_names.contains(s)){
            ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.GONE);
            photo_Generic_Layout_Minor_Pest.setVisibility(View.GONE);

            Generic_Layout_Major_and_Minor__Pest_tv.setText("");
            et_no_Generic_Layout_Major_and_Minor_Pest.setText("");

            for(int i=0;i<pest_list_et.size();i++){
                pest_list_et.get(i).setText("");
            }

            for(int j=0;j<pest_list_names.size();j++){
                if(pest_list_names.get(j).equals(s)){
                    pest_list_layout.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout.get(j).setVisibility(View.GONE);
                    et_no_Generic_Layout_Major_and_Minor_Pest.setText("");
                }
            }
        }
        else{
            String localstr=s;
            String localstr2;
            localstr2= capitalizeWord(localstr);
            ll_Generic_Layout_Major_and_Minor__Pest.setVisibility(View.VISIBLE);
            photo_Generic_Layout_Minor_Pest.setVisibility(View.VISIBLE);
            Generic_Layout_Major_and_Minor__Pest_tv.setText(localstr2);
            et_no_Generic_Layout_Major_and_Minor_Pest.setText("");
            for(int j=0;j<pest_list_names.size();j++){
                pest_list_layout.get(j).setVisibility(View.GONE);
            }

        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
