package com.maha.agri.activity.user_dashboard.RJDA;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.activity.common.GetOfflineData;
import com.maha.agri.activity.common.LoginActivity;
import com.maha.agri.activity.common.ProfileActivity;
import com.maha.agri.activity.task_manager.TaskManagerActivity;
import com.maha.agri.activity.user_assigned_location.AssignedLocationActivity;
import com.maha.agri.adapter.Dashboard_Adapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIAlertView;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class RJDAActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView rjda_dash_recycler_view;
    /*private int[] dash_background = {R.drawable.dash_attendance, R.drawable.dash_task,  R.drawable.dash_assigned_villages,R.drawable.dash_task_report, R.drawable.dash_my_profile};
    private int[] dash_icon = {R.drawable.appointment, R.drawable.task,  R.drawable.assigned_village, R.drawable.report, R.drawable.profile};
    private String[] dash_title = {"Attendance", "Task Manager", "Assigned Locations", "Task Report", "My Profile"};*/
    private int[] dash_background = {R.drawable.dash_task,  R.drawable.dash_assigned_villages, R.drawable.dash_my_profile};
    private int[] dash_icon = {R.drawable.task,  R.drawable.assigned_village,R.drawable.profile};
    private String[] dash_title = {"Task Manager", "Assigned Locations", "My Profile"};
    PreferenceManager preferenceManager;
    private TextView rjda_name_TView, rjda_desig_TView,rjda_Circle_Tview,version_rjda;
    private CircleImageView rjda_profile_image_view;
    private Transformation transformation;
    private ImageView rjda_log_out_iv;

    private GetOfflineData getOfflineData;
    private DBHandler dbHandler;

    String version_name="";
    int version_code = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_rjda);

        dbHandler = new DBHandler(this);
        version_name = BuildConfig.VERSION_NAME;
        version_code = BuildConfig.VERSION_CODE;
        version_rjda = (TextView) findViewById(R.id.version_aa);
        version_rjda.setText("V - " + version_name);


        init();
        defaultConfig();
    }



    private void init() {

        preferenceManager = new PreferenceManager(this);

        getOfflineData = new GetOfflineData(this);

        rjda_dash_recycler_view = (RecyclerView) findViewById(R.id.rjda_dashboard_recyclerView);
        rjda_name_TView = (TextView) findViewById(R.id.rjda_name_TView);
        rjda_desig_TView = (TextView) findViewById(R.id.rjda_desig_TView);
        rjda_Circle_Tview = (TextView) findViewById(R.id.rjda_circle_TView);
        rjda_profile_image_view = (CircleImageView) findViewById(R.id.rjda_profile_image_view);
        rjda_log_out_iv = (ImageView) findViewById(R.id.rjda_log_out);
        rjda_dash_recycler_view.setAdapter(new Dashboard_Adapter(dash_background, dash_icon, dash_title, this));
        rjda_dash_recycler_view.setLayoutManager(new GridLayoutManager(this, 1));
        getOfflineData.task_type();

    }

    private void defaultConfig() {

        getAbsentReasonList();

        rjda_log_out_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(40)
                .oval(false)
                .build();


        rjda_dash_recycler_view.addOnItemTouchListener(new Dashboard_Adapter.RecyclerTouchListener(this, rjda_dash_recycler_view, new Dashboard_Adapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                switch (position) {
                   /* case 0:
                        Intent attendance = new Intent(RJDAActivity.this, AttedanceDashboardActivity.class);
                        startActivity(attendance);
                        break;*/

                    case 0:
                        Intent taskmanager = new Intent(RJDAActivity.this, TaskManagerActivity.class);
                        startActivity(taskmanager);
                        break;

                    /*case 2:
                        Intent attendancelist = new Intent(AADashboardActivity.this, AttedanceCalenderActivity.class);
                        startActivity(attendancelist);
                        break;*/

                    /*case 3:
                        Intent syncAttendance = new Intent(AADashboardActivity.this, SyncAttendanceActivity.class);
                        startActivity(syncAttendance);
                        break;*/

                    case 1:
                        Intent assignedvillages = new Intent(RJDAActivity.this, AssignedLocationActivity.class);
                        startActivity(assignedvillages);
                        break;

                   /* case 3:
                        Intent profile = new Intent(RJDAActivity.this, TaskReportActivity.class);
                        startActivity(profile);
                        break;*/

                    case 2:
                        Intent attendance_report = new Intent(RJDAActivity.this, ProfileActivity.class);
                        startActivity(attendance_report);
                        break;


                }
            }


            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }

    @Override
    public void onBackPressed() {
        UIAlertView.getOurInstance().exitFromApplicationMessage(this,"Do you want to exit ?");
    }

    private void getAbsentReasonList() {

        JSONObject param = new JSONObject();
        /*try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.absentReasonListReq(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void logout() {
        new FancyAlertDialog.Builder(this)
                .setTitle("Log out")
                .setBackgroundColor(Color.parseColor("#d50000"))  //Don't pass R.color.colorvalue
                .setMessage("Do you really wish to log out ?")
                .setNegativeBtnText("No")
                .setIcon(R.drawable.ic_error_outline_black_24dp, Icon.Visible)
                .setPositiveBtnBackground(Color.parseColor("#9b0000"))  //Don't pass R.color.colorvalue
                .setPositiveBtnText("Yes")
                .setNegativeBtnBackground(Color.parseColor("#FFA9A7A8"))  //Don't pass R.color.colorvalue
                .setAnimation(Animation.POP)
                .isCancellable(true)
                .OnPositiveClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {
                        preferenceManager.clearSharedPreferance();
                        Intent log_out_Intent = new Intent(RJDAActivity.this, LoginActivity.class);
                        startActivity(log_out_Intent);
                        finishAffinity();
                    }
                })
                .OnNegativeClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {


                    }
                })
                .build();
    }

    private void Exit() {

        /*new FancyAlertDialog.Builder(this)
                .setTitle("Krishi SMA")
                .setBackgroundColor(Color.parseColor("#d50000"))  //Don't pass R.color.colorvalue
                .setMessage("Do you want to exit ?")
                .setNegativeBtnText("No")
                .setPositiveBtnBackground(Color.parseColor("#9b0000"))  //Don't pass R.color.colorvalue
                .setPositiveBtnText("Yes")
                .setNegativeBtnBackground(Color.parseColor("#FFA9A7A8"))  //Don't pass R.color.colorvalue
                .setAnimation(Animation.SLIDE)
                .isCancellable(true)
                .OnPositiveClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {
                        finish();
                    }
                })
                .OnNegativeClicked(new FancyAlertDialogListener() {
                    @Override
                    public void OnClick() {


                    }
                })
                .build();*/
        UIAlertView.getOurInstance().exitFromApplicationMessage(this,"Do you want to exit ?");
    }


    @Override
    protected void onResume() {
        super.onResume();
        setProfileData();
    }

    private void setProfileData() {
        String user_data = AppSettings.getInstance().getValue(this, ApConstants.kLOGIN_DATA, ApConstants.kLOGIN_DATA);
        if (!user_data.equalsIgnoreCase("kLOGIN_DATA")) {

            try {
                JSONObject  userJson = new JSONObject(user_data);

                String fName = AppUtility.getInstance().sanitizeJSONObj(userJson, "first_name");
                String lName =  AppUtility.getInstance().sanitizeJSONObj(userJson, "last_name");
                String email =  AppUtility.getInstance().sanitizeJSONObj(userJson, "email");
                String mobile = AppUtility.getInstance().sanitizeJSONObj(userJson, "mobile");
                String mName = AppUtility.getInstance().sanitizeJSONObj(userJson, "middle_name");
                String profileImage = AppUtility.getInstance().sanitizeJSONObj(userJson, "profile_pic");
                String role_design = AppUtility.getInstance().sanitizeJSONObj(userJson, "role_desg");

                String name = fName+" "+mName+" "+lName;
                rjda_name_TView.setText(name);
                rjda_desig_TView.setText(role_design);
                rjda_Circle_Tview.setText(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ASSIGN));

                if (!profileImage.isEmpty()) {

                    Picasso.get()
                            .load(Uri.parse(profileImage))
                            .transform(transformation)
                            .resize(150, 150)
                            .centerCrop()
                            .placeholder(R.drawable.person)
                            .into(rjda_profile_image_view);

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (i == 1) {
            ResponseModel responseModel = new ResponseModel(jsonObject);
            if (responseModel.isStatus()) {
                JSONArray reasonListArray = responseModel.getData();
                AppSettings.getInstance().setValue(this,ApConstants.kAB_REASON,reasonListArray.toString());
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
