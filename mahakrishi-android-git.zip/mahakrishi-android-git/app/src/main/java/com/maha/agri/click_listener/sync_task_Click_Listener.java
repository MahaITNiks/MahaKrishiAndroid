package com.maha.agri.click_listener;

public interface sync_task_Click_Listener {

    public void onSyncClick(String i_d);
}
