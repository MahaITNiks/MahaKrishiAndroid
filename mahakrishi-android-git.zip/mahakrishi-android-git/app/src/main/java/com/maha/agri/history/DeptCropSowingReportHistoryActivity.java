package com.maha.agri.history;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.Dashboard_Adapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DeptCropSowingReportHistoryActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView crop_sowing_report_week_tv;
    private RecyclerView crop_sowing_report_history_rv;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String week_number = "";
    private String week_name = "";
    private JSONArray week_list, village_count_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dept_crop_sowing_report_history);
        getSupportActionBar().setTitle("Crop Sowing History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DeptCropSowingReportHistoryActivity.this);
        sharedPref = new SharedPref(DeptCropSowingReportHistoryActivity.this);
        init();
        default_confiq();
    }

    private void init() {
        crop_sowing_report_week_tv = (TextView) findViewById(R.id.crop_sowing_report_week_tv);
        crop_sowing_report_history_rv = (RecyclerView) findViewById(R.id.crop_sowing_report_history_rv);
        week_list = new JSONArray();
        village_count_list = new JSONArray();
        meterologicalWeek();
    }

    private void default_confiq() {
        crop_sowing_report_week_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (week_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(week_list, 1, "Select Week", "week", "week_number", DeptCropSowingReportHistoryActivity.this, DeptCropSowingReportHistoryActivity.this);
                } else {
                    meterologicalWeek();
                }
            }
        });

        crop_sowing_report_history_rv.addOnItemTouchListener(new Dashboard_Adapter.RecyclerTouchListener(this, crop_sowing_report_history_rv, new Dashboard_Adapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent intent = new Intent(DeptCropSowingReportHistoryActivity.this, DeptCropSowingReportHistoryDetailsActivity.class);
                intent.putExtra("position",position);
                intent.putExtra("week_number", week_number);
                intent.putExtra("village_list", village_count_list.toString());
                startActivity(intent);
            }


            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    private void meterologicalWeek() {

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.get_csr_history_meterological_week(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }


    private void getSowingReportTotalCountVillagewise() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("week_number", week_number);

        } catch (Exception e) {

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_village_history_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            week_list = jsonObject.getJSONArray("data");
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_count_list = jsonObject.getJSONArray("data");
                            crop_sowing_report_history_rv.setLayoutManager(new LinearLayoutManager(DeptCropSowingReportHistoryActivity.this));
                            crop_sowing_report_history_rv.setAdapter(new CropSowingReportHistoryAdapter(village_count_list,this));

                        }
                    } else {
                        crop_sowing_report_history_rv.setAdapter(null);
                        //UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            week_number = s1;
            week_name = s;
            crop_sowing_report_week_tv.setText(week_name);
            getSowingReportTotalCountVillagewise();

        }

    }
}
