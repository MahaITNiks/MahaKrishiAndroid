package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class OnSpotPhysicalVerificationActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private EditText on_spot_policy, on_spot_app_no, on_spot_area_application, on_spot_area_actual,
            on_spot_crop_age_application, on_spot_crop_age_actual, on_spot_no_crop_plant_application, on_spot_no_crop_plant_actual;
    private TextView on_spot_year, on_spot_district, on_spot_taluka, on_spot_revenue_circle, on_spot_gram_panchayat,
            on_spot_village, on_spot_season_tv, on_spot_crop_tv;
    private ImageView phy_veri_wbcis_iv;
    private Button dept_phy_veri_submit_btn;
    static final Integer CAMERA = 0x5;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;

    private String imagePath = "",first_image_url = "", currentTime = "", crop_name = "", app_crop_age = "", actual_crop_age = "";
    private int year_id = 0;
    private int district_id = 0;
    private int taluka_id = 0;
    private int revenue_id = 0;
    private int gram_panchayat_id = 0;
    private int village_id = 0;
    private int season_id = 0;
    private int crop_id = 0;
    private double app_crop_age_int = 0.0;
    private double actual_crop_age_int = 0.0;
    private JSONArray year_list = null;
    private JSONArray district_list = null;
    private JSONArray taluka_list = null;
    private JSONArray revenue_circle_list = null;
    private JSONArray gram_panchayat_list = null;
    private JSONArray village_list = null;
    private JSONArray season_list = null;
    private JSONArray crop_list = null;

    private PreferenceManager preferenceManager;
    private SharedPref sharedPref;
    private AppLocationManager appLocationManager;
    public double lat,lang;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_spot_physical_verification);
        getSupportActionBar().setTitle("Physical Verification - WBCIS");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(OnSpotPhysicalVerificationActivity.this);
        sharedPref = new SharedPref(OnSpotPhysicalVerificationActivity.this);
        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();
        idcalling();
        click_listerner();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void idcalling() {
        //Edit text
        on_spot_policy = (EditText) findViewById(R.id.on_spot_policy);
        on_spot_app_no = (EditText) findViewById(R.id.on_spot_app_no);
        on_spot_area_application = (EditText) findViewById(R.id.on_spot_area_application);
        on_spot_area_actual = (EditText) findViewById(R.id.on_spot_area_actual);
        on_spot_crop_age_application = (EditText) findViewById(R.id.on_spot_crop_age_application);
        on_spot_crop_age_actual = (EditText) findViewById(R.id.on_spot_crop_age_actual);
        on_spot_no_crop_plant_application = (EditText) findViewById(R.id.on_spot_no_crop_plant_application);
        on_spot_no_crop_plant_actual = (EditText) findViewById(R.id.on_spot_no_crop_plant_actual);
        //Text view
        on_spot_year = (TextView) findViewById(R.id.on_spot_year);
        on_spot_district = (TextView) findViewById(R.id.on_spot_district);
        on_spot_taluka = (TextView) findViewById(R.id.on_spot_taluka);
        on_spot_revenue_circle = (TextView) findViewById(R.id.on_spot_revenue_circle);
        on_spot_gram_panchayat = (TextView) findViewById(R.id.on_spot_gram_panchayat);
        on_spot_village = (TextView) findViewById(R.id.on_spot_village);
        on_spot_season_tv = (TextView) findViewById(R.id.on_spot_season_tv);
        on_spot_crop_tv = (TextView) findViewById(R.id.on_spot_crop_tv);
        //Image view
        phy_veri_wbcis_iv = (ImageView) findViewById(R.id.phy_veri_wbcis_iv);
        dept_phy_veri_submit_btn = (Button)findViewById(R.id.dept_phy_veri_submit_btn);

        year_list = new JSONArray();
        district_list = new JSONArray();
        taluka_list = new JSONArray();
        revenue_circle_list = new JSONArray();
        gram_panchayat_list = new JSONArray();
        village_list = new JSONArray();
        season_list = new JSONArray();
        crop_list = new JSONArray();

        currentTime = ApUtil.getCurrentTimeStamp();
        year();
        district();
        season();
    }

    private void click_listerner() {
        on_spot_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (year_list != null) {
                    AppUtility.getInstance().showListDialogIndex(year_list, 1, "Select Year", "year", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                }
            }
        });

        on_spot_district.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (district_list != null) {
                    AppUtility.getInstance().showListDialogIndex(district_list, 2, "Select District", "district_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                } else {
                    district();
                }
            }
        });

        on_spot_taluka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(district_id==0){
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this,"Please select district",Toast.LENGTH_SHORT).show();
                }else {
                    if (taluka_list != null) {
                        AppUtility.getInstance().showListDialogIndex(taluka_list, 3, "Select Taluka", "taluka_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                    } else {
                        taluka(district_id);
                    }
                }
            }
        });


        on_spot_revenue_circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(taluka_id==0){
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this,"Please select taluka",Toast.LENGTH_SHORT).show();
                }else {
                if (revenue_circle_list != null) {
                    AppUtility.getInstance().showListDialogIndex(revenue_circle_list, 4, "Select Revenue Circle", "revenue_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                } else {
                    revenue(taluka_id);
                }
                }
            }
        });

        on_spot_gram_panchayat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(revenue_id==0){
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this,"Please select revenue circle",Toast.LENGTH_SHORT).show();
                }else {
                    if (gram_panchayat_list != null) {
                        AppUtility.getInstance().showListDialogIndex(gram_panchayat_list, 5, "Select Gram Panchayat", "gram_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                    } else {
                        gram_panchayat(revenue_id);
                    }
                }
            }
        });

        on_spot_village.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (gram_panchayat_id == 0) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please select gram panchayat", Toast.LENGTH_SHORT).show();
                } else {
                    if (village_list != null) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 6, "Select Village", "village_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                    } else {
                        village(gram_panchayat_id);
                    }
                }
            }
        });

        on_spot_season_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (season_list != null) {
                    AppUtility.getInstance().showListDialogIndex(season_list, 7, "Select Season", "season_combo", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                } else {
                    season();
                }
            }
        });

        on_spot_crop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (crop_list != null) {
                    AppUtility.getInstance().showListDialogIndex(crop_list, 8, "Select Crop", "crop_name_en", "id", OnSpotPhysicalVerificationActivity.this, OnSpotPhysicalVerificationActivity.this);
                } else {
                    crop(season_id);
                }
            }
        });

        phy_veri_wbcis_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(OnSpotPhysicalVerificationActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OnSpotPhysicalVerificationActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OnSpotPhysicalVerificationActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        dept_phy_veri_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Save();
            }
        });

        on_spot_crop_age_application.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                crop_age_validation();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        });

        on_spot_crop_age_actual.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                crop_age_validation();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .resize(phy_veri_wbcis_iv.getWidth(), phy_veri_wbcis_iv.getHeight())
                                .centerCrop()
                                .into(phy_veri_wbcis_iv);
                        uploadImageOnServer(imagePath);

                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void year() {
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.phy_veri_year();
        api.postRequest(responseCall, this, 1);
    }

    private void district() {
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.phy_veri_district();
        api.postRequest(responseCall, this, 2);
    }

    private void taluka(int districtID) {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", districtID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void revenue(int talukaID) {
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id", talukaID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_revenue(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);

    }

    private void gram_panchayat(int revenueID) {
        JSONObject param = new JSONObject();
        try {
            param.put("revenue_id", revenueID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_gram_panchayat(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);

    }

    private void village(int gramID) {
        JSONObject param = new JSONObject();
        try {
            param.put("gram_id", gramID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_village(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    private void season() {
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.phy_veri_season();
        api.postRequest(responseCall, this, 7);
    }

    private void crop(int seasonID) {
        JSONObject param = new JSONObject();
        try {
            param.put("season_id", seasonID);
        } catch (Exception e) {

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_crop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);
    }

    private void uploadImageOnServer(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("revenue_id", String.valueOf(revenue_id));
            params.put("gram_id", String.valueOf(gram_panchayat_id));
            params.put("village_id", String.valueOf(village_id));

            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.phy_veri_save_image(partBody, params);
            api.postRequest(responseCall, this, 9);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void Save(){
        if(year_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select year", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_policy.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter policy number", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_app_no.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter application number", Toast.LENGTH_SHORT);
            toast.show();
        }else if(district_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select district", Toast.LENGTH_SHORT);
            toast.show();
        }else if(taluka_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select taluka", Toast.LENGTH_SHORT);
            toast.show();
        }else if(revenue_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select revenue circle", Toast.LENGTH_SHORT);
            toast.show();
        }else if (gram_panchayat_id==0) {
            Toast toast= Toast.makeText(getApplicationContext(), "Select gram panchayat", Toast.LENGTH_SHORT);
            toast.show();
        }else if(village_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select village", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_area_application.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter application area", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_area_actual.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter actual area", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_crop_age_application.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter actual age of crop", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_crop_age_actual.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter application age of crop", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_no_crop_plant_application.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter application crop plant", Toast.LENGTH_SHORT);
            toast.show();
        }else if(on_spot_no_crop_plant_actual.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Please enter actual crop plant", Toast.LENGTH_SHORT);
            toast.show();
        }else if(season_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select season", Toast.LENGTH_SHORT);
            toast.show();
        }else if(crop_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select crop", Toast.LENGTH_SHORT);
            toast.show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("fruit_policy", on_spot_policy.getText().toString().trim());
                param.put("application_no", on_spot_app_no.getText().toString().trim());
                param.put("year_id", year_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("revenue_id", revenue_id);
                param.put("gram_id", gram_panchayat_id);
                param.put("village_id", village_id);
                param.put("area_app", on_spot_area_application.getText().toString().trim());
                param.put("area_actual", on_spot_area_actual.getText().toString().trim());
                param.put("crop_age_app", on_spot_crop_age_application.getText().toString().trim());
                param.put("crop_age_actual", on_spot_crop_age_actual.getText().toString().trim());
                param.put("season_id", season_id);
                param.put("crop_id", crop_id);
                param.put("no_crop_plant_app", on_spot_no_crop_plant_application.getText().toString().trim());
                param.put("no_crop_plant_actual", on_spot_no_crop_plant_actual.getText().toString().trim());
                param.put("first_img_url",first_image_url);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.phy_veri_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 10);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            taluka_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            revenue_circle_list = jsonObject.getJSONArray("data");

                        }
                    }
                }
                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            gram_panchayat_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 6) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 7) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            season_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 8) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            crop_list = jsonObject.getJSONArray("data");

                        }
                    }
                }

                if (i == 9) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            first_image_url = data.getString("file_url");
                        }
                    }
                }

                if (i == 10) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Physical Verification - WBCIS")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    }
                }


            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            year_id = Integer.parseInt(s1);
            on_spot_year.setText(s);
        }
        if (i == 2) {
            district_id = Integer.parseInt(s1);
            on_spot_district.setText(s);
            on_spot_taluka.setText("Select");
            on_spot_revenue_circle.setText("Select");
            on_spot_gram_panchayat.setText("Select");
            on_spot_village.setText("Select");
            taluka_list = new JSONArray();
            taluka(district_id);
        }
        if (i == 3) {
            taluka_id = Integer.parseInt(s1);
            on_spot_taluka.setText(s);
            on_spot_revenue_circle.setText("Select");
            on_spot_gram_panchayat.setText("Select");
            on_spot_village.setText("Select");
            revenue_circle_list = new JSONArray();
            revenue(taluka_id);

        }
        if (i == 4) {
            revenue_id = Integer.parseInt(s1);
            on_spot_revenue_circle.setText(s);
            on_spot_gram_panchayat.setText("Select");
            on_spot_village.setText("Select");
            gram_panchayat_list = new JSONArray();
            gram_panchayat(revenue_id);
        }

        if (i == 5) {
            gram_panchayat_id = Integer.parseInt(s1);
            on_spot_gram_panchayat.setText(s);
            on_spot_village.setText("Select");
            village_list = new JSONArray();
            village(gram_panchayat_id);
        }

        if (i == 6) {
            village_id = Integer.parseInt(s1);
            on_spot_village.setText(s);
        }

        if (i == 7) {
            season_id = Integer.parseInt(s1);
            on_spot_season_tv.setText(s);
            crop_list = new JSONArray();
            on_spot_crop_tv.setText("Select");
            crop(season_id);
        }

        if (i == 8) {
            crop_id = Integer.parseInt(s1);
            crop_name = s;
            on_spot_crop_tv.setText(crop_name);
        }
    }

    private void crop_age_validation(){
        if (!on_spot_crop_age_application.getText().toString().trim().equalsIgnoreCase("")) {
            app_crop_age = on_spot_crop_age_application.getText().toString().trim();
            app_crop_age_int = Double.valueOf(app_crop_age);
            if (crop_name.contains("Banana")) {
                if (app_crop_age_int < 1) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else  if (crop_name.contains("Grape")) {
                if (app_crop_age_int < 2) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Cashew")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Mango")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Pomegranate")) {
                if (app_crop_age_int < 2.5) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Sweet Orange")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Orange")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Lime(Nimbu/Lemon)")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Sapkota (Chiku)")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }else if (crop_name.contains("Guava")) {
                if (app_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_application.setText("");
                }
            }
        }else if (!on_spot_crop_age_actual.getText().toString().trim().equalsIgnoreCase("")) {
            actual_crop_age = on_spot_crop_age_actual.getText().toString().trim();
            actual_crop_age_int = Double.valueOf(actual_crop_age);
            if (crop_name.contains("Banana")) {
                if (actual_crop_age_int < 1) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else  if (crop_name.contains("Grape")) {
                if (actual_crop_age_int < 2) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Cashew")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Mango")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Pomegranate")) {
                if (actual_crop_age_int < 2.5) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Sweet Orange")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Orange")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Lime(Nimbu/Lemon)")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Sapkota (Chiku)")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }else if (crop_name.contains("Guava")) {
                if (actual_crop_age_int < 3) {
                    Toast.makeText(OnSpotPhysicalVerificationActivity.this, "Please enter valid age for this crop", Toast.LENGTH_SHORT).show();
                    on_spot_crop_age_actual.setText("");
                }
            }
        }

    }

}
