/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class HostFarmerModel {

    private int host_farmer_id;
    private String farmer_name;
    private int plot_id;
    private String plot;
    private int village_id;
    private String village;
    private int crop_id;
    private int cropping_system_id;
    private String profile_pic;
    private JSONObject jsonObject;

    public HostFarmerModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getHost_farmer_id() {
        host_farmer_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "host_farmer_id");
        return host_farmer_id;
    }

    public String getFarmer_name() {
        farmer_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "farmer_name");
        return farmer_name;
    }

    public int getPlot_id() {
        plot_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "plot_id");
        return plot_id;
    }

    public String getPlot() {
        plot = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "plot");
        return plot;
    }

    public int getVillage_id() {
        village_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "village_id");
        return village_id;
    }

    public String getVillage() {
        village = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "village");
        return village;
    }


    public int getCrop_id() {
        crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "crop_id");
        return crop_id;
    }

    public int getCropping_system_id() {
        cropping_system_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "cropping_system_id");
        return cropping_system_id;
    }



    public String getProfile_pic() {
        profile_pic = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "profile_pic");
        return profile_pic;
    }


}
