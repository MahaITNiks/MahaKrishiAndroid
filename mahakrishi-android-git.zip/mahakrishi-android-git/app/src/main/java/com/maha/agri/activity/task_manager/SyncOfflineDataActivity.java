package com.maha.agri.activity.task_manager;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SyncOfflineDataAdapter;
import com.maha.agri.click_listener.sync_task_Click_Listener;
import com.maha.agri.database.DBHandler;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SyncOfflineDataActivity extends AppCompatActivity implements sync_task_Click_Listener, ApiCallbackCode {

    private DBHandler dbHandler;
    private RecyclerView sync_offline_recycler_view;
    private PreferenceManager preferenceManager;
    private SharedPref sharedPref;
    private JSONArray offline_Task_list,offline_Work_task_list;
    private Context context;
    private String imagePath,activityName,workDetails,farmername,cropname,areaname,sitelocations,user_id,activity_id,scheme_id,no_of_participants,id,currentTime;
    private int responseID;
    private File photoFile = null;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";

    private ManagePermission managePermissions;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final int APP_PERMISSION_CAMERA_REQUEST_CODE = 222;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync_offline_data);
        getSupportActionBar().setTitle("Offline Task List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SyncOfflineDataActivity.this);
        sharedPref = new SharedPref(SyncOfflineDataActivity.this);
        dbHandler = new DBHandler(this);
        currentTime = ApUtil.getCurrentTimeStamp();
        initialization();
        defaultConfig();

    }

    private void initialization() {
        sync_offline_recycler_view = (RecyclerView) findViewById(R.id.offlineTaskRView);
        sync_offline_recycler_view.setLayoutManager(new LinearLayoutManager(this));
        sync_offline_recycler_view.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));
        offline_Task_list = dbHandler.getAllOfflineSchemeWorkDetails();

        sync_offline_recycler_view.setAdapter(new SyncOfflineDataAdapter(preferenceManager,offline_Task_list,this));


    }



    private void defaultConfig() {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onSyncClick(String i_d) {

          id = i_d;

        for (int i=0;i<offline_Task_list.length();i++){
            try {
                JSONObject offline_work_details_json_object = offline_Task_list.getJSONObject(i);

                String itemId = offline_work_details_json_object.getString("id");
                if (itemId.equalsIgnoreCase(id)){

                    user_id = offline_work_details_json_object.getString("user_id");
                    String  sch_id = offline_work_details_json_object.getString("scheme_id");
                    if (sch_id.equalsIgnoreCase("")){
                        scheme_id = "0";
                    }else {
                        scheme_id = sch_id;
                    }
                    activity_id = offline_work_details_json_object.getString("activity_id");
                    activityName = offline_work_details_json_object.getString("activity_name");
                    farmername = offline_work_details_json_object.getString("farmer_name");
                    cropname = offline_work_details_json_object.getString("crop_name");
                    areaname = offline_work_details_json_object.getString("area");
                    sitelocations = offline_work_details_json_object.getString("site_location");
                    //id = offline_work_details_json_object.getString("id");
                    no_of_participants = offline_work_details_json_object.getString("no_of_participants");
                    workDetails = offline_work_details_json_object.getString("details");
                    imagePath = offline_work_details_json_object.getString("photo");
                    photoFile = new File(imagePath);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

          add_work_detail_to_server_Webservice();


        if (Build.VERSION.SDK_INT < 19) {
            uploadOfflineImageOnServer(imagePath);
        } else {
            if (checkUserPermission(APP_PERMISSION_REQUEST_CODE)) {
                uploadOfflineImageOnServer(imagePath);
            }
        }
    }


    private void add_work_detail_to_server_Webservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("schemeId", scheme_id);
            param.put("activityId", activity_id);
            param.put("userId", user_id);
            param.put("farmer_name", farmername);
            param.put("details", workDetails);
            param.put("crop_name", cropname);
            param.put("area",areaname);
            param.put("site_location", sitelocations);
            param.put("no_of_participants", no_of_participants);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ASSIGNED_VILLAGE_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.add_work_details_offline_url(requestBody);
        DebugLog.getInstance().d("sync_data_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("sync_data_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    private boolean checkUserPermission(int appPermissionCode) {

        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionFineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int permissionCoarseLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int permissionStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        ArrayList<String> listPermissionsNeeded = new ArrayList<>();

        if (permissionWrite != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionFineLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionCoarseLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        if (appPermissionCode == APP_PERMISSION_REQUEST_CODE ){
            if (!listPermissionsNeeded.isEmpty()) {
                managePermissions = new ManagePermission(this, listPermissionsNeeded, APP_PERMISSION_REQUEST_CODE);
                ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), APP_PERMISSION_REQUEST_CODE);
                return false;
            }
        }


        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case APP_PERMISSION_REQUEST_CODE: {
                boolean isPermissionsGranted = managePermissions.processPermissionsResult(requestCode, permissions, grantResults);
                if (isPermissionsGranted) {
                    uploadOfflineImageOnServer(imagePath);
                } else {
                    // toast("Permissions denied.")
                    managePermissions.checkPermission();
                }
            }
            break;

        }
    }






    private void uploadOfflineImageOnServer(String imagePath) {
        File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        if (!photoDirectory.exists()) {
            photoDirectory.mkdirs();
        }

        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("user_id", user_id);
            params.put("id", String.valueOf(responseID));


            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", String.valueOf(reqFile));

            /*RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload",imagePath);*/

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.add_work_details_image_offline_url(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {
                    if (jsonObject.getString("status").equals("200")) {
                        responseID = jsonObject.getInt("data");
                        UIToastMessage.show(this, jsonObject.getString("response"));
                        uploadOfflineImageOnServer(imagePath);

                        finish();
                        startActivity(getIntent());

                    } else {

                        UIToastMessage.show(this, jsonObject.getString("response"));

                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                        dbHandler.deleteWorkDetails(id);
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
