package com.maha.agri.ffs;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.ffs.adaptor.D_F_PreShowingVisitListAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_PreSowingVisitListActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {

    private PreferenceManager preferenceManager;
    private String reg_type;
    private String planId;
    private String cropID;
    private String cropVerityID;

    private TextView numOfVisitsTV;
    private RecyclerView preSowingRecyclerView;


    public static void expand(final View v, int duration, int targetHeight) {
        int prevHeight = v.getHeight();

        v.setVisibility(View.VISIBLE);
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }

    public static void collapse(final View v, int duration, int targetHeight) {
        int prevHeight = v.getHeight();
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_pre_sowing_visit_list);

        getSupportActionBar().setTitle("Pre Sowing Visits");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(D_F_PreSowingVisitListActivity.this);

        init();
        defaultConfig();
    }

    private void init() {
        numOfVisitsTV = (TextView) findViewById(R.id.numOfVisitsTV);
        preSowingRecyclerView = (RecyclerView) findViewById(R.id.preSowingRecyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        preSowingRecyclerView.setLayoutManager(linearLayoutManager);
    }

    private void defaultConfig() {

    }

    @Override
    protected void onResume() {
        super.onResume();

        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);
        cropID = AppSettings.getInstance().getValue(this, ApConstants.kCROP_ID_DEMO_FFS, ApConstants.kCROP_ID_DEMO_FFS);
        cropVerityID = AppSettings.getInstance().getValue(this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, ApConstants.kCROP_VERITY_ID_DEMO_FFS);

        getPreShowingVisit();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject) o;
        try {
            String visitName = jsonObject.getString("pre_visit_days");
            JSONArray actArray = jsonObject.getJSONArray("activities");
            Intent intent = new Intent(this, D_F_PreSowingActivityListActivity.class);
            intent.putExtra("visitName", visitName);
            intent.putExtra("ShowingActivities", actArray.toString());
            startActivity(intent);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void getPreShowingVisit() {
        JSONObject param = new JSONObject();
        try {
            param.put("plan_id", planId);
            param.put("crop_id", cropID);
            param.put("vareity_id", cropVerityID);
            param.put("reg_type", reg_type);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.getPreShowingList(requestBody);
        DebugLog.getInstance().d("get_pre_showing_list=" + responseCall.request().toString());
        DebugLog.getInstance().d("get_pre_showing_list=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        JSONArray preShowing_List = jsonObject.getJSONArray("data");
                        if (preShowing_List.length() > 0) {
                            D_F_PreShowingVisitListAdapter preShowingVisitListAdapter = new D_F_PreShowingVisitListAdapter(this, this, preShowing_List);
                            preSowingRecyclerView.setAdapter(preShowingVisitListAdapter);
                            numOfVisitsTV.setText(String.valueOf(preShowing_List.length()));
                        }
                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                        numOfVisitsTV.setText("0");
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
