package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;

public class AssignedLocationAdapter extends RecyclerView.Adapter<AssignedLocationAdapter.ViewHolder> {

    private Context context;
    private JSONArray mALocationArray;
    private OnMultiRecyclerItemClickListener mListener;

    public AssignedLocationAdapter(Context context, JSONArray aLocationArray, OnMultiRecyclerItemClickListener listener) {
        this.context = context;
        this.mALocationArray = aLocationArray;
        this.mListener = listener;
    }


    @Override
    public int getItemCount() {
        if (mALocationArray != null) {
            return mALocationArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public AssignedLocationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_assigned_location, viewGroup, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull AssignedLocationAdapter.ViewHolder viewHolder, int i) {
        try {
            viewHolder.onBind(mALocationArray.getJSONObject(i), i);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private final LinearLayout oNameLL,oDesiLL,oMobileLL;
        private TextView circleCodeTV, circleNameTV, officerNameTV, officerMobileTV,officerDesignationTv;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            circleCodeTV = (TextView) itemView.findViewById(R.id.circleCodeTV);
            circleNameTV = (TextView) itemView.findViewById(R.id.circleNameTV);
            officerNameTV = (TextView) itemView.findViewById(R.id.officerNameTV);
            officerMobileTV = (TextView) itemView.findViewById(R.id.officerMobileTV);
            officerDesignationTv = (TextView) itemView.findViewById(R.id.officerDesignationTV);
            oNameLL = (LinearLayout)itemView.findViewById(R.id.oNameLL);
            oDesiLL = (LinearLayout)itemView.findViewById(R.id.oDesiLL);
            oMobileLL = (LinearLayout)itemView.findViewById(R.id.oMobileLL);
        }


        public void onBind(final JSONObject jsonObject, int i) {

            circleCodeTV.setText(AppUtility.getInstance().sanitizeJSONObj(jsonObject, "location_code"));
            circleNameTV.setText(AppUtility.getInstance().sanitizeJSONObj(jsonObject, "location_name"));

            String fName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "first_name");
            String mName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "middle_name");
            String lName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "last_name");
            String name = (fName + " " + mName + " " + lName).trim();
            officerNameTV.setText(name);

            officerDesignationTv.setText(AppUtility.getInstance().sanitizeJSONObj(jsonObject, "name"));
            officerMobileTV.setText(AppUtility.getInstance().sanitizeJSONObj(jsonObject, "mobile"));

            if (!name.equalsIgnoreCase("")){
                oNameLL.setVisibility(View.VISIBLE);
                oDesiLL.setVisibility(View.VISIBLE);
                oMobileLL.setVisibility(View.VISIBLE);
            }else {
                oNameLL.setVisibility(View.GONE);
                oDesiLL.setVisibility(View.GONE);
                oMobileLL.setVisibility(View.GONE);
            }


            final String juniorRoleId = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "junior_role_id");
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!juniorRoleId.equalsIgnoreCase("")){
                        mListener.onMultiRecyclerViewItemClick(1, jsonObject);
                    }
                }
            });
        }


    }

}
