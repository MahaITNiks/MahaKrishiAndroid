/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.model.HostFarmerEditModel;
import com.maha.agri.util.AppString;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;

public class HostFarmerEditAdapter extends RecyclerView.Adapter<HostFarmerEditAdapter.ViewHolder> {


    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;


    public HostFarmerEditAdapter(Context mContext, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
    }


    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.recycler_host_farmer_edit, parent, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            holder.onBind(mDataArray.getJSONObject(position), listener);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView villNameTextView;
        private TextView farmerNameTextView;
        private TextView plotTextView;
        private ImageView editHostImageView;
        private ImageView editGuestImageView;


        public ViewHolder(View itemView) {
            super(itemView);

            villNameTextView = itemView.findViewById(R.id.villNameTextView);
            farmerNameTextView = itemView.findViewById(R.id.farmerNameTextView);
            plotTextView = itemView.findViewById(R.id.plotTextView);

            editHostImageView = itemView.findViewById(R.id.editHostImageView);
            editGuestImageView = itemView.findViewById(R.id.editGuestImageView);

        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            AppString appString = new AppString(mContext);
            HostFarmerEditModel model = new HostFarmerEditModel(jsonObject);

            String vill = appString.getVillage()+" "+model.getVillage_name();
            String name = appString.getHostFarmerName()+" "+model.getFirst_name()+" "+model.getMiddle_name()+" "+model.getLast_name();
            String plot = appString.getPlotNum()+" "+model.getPlot();

            villNameTextView.setText(vill);
            farmerNameTextView.setText(name);
            plotTextView.setText(plot);


            editHostImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onMultiRecyclerViewItemClick(2, jsonObject);

                }
            });


            editGuestImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onMultiRecyclerViewItemClick(3, jsonObject);

                }
            });



            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onMultiRecyclerViewItemClick(2, jsonObject);
                }
            });*/



        }

    }




}
