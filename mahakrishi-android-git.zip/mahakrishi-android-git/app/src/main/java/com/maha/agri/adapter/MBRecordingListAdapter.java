package com.maha.agri.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.model.MBRecordingModel;

import java.util.ArrayList;

public class MBRecordingListAdapter extends RecyclerView.Adapter<MBRecordingListAdapter.ViewHolder> {

    private ArrayList<MBRecordingModel> dataSet;
    public MBRecordingListAdapter(ArrayList<MBRecordingModel> dataSet) {
        this.dataSet = dataSet;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView mb_rcdg_background_single_image_view,mb_rcdg_single_image_view;
        private TextView name_single_text_view,level_single_text_view;

        public ViewHolder(View itemView) {
            super(itemView);
          /*  this.mb_rcdg_background_single_image_view = (ImageView)itemView.findViewById(R.id.mb_rcdg_background_single_image_view);*/
//            this.mb_rcdg_single_image_view = (ImageView)itemView.findViewById(R.id.mb_rcdg_single_image_view);
//            this.name_single_text_view = (TextView) itemView.findViewById(R.id.name_single_text_view);
//            this.level_single_text_view = (TextView)itemView.findViewById(R.id.level_single_text_view);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_mb_soil_report,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int listPosition) {
        TextView textViewName = holder.name_single_text_view;
        TextView textViewlevel = holder.level_single_text_view;
        ImageView imageView = holder.mb_rcdg_single_image_view;


        // holder.mb_rcdg_background_single_image_view.setImageResource(mb_rcdg_background[listPosition]);
        textViewName.setText(dataSet.get(listPosition).getName());
        textViewlevel.setText(dataSet.get(listPosition).getLevel());
        imageView.setImageResource(dataSet.get(listPosition).getImg());
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private MBRecordingListAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final MBRecordingListAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

}
