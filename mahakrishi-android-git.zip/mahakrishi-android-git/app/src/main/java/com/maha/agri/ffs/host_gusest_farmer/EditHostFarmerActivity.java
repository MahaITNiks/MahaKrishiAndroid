/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.host_gusest_farmer;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.enums.CroppingSystem;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.HostFarmerEditModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.helper.AIDecimalDigitsInputFilter;
import in.co.appinventor.services_api.helper.AIDigitsDoubleMinMaxFilter;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class EditHostFarmerActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {


    private TextView districtTextView;
    private TextView subDivTextView;
    private TextView talukaTextView;
    private TextView villTextView;
    private TextView plotTextView;

    private AppSession session;

    private int subDivID = 0;
    private int talukaID = 0;
    private int villageID = 0;
    private int plotID = 0;

    private EditText lNameEditText;
    private EditText fNameEditText;
    private EditText mNameEditText;
    private EditText ageEditText;
    private EditText mobEditText;
    private EditText surveyNoEditText;
    private EditText area8AEditText;
    private EditText landHoldingCatEditText;
    private TextView socialCatDropTextView;
    private int socialCatId = 0;
    private JSONArray mDataArray;
    private int genderId = -1;
    private int physicallyId = -1;
    private AppString appString;

    private TextView cropDropTextView;
    private LinearLayout interCropLinearLayout;
    private TextView interCropDropTextView;

    private EditText cropAreaEditText;
    private TextView irrigationDropTextView;
    private TextView soilTypeDropTextView;
    private int majorCropId = 0;
    private int interCropId = 0;
    private int irrigationId = 0;
    private int soilTypeId = 0;
    private JSONArray soleCropJSONArray = null;
    private JSONArray majorCropJSONArray = null;
    private JSONArray interCropJSONArray = null;
    private JSONArray irrigationJSONArray = null;
    private JSONArray soilTypeJSONArray = null;
    private int croppingSystem = CroppingSystem.SOLE.id();

    private EditText farmerNameEditText;
    private TextView controlCropDropTextView;
    private LinearLayout controlInterCropLinearLayout;
    private TextView controlInterCropDropTextView;
    private RadioButton yesRadioButton;
    private RadioButton noRadioButton;
    private int controlCroppingSystem = CroppingSystem.SOLE.id();

    private RadioButton soleRadioButton;
    private RadioButton interCropRadioButton;

    private EditText controlCropAreaEditText;
    private Boolean isIntercropTaken = false;
    private int controlMajorCropId = 0;
    private int controlInterCropId = 0;
    private HostFarmerEditModel model;
    private boolean isUpdated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_host_farmer);

        initComponents();
        setConfiguration();
    }


    private void initComponents() {

        session = new AppSession(this);
        appString = new AppString(this);

        districtTextView = findViewById(R.id.districtTextView);

        subDivTextView = findViewById(R.id.subDivTextView);
        talukaTextView = findViewById(R.id.talukaTextView);
        villTextView = findViewById(R.id.villTextView);
        plotTextView = findViewById(R.id.plotTextView);

        lNameEditText = findViewById(R.id.lNameEditText);
        fNameEditText = findViewById(R.id.fNameEditText);
        mNameEditText = findViewById(R.id.mNameEditText);
        ageEditText = findViewById(R.id.ageEditText);
        mobEditText = findViewById(R.id.mobEditText);
        surveyNoEditText = findViewById(R.id.surveyNoEditText);
        area8AEditText = findViewById(R.id.area8AEditText);
        landHoldingCatEditText = findViewById(R.id.landHoldingCatEditText);
        socialCatDropTextView = findViewById(R.id.socialCatDropTextView);

        // districtTextView.setText(session.getProfileModel().getDistrict_name());

    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isUpdated) {
                    EventBus.getDefault().post(new EventModel("update_1"));
                }
                finish();
            }
        });

        findViewById(R.id.updateButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateRequest();
            }
        });



        RadioGroup radioGroup = findViewById(R.id.genderRadioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                  @Override
                                                  public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                      if (checkedId == R.id.maleRadioButton) {
                                                          genderId = 1;
                                                      } else if (checkedId == R.id.femaleRadioButton) {
                                                          genderId = 2;
                                                      } else if (checkedId == R.id.transgenderRadioButton) {
                                                          genderId = 3;
                                                      }
                                                  }
                                              }
        );

        RadioGroup physicallyRadioGroup = findViewById(R.id.physicallyRadioGroup);
        physicallyRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                            @Override
                                                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                                if (checkedId == R.id.yesRadioButton) {
                                                                    physicallyId = 1;
                                                                } else if (checkedId == R.id.noRadioButton) {
                                                                    physicallyId = 0;
                                                                }
                                                            }
                                                        }
        );


        area8AEditText.setFilters(new InputFilter[]{new AIDecimalDigitsInputFilter(5, 2)});
        area8AEditText.setKeyListener(DigitsKeyListener.getInstance(true, true));
        area8AEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                try {
                    String value = editable.toString();

                    if (value.length() > 0) {

                        double val = Double.parseDouble(value);

                        if ((val >= 0.01) && (val <= 1.00)) {
                            landHoldingCatEditText.setText(appString.getLandMarginal());

                        } else if ((val >= 1) && (val <= 2.00)) {
                            landHoldingCatEditText.setText(appString.getLandSmall());

                        } else {
                            landHoldingCatEditText.setText(appString.getLandOthers());
                        }
                    } else {
                        landHoldingCatEditText.setText("");
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        });


        socialCatDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSocialCategory();
            }
        });



        //::TODO FFS Plot

        TextView irrigationTextView = findViewById(R.id.irrigationTextView);

        if (AppSettings.getInstance().getValue(this,ApConstants.kSLED_SEASON_ID,ApConstants.kSLED_SEASON_ID) == "1") {
            irrigationTextView.setText(getResources().getString(R.string.ffs_plot_source_of_pro_irr));
        } else {
            irrigationTextView.setText(getResources().getString(R.string.ffs_plot_source_of_irrigation));
        }


        cropDropTextView = findViewById(R.id.cropDropTextView);

        interCropLinearLayout = findViewById(R.id.interCropLinearLayout);
        interCropDropTextView = findViewById(R.id.interCropDropTextView);

        cropAreaEditText = findViewById(R.id.cropAreaEditText);
        irrigationDropTextView = findViewById(R.id.irrigationDropTextView);
        soilTypeDropTextView = findViewById(R.id.soilTypeDropTextView);

        RadioGroup ffsRadioGroup = findViewById(R.id.ffsRadioGroup);

        ffsRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                     @Override
                                                     public void onCheckedChanged(RadioGroup group, int checkedId) {

                                                         if (checkedId == R.id.ffsSoleRadioButton) {
                                                             croppingSystem = CroppingSystem.SOLE.id();
                                                             cropDropTextView.setText("");
                                                             interCropLinearLayout.setVisibility(View.GONE);
                                                             majorCropId = 0;
                                                             interCropId = 0;

                                                         } else {
                                                             croppingSystem = CroppingSystem.INTER_CROP.id();
                                                             interCropLinearLayout.setVisibility(View.VISIBLE);
                                                             cropDropTextView.setText("");
                                                             fetchMajorCropMasterData();

                                                             majorCropId = 0;
                                                             interCropId = 0;
                                                         }
                                                     }
                                                 }
        );


        cropAreaEditText.setFilters(new InputFilter[]{new AIDigitsDoubleMinMaxFilter(00.00, 00.40, 5, 2)});
        cropDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMajorCrop();
            }
        });

        interCropDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInterCrop();
            }
        });

        irrigationDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showIrrigation();
            }
        });

        soilTypeDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSoilType();
            }
        });



        //::TODO COntrol plot


        farmerNameEditText = findViewById(R.id.farmerNameEditText);
        controlCropDropTextView = findViewById(R.id.controlCropDropTextView);
        controlInterCropLinearLayout = findViewById(R.id.controlInterCropLinearLayout);
        controlInterCropDropTextView = findViewById(R.id.controlInterCropDropTextView);

        yesRadioButton = findViewById(R.id.yesRadioButton);
        noRadioButton = findViewById(R.id.noRadioButton);


        soleRadioButton = findViewById(R.id.soleRadioButton);
        interCropRadioButton = findViewById(R.id.interCropRadioButton);

        soleRadioButton.setClickable(false);
        interCropRadioButton.setClickable(false);

        controlCropAreaEditText = findViewById(R.id.controlCropAreaEditText);


        RadioGroup questionRadioGroup = findViewById(R.id.questionRadioGroup);
        questionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                          @Override
                                                          public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                              if (checkedId == R.id.yesRadioButton) {
                                                                  isIntercropTaken = true;
                                                                  controlCroppingSystem = CroppingSystem.INTER_CROP.id();
                                                                  controlCropDropTextView.setText("");
                                                                  interCropRadioButton.setChecked(true);
                                                                  soleRadioButton.setChecked(false);
                                                                  controlInterCropLinearLayout.setVisibility(View.VISIBLE);
                                                                  fetchControlMajorCropMasterData();
                                                              } else {
                                                                  isIntercropTaken = false;
                                                                  controlCroppingSystem = CroppingSystem.SOLE.id();
                                                                  controlCropDropTextView.setText("");
                                                                  controlInterCropLinearLayout.setVisibility(View.GONE);
                                                                  interCropRadioButton.setChecked(false);
                                                                  soleRadioButton.setChecked(true);
                                                                  fetchControlMajorCropMasterData();
                                                              }
                                                          }
                                                      }
        );


        controlCropAreaEditText.setFilters(new InputFilter[]{new AIDigitsDoubleMinMaxFilter(00.00, 00.40, 5, 2)});


        controlCropDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showControlMajorCrop();
            }
        });
        controlInterCropDropTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showControlInterCrop();
            }
        });

        String data = null;
        if (getIntent().getStringExtra("mDetails") != null) {
            data = getIntent().getStringExtra("mDetails");
        }
        try {
            JSONObject jsonObject = new JSONObject(data);
            model = new HostFarmerEditModel(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        subDivTextView.setText(model.getSubdivision_name());
        subDivID = model.getSubdivision_id();

        talukaTextView.setText(model.getTaluka_name());
        talukaID = model.getTaluka_id();

        villTextView.setText(model.getVillage_name());
        villageID = model.getVillage_id();

        plotTextView.setText(model.getPlot());
        plotID = model.getPlot_id();


        lNameEditText.setText(model.getLast_name());
        fNameEditText.setText(model.getFirst_name());
        mNameEditText.setText(model.getMiddle_name());

        if (model.getGender().equalsIgnoreCase("1")) {
            RadioButton maleRadioButton = findViewById(R.id.maleRadioButton);
            maleRadioButton.setChecked(true);
        }

        if (model.getGender().equalsIgnoreCase("2")) {
            RadioButton femaleRadioButton = findViewById(R.id.femaleRadioButton);
            femaleRadioButton.setChecked(true);
        }

        if (model.getGender().equalsIgnoreCase("3")) {
            RadioButton transgenderRadioButton = findViewById(R.id.transgenderRadioButton);
            transgenderRadioButton.setChecked(true);
        }

        genderId = Integer.parseInt(model.getGender());

        ageEditText.setText(String.valueOf(model.getAge()));
        mobEditText.setText(model.getMobile());
        surveyNoEditText.setText(model.getSurvey_number());
        area8AEditText.setText(model.getArea_8a());

        double val = Double.parseDouble(model.getArea_8a());
        if( (val >= 0.01) && (val <= 1.00)) {
            landHoldingCatEditText.setText(appString.getLandMarginal());

        } else if( (val >= 1) && (val <= 2.00) ) {
            landHoldingCatEditText.setText(appString.getLandSmall());

        }  else  {
            landHoldingCatEditText.setText(appString.getLandOthers());
        }


        socialCatDropTextView.setText(model.getSocial_category_name());
        socialCatId = model.getSocial_category_id();

        if (model.getPhysically_challenged() == 1) {
            RadioButton pYesRadioButton = findViewById(R.id.pYesRadioButton);
            pYesRadioButton.setChecked(true);
        }

        if (model.getPhysically_challenged() == 0) {
            RadioButton pNoRadioButton = findViewById(R.id.pNoRadioButton);
            pNoRadioButton.setChecked(true);
        }
        physicallyId = model.getPhysically_challenged();


        if (model.getCropping_system_id() == 1) {
            RadioButton ffsSoleRadioButton = findViewById(R.id.ffsSoleRadioButton);
            ffsSoleRadioButton.setChecked(true);
        }
        if (model.getCropping_system_id() == 2) {
            RadioButton ffsInterCropRadioButton = findViewById(R.id.ffsInterCropRadioButton);
            ffsInterCropRadioButton.setChecked(true);
        }
        croppingSystem = model.getCropping_system_id();

        cropDropTextView.setText(model.getCrop_name());
        majorCropId = model.getCrop_id();

        interCropDropTextView.setText(model.getInter_crop_name());
        interCropId = model.getInter_crop_id();

        cropAreaEditText.setText(model.getArea_under_crop());

        irrigationDropTextView.setText(model.getIrrigation_name());
        irrigationId = model.getIrrigation_id();

        soilTypeDropTextView.setText(model.getSoil_type_name());
        soilTypeId = model.getSoil_type_id();

        farmerNameEditText.setText(model.getControl_plot_farmer_name());

        if (model.getControl_plot_cropping_system_id() == 1) {
            RadioButton noRadioButton = findViewById(R.id.noRadioButton);
            noRadioButton.setChecked(true);
            RadioButton soleRadioButton = findViewById(R.id.soleRadioButton);
            soleRadioButton.setChecked(true);
        }

        if (model.getControl_plot_cropping_system_id() == 2) {

            RadioButton yesRadioButton = findViewById(R.id.yesRadioButton);
            yesRadioButton.setChecked(true);
            RadioButton interCropRadioButton = findViewById(R.id.interCropRadioButton);
            interCropRadioButton.setChecked(true);
        }
        controlCroppingSystem = model.getControl_plot_cropping_system_id();
        controlCropDropTextView.setText(model.getControl_plot_crop_name());
        controlMajorCropId = model.getControl_plot_crop_id();
        controlInterCropDropTextView.setText(model.getControl_plot_inter_crop_name());
        controlInterCropId = model.getControl_plot_inter_crop_id();
        controlCropAreaEditText.setText(model.getControl_plot_area_under_crop());

        fetchSocialCategoryMasterData();

        fetchMajorCropMasterData();
        fetchIrrigationMasterData();
        fetchSoilTypeMasterData();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (isUpdated) {
                    EventBus.getDefault().post(new EventModel("update_1"));
                }
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }


    private void showSocialCategory() {
        if (mDataArray == null) {
            fetchSocialCategoryMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(mDataArray, 5, "Select Social Category", "name", "id", this, this);
        }
    }


    private void showMajorCrop() {

        if (croppingSystem == CroppingSystem.SOLE.id()) {
            if (soleCropJSONArray == null) {
                fetchMajorCropMasterData();
            } else {
                AppUtility.getInstance().showListDialogIndex(soleCropJSONArray, 6, "Select Sole Crop", "name", "id", this, this);
            }

        } else {
            if (majorCropJSONArray == null) {
                fetchMajorCropMasterData();
            } else {

                AppUtility.getInstance().showListDialogIndex(majorCropJSONArray, 6, "Select Major Crop", "name", "id", this, this);
            }
        }

    }

    private void showInterCrop() {
        if (interCropJSONArray == null) {
            fetchMajorCropMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(interCropJSONArray, 7, "Select Inter Crop", "name", "id", this, this);
        }
    }

    private void showControlMajorCrop() {

        if (controlCroppingSystem == CroppingSystem.SOLE.id()) {
            if (soleCropJSONArray == null) {
                fetchMajorCropMasterData();
            } else {
                AppUtility.getInstance().showListDialogIndex(soleCropJSONArray, 10, "Select Sole Crop", "name", "id", this, this);
            }

        } else {
            if (majorCropJSONArray == null) {
                fetchMajorCropMasterData();
            } else {

                AppUtility.getInstance().showListDialogIndex(majorCropJSONArray, 10, "Select Major Crop", "name", "id", this, this);
            }
        }

    }

    private void showControlInterCrop() {
        if (interCropJSONArray == null) {
            fetchMajorCropMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(interCropJSONArray, 11, "Select Inter Crop", "name", "id", this, this);
        }
    }


    private void showIrrigation() {
        if (irrigationJSONArray == null) {
            fetchIrrigationMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(irrigationJSONArray, 8, "Select Irrigation", "name", "id", this, this);
        }
    }


    private void showSoilType() {
        if (soilTypeJSONArray == null) {
            fetchSoilTypeMasterData();
        } else {
            AppUtility.getInstance().showListDialogIndex(soilTypeJSONArray, 9, "Select Soil Type", "name", "id", this, this);

        }
    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {


        if (i == 5) {
            socialCatId = Integer.parseInt(s1);
            socialCatDropTextView.setText(s);
        }


        if (i == 6) {

            if (croppingSystem == CroppingSystem.SOLE.id()) {
                majorCropId = Integer.parseInt(s1);
                cropDropTextView.setText(s);

            } else {
                majorCropId = Integer.parseInt(s1);
                cropDropTextView.setText(s);
                interCropId = 0;
                interCropDropTextView.setText("");
            }
        }

        if (i == 7) {
            interCropId = Integer.parseInt(s1);
            interCropDropTextView.setText(s);
        }


        if (i == 8) {
            irrigationId = Integer.parseInt(s1);
            irrigationDropTextView.setText(s);
        }

        if (i == 9) {
            soilTypeId = Integer.parseInt(s1);
            soilTypeDropTextView.setText(s);
        }


        if (i == 10) {

            if (croppingSystem == CroppingSystem.SOLE.id()) {
                controlMajorCropId = Integer.parseInt(s1);
                controlCropDropTextView.setText(s);

            } else {
                controlMajorCropId = Integer.parseInt(s1);
                controlCropDropTextView.setText(s);
                controlInterCropId = 0;
                controlInterCropDropTextView.setText("");
            }
        }

        if (i == 11) {
            controlInterCropId = Integer.parseInt(s1);
            controlInterCropDropTextView.setText(s);
        }


    }



    private void fetchSocialCategoryMasterData() {

        String url = APIServices.kSocialCat;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                mDataArray = response.getData();
                            } else {
                                UIToastMessage.show(EditHostFarmerActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    //::TODO FFS Plot Details


    private void fetchMajorCropMasterData() {

        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("crop_season_id", AppSettings.getInstance().getValue(this, ApConstants.kSLED_SEASON_ID,ApConstants.kSLED_SEASON_ID));
            jsonObject.put("cropping_system_id", croppingSystem);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchControlMajorCropMasterData() {

        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("season_id", AppSettings.getInstance().getValue(this,ApConstants.kSLED_SEASON_ID,ApConstants.kSLED_SEASON_ID));
            jsonObject.put("cropping_system_id", controlCroppingSystem);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 51);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchIrrigationMasterData() {

        String url = APIServices.kIrrigation;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                irrigationJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(EditHostFarmerActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }

    private void fetchSoilTypeMasterData() {

        String url = APIServices.kSoilTypes;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                soilTypeJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(EditHostFarmerActivity.this, response.getMsg());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    private void updateRequest() {

        String lName = lNameEditText.getText().toString();
        String fName = fNameEditText.getText().toString();
        String mName = mNameEditText.getText().toString();
        String age = ageEditText.getText().toString();
        String mob = mobEditText.getText().toString();
        String survey = surveyNoEditText.getText().toString();
        String area8a = area8AEditText.getText().toString();
        String landHolding = landHoldingCatEditText.getText().toString();

        String cropArea = cropAreaEditText.getText().toString();

        String farmerName = farmerNameEditText.getText().toString();
        String controlCropArea = controlCropAreaEditText.getText().toString();


        if (subDivID == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_village_sub_err));

        } else if (talukaID == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_village_taluka_err));

        } else if (villageID == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_village_vill_err));

        } else if (plotID == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_village_plot_err));

        } else if (lName.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_lname_err));

        } else if (fName.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_fname_err));

        } else if (mName.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_mname_err));

        } else if (genderId == -1) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_gender_err));

        } else if (age.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_age_err));

        } else if (age.length() < 2) {
            UIToastMessage.show(this, "Please enter valid age");

        } else if (Integer.parseInt(age) < 15) {
            UIToastMessage.show(this, "Your age should be greater than 15 year");

        } else if (mob.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_mob_err));

        } else if (!AppUtility.getInstance().isValidPhoneNumber(mob)) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_valid_mob_err));

        } else if (survey.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_survey_err));

        } else if (area8a.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_area_err));

        } else if (landHolding.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_land_err));

        } else if (socialCatId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.host_farmer_reg_social_err));

        } else if (physicallyId == -1) {
            UIToastMessage.show(this, "Please select physically challenged");

        } else if (majorCropId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_err));

        } else if (croppingSystem == CroppingSystem.INTER_CROP.id() && interCropId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_inter_err));

        } else if (cropArea.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_area_err));

        } else if (!(Double.parseDouble(cropArea) > 0 && Double.parseDouble(cropArea) <= 0.40)) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_area_err));

        } else if (irrigationId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_irrigation_err));

        } else if (soilTypeId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_soil_err));

        } else if (farmerName.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_farmer_name_err));

        } else if (!yesRadioButton.isChecked() && !noRadioButton.isChecked()) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_q_err));

        } else if (majorCropId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_err));

        } else if (controlCroppingSystem == CroppingSystem.INTER_CROP.id() && controlInterCropId == 0) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_inter_err));

        } else if (controlCropArea.isEmpty()) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_area_err));

        } else if (!(Double.parseDouble(controlCropArea) > 0 && Double.parseDouble(controlCropArea) <= 0.40)) {
            UIToastMessage.show(this, getResources().getString(R.string.ffs_plot_crop_area_err));

        } else {

            try {

                JSONObject jsonObject = new JSONObject();

                jsonObject.put("user_id", model.getHost_farmer_id());

                jsonObject.put("last_name", lName);
                jsonObject.put("first_name", fName);
                jsonObject.put("middle_name", mName);
                jsonObject.put("gender", genderId);

                jsonObject.put("age", age);

                jsonObject.put("mobile", mob);
                jsonObject.put("social_category_id", socialCatId);
                jsonObject.put("physically_challenged", physicallyId);

                jsonObject.put("survey_number", survey);
                jsonObject.put("area_8a", area8a);
                jsonObject.put("land_holding_cat", landHolding);
                jsonObject.put("village_id", villageID);

                jsonObject.put("cropping_system_id", croppingSystem);
                jsonObject.put("plot_id", plotID);
                jsonObject.put("crop_id", majorCropId);
                jsonObject.put("inter_crop_id", interCropId);
                jsonObject.put("area_under_crop", cropArea);
                jsonObject.put("irrigation_id", irrigationId);
                jsonObject.put("soil_type_id", soilTypeId);

                jsonObject.put("control_plot_farmer_name", farmerName);
                jsonObject.put("control_plot_cropping_system_id", controlCroppingSystem);
                jsonObject.put("control_plot_crop_id", controlMajorCropId);
                jsonObject.put("control_plot_inter_crop_id", controlInterCropId);
                jsonObject.put("control_plot_area_under_crop", controlCropArea);

                jsonObject.put("lat","");
                jsonObject.put("lon", "");
                /*jsonObject.put("lat", String.valueOf(appLocationManager.getLatitude()));
                jsonObject.put("lon", String.valueOf(appLocationManager.getLongitude()));*/

                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.updateHostFarmer(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 66);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {


            if (i == 5 && jsonObject != null) {

                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {

                    if (croppingSystem == CroppingSystem.SOLE.id()) {
                        soleCropJSONArray = response.getData();

                    }/* else {
                        JSONObject jsonObject1 = response.getData();

                        majorCropJSONArray = jsonObject1.getJSONArray("majorcrop");
                        interCropJSONArray = jsonObject1.getJSONArray("intercrop");

                    }*/


                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

            if (i == 51 && jsonObject != null) {

                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {

                    if (controlCroppingSystem == CroppingSystem.SOLE.id()) {
                        soleCropJSONArray = response.getData();

                    }/* else {
                        JSONObject jsonObject1 = response.getData();

                        majorCropJSONArray = jsonObject1.getJSONArray("majorcrop");
                        interCropJSONArray = jsonObject1.getJSONArray("intercrop");
                    }*/


                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }


            if (i == 66 && jsonObject != null) {

                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    isUpdated = true;
                    UIToastMessage.show(this, response.getMsg());
                } else {
                    isUpdated = false;
                    UIToastMessage.show(this, response.getMsg());
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}