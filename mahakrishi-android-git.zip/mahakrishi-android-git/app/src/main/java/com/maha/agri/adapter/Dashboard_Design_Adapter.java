package com.maha.agri.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;

public class Dashboard_Design_Adapter extends RecyclerView.Adapter<Dashboard_Design_Adapter.MyViewHolder>  {
    private int[]  dash_icon;
    private String[] dash_title;
    private Context context;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView dash_single_image_view;
        private TextView dash_single_text_view;



        public MyViewHolder(View itemView) {
            super(itemView);
            this.dash_single_image_view = itemView.findViewById(R.id.dash_single_image_view);
            this.dash_single_text_view = itemView.findViewById(R.id.dash_single_text_view);

        }
    }

    public Dashboard_Design_Adapter(int[] dash_icon, String[] dash_title, Context context) {
        this.dash_icon = dash_icon;
        this.dash_title = dash_title;
        this.context = context;

    }

    @Override
    public Dashboard_Design_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                             int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dash_design_single_item, parent, false);

        Dashboard_Design_Adapter.MyViewHolder myViewHolder = new Dashboard_Design_Adapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final Dashboard_Design_Adapter.MyViewHolder holder, final int listPosition) {
        holder.dash_single_image_view.setImageResource(dash_icon[listPosition]);
        holder.dash_single_text_view.setText(dash_title[listPosition]);

    }

    @Override
    public int getItemCount() {
        return dash_title.length;
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private Dashboard_Design_Adapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final Dashboard_Design_Adapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
