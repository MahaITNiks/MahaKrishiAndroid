package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.PhyVerfCompTileAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ComponentTilesActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView phy_veri_comp_tiles_rv;
    private JSONArray component_list;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component_tiles);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Component Tiles");
        preferenceManager = new PreferenceManager(ComponentTilesActivity.this);
        sharedPref = new SharedPref(ComponentTilesActivity.this);
        phy_veri_comp_tiles_rv = (RecyclerView) findViewById(R.id.phy_veri_comp_tiles_rv);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        phy_veri_comp_tiles_rv.setLayoutManager(gridLayoutManager);
        component_tiles_service();
        functionality();

        component_list = new JSONArray();
    }
    private void functionality(){

        phy_veri_comp_tiles_rv.addOnItemTouchListener(new PhyVerfCompTileAdapter.RecyclerTouchListener(this, phy_veri_comp_tiles_rv, new PhyVerfCompTileAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent int_1 = new Intent(ComponentTilesActivity.this, AssignFarmerListActivity.class);
                int_1.putExtra("component_list",component_list.toString());
                int_1.putExtra("position",position);
                startActivity(int_1);
            }
            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }
    private void component_tiles_service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_component_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            component_list = jsonObject.getJSONArray("data");
                            phy_veri_comp_tiles_rv.setAdapter(new PhyVerfCompTileAdapter(this,component_list));
                        }
                    }

                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}