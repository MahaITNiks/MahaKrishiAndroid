package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class RicePheromone extends AppCompatActivity implements ApiCallbackCode {
    private Button btn_submit_rice;

    private TextView otherpest_tv_rice;

    private EditText pheromone_trap1_rice,pheromone_trap2_rice,comments_rice,otherpest_et_rice,tradename_insecticide_rice,quantity_used_acre_insecticide_rice,tradename_fungicide_rice,quantity_used_acre_fungicide_rice,
            tradename_weedicide_rice,quantity_used_acre_weedicide_rice,fertilizer_rice_N,fertilizer_rice_P,fertilizer_rice_K,fertilizername_rice,quantity_used_acre_fertilizer_rice;

    private ImageView pheromone_trap1_photo_rice,pheromone_trap2_photo_rice,pest_rice_photo,crop_growth_rice_photo;

    private RadioGroup insecticide_radio_group_rice,fungicide_radio_group_rice,weedicide_radio_group_rice,fertilizer_radio_group_rice,radio_group_intercultural_rice,radio_group_irrigation_field_rice;

    private RadioButton insecticide_rice_yes,insecticide_rice_no,fungicide_rice_yes,fungicide_rice_no,weedicide_rice_yes,weedicide_rice_no,fertilizer_rice_yes,fertilizer_rice_no,weeding_rice_rb,
            hoeing_rice_rb,detopping_rice_rb,none_rice_rb,irrigation_rice_yes,irrigation_rice_no;

    private Spinner sp_technicalname_insecticide_rice,sp_technicalname_fungicide_rice,sp_weedicide_technicalname_rice,sp_irrigation_given_rice;

    private LinearLayout ll_insecticide_layout_rice,ll_fungicide_layout_rice,ll_weedicide_layout_rice,ll_fertilizer_layout_rice;

    private RelativeLayout irrigation_layout_rice;

    private String insecticide = "", fungicide = "", weedicide = "", fertilizer = "", irrigation = "", intercultural = "";

    private String insecticide_tech_name="", fungicide_tech_name="", weedicide_tech_name="", irrigation_name="";

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private AppLocationManager locationManager;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private File photoFile3 = null;
    private File photoFile4 = null;
    private String imagePath1, imagePath2, imagePath3, imagePath4, type;
    private String image_1_file_name,image_2_file_name,image_3_file_name,image_4_file_name;
    public double lat,lang;
    int count = 1;

    private int district_id, taluka_id, village_id, farmer_id;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_rice_pheromone);
        getSupportActionBar().setTitle("CROPSAP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        preferenceManager = new PreferenceManager(RicePheromone.this);
        sharedPref = new SharedPref(RicePheromone.this);
        locationManager = new AppLocationManager(this);

        initView();
        setListners();

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
    }

    private void initView() {
        //Button
        otherpest_tv_rice =(TextView) findViewById(R.id.otherpest_tv_rice);
        btn_submit_rice = (Button)findViewById(R.id.btn_submit_rice);
        //Edittext
        pheromone_trap1_rice = (EditText)findViewById(R.id.pheromone_trap1_rice);
        pheromone_trap2_rice = (EditText)findViewById(R.id.pheromone_trap2_rice);
        comments_rice = (EditText)findViewById(R.id.comments_rice);
        otherpest_et_rice = (EditText)findViewById(R.id.otherpest_et_rice);
        tradename_insecticide_rice = (EditText)findViewById(R.id.tradename_insecticide_rice);
        quantity_used_acre_insecticide_rice = (EditText)findViewById(R.id.quantity_used_acre_insecticide_rice);
        tradename_fungicide_rice = (EditText)findViewById(R.id.tradename_fungicide_rice);
        quantity_used_acre_fungicide_rice = (EditText)findViewById(R.id.quantity_used_acre_fungicide_rice);
        tradename_weedicide_rice = (EditText)findViewById(R.id.tradename_weedicide_rice);
        quantity_used_acre_weedicide_rice = (EditText)findViewById(R.id.quantity_used_acre_weedicide_rice);
        fertilizer_rice_N = (EditText)findViewById(R.id.fertilizer_rice_N);
        fertilizer_rice_P = (EditText)findViewById(R.id.fertilizer_rice_P);
        fertilizer_rice_K = (EditText)findViewById(R.id.fertilizer_rice_K);
        fertilizername_rice = (EditText)findViewById(R.id.fertilizername_rice);
        quantity_used_acre_fertilizer_rice = (EditText)findViewById(R.id.quantity_used_acre_fertilizer_rice);
        //Imageview
        pheromone_trap1_photo_rice = (ImageView) findViewById(R.id.pheromone_trap1_photo_rice);
        pheromone_trap2_photo_rice = (ImageView) findViewById(R.id.pheromone_trap2_photo_rice);
        pest_rice_photo = (ImageView) findViewById(R.id.pest_rice_photo);
        crop_growth_rice_photo = (ImageView) findViewById(R.id.crop_growth_rice_photo);
        //Radiogroup
        insecticide_radio_group_rice = (RadioGroup) findViewById(R.id.insecticide_radio_group_rice);
        fungicide_radio_group_rice = (RadioGroup) findViewById(R.id.fungicide_radio_group_rice);
        weedicide_radio_group_rice = (RadioGroup) findViewById(R.id.weedicide_radio_group_rice);
        fertilizer_radio_group_rice = (RadioGroup) findViewById(R.id.fertilizer_radio_group_rice);
        radio_group_intercultural_rice = (RadioGroup) findViewById(R.id.radio_group_intercultural_rice);
        radio_group_irrigation_field_rice = (RadioGroup) findViewById(R.id.radio_group_irrigation_field_rice);
        //Radiobutton
        insecticide_rice_yes = (RadioButton) findViewById(R.id.insecticide_rice_yes);
        insecticide_rice_no = (RadioButton) findViewById(R.id.insecticide_rice_no);
        fungicide_rice_yes = (RadioButton) findViewById(R.id.fungicide_rice_yes);
        fungicide_rice_no = (RadioButton) findViewById(R.id.fungicide_rice_no);
        weedicide_rice_yes = (RadioButton) findViewById(R.id.weedicide_rice_yes);
        weedicide_rice_no = (RadioButton) findViewById(R.id.weedicide_rice_no);
        fertilizer_rice_yes = (RadioButton) findViewById(R.id.fertilizer_rice_yes);
        fertilizer_rice_no = (RadioButton) findViewById(R.id.fertilizer_rice_no);
        weeding_rice_rb = (RadioButton) findViewById(R.id.weeding_rice_rb);
        hoeing_rice_rb = (RadioButton) findViewById(R.id.hoeing_rice_rb);
        detopping_rice_rb = (RadioButton) findViewById(R.id.detopping_rice_rb);
        none_rice_rb = (RadioButton) findViewById(R.id.none_rice_rb);
        irrigation_rice_yes = (RadioButton) findViewById(R.id.irrigation_rice_yes);
        irrigation_rice_no = (RadioButton) findViewById(R.id.irrigation_rice_no);
        //Spinner
        sp_technicalname_insecticide_rice = (Spinner) findViewById(R.id.sp_technicalname_insecticide_rice);
        sp_technicalname_fungicide_rice = (Spinner) findViewById(R.id.sp_technicalname_fungicide_rice);
        sp_weedicide_technicalname_rice = (Spinner) findViewById(R.id.sp_weedicide_technicalname_rice);
        sp_irrigation_given_rice = (Spinner) findViewById(R.id.sp_irrigation_given_rice);
        //LL
        ll_insecticide_layout_rice = (LinearLayout)findViewById(R.id.ll_insecticide_layout_rice);
        ll_fungicide_layout_rice = (LinearLayout)findViewById(R.id.ll_fungicide_layout_rice);
        ll_weedicide_layout_rice = (LinearLayout)findViewById(R.id.ll_weedicide_layout_rice);
        ll_fertilizer_layout_rice = (LinearLayout)findViewById(R.id.ll_fertilizer_layout_rice);
        irrigation_layout_rice = (RelativeLayout)findViewById(R.id.irrigation_layout_rice);

    }

    private void setListners() {

        otherpest_tv_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(otherpest_et_rice.getVisibility() == View.VISIBLE) {
                    otherpest_et_rice.setVisibility(View.GONE);
                }else {
                    otherpest_et_rice.setVisibility(View.VISIBLE);
                }
            }
        });

        insecticide_radio_group_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.insecticide_rice_yes:
                        insecticide_rice_yes.setChecked(true);
                        ll_insecticide_layout_rice.setVisibility(View.VISIBLE);
                        insecticide = insecticide_rice_yes.getText().toString();
                        break;

                    case R.id.insecticide_rice_no:
                        insecticide_rice_no.setChecked(true);
                        ll_insecticide_layout_rice.setVisibility(View.GONE);
                        insecticide = insecticide_rice_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_insecticide_rice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                insecticide_tech_name = sp_technicalname_insecticide_rice.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fungicide_radio_group_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fungicide_rice_yes:
                        fungicide_rice_yes.setChecked(true);
                        ll_fungicide_layout_rice.setVisibility(View.VISIBLE);
                        fungicide = fungicide_rice_yes.getText().toString();
                        break;

                    case R.id.fungicide_rice_no:
                        fungicide_rice_no.setChecked(true);
                        ll_fungicide_layout_rice.setVisibility(View.GONE);
                        fungicide = fungicide_rice_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_fungicide_rice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                fungicide_tech_name = sp_technicalname_fungicide_rice.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        weedicide_radio_group_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.weedicide_rice_yes:
                        weedicide_rice_yes.setChecked(true);
                        ll_weedicide_layout_rice.setVisibility(View.VISIBLE);
                        weedicide = weedicide_rice_yes.getText().toString();
                        break;

                    case R.id.weedicide_rice_no:
                        weedicide_rice_no.setChecked(true);
                        ll_weedicide_layout_rice.setVisibility(View.GONE);
                        weedicide = weedicide_rice_no.getText().toString();
                        break;
                }
            }
        });

        sp_weedicide_technicalname_rice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                weedicide_tech_name = sp_weedicide_technicalname_rice.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fertilizer_radio_group_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fertilizer_rice_yes:
                        fertilizer_rice_yes.setChecked(true);
                        ll_fertilizer_layout_rice.setVisibility(View.VISIBLE);
                        fertilizer = fertilizer_rice_yes.getText().toString();
                        break;

                    case R.id.fertilizer_rice_no:
                        fertilizer_rice_no.setChecked(true);
                        ll_fertilizer_layout_rice.setVisibility(View.GONE);
                        fertilizer = fertilizer_rice_no.getText().toString();
                        break;
                }
            }
        });

        radio_group_intercultural_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.weeding_rice_rb:
                        weeding_rice_rb.setChecked(true);
                        intercultural = weeding_rice_rb.getText().toString();
                        break;

                    case R.id.hoeing_rice_rb:
                        hoeing_rice_rb.setChecked(true);
                        intercultural = hoeing_rice_rb.getText().toString();
                        break;

                    case R.id.detopping_rice_rb:
                        detopping_rice_rb.setChecked(true);
                        intercultural = detopping_rice_rb.getText().toString();
                        break;

                    case R.id.none_rice_rb:
                        none_rice_rb.setChecked(true);
                        intercultural = none_rice_rb.getText().toString();
                        break;
                }
            }
        });

        radio_group_irrigation_field_rice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.irrigation_rice_yes:
                        irrigation_rice_yes.setChecked(true);
                        irrigation_layout_rice.setVisibility(View.VISIBLE);
                        irrigation = irrigation_rice_yes.getText().toString();
                        break;

                    case R.id.irrigation_rice_no:
                        irrigation_rice_no.setChecked(true);
                        irrigation_layout_rice.setVisibility(View.GONE);
                        irrigation = irrigation_rice_no.getText().toString();
                        break;
                }
            }
        });

        sp_irrigation_given_rice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                irrigation_name = sp_irrigation_given_rice.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        pheromone_trap1_photo_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        pheromone_trap2_photo_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        pest_rice_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "3";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        crop_growth_rice_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(RicePheromone.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "4";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        btn_submit_rice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rice_save_service();
            }
        });

    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("3")) {
                photoFile3 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile3);
                } else {
                    photoURI = Uri.fromFile(photoFile3);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else if (type.equalsIgnoreCase("4")) {
                photoFile4 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile4);
                } else {
                    photoURI = Uri.fromFile(photoFile4);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pheromone_trap1_photo_rice.getWidth(), pheromone_trap1_photo_rice.getHeight())
                                    .centerCrop()
                                    .into(pheromone_trap1_photo_rice);

                            uploadImage1OnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("2")) {


            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(pheromone_trap2_photo_rice.getWidth(), pheromone_trap2_photo_rice.getHeight())
                                    .centerCrop()
                                    .into(pheromone_trap2_photo_rice);

                            uploadImage2OnServer(imagePath2);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("3")) {

            if (photoFile3 != null) {

                if (photoFile3.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile3, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath3 = "file://" + photoFile3;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath3)
                                    .resize(pest_rice_photo.getWidth(), pest_rice_photo.getHeight())
                                    .centerCrop()
                                    .into(pest_rice_photo);

                            uploadImage3OnServer(imagePath3);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile3);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if(type.equalsIgnoreCase("4")) {

            if (photoFile4 != null) {

                if (photoFile4.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile4, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath4 = "file://" + photoFile4;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath4)
                                    .resize(crop_growth_rice_photo.getWidth(), crop_growth_rice_photo.getHeight())
                                    .centerCrop()
                                    .into(crop_growth_rice_photo);

                            uploadImage4OnServer(imagePath4);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile4);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "1");

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 1);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImage2OnServer(String imagePath2) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath2);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "2");
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImage3OnServer(String imagePath3) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath3);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "3");
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile3.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImage4OnServer(String imagePath4) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath4);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "4");
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile4.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 4);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(RicePheromone.this,RiceGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void rice_save_service(){

        JSONObject param = new JSONObject();

        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("village_id", village_id);
            param.put("helicover_trap1_cp", pheromone_trap1_rice.getText().toString().trim());
            param.put("helicoverpa_trap2_cp", pheromone_trap2_rice.getText().toString().trim());
            param.put("other_pest_cp", otherpest_et_rice.getText().toString().trim());
            param.put("tn_insect_cp", tradename_insecticide_rice.getText().toString().trim());
            param.put("tn_fungi_cp", tradename_fungicide_rice.getText().toString().trim());
            param.put("tn_weed_cp", tradename_weedicide_rice.getText().toString().trim());
            param.put("quantity_insect_cp", quantity_used_acre_insecticide_rice.getText().toString().trim());
            param.put("quantity_fungi_cp", quantity_used_acre_fungicide_rice.getText().toString().trim());
            param.put("quantity_weed_cp", quantity_used_acre_weedicide_rice.getText().toString().trim());
            param.put("fert_n_cp", fertilizer_rice_N.getText().toString().trim());
            param.put("fert_p_cp", fertilizer_rice_P.getText().toString().trim());
            param.put("fert_k_cp", fertilizer_rice_K.getText().toString().trim());
            param.put("fertname_cp", fertilizername_rice.getText().toString().trim());
            param.put("quantity_fert_cp", quantity_used_acre_fertilizer_rice.getText().toString().trim());
            param.put("techn_insect_cp", insecticide_tech_name);
            param.put("techn_fungi_cp", fungicide_tech_name);
            param.put("techn_weed_cp", weedicide_tech_name);
            param.put("irrigation_cp", irrigation_name);
            param.put("insect_rb_cp", insecticide);
            param.put("fungi_rb_cp", fungicide);
            param.put("weed_rb_cp", weedicide);
            param.put("fert_rb_cp", fertilizer);
            param.put("inter_rb_cp", intercultural);
            param.put("irrigation_rb_cp", irrigation);
            param.put("helicover_image1_cp", image_1_file_name);
            param.put("helicover_image2_cp", image_2_file_name);
            param.put("pest_image_cp", image_3_file_name);
            param.put("crop_image_cp", image_4_file_name);
        } catch (Exception e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_chickpea_last_step_save(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null) {

            try {

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_2_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_3_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_4_file_name = data.getString("file_name");
                        }
                    }
                }

                if(i == 5){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")){
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Chickpea Pheromone Completed")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
