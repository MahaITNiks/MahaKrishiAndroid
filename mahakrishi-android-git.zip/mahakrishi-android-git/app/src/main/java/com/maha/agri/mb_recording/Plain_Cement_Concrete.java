package com.maha.agri.mb_recording;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Plain_Cement_Concrete extends AppCompatActivity implements ApiCallbackCode {

    private AppLocationManager locationManager;
    private int soil_lavel;
    public double lat;
    public double lang;
    private String soil_id = "1";
    private String soilName;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;

    // For Image upload
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private File photoFile3 = null;
    static final Integer CAMERA = 0x5;
    String imagePath, currentTime;
    private Transformation transformation;
    String type;

    private String image1URL;
    private String image2URL;
    private String image3URL;

    ImageView farmers_photo_pcc1, farmers_photo_beam, farmers_photo_vertical_wall;
    EditText edt_nos_pcc1, edt_diameter_pcc1, edt_Breadth_pcc1, edt_height_pcc1, edt_qty_pcc1;
    EditText edt_nos_beam, edt_diameter_beam, edt_Breadth_beam, edt_height_beam, edt_qty_beam;
    EditText edt_nos_vertical_wall, edt_diameter_vertical_wall, edt_Breadth_vertical_wall, edt_height_vertical_wall, edt_qty_vertical_wall;
    TextView txt_Total_pcc;
    String pcc_total, beam_total, vertical_wall_total, Total_pcc;
    String str_farmer_name;
    TextView txt_farmer_name;
    String str_nos_pcc1, str_diameter_pcc1, str_Breadth_pcc1, str_height_pcc1, str_qty_pcc1;
    String str_nos_beam, str_diameter_beam, str_Breadth_beam, str_height_beam, str_qty_beam;
    String str_nos_vertical_wall, str_diameter_vertical_wall, str_Breadth_vertical_wall, str_height_vertical_wall, str_qty_vertical_wall;

    Button btn_submit_pcc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plain_cement_concrete);
        getSupportActionBar().setTitle("Plain Cement Concrete");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(Plain_Cement_Concrete.this);
        sharedPref = new SharedPref(Plain_Cement_Concrete.this);
        soil_lavel = AppSettings.getInstance().getIntValue(this, ApConstants.MB_STAGE_LAVAL, 0);

        init();
        defaultConfig();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {
        soil_id = getIntent().getStringExtra("soilId");
        soilName = getIntent().getStringExtra("soilName");
        locationManager = new AppLocationManager(this);
        currentTime = ApUtil.getCurrentTimeStamp();

        edt_nos_pcc1 = (EditText) findViewById(R.id.edt_nos_pcc1);
        edt_diameter_pcc1 = (EditText) findViewById(R.id.edt_diameter_pcc1);
        edt_Breadth_pcc1 = (EditText) findViewById(R.id.edt_Breadth_pcc1);
        edt_height_pcc1 = (EditText) findViewById(R.id.edt_height_pcc1);
        edt_qty_pcc1 = (EditText) findViewById(R.id.edt_qty_pcc1);
        farmers_photo_pcc1 = (ImageView) findViewById(R.id.farmers_photo_pcc1);

        edt_nos_beam = (EditText) findViewById(R.id.edt_nos_beam);
        edt_diameter_beam = (EditText) findViewById(R.id.edt_diameter_beam);
        edt_Breadth_beam = (EditText) findViewById(R.id.edt_Breadth_beam);
        edt_height_beam = (EditText) findViewById(R.id.edt_height_beam);
        edt_qty_beam = (EditText) findViewById(R.id.edt_qty_beam);
        farmers_photo_beam = (ImageView) findViewById(R.id.farmers_photo_beam);

        edt_nos_vertical_wall = (EditText) findViewById(R.id.edt_nos_vertical_wall);
        edt_diameter_vertical_wall = (EditText) findViewById(R.id.edt_diameter_vertical_wall);
        edt_Breadth_vertical_wall = (EditText) findViewById(R.id.edt_Breadth_vertical_wall);
        edt_height_vertical_wall = (EditText) findViewById(R.id.edt_height_vertical_wall);
        edt_qty_vertical_wall = (EditText) findViewById(R.id.edt_qty_vertical_wall);
        farmers_photo_vertical_wall = (ImageView) findViewById(R.id.farmers_photo_vertical_wall);

        txt_Total_pcc = (TextView) findViewById(R.id.txt_Total_pcc);
        btn_submit_pcc = (Button) findViewById(R.id.btn_submit_pcc);

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        String soilData = getIntent().getStringExtra("soilData");
        if (!soilData.equalsIgnoreCase("")){
            setSoilDetail(soilData);
        }

        txt_farmer_name = (TextView) findViewById(R.id.txt_farmer_name);
        str_farmer_name = AppSettings.getInstance().getValue(Plain_Cement_Concrete.this, ApConstants.MB_FARMER_NAME, "");
        txt_farmer_name.setText(str_farmer_name);

    }

    private void setSoilDetail(String soilData) {
        btn_submit_pcc.setVisibility(View.INVISIBLE);
        try {
            JSONObject soilJSON = new JSONObject(soilData);

            String nos_pcc1 = soilJSON.getString("str_nos_pcc1");
            String diameter_pcc1 = soilJSON.getString("str_diameter_pcc1");
            String breadth_pcc1 = soilJSON.getString("str_Breadth_pcc1");
            String height_pcc1 = soilJSON.getString("str_height_pcc1");
            String qty_pcc1 = soilJSON.getString("str_qty_pcc1");

            edt_nos_pcc1.setText(nos_pcc1);
            edt_diameter_pcc1.setText(diameter_pcc1);
            edt_Breadth_pcc1.setText(breadth_pcc1);
            edt_height_pcc1.setText(height_pcc1);
            edt_qty_pcc1.setText(qty_pcc1);

            String nos_beam = soilJSON.getString("str_nos_beam");
            String diameter_beam = soilJSON.getString("str_diameter_beam");
            String breadth_beam = soilJSON.getString("str_Breadth_beam");
            String height_beam = soilJSON.getString("str_height_beam");
            String qty_beam = soilJSON.getString("str_qty_beam");

            edt_nos_beam.setText(nos_beam);
            edt_diameter_beam.setText(diameter_beam);
            edt_Breadth_beam.setText(breadth_beam);
            edt_height_beam.setText(height_beam);
            edt_qty_beam.setText(qty_beam);

            String nos_vertical_wall = soilJSON.getString("str_nos_vertical_wall");
            String diameter_vertical_wall = soilJSON.getString("str_diameter_vertical_wall");
            String breadth_vertical_wall = soilJSON.getString("str_Breadth_vertical_wall");
            String height_vertical_wall = soilJSON.getString("str_height_vertical_wall");
            String qty_vertical_wall = soilJSON.getString("str_qty_vertical_wall");

            edt_nos_vertical_wall.setText(nos_vertical_wall);
            edt_diameter_vertical_wall.setText(diameter_vertical_wall);
            edt_Breadth_vertical_wall.setText(breadth_vertical_wall);
            edt_height_vertical_wall.setText(height_vertical_wall);
            edt_qty_vertical_wall.setText(qty_vertical_wall);

            String tot_pcc = soilJSON.getString("total_pcc");
            txt_Total_pcc.setText(tot_pcc);

            String img1URL = soilJSON.getString("img1Url");
            if (!img1URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img1URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_pcc1);
            }

            String img2URL = soilJSON.getString("img2Url");
            if (!img2URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img2URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_beam);
            }

            String img3URL = soilJSON.getString("img3Url");
            if (!img3URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img2URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_vertical_wall);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void defaultConfig() {

        farmers_photo_pcc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "1";
                    takeImage1FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });


        farmers_photo_beam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImage2FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });


        farmers_photo_vertical_wall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Plain_Cement_Concrete.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {

                    type = "3";
                    takeImage3FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        edt_height_pcc1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               /* int value1 = Integer.parseInt(edt_list_from_soil.getText().toString());
                int value2 = Integer.parseInt(edt_lift_to_soil.getText().toString());*/
                double value1 = 0;
                double value2 = 0;
                double value3 = 0;
                double value4 = 0;
                String total_pcc;
                String v1 = edt_nos_pcc1.getText().toString();
                String v2 = edt_diameter_pcc1.getText().toString();
                String v3 = edt_Breadth_pcc1.getText().toString();
                String v4 = edt_height_pcc1.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                    //edt_qty_pcc1.setText(String.valueOf(3.14*(value1)));
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                    //edt_qty_pcc1.setText(String.valueOf(3.14*(value1*value2)));
                }
                if (!v3.equalsIgnoreCase("")) {
                    value3 = Double.parseDouble(v3);
                    // edt_qty_pcc1.setText(String.valueOf(3.14*(value1*value2*value3)));
                }
                if (!v4.equalsIgnoreCase("")) {
                    value4 = Double.parseDouble(v4);
                }

                edt_qty_pcc1.setText(String.valueOf(3.14 * (value1 * value2 * value3 * value4)));
                pcc_total = edt_qty_pcc1.getText().toString();

            }
        });


        edt_height_beam.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               /* int value1 = Integer.parseInt(edt_list_from_soil.getText().toString());
                int value2 = Integer.parseInt(edt_lift_to_soil.getText().toString());*/
                double value1 = 0;
                double value2 = 0;
                double value3 = 0;
                double value4 = 0;
                String v1 = edt_nos_beam.getText().toString();
                String v2 = edt_diameter_beam.getText().toString();
                String v3 = edt_Breadth_beam.getText().toString();
                String v4 = edt_height_beam.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
                if (!v3.equalsIgnoreCase("")) {
                    value3 = Double.parseDouble(v3);
                }
                if (!v4.equalsIgnoreCase("")) {
                    value4 = Double.parseDouble(v4);
                }

                edt_qty_beam.setText(String.valueOf(3.14 * (value1 * value2 * value3 * value4)));
                beam_total = edt_qty_beam.getText().toString();

            }
        });


        edt_height_vertical_wall.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               /* int value1 = Integer.parseInt(edt_list_from_soil.getText().toString());
                int value2 = Integer.parseInt(edt_lift_to_soil.getText().toString());*/
                double value1 = 0;
                double value2 = 0;
                double value3 = 0;
                double value4 = 0;
                String v1 = edt_nos_vertical_wall.getText().toString();
                String v2 = edt_diameter_vertical_wall.getText().toString();
                String v3 = edt_Breadth_vertical_wall.getText().toString();
                String v4 = edt_height_vertical_wall.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
                if (!v3.equalsIgnoreCase("")) {
                    value3 = Double.parseDouble(v3);
                }
                if (!v4.equalsIgnoreCase("")) {
                    value4 = Double.parseDouble(v4);
                }

                edt_qty_vertical_wall.setText(String.valueOf(3.14 * (value1 * value2 * value3 * value4)));
                vertical_wall_total = edt_qty_vertical_wall.getText().toString();

                ////////////////////////////////////////////////////////////////////
                double pcc_total_1 = 0;
                double beam_total_1 = 0;
                double vertical_wall_total_1 = 0;

                pcc_total = edt_qty_pcc1.getText().toString();
                beam_total = edt_qty_beam.getText().toString();
                vertical_wall_total = edt_qty_vertical_wall.getText().toString();

                if (!pcc_total.equalsIgnoreCase("")) {
                    pcc_total_1 = Double.parseDouble(pcc_total);
                }

                if (!beam_total.equalsIgnoreCase("")) {
                    beam_total_1 = Double.parseDouble(beam_total);
                }

                if (!vertical_wall_total.equalsIgnoreCase("")) {
                    vertical_wall_total_1 = Double.parseDouble(vertical_wall_total);
                }

                Total_pcc = String.valueOf(pcc_total_1 + beam_total_1 + vertical_wall_total_1);
                txt_Total_pcc.setText(Total_pcc);
            }
        });


        btn_submit_pcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Plain_cemenet_concrete_Save_Service();
            }
        });
    }


    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    private void takeImage2FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
            } else {
                photoURI = Uri.fromFile(photoFile2);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage3FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile3 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile3);
            } else {
                photoURI = Uri.fromFile(photoFile3);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void uploadImage1OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage2OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage3OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile3.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 4);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            /*Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_pcc1.getWidth(), farmers_photo_pcc1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_pcc1);*/
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    uploadImage1OnServer(imagePath);
                }
            }
        }


        if (photoFile2 != null) {

            if (type.equalsIgnoreCase("2")) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            /*Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_beam.getWidth(), farmers_photo_beam.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_beam);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage2OnServer(imagePath);
                }
            }
        }


        if (photoFile3 != null) {

            if (type.equalsIgnoreCase("3")) {

                if (photoFile3.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile3, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile3;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                           /* Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_vertical_wall.getWidth(), farmers_photo_vertical_wall.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_vertical_wall);*/
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile3);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage3OnServer(imagePath);
                }
            }
        }
    }


    // save
    private void Plain_cemenet_concrete_Save_Service() {
        str_nos_pcc1 = edt_nos_pcc1.getText().toString().trim();
        str_diameter_pcc1 = edt_diameter_pcc1.getText().toString().trim();
        str_Breadth_pcc1 = edt_Breadth_pcc1.getText().toString().trim();
        str_height_pcc1 = edt_height_pcc1.getText().toString().trim();
        str_qty_pcc1 = edt_qty_pcc1.getText().toString().trim();

        str_nos_beam = edt_nos_beam.getText().toString().trim();
        str_diameter_beam = edt_diameter_beam.getText().toString().trim();
        str_Breadth_beam = edt_Breadth_beam.getText().toString().trim();
        str_height_beam = edt_height_beam.getText().toString().trim();
        str_qty_beam = edt_qty_beam.getText().toString().trim();

        str_nos_vertical_wall = edt_nos_vertical_wall.getText().toString().trim();
        str_diameter_vertical_wall = edt_diameter_vertical_wall.getText().toString().trim();
        str_Breadth_vertical_wall = edt_Breadth_vertical_wall.getText().toString().trim();
        str_height_vertical_wall = edt_height_vertical_wall.getText().toString().trim();
        str_qty_vertical_wall = edt_qty_vertical_wall.getText().toString().trim();
        str_farmer_name = txt_farmer_name.getText().toString().trim();

        if (str_nos_pcc1.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Numbers for bed concrete", Toast.LENGTH_SHORT).show();
        } else if (str_diameter_pcc1.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Diameter for bed concrete", Toast.LENGTH_SHORT).show();
        } else if (str_Breadth_pcc1.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Breadth for bed concrete", Toast.LENGTH_SHORT).show();
        } else if (str_height_pcc1.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Height for bed concrete", Toast.LENGTH_SHORT).show();
        } else if (str_qty_pcc1.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input qty for bed concrete", Toast.LENGTH_SHORT).show();
        } else if (photoFile1 == null) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input bed Concrete photo", Toast.LENGTH_SHORT).show();
        } else if (str_nos_beam.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Numbers for Beam", Toast.LENGTH_SHORT).show();
        } else if (str_diameter_beam.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Diameter for Beam ", Toast.LENGTH_SHORT).show();
        } else if (str_Breadth_beam.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Breadth for Beam", Toast.LENGTH_SHORT).show();
        } else if (str_height_beam.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Height for Beam", Toast.LENGTH_SHORT).show();
        } else if (str_qty_beam.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input qty", Toast.LENGTH_SHORT).show();
        } else if (photoFile2 == null) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Beam photo", Toast.LENGTH_SHORT).show();
        } else if (str_nos_vertical_wall.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Numbers for Vertical Wall", Toast.LENGTH_SHORT).show();
        } else if (str_diameter_vertical_wall.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Diameter for Vertical wall", Toast.LENGTH_SHORT).show();
        } else if (str_Breadth_vertical_wall.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Breadth for Vertical wall", Toast.LENGTH_SHORT).show();
        } else if (str_height_vertical_wall.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Height for Vertical wall", Toast.LENGTH_SHORT).show();
        } else if (str_qty_vertical_wall.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input qty for Vertical wall", Toast.LENGTH_SHORT).show();
        } else if (photoFile3 == null) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Vertical wall photo", Toast.LENGTH_SHORT).show();
        } else if (str_farmer_name.isEmpty()) {
            Toast.makeText(Plain_Cement_Concrete.this, "Input Farmer Name", Toast.LENGTH_SHORT).show();
        } else {

            soil_lavel++;
            JSONObject param = new JSONObject();
            try {
                param.put("farmer_reg_id", Integer.valueOf(preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID)));
                param.put("soil_id", Integer.valueOf(soil_id));
                param.put("soil_name", soilName);
                param.put("stepID", soil_lavel);

                //  String str_nos_pcc1,str_diameter_pcc1,str_Breadth_pcc1,str_height_pcc1,str_qty_pcc1;
                param.put("str_nos_pcc1", str_nos_pcc1);
                param.put("str_diameter_pcc1", str_diameter_pcc1);
                param.put("str_Breadth_pcc1", str_Breadth_pcc1);
                param.put("str_height_pcc1", str_height_pcc1);
                param.put("str_qty_pcc1", str_qty_pcc1);

                //String str_nos_beam,str_diameter_beam,str_Breadth_beam,str_height_beam,str_qty_beam;
                param.put("str_nos_beam", str_nos_beam);
                param.put("str_diameter_beam", str_diameter_beam);
                param.put("str_Breadth_beam", str_Breadth_beam);
                param.put("str_height_beam", str_height_beam);
                param.put("str_qty_beam", str_qty_beam);

                //String str_nos_vertical_wall,str_diameter_vertical_wall,str_Breadth_vertical_wall,str_height_vertical_wall,str_qty_vertical_wall;
                param.put("str_nos_vertical_wall", str_nos_vertical_wall);
                param.put("str_diameter_vertical_wall", str_diameter_vertical_wall);
                param.put("str_Breadth_vertical_wall", str_Breadth_vertical_wall);
                param.put("str_height_vertical_wall", str_height_vertical_wall);
                param.put("str_qty_vertical_wall", str_qty_vertical_wall);

                param.put("total_pcc", Total_pcc);

                param.put("str_farmer_name", str_farmer_name);
                param.put("img1Url", image1URL);
                param.put("img2Url", image2URL);
                param.put("img3Url", image3URL);
                param.put("lat", lat);
                param.put("lang", lang);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.soil_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);
        }

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                //save1
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();

                        AppSettings.getInstance().setValue(Plain_Cement_Concrete.this, ApConstants.PCC_QTY_BEAM, str_qty_pcc1);
                        AppSettings.getInstance().setValue(Plain_Cement_Concrete.this, ApConstants.HEIGHT_VERTICAL_WALL_HEIGHT_ID, str_height_vertical_wall);
                        AppSettings.getInstance().setValue(Plain_Cement_Concrete.this, ApConstants.PCC_VERTICAL_WALL, str_qty_vertical_wall);

                        AppSettings.getInstance().setIntValue(Plain_Cement_Concrete.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                        finish();
                    } else {
                        soil_lavel--;
                        AppSettings.getInstance().setIntValue(Plain_Cement_Concrete.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image1URL = data.getString("file_url");
                        if (!image1URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image1URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_pcc1.getWidth(), farmers_photo_pcc1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_pcc1);
                        }
                    } else {
                        UIToastMessage.show(Plain_Cement_Concrete.this, jsonObject.getString("response"));
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image2URL = data.getString("file_url");
                        if (!image2URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image2URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_beam.getWidth(), farmers_photo_beam.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_beam);
                        }
                    } else {
                        UIToastMessage.show(Plain_Cement_Concrete.this, jsonObject.getString("response"));
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image2URL = data.getString("file_url");
                        if (!image2URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image2URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_vertical_wall.getWidth(), farmers_photo_vertical_wall.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_vertical_wall);
                        }
                    } else {
                        UIToastMessage.show(Plain_Cement_Concrete.this, jsonObject.getString("response"));
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
