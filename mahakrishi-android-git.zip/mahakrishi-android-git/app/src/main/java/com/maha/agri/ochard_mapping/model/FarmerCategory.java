package com.maha.agri.ochard_mapping.model;

import org.json.JSONException;
import org.json.JSONObject;

public class FarmerCategory {

    private int id;
    private String category;

    public FarmerCategory(int id, String category) {
        this.id = id;
        this.category = category;
    }

    public JSONObject getJSONObject() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("id", id);
            obj.put("category", category);
        } catch (JSONException e) {
        }
        return obj;
    }
}
