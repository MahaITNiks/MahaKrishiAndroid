package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class EnterNewPasswordActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button resetBtn;
    private EditText new_pass,confirm_pass;
    private String newPass,confirmPass,mobile_number;
    private JSONObject forgotpass_json_object;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_new_password);

        getSupportActionBar().setTitle("Reset Password");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sharedPref = new SharedPref(EnterNewPasswordActivity.this);
        preferenceManager = new PreferenceManager(EnterNewPasswordActivity.this);
        init();
        default_confiq();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void init () {
        resetBtn = (Button) findViewById(R.id.resetBtn);
        new_pass = (EditText) findViewById(R.id.newPasswordEText);
        confirm_pass = (EditText) findViewById(R.id.confPasswordEText);

    }

    private void default_confiq () {
        new_pass.getText().toString().trim();
        confirm_pass.getText().toString().trim();
        Intent intent = getIntent();
        mobile_number = intent.getStringExtra("mobile_number");
        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(new_pass.getText().toString().trim().equalsIgnoreCase(confirm_pass.getText().toString().trim())) {
                    resetPasswordWebservice();
                } else{
                    UIToastMessage.show(EnterNewPasswordActivity.this,"Password is not matching! Please check the password");
                }
            }
        });
    }

    private void resetPasswordWebservice () {

        if(new_pass.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter the password");
        } else if(confirm_pass.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter the password");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("mobile", mobile_number);
                param.put("newPass", new_pass.getText().toString().trim());
                param.put("confirmPass", confirm_pass.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.change_password(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse (JSONObject jsonObject,int i){

        try {

            if (jsonObject != null) {
                // District Response
                if (i == 1) {

                    if (jsonObject.getString("status").equals("200")) {
                        Intent intent = new Intent(EnterNewPasswordActivity.this,LoginActivity.class);
                        startActivity(intent);
                      //  UIToastMessage.show(EnterNewPasswordActivity.this, jsonObject.getString("response"));
                        Toast.makeText(EnterNewPasswordActivity.this, jsonObject.getString("response"), Toast.LENGTH_LONG).show();

                        finish();



                    } else {
                        UIToastMessage.show(EnterNewPasswordActivity.this, jsonObject.getString("response"));
                    }


                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFailure (Object o, Throwable throwable,int i){

    }
}
