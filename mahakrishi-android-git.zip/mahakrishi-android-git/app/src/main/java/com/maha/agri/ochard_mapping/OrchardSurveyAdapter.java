package com.maha.agri.ochard_mapping;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.CurrentDateTime;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class OrchardSurveyAdapter extends RecyclerView.Adapter<OrchardSurveyAdapter.OrachrdSurveyViewHolder> implements ApiCallbackCode {

    private JSONArray orchardSurveyList;
    private JSONArray orchardSurveyList1;
    private Context context;
    PreferenceManager preferenceManager;
    private int position;
    private OrchardSurveyInterface orchardSurveyInterface;

    public OrchardSurveyAdapter(JSONArray orchardSurveyList, View.OnClickListener listener, Context context) {
        this.orchardSurveyList = orchardSurveyList;
        this.orchardSurveyList1 = orchardSurveyList;
        this.context = context;
        preferenceManager = new PreferenceManager(context);
        this.orchardSurveyInterface = (OrchardSurveyInterface) listener;

    }

    @NonNull
    @Override
    public OrachrdSurveyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.orchard_survey_adapter, parent, false);
        OrachrdSurveyViewHolder vh = new OrachrdSurveyViewHolder(v);
        return vh;

    }

    public void filter(String query) {
        JSONArray tempList = new JSONArray();
        for (int i = 0; i < orchardSurveyList1.length(); i++) {
            try {

                JSONObject jsonObject = orchardSurveyList1.getJSONObject(i);
                Log.d("### o:", jsonObject.getString("village_name") + " * " + query);
                if (jsonObject.getString("village_name").toUpperCase().contains(query.toUpperCase()) || jsonObject.getString("first_name").toUpperCase().contains(query.toUpperCase()) || jsonObject.getString("surveyorgutvalue").toUpperCase().contains(query.toUpperCase())) {
                    tempList.put(jsonObject);
                    Log.d("### p:", jsonObject.getString("village_name"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        orchardSurveyList = new JSONArray();
        orchardSurveyList = tempList;
        Log.d("### q:", String.valueOf(orchardSurveyList.length()));
        notifyDataSetChanged();
    }


    @Override
    public void onBindViewHolder(@NonNull OrachrdSurveyViewHolder holder, int position) {
        try {
            JSONObject jsonObject = orchardSurveyList.getJSONObject(position);
            int sr = position + 1;

            holder.Srno.setText("SR#: " + sr + "");
            String ddate = jsonObject.getString("to_timestamp");
            Log.i("converted date", "" + CurrentDateTime.ConvertToDate(ddate));
            holder.survey_added_date.setText("Survey Date: " + CurrentDateTime.ConvertToDate(ddate));
            holder.survey_gat_no.setText("Survey/Gat No: " + jsonObject.getString("surveyorgutvalue"));
            holder.village_name.setText("Village Name: " + jsonObject.getString("village_name"));
            holder.crop_name.setText("Crop Name: " + jsonObject.getString("crop_name"));


            String firstname = "", middlename = "", lastname = "";
            if (jsonObject.getString("first_name") != null) {
                firstname = jsonObject.getString("first_name");
            }
            if (jsonObject.getString("middle_name") != null) {
                middlename = jsonObject.getString("middle_name");
            }
            if (jsonObject.getString("last_name") != null) {
                lastname = jsonObject.getString("last_name");
            }

            holder.farmer_name.setText("Farmer Name: " + firstname + " " + middlename + " " + lastname);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return orchardSurveyList.length();
    }


    public class OrachrdSurveyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView Srno, survey_added_date, survey_gat_no, village_name, crop_name, farmer_name, remove;
        private SweetAlertDialog sweetAlertDialog;

        public OrachrdSurveyViewHolder(View v) {
            super(v);
            Srno = (TextView) v.findViewById(R.id.Srno);
            survey_added_date = (TextView) v.findViewById(R.id.survey_added_date);
            survey_gat_no = (TextView) v.findViewById(R.id.survey_gat_no);
            village_name = (TextView) v.findViewById(R.id.village_name);
            crop_name = (TextView) v.findViewById(R.id.crop_name);
            farmer_name = (TextView) v.findViewById(R.id.farmer_name);
            remove = (TextView) v.findViewById(R.id.remove);

            remove.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {

            if (v.equals(remove)) {


                sweetAlertDialog = new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE);
                sweetAlertDialog.setTitleText("Warning");
                sweetAlertDialog.setContentText("Are you sure you want to remove!");
                sweetAlertDialog.setConfirmText("Ok");
                sweetAlertDialog.setCancelText("Cancel");
                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        removeAt(getPosition());
                        position = getPosition();
                        sweetAlertDialog.cancel();

                    }
                });
                sweetAlertDialog.show();
            }
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {
            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        orchardSurveyList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, orchardSurveyList.length());
                        if(orchardSurveyInterface!=null) {
                            orchardSurveyInterface.getUpdatedCount(orchardSurveyList.length());
                        }
                    } else {
                        UIToastMessage.show(context, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    public void removeAt(int position) {


        try {

            JSONObject param = new JSONObject();
            try {
                String uniqueId = orchardSurveyList.getJSONObject(position).getString("id");
                param.put("id", uniqueId);
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(context, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.remove_orchard_survey_from_list(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);


        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}


