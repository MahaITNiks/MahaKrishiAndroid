package com.maha.agri.panchnama;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FinalReportAdapter extends RecyclerView.Adapter<FinalReportAdapter.MyViewHolder> {

    private JSONArray final_report_array_list;
    private int[] final_manager_background;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    String id;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView final_report_single_title;
        private RelativeLayout final_report_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.final_report_single_title = itemView.findViewById(R.id.final_report_single_text_view);
            this.final_report_single_item_rl = itemView.findViewById(R.id.final_report_single_item_rl);

        }
    }

    public FinalReportAdapter(PreferenceManager preferenceManager, JSONArray final_report_array_list, int[] final_manager_background, Context context) {
        this.preferencemanager = preferenceManager;
        this.final_report_array_list = final_report_array_list;
        this.final_manager_background = final_manager_background;
        this.context = context;

    }


    @NonNull
    @Override
    public FinalReportAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.final_report_singleitem, viewGroup, false);

        FinalReportAdapter.MyViewHolder myViewHolder = new FinalReportAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FinalReportAdapter.MyViewHolder holder, int listposition) {
        try {
            jsonObject = final_report_array_list.getJSONObject(listposition);

                holder.final_report_single_title.setText(jsonObject.getString("first_name") + " " + jsonObject.getString("last_name"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (final_report_array_list != null) {
            return final_report_array_list.length();
        } else {
            return 0;
        }
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FinalReportAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FinalReportAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
