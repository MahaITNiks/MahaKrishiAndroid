package com.maha.agri.ffs;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListCallbackEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_FFSActivity extends AppCompatActivity implements ApiCallbackCode, AlertListCallbackEventListener {

    private JSONArray seasonArrayList = new JSONArray();
    private String reg_type;
    private String activityID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_ffs);
        getSupportActionBar().setTitle("Schedule of Visit");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        Button planButton = (Button) findViewById(R.id.planButton);
        Button observationButton = (Button) findViewById(R.id.observationButton);
        Button demo_plus_ffs = (Button) findViewById(R.id.dept_demo_plus_ffs);

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
            demo_plus_ffs.setVisibility(View.GONE);
            planButton.setText("Plan A Demonstration");
            observationButton.setText("Demonstration Observation");
        }else {
            demo_plus_ffs.setVisibility(View.VISIBLE);
            planButton.setText("Plan FFS");
            observationButton.setText("FFS Observation");
        }

        planButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent host_farmer_reg = new Intent(D_F_FFSActivity.this, AddPlanActivity.class);
                startActivity(host_farmer_reg);
            }
        });


        observationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (seasonArrayList.length()>0){
                    if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
                        Intent intent = new Intent(D_F_FFSActivity.this, D_F_PlanSelectionActivity.class);
                        startActivity(intent);
                    }else {
                        Intent intent = new Intent(D_F_FFSActivity.this, D_F_PlanSelectionActivity.class);
                        startActivity(intent);
                        //AppUtility.getInstance().showListDialog(seasonArrayList,"Select Season","name","id", D_F_FFSActivity.this,  D_F_FFSActivity.this);
                    }
                }else {
                    getSeasonList();
                }

            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        getSeasonList();
    }

    private void getSeasonList() {

        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", activityID);
            param.put("panchnama_scheme_id", "");

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
            DebugLog.getInstance().d("season_list_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("season_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void didSelectAlertViewListItem(TextView textView, String s) {
        if (!s.equalsIgnoreCase("")){
            AppSettings.getInstance().setValue(this, ApConstants.kSLED_SEASON_ID, s);
            Intent intent = new Intent(D_F_FFSActivity.this, D_F_PlanSelectionActivity.class);
            startActivity(intent);
        }else {
            AppSettings.getInstance().setValue(this, ApConstants.kSLED_SEASON_ID, ApConstants.kSLED_SEASON_ID);
            UIToastMessage.show(this,"Select Season");
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            seasonArrayList = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(this, ApConstants.kSEASON_LIST, seasonArrayList.toString());
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
