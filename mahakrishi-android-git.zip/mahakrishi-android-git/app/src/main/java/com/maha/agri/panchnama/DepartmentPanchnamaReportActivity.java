package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.maha.agri.R;

public class DepartmentPanchnamaReportActivity extends AppCompatActivity {
    private Button dept_self_panchnama_btn,dept_edit_farmer_panchnama_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_panchnama_report);
        getSupportActionBar().setTitle("Panchnama");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        dept_self_panchnama_btn = (Button)findViewById(R.id.dept_self_panchnama_btn);
        dept_edit_farmer_panchnama_btn = (Button)findViewById(R.id.dept_edit_farmer_panchnama_btn);
        dept_self_panchnama_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent primary_report = new Intent(DepartmentPanchnamaReportActivity.this, DepartmentSelfPunchnamaActivity.class);
                startActivity(primary_report);
            }
        });

        dept_edit_farmer_panchnama_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent primary_report = new Intent(DepartmentPanchnamaReportActivity.this, DepartmentPunchnamaActivity.class);
                startActivity(primary_report);
                /*Toast toast= Toast.makeText(DepartmentPanchnamaReportActivity.this, "Coming Soon !", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                toast.show();*/
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
