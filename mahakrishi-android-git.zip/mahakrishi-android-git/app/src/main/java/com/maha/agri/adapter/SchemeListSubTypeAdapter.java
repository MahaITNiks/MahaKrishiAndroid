package com.maha.agri.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.activity.task_manager.SchemeSubActListActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SchemeListSubTypeAdapter extends RecyclerView.Adapter<SchemeListSubTypeAdapter.CustomViewHolder> {

    private Context context;
    private JSONArray scheme_types_array_list;
    private PreferenceManager preferenceManager;
    private JSONObject jsonObject;

    public SchemeListSubTypeAdapter(Context context, JSONArray scheme_types_array_list,PreferenceManager preferenceManager) {
        this.context = context;
        this.scheme_types_array_list = scheme_types_array_list;
        this.preferenceManager = preferenceManager;

    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private TextView listTitleTextView;
        private LinearLayout scheme_list_type_ll;


        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            listTitleTextView = (TextView) mView.findViewById(R.id.listTitle);
            scheme_list_type_ll=(LinearLayout) mView.findViewById(R.id.scheme_list_type_ll);
            listTitleTextView.setTypeface(null, Typeface.BOLD);

        }
    }

    @Override
    public SchemeListSubTypeAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.schemelist_group_single_item, parent, false);
        return new SchemeListSubTypeAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SchemeListSubTypeAdapter.CustomViewHolder holder, final int position) {

        try {

            jsonObject = scheme_types_array_list.getJSONObject(position);
            holder.scheme_list_type_ll.setTag(position);
            holder.listTitleTextView.setText(jsonObject.getString("name"));



            holder.scheme_list_type_ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String activityId = scheme_types_array_list.getJSONObject(index).getString("id") ;
                        preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_ID,activityId);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        //activityId = scheme_types_array_list.getJSONObject(index).getString("typeId");
                        String  has_subactivity = scheme_types_array_list.getJSONObject(index).getString("has_subactivity");
                        if(has_subactivity.equalsIgnoreCase("1")){
                            Intent intent = new Intent(context, SchemeSubActListActivity.class);
                            intent.putExtra("schemeList", scheme_types_array_list.toString());
                            intent.putExtra("position", position);
                            //intent.putExtra("activityId",activityId);
                            context.startActivity(intent);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            });

            /*String  typeId = scheme_types_array_list.getJSONObject(position).getString("typeId");
            preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_ID,typeId);*/




        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return scheme_types_array_list.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SchemeListSubTypeAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SchemeListSubTypeAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
