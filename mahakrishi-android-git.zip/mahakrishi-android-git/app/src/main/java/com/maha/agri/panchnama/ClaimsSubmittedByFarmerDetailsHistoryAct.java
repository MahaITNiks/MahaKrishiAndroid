package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ClaimsSubmittedByFarmerDetailsHistoryAct extends AppCompatActivity {
    private EditText dept_punchnama_year_edt,dept_punchnama_district_edt,dept_punchnama_taluka_edt,dept_punchnama_village_edt,edt_survey_no_group_no,
            dept_punchnama_sheticha_prakar_edt,dept_punchnama_hangam_edt,dept_punchnama_pikvima_edt,dept_punchnama_yojna_edt,dept_punchnama_pikacha_prakar_edt,
            dept_punchnama_pikache_naav_edt,lagwadi_ekkar_edt,lagwadi_guntha_edt,pikvima_ekkar_edt,pikvima_guntha_edt,andajeet_ekkar_edt,andajeet_guntha_edt,
            dept_punchnama_nuksanicha_edt,dept_punchnama_nuksanicha_karan_edt,txt_vw_Specify_disease,txt_vw_Specify_Pest,dept_punchnama_nuksanicha_dinaak_edt,dept_punchnama_nuksanicha_notice_dinaak_edt,
            dept_punchnama_nuksanicha_takkewari_edt;

    private TextView txt_vw_full_name_of_farmer;
    private String punchanam_details_str;
    private int position;
    private JSONObject jsonObject;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;

    private String year,district,taluka,village,farmer_name,gut_no,sheticha_prakar,hangam,pik_vima,yojna,pikache_prakar,pikache_naav,lagwadi_ekkar,lagwadi_guntha,pika_vima_ekkar="0",pik_vima_guntha="0",
            andajeet_ekkar,andajeet_guntha,nuksanicha_prakar,nuksanicha_karan,rogache_naav,keedache_naav,farmer_punchanama_type_id,crop_insurance_name,nuksani_per,nuksani_date,nuksani_notice_date;

    private LinearLayout dept_punchnama_rogache_naav_ll,dept_punchnama_keedecha_naav_ll,dept_punchnama_pik_vima_linear_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claims_submitted_by_farmer_details_history);
        getSupportActionBar().setTitle("Claims Submitted By Farmer Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(ClaimsSubmittedByFarmerDetailsHistoryAct.this);
        sharedPref = new SharedPref(ClaimsSubmittedByFarmerDetailsHistoryAct.this);
        initialiazation();

        Intent intent = getIntent();
        punchanam_details_str = intent.getStringExtra("punchanam_details");

        try {
            JSONArray array = new JSONArray(punchanam_details_str);
            position = intent.getIntExtra("position", 0);
            jsonObject = array.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        default_confiq();


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void initialiazation() {
        dept_punchnama_pik_vima_linear_layout = (LinearLayout)findViewById(R.id.dept_punchnama_pik_vima_linear_layout);
        dept_punchnama_rogache_naav_ll = (LinearLayout)findViewById(R.id.dept_punchnama_rogache_naav_ll);
        dept_punchnama_keedecha_naav_ll = (LinearLayout)findViewById(R.id.dept_punchnama_keedecha_naav_ll);
        dept_punchnama_year_edt = (EditText)findViewById(R.id.dept_punchnama_year_edt);
        dept_punchnama_district_edt = (EditText)findViewById(R.id.dept_punchnama_district_edt);
        dept_punchnama_taluka_edt = (EditText)findViewById(R.id.dept_punchnama_taluka_edt);
        dept_punchnama_village_edt = (EditText)findViewById(R.id.dept_punchnama_village_edt);
        edt_survey_no_group_no = (EditText)findViewById(R.id.edt_survey_no_group_no);
        dept_punchnama_sheticha_prakar_edt = (EditText)findViewById(R.id.dept_punchnama_sheticha_prakar_edt);
        dept_punchnama_hangam_edt = (EditText)findViewById(R.id.dept_punchnama_hangam_edt);
        dept_punchnama_pikvima_edt = (EditText)findViewById(R.id.dept_punchnama_pikvima_edt);
        dept_punchnama_yojna_edt = (EditText)findViewById(R.id.dept_punchnama_yojna_edt);
        dept_punchnama_pikacha_prakar_edt = (EditText)findViewById(R.id.dept_punchnama_pikacha_prakar_edt);
        dept_punchnama_pikache_naav_edt = (EditText)findViewById(R.id.dept_punchnama_pikache_naav_edt);
        lagwadi_ekkar_edt = (EditText)findViewById(R.id.lagwadi_ekkar_edt);
        lagwadi_guntha_edt = (EditText)findViewById(R.id.lagwadi_guntha_edt);
        pikvima_ekkar_edt = (EditText)findViewById(R.id.pikvima_ekkar_edt);
        pikvima_guntha_edt = (EditText)findViewById(R.id.pikvima_guntha_edt);
        andajeet_ekkar_edt = (EditText)findViewById(R.id.andajeet_ekkar_edt);
        andajeet_guntha_edt = (EditText)findViewById(R.id.andajeet_guntha_edt);
        dept_punchnama_nuksanicha_edt = (EditText)findViewById(R.id.dept_punchnama_nuksanicha_edt);
        dept_punchnama_nuksanicha_karan_edt = (EditText)findViewById(R.id.dept_punchnama_nuksanicha_karan_edt);
        txt_vw_Specify_disease = (EditText)findViewById(R.id.txt_vw_Specify_disease);
        txt_vw_Specify_Pest = (EditText)findViewById(R.id.txt_vw_Specify_Pest_dept);
        dept_punchnama_nuksanicha_dinaak_edt = (EditText)findViewById(R.id.dept_punchnama_nuksanicha_dinaak_edt);
        dept_punchnama_nuksanicha_notice_dinaak_edt = (EditText)findViewById(R.id.dept_punchnama_nuksanicha_notice_dinaak_edt);
        dept_punchnama_nuksanicha_takkewari_edt = (EditText)findViewById(R.id.dept_punchnama_nuksanicha_takkewari_edt);
        txt_vw_full_name_of_farmer = (TextView)findViewById(R.id.txt_vw_full_name_of_farmer);
    }


    private void default_confiq(){

        try {
            farmer_punchanama_type_id = jsonObject.getString("id");
            year = jsonObject.getString("year_name");
            district = jsonObject.getString("district_name");
            taluka = jsonObject.getString("taluka_name");
            village = jsonObject.getString("village_name");
            farmer_name = jsonObject.getString("farmer_name");
            sheticha_prakar = jsonObject.getString("crop_type");
            hangam = jsonObject.getString("season_name");
            yojna = jsonObject.getString("scheme_name");
            pikache_naav = jsonObject.getString("crop_name");
            gut_no = jsonObject.getString("survey_no");
            pikache_prakar = jsonObject.getString("farm_type_name");
            crop_insurance_name = jsonObject.getString("crop_insurance_name");
            lagwadi_ekkar = jsonObject.getString("area_under_crop_acre");
            lagwadi_guntha = jsonObject.getString("area_under_crop_guntha");
            pika_vima_ekkar = jsonObject.getString("insured_area_under_crop_acre");
            pik_vima_guntha = jsonObject.getString("insured_area_under_crop_guntha");
            andajeet_ekkar = jsonObject.getString("approxmate_area_acre");
            andajeet_guntha = jsonObject.getString("approxmate_area_guntha");
            nuksanicha_prakar = jsonObject.getString("damage_type_name");
            nuksanicha_karan = jsonObject.getString("damage_reason_name");
            rogache_naav = jsonObject.getString("disease_name");
            keedache_naav = jsonObject.getString("pest_name");
            nuksani_per = jsonObject.getString("nuksani_per");
            nuksani_date = jsonObject.getString("nuksani_date");
            nuksani_notice_date = jsonObject.getString("nuksani_notice_date");


            dept_punchnama_year_edt.setText(year);
            dept_punchnama_district_edt.setText(district);
            dept_punchnama_taluka_edt.setText(taluka);
            dept_punchnama_village_edt.setText(village);
            dept_punchnama_sheticha_prakar_edt.setText(sheticha_prakar);
            dept_punchnama_hangam_edt.setText(hangam);
            dept_punchnama_yojna_edt.setText(yojna);
            dept_punchnama_pikvima_edt.setText(crop_insurance_name);
            dept_punchnama_pikacha_prakar_edt.setText(pikache_prakar);
            dept_punchnama_pikache_naav_edt.setText(pikache_naav);
            edt_survey_no_group_no.setText(gut_no);
            txt_vw_full_name_of_farmer.setText(farmer_name);
            lagwadi_ekkar_edt.setText(lagwadi_ekkar);
            lagwadi_guntha_edt.setText(lagwadi_guntha);
            andajeet_ekkar_edt.setText(andajeet_ekkar);
            andajeet_guntha_edt.setText(andajeet_guntha);
            dept_punchnama_nuksanicha_edt.setText(nuksanicha_prakar);
            dept_punchnama_nuksanicha_karan_edt.setText(nuksanicha_karan);
            dept_punchnama_nuksanicha_takkewari_edt.setText(nuksani_per);
            dept_punchnama_nuksanicha_dinaak_edt.setText(nuksani_date);
            dept_punchnama_nuksanicha_notice_dinaak_edt.setText(nuksani_notice_date);

            if(!pika_vima_ekkar.equalsIgnoreCase("")&&!pik_vima_guntha.equalsIgnoreCase("")){
                dept_punchnama_pik_vima_linear_layout.setVisibility(View.VISIBLE);
                pikvima_ekkar_edt.setText(pika_vima_ekkar);
                pikvima_guntha_edt.setText(pik_vima_guntha);
            }else if(!rogache_naav.equalsIgnoreCase("")){
                dept_punchnama_rogache_naav_ll.setVisibility(View.VISIBLE);
                txt_vw_Specify_disease.setText(rogache_naav);
            } else if(!keedache_naav.equalsIgnoreCase("")){
                dept_punchnama_keedecha_naav_ll.setVisibility(View.VISIBLE);
                txt_vw_Specify_Pest.setText(keedache_naav);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}
