/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.model;

public class EventModel {

    private String event;

    public EventModel(String event) {
        this.setEvent(event);
    }


    public String getEvent() {
        return event;
    }

    private void setEvent(String event) {
        this.event = event;
    }


}
