package com.maha.agri.ffs;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.enums.CroppingSystem;
import com.maha.agri.ffs.host_gusest_farmer.D_F_HostFarmerRagistrationActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AddPlanActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {

    private PreferenceManager preferenceManager;
    private String reg_type;
    private String activityID;
    String planArea;
    String kharifPlanArea = "0";
    String rabiPlanArea = "0";

    private TextView district_name_tv;
    private String district_name;
    private String district_id;

    private TextView subDiv_name_tv;
    private String subDiv_name;
    private int subDivID;

    private TextView tal_name_tv;
    private String taluka_name;
    private int talukaID;

    private TextView village_name_tv;
    private String village_name;
    private int villageID;
    private JSONArray village_list;

    private LinearLayout demoSchemeLL;
    private TextView demo_scheme_tv;
    private JSONArray demoSchemeJSONArray;
    private int demoSchemeID = 0;

    private LinearLayout seasonLL;
    private TextView season_tv;
    private int seasonID = 0;
    private int season2ID = 0;
    private int seasonRabi = 0;
    private int seasonKharif = 0;
    private JSONArray seasonArray = new JSONArray();

    private RadioGroup cropping_system_radio_group;
    private int cropingSystemID = CroppingSystem.SOLE.id();

    private LinearLayout majorCropLL;
    private LinearLayout kharifCropLL;
    private LinearLayout crop1VerityLL;
    private TextView kharifSeasonCrop_tv;
    private TextView majorCrop_tv;
    private int crop1Id = 0;
    private String crop1Name = "";
    private TextView crop1_verity_tv;
    private int crop1VerityID = 0;
    private String crop1VerityName = "";
    private LinearLayout interCropLL;
    private LinearLayout rabiLL;
    private LinearLayout crop2VerityLL;
    private TextView interCrop_tv;
    private TextView rabiSeasonCrop_tv;
    private int crop2Id = 0;
    private String crop2VerityName = "";
    private String crop2Name = "";
    private TextView crop2_verity_tv;
    private int crop2VerityID = 0;
    private JSONArray crop_data = new JSONArray();
    private JSONArray majorCropJSONArray = null;
    private JSONArray interCropJSONArray = null;
    private JSONArray cropVerityJSONArray = new JSONArray();
    private JSONArray kharifCropJSONArray = null;
    private JSONArray rabiCropJSONArray = null;
    private TextInputLayout totDemoAreaIT;
    private EditText totDemoAreaET;
    private EditText rabiDemoAreaET;
    private String totalDemoArea;
    private String rabiTotalDemoArea;
    private TextInputLayout totFFSAreaIT;
    private EditText totFFSAreaET;
    private EditText totRabiFFSAreaET;
    private String totalFFSArea;
    private String rabiTotalFFSArea;
    private LinearLayout rabiTotAreaLL;
    private Button createBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plan);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(AddPlanActivity.this);

        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            getSupportActionBar().setTitle("Plan A Demonstration");
        } else {
            getSupportActionBar().setTitle("Plan A FFS");
        }

        init();
        defaultConfig();
    }


    private void init() {

        demo_scheme_tv = (TextView) findViewById(R.id.demo_scheme_tv);
        district_name_tv = (TextView) findViewById(R.id.district_name_tv);
        subDiv_name_tv = (TextView) findViewById(R.id.subDiv_name_tv);
        tal_name_tv = (TextView) findViewById(R.id.tal_name_tv);
        village_name_tv = (TextView) findViewById(R.id.village_name_tv);
        demoSchemeLL = (LinearLayout) findViewById(R.id.demoSchemeLL);
        cropping_system_radio_group = (RadioGroup) findViewById(R.id.cropping_system_radio_group);
        seasonLL = (LinearLayout) findViewById(R.id.seasonLL);
        season_tv = (TextView) findViewById(R.id.season_tv);
        majorCropLL = (LinearLayout) findViewById(R.id.majorCropLL);
        kharifCropLL = (LinearLayout) findViewById(R.id.kharifCropLL);
        crop1VerityLL = (LinearLayout) findViewById(R.id.crop1VerityLL);
        crop1_verity_tv = (TextView) findViewById(R.id.crop1_verity_tv);
        majorCrop_tv = (TextView) findViewById(R.id.majorCrop_tv);
        interCropLL = (LinearLayout) findViewById(R.id.interCropLL);
        rabiLL = (LinearLayout) findViewById(R.id.rabiLL);
        crop2VerityLL = (LinearLayout) findViewById(R.id.crop2VerityLL);
        crop2_verity_tv = (TextView) findViewById(R.id.crop2_verity_tv);
        interCrop_tv = (TextView) findViewById(R.id.interCrop_tv);
        rabiSeasonCrop_tv = (TextView) findViewById(R.id.rabiSeasonCrop_tv);
        kharifSeasonCrop_tv = (TextView) findViewById(R.id.kharifSeasonCrop_tv);
        totDemoAreaIT = (TextInputLayout) findViewById(R.id.totDemoAreaIT);
        totDemoAreaET = (EditText) findViewById(R.id.totDemoAreaET);
        rabiDemoAreaET = (EditText) findViewById(R.id.rabiDemoAreaET);
        totFFSAreaIT = (TextInputLayout) findViewById(R.id.totFFSAreaIT);
        totFFSAreaET = (EditText) findViewById(R.id.totFFSAreaET);
        totRabiFFSAreaET = (EditText) findViewById(R.id.totRabiFFSAreaET);
        rabiTotAreaLL = (LinearLayout) findViewById(R.id.rabiTotAreaLL);
        createBtn = (Button) findViewById(R.id.createBtn);

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            demoSchemeLL.setVisibility(View.VISIBLE);
            totDemoAreaIT.setVisibility(View.VISIBLE);
            totFFSAreaIT.setVisibility(View.GONE);
            fetchDemoSchemeList();
        } else {
            demoSchemeLL.setVisibility(View.GONE);
            totDemoAreaIT.setVisibility(View.GONE);
            totFFSAreaIT.setVisibility(View.VISIBLE);
            getSeasonList();
        }
    }

    private void defaultConfig() {

        demo_scheme_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (demoSchemeJSONArray == null) {
                    fetchDemoSchemeList();
                } else {
                    AppUtility.getInstance().showListDialogIndex(demoSchemeJSONArray, 10, "Select Scheme", "name", "id", AddPlanActivity.this, AddPlanActivity.this);

                }
            }
        });

        village_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(village_list, 1, "Select Village", "village_name", "village_id", AddPlanActivity.this, AddPlanActivity.this);
            }
        });


        season_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (seasonArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(seasonArray, 2, "Select Season", "name", "id", AddPlanActivity.this, AddPlanActivity.this);
                } else {
                    getSeasonList();
                }
            }
        });


        majorCrop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cropingSystemID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select cropping system");
                } else if (seasonID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select season");
                } else {
                    if (majorCropJSONArray != null && majorCropJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(majorCropJSONArray, 4, "Select Major Crop", "crop_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        fetchCropMasterData(seasonID, "");
                    }
                }
            }
        });


        interCrop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cropingSystemID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select cropping system");
                } else if (seasonID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select season");
                } else if (crop1Id == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select Major Crop");
                } else {
                    if (interCropJSONArray != null && interCropJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(interCropJSONArray, 7, "Select Inter Crop", "crop_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        fetchInterMasterData(seasonID, cropingSystemID, String.valueOf(crop1Id));
                    }
                }
            }
        });

        kharifSeasonCrop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cropingSystemID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "select cropping system");
                } else {
                    if (kharifCropJSONArray != null && kharifCropJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(kharifCropJSONArray, 9, "Select Kharif Crop", "crop_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        // seasonID = seasonKharif;
                        fetchKharifCropData(seasonKharif, "");
                    }
                }
            }
        });


        rabiSeasonCrop_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cropingSystemID == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select cropping system");
                } else if (crop1Id == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select kharif crop");
                } else {
                    if (rabiCropJSONArray != null && rabiCropJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(rabiCropJSONArray, 8, "Select Rabi Crop", "crop_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        // seasonID = seasonRabi;
                        fetchRabiCropData(seasonRabi, "");

                    }
                }
            }
        });


        crop1_verity_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (crop1Id == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select Crop");
                } else {
                    if (cropVerityJSONArray != null && cropVerityJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(cropVerityJSONArray, 11, "Select Crop Verity", "variety_name_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        fetchCropVariety(crop1Id);
                    }
                }
            }
        });

        crop2_verity_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (crop2Id == 0) {
                    UIToastMessage.show(AddPlanActivity.this, "Select Crop");
                } else {
                    if (cropVerityJSONArray != null && cropVerityJSONArray.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(cropVerityJSONArray, 12, "Select Crop Verity", "variety_name_english", "id", AddPlanActivity.this, AddPlanActivity.this);
                    } else {
                        fetchCropVariety(crop2Id);
                    }
                }
            }
        });


        // For physically challenged
        cropping_system_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                                   @Override
                                                                   public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                                       if (checkedId == R.id.soleC_RB) {
                                                                           cropingSystemID = CroppingSystem.SOLE.id();
                                                                           majorCropLL.setVisibility(View.VISIBLE);
                                                                           crop1VerityLL.setVisibility(View.VISIBLE);
                                                                           interCropLL.setVisibility(View.GONE);
                                                                           crop2VerityLL.setVisibility(View.GONE);
                                                                           kharifCropLL.setVisibility(View.GONE);
                                                                           rabiLL.setVisibility(View.GONE);
                                                                           rabiTotAreaLL.setVisibility(View.GONE);
                                                                           totDemoAreaIT.setHint("Total demonstration area (ha)");
                                                                           totDemoAreaET.setHint("Total demonstration area (ha)");
                                                                           totDemoAreaET.setText("");
                                                                           seasonLL.setVisibility(View.VISIBLE);
                                                                           season_tv.setText("");
                                                                           majorCrop_tv.setText("");
                                                                           interCrop_tv.setText("");
                                                                           crop1_verity_tv.setText("");
                                                                           crop2_verity_tv.setText("");
                                                                           seasonID = 0;
                                                                           crop1Id = 0;
                                                                           crop1Name = "";
                                                                           crop2Id = 0;
                                                                           crop2Name = "";
                                                                           crop1VerityID = 0;
                                                                           crop2VerityID = 0;
                                                                           crop_data = new JSONArray();
                                                                           majorCropJSONArray = new JSONArray();
                                                                           interCropJSONArray = new JSONArray();
                                                                           kharifCropJSONArray = new JSONArray();
                                                                           rabiCropJSONArray = new JSONArray();
                                                                       } else if (checkedId == R.id.interCropping_RB) {
                                                                           cropingSystemID = CroppingSystem.INTER_CROP.id();
                                                                           majorCropLL.setVisibility(View.VISIBLE);
                                                                           crop1VerityLL.setVisibility(View.VISIBLE);
                                                                           interCropLL.setVisibility(View.VISIBLE);
                                                                           crop2VerityLL.setVisibility(View.VISIBLE);
                                                                           kharifCropLL.setVisibility(View.GONE);
                                                                           rabiLL.setVisibility(View.GONE);
                                                                           rabiTotAreaLL.setVisibility(View.GONE);
                                                                           totDemoAreaIT.setHint("Total demonstration area (ha)");
                                                                           totDemoAreaET.setHint("Total demonstration area (ha)");
                                                                           totDemoAreaET.setText("");
                                                                           seasonLL.setVisibility(View.VISIBLE);
                                                                           season_tv.setText("");
                                                                           majorCrop_tv.setText("");
                                                                           interCrop_tv.setText("");
                                                                           crop1_verity_tv.setText("");
                                                                           crop2_verity_tv.setText("");
                                                                           seasonID = 0;
                                                                           crop1Id = 0;
                                                                           crop1Name = "";
                                                                           crop2Id = 0;
                                                                           crop2Name = "";
                                                                           crop1VerityID = 0;
                                                                           crop2VerityID = 0;
                                                                           crop_data = new JSONArray();
                                                                           majorCropJSONArray = new JSONArray();
                                                                           interCropJSONArray = new JSONArray();
                                                                           kharifCropJSONArray = new JSONArray();
                                                                           rabiCropJSONArray = new JSONArray();
                                                                       } else if (checkedId == R.id.cropping_sys_based_RB) {
                                                                           cropingSystemID = CroppingSystem.CROP_SYS_BASED.id();
                                                                           seasonLL.setVisibility(View.GONE);
                                                                           season_tv.setText("");
                                                                           majorCropLL.setVisibility(View.GONE);
                                                                           majorCrop_tv.setText("");
                                                                           interCropLL.setVisibility(View.GONE);
                                                                           interCrop_tv.setText("");
                                                                           kharifCropLL.setVisibility(View.VISIBLE);
                                                                           crop1VerityLL.setVisibility(View.VISIBLE);
                                                                           crop1_verity_tv.setText("");
                                                                           rabiLL.setVisibility(View.VISIBLE);
                                                                           rabiTotAreaLL.setVisibility(View.VISIBLE);
                                                                           totDemoAreaIT.setHint("Kharif demonstration area (ha)");
                                                                           totDemoAreaET.setHint("Kharif demonstration area (ha)");
                                                                           totDemoAreaET.setText("");
                                                                           crop2VerityLL.setVisibility(View.VISIBLE);
                                                                           crop2_verity_tv.setText("");
                                                                           seasonID = 0;
                                                                           crop1Id = 0;
                                                                           crop1Name = "";
                                                                           crop2Id = 0;
                                                                           crop2Name = "";
                                                                           crop1VerityID = 0;
                                                                           crop2VerityID = 0;
                                                                           crop_data = new JSONArray();
                                                                           majorCropJSONArray = new JSONArray();
                                                                           interCropJSONArray = new JSONArray();
                                                                           kharifCropJSONArray = new JSONArray();
                                                                           kharifSeasonCrop_tv.setText("");
                                                                           rabiCropJSONArray = new JSONArray();
                                                                           rabiSeasonCrop_tv.setText("");
                                                                           getSeasonList();
                                                                       }
                                                                   }
                                                               }
        );


        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createBtnAction();
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        get_district_taluka();

        String data = AppSettings.getInstance().getValue(AddPlanActivity.this, ApConstants.kLOGIN_DATA, "");
        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            villageID = Integer.parseInt(s1);
            village_name_tv.setText(s);
        }

        if (i == 10) {
            demoSchemeID = Integer.parseInt(s1);
            demo_scheme_tv.setText(s);

            season_tv.setText("");
            seasonID = 0;
            majorCrop_tv.setText("");
            interCrop_tv.setText("");
            crop1Id = 0;
            crop1Name = "";
            crop2Id = 0;
            crop2Name = "";
            crop_data = new JSONArray();

            crop1_verity_tv.setText("");
            crop2_verity_tv.setText("");
            crop1VerityID = 0;
            crop2VerityID = 0;
            majorCropJSONArray = new JSONArray();
            interCropJSONArray = new JSONArray();
            kharifSeasonCrop_tv.setText("");
            kharifCropJSONArray = new JSONArray();
            rabiSeasonCrop_tv.setText("");
            rabiCropJSONArray = new JSONArray();

        }

        if (i == 2) {
            seasonID = Integer.parseInt(s1);
            season_tv.setText(s);
            majorCrop_tv.setText("");
            interCrop_tv.setText("");
            crop1Id = 0;
            crop1Name = "";
            crop2Id = 0;
            crop2Name = "";
            crop_data = new JSONArray();
            fetchCropMasterData(seasonID, "");
        }


        if (i == 4) {
            crop1Id = Integer.parseInt(s1);
            majorCrop_tv.setText(s);
            crop1Name = s;
            crop_data = new JSONArray();
            crop1_verity_tv.setText("");
            crop1VerityID = 0;
            fetchCropVariety(crop1Id);
            fetchInterMasterData(seasonID, cropingSystemID, String.valueOf(crop1Id));
        }

        if (i == 7) {
            crop2Id = Integer.parseInt(s1);
            interCrop_tv.setText(s);
            crop2Name = s;
            season2ID = seasonID;
            crop2_verity_tv.setText("");
            crop2VerityID = 0;
            fetchCropVariety(crop2Id);
        }

        if (i == 9) {
            crop1Id = Integer.parseInt(s1);
            kharifSeasonCrop_tv.setText(s);
            crop1Name = s;
            crop_data = new JSONArray();
            crop1_verity_tv.setText("");
            crop1VerityID = 0;
            fetchCropVariety(crop1Id);
        }

        if (i == 8) {
            crop2Id = Integer.parseInt(s1);
            rabiSeasonCrop_tv.setText(s);
            crop2Name = s;
            crop2_verity_tv.setText("");
            crop2VerityID = 0;
            fetchCropVariety(crop2Id);
        }

        if (i == 11) {
            crop1VerityID = Integer.parseInt(s1);
            crop1VerityName = s;
            crop1_verity_tv.setText(s);
            addCropData(seasonID, crop1Id, crop1Name, crop1VerityID, s);
            if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id()) {
                season2ID = 2;
                fetchCropMasterData(season2ID, "");
                getPlanArea(seasonKharif);
            }else{
                getPlanArea(seasonID);
            }

        }

        if (i == 12) {
            crop2VerityID = Integer.parseInt(s1);
            crop2VerityName = s;
            crop2_verity_tv.setText(s);
            addCropData(season2ID, crop2Id, crop2Name, crop2VerityID, s);
            if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id()) {
                getPlanArea2();
            }
        }
    }

    private void getPlanArea(int season) {

        if (villageID == 0) {
            UIToastMessage.show(AddPlanActivity.this, "Please Select village");
        } else if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && demoSchemeID == 0) {
            UIToastMessage.show(this, "Select demonstration scheme id");
        } else if (cropingSystemID == 0) {
            UIToastMessage.show(this, "Select cropping system");
        } else if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && seasonID == 0) {
            UIToastMessage.show(this, "Select Season");
        } else if (crop1Id == 0) {
            UIToastMessage.show(this, "Select Crop");
        } else if (crop1VerityID == 0) {
            UIToastMessage.show(this, "Select Crop variety");
        } else {

            try {

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("village_id", villageID);
                jsonObject.put("demo_scheme_id", demoSchemeID);
                jsonObject.put("cropping_system_id", cropingSystemID);
                jsonObject.put("season_id", season);
                jsonObject.put("crop_id", crop1Id);
                jsonObject.put("crop_verity_id", crop1VerityID);

                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.planAreaRequest(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 8);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void getPlanArea2() {

        if (villageID == 0) {
            UIToastMessage.show(AddPlanActivity.this, "Please Select village");
        } else if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && demoSchemeID == 0) {
            UIToastMessage.show(this, "Select demonstration scheme id");
        } else if (cropingSystemID == 0) {
            UIToastMessage.show(this, "Select cropping system");
        } else if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && seasonID == 0) {
            UIToastMessage.show(this, "Select Season");
        } else if (crop1Id == 0) {
            UIToastMessage.show(this, "Select Crop");
        } else if (crop1VerityID == 0) {
            UIToastMessage.show(this, "Select Crop variety");
        } else {

            try {

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("village_id", villageID);
                jsonObject.put("demo_scheme_id", demoSchemeID);
                jsonObject.put("cropping_system_id", cropingSystemID);
                jsonObject.put("season_id", seasonRabi);
                jsonObject.put("crop_id", crop2Id);
                jsonObject.put("crop_verity_id", crop2VerityID);

                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.planAreaRequest(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 10);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    private void addCropData(int season_id, int cId, String cName, int cropVerityID, String cVerityName) {

        try {
            if (crop_data.length() > 0) {

                for (int i = 0; crop_data.length() > i; i++) {
                    JSONObject cropJSON = crop_data.getJSONObject(i);
                    String cropId =cropJSON.getString("crop_id");
                    if (cropId.equalsIgnoreCase(String.valueOf(cId)) && cropId.equalsIgnoreCase(String.valueOf(crop1Id))){
                        crop_data.remove(i);
                    }else if (cropId.equalsIgnoreCase(String.valueOf(cId)) && cropId.equalsIgnoreCase(String.valueOf(crop2Id))){
                        crop_data.remove(i);
                    }
                }

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("season_id", season_id);
                jsonObject.put("crop_id", cId);
                jsonObject.put("crop_name", cName);
                jsonObject.put("crop_verity_id", cropVerityID);
                jsonObject.put("crop_verity_name", cVerityName);
                crop_data.put(jsonObject);

            }else {

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("season_id", season_id);
                jsonObject.put("crop_id", cId);
                jsonObject.put("crop_name", cName);
                jsonObject.put("crop_verity_id", cropVerityID);
                jsonObject.put("crop_verity_name", cVerityName);
                crop_data.put(jsonObject);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        /*try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("season_id", season_id);
            jsonObject.put("crop_id", cId);
            jsonObject.put("crop_name", cName);
            jsonObject.put("crop_verity_id", cropVerityID);
            jsonObject.put("crop_verity_name", cVerityName);
            crop_data.put(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/
    }


    private void getSeasonList() {

        try {
            JSONObject param = new JSONObject();
            param.put("activity_id", activityID);
            param.put("panchnama_scheme_id", "");

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
            DebugLog.getInstance().d("season_list_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("season_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void fetchDemoSchemeList() {

        String url = APIServices.kDemoSchemeList;
        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {

            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                demoSchemeJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(AddPlanActivity.this, response.getMsg());
                            }
                            getSeasonList();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

    }


    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void fetchCropMasterData(int seasonId, String sCropID) {

        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);

            int cropingSysId;
            if (cropingSystemID == CroppingSystem.INTER_CROP.id()) {
                cropingSysId = CroppingSystem.SOLE.id();
            } else {
                cropingSysId = cropingSystemID;
            }

            String schemeID = "";
            if (demoSchemeID == 0) {
                schemeID = "";
            } else {
                schemeID = String.valueOf(demoSchemeID);
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_activity_id", activityID);
            jsonObject.put("demo_scheme_id", schemeID);
            jsonObject.put("crop_season_id", seasonId);
            jsonObject.put("cropping_system_id", cropingSysId);
            jsonObject.put("sole_crop_id", sCropID);
            // jsonObject.put("year", year);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchKharifCropData(int seasonId, String sCropID) {

        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);

            int cropingSysId;
            if (cropingSystemID == CroppingSystem.INTER_CROP.id()) {
                cropingSysId = CroppingSystem.SOLE.id();
            } else {
                cropingSysId = cropingSystemID;
            }

            String schemeID = "";
            if (demoSchemeID == 0) {
                schemeID = "";
            } else {
                schemeID = String.valueOf(demoSchemeID);
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_activity_id", activityID);
            jsonObject.put("demo_scheme_id", schemeID);
            jsonObject.put("crop_season_id", seasonId);
            jsonObject.put("cropping_system_id", cropingSysId);
            jsonObject.put("sole_crop_id", sCropID);
            // jsonObject.put("year", year);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 51);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void fetchRabiCropData(int seasonId, String sCropID) {

        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);

            int cropingSysId;
            if (cropingSystemID == CroppingSystem.INTER_CROP.id()) {
                cropingSysId = CroppingSystem.SOLE.id();
            } else {
                cropingSysId = cropingSystemID;
            }

            String schemeID = "";
            if (demoSchemeID == 0) {
                schemeID = "";
            } else {
                schemeID = String.valueOf(demoSchemeID);
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_activity_id", activityID);
            jsonObject.put("demo_scheme_id", schemeID);
            jsonObject.put("crop_season_id", seasonId);
            jsonObject.put("cropping_system_id", cropingSysId);
            jsonObject.put("sole_crop_id", sCropID);
            // jsonObject.put("year", year);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 52);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void fetchInterMasterData(int seasonId, int cropingSysID, String sCropID) {

        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);

            String schemeID = "";
            if (demoSchemeID == 0) {
                schemeID = "";
            } else {
                schemeID = String.valueOf(demoSchemeID);
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_activity_id", activityID);
            jsonObject.put("demo_scheme_id", schemeID);
            jsonObject.put("crop_season_id", seasonId);
            jsonObject.put("cropping_system_id", cropingSysID);
            jsonObject.put("sole_crop_id", sCropID);


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchMasterCropList(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 6);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void fetchCropVariety(int cID) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("crop_name_id", cID);
            // jsonObject.put("activity_id", activityID);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MASTER_API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchCropVerityById(requestBody);
            api.postRequest(responseCall, this, 7);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void createBtnAction() {

        totalDemoArea = totDemoAreaET.getText().toString().trim();
        rabiTotalDemoArea = rabiDemoAreaET.getText().toString().trim();
        totalFFSArea = totFFSAreaET.getText().toString().trim();
        rabiTotalFFSArea = totRabiFFSAreaET.getText().toString().trim();

        if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            planArea = totalDemoArea;
        } else {
            planArea = totalFFSArea;
        }

        if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            kharifPlanArea = totalDemoArea;
        } else {
            kharifPlanArea = "0";
        }

        if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() &&  reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            rabiPlanArea = rabiTotalDemoArea;
        } else {
            rabiPlanArea = "0";
        }

        if (villageID == 0) {
            UIToastMessage.show(AddPlanActivity.this, "Please Select village");
        } else if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && demoSchemeID == 0) {
            UIToastMessage.show(this, "Select demonstration scheme id");
        } else if (cropingSystemID == 0) {
            UIToastMessage.show(this, "Select cropping system");
        } else if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && seasonID == 0) {
            UIToastMessage.show(this, "Select Season");
        } else if (crop1Id == 0) {
            UIToastMessage.show(this, "Select Crop");
        } else if (cropingSystemID != CroppingSystem.SOLE.id() && crop2Id == 0) {
            UIToastMessage.show(this, "Select second Crop");
        } else if (crop1VerityID == 0) {
            UIToastMessage.show(this, "Select Crop variety");
        } else if (cropingSystemID != CroppingSystem.SOLE.id() && crop2VerityID == 0) {
            UIToastMessage.show(this, "Select Crop variety");
        } else if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_FFS_REG) && totalFFSArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter total FFS area");
        } else if (cropingSystemID != CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && totalDemoArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter total demonstration area");
        } else if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_FFS_REG) && rabiTotalFFSArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Rabi FFS area");
        } else if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && rabiTotalDemoArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Rabi demonstration area");
        } else if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_FFS_REG) && totalFFSArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Kharif total FFS area");
        } else if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && totalDemoArea.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Kharif total demonstration area");
        }else {

            if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id()) {
                getPlanArea2();
            }

            String planName;
            if (cropingSystemID == CroppingSystem.SOLE.id()) {
                planName = crop1Name + " - '" + crop1VerityName + "' (Sole)";
            } else if (cropingSystemID == CroppingSystem.INTER_CROP.id()) {
                planName = crop1Name + " - '" + crop1VerityName + "'_" + crop2Name + " - '" + crop2VerityName+ "' (Inter)";
            } else {
                planName = crop1Name + " - '" + crop1VerityName + "'_" + crop2Name + " - '" + crop2VerityName+ "' (CSB)";
            }

            try {

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
                jsonObject.put("created_by", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                jsonObject.put("village_id", villageID);
                jsonObject.put("cropping_system_id", cropingSystemID);
                jsonObject.put("activity_id", activityID);
                jsonObject.put("demo_scheme_id", demoSchemeID);
                jsonObject.put("crop_data", crop_data);
                jsonObject.put("reg_type", reg_type);
                jsonObject.put("plan_name", planName);
                jsonObject.put("total_plan_area", planArea);
                jsonObject.put("kharif_plan_area", kharifPlanArea);
                jsonObject.put("rabi_plan_area", rabiPlanArea);
                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.planRegistrationRequest(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 9);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            JSONArray district_List = jsonObject.getJSONArray("data");
                            for (int j = 0; j < district_List.length(); j++) {
                                JSONObject district_json_object = district_List.getJSONObject(j);

                                district_name = district_json_object.getString("district_name");
                                district_id = district_json_object.getString("district_id");
                                district_name_tv.setText(district_name);

                                subDiv_name = district_json_object.getString("subdivision_name");
                                subDivID = Integer.valueOf(district_json_object.getString("subdivision_id"));
                                subDiv_name_tv.setText(subDiv_name);

                                taluka_name = district_json_object.getString("taluka_name");
                                talukaID = Integer.valueOf(district_json_object.getString("taluka_id"));
                                tal_name_tv.setText(taluka_name);

                            }
                        }
                    }
                }

                // To get Season list
                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            seasonArray = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(this, ApConstants.kSEASON_LIST, seasonArray.toString());

                            if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id()) {
                                for (int s = 0; s < seasonArray.length(); s++) {
                                    JSONObject seasonJson = seasonArray.getJSONObject(s);
                                    String name = seasonJson.getString("name");
                                    String id = seasonJson.getString("id");
                                    if (name.equalsIgnoreCase("KHARIF")) {
                                        seasonKharif = Integer.valueOf(id);
                                    } else if (name.equalsIgnoreCase("RABI")) {
                                        seasonRabi = Integer.valueOf(id);
                                    }
                                }
                                // seasonID = seasonKharif;
                                fetchKharifCropData(seasonKharif, "");

                            }
                        }
                    } else {
                        seasonArray = new JSONArray();
                        UIToastMessage.show(AddPlanActivity.this, jsonObject.getString("response").trim());
                    }
                }


                if (i == 3) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        UIToastMessage.show(this, response.getMsg().trim());
                        finish();
                    } else {
                        UIToastMessage.show(this, response.getMsg().trim());
                    }
                }


                // For Major Crop
                if (i == 5) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && seasonID == 2) {
                            kharifCropJSONArray = response.getData();
                        } else if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && seasonID == 3) {
                            rabiCropJSONArray = response.getData();
                        } else {
                            majorCropJSONArray = response.getData();
                        }
                    } else {
                        majorCropJSONArray = new JSONArray();
                        // UIToastMessage.show(this, response.getMsg());
                        UIToastMessage.show(this, "Crop not found");
                    }
                }

                // For Kharif Crop
                if (i == 51) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        kharifCropJSONArray = response.getData();
                    } else {
                        kharifCropJSONArray = new JSONArray();
                        // UIToastMessage.show(this, response.getMsg());
                        UIToastMessage.show(this, "Crop not found");
                    }
                }

                // For Rabi Crop
                if (i == 52) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        rabiCropJSONArray = response.getData();
                    } else {
                        rabiCropJSONArray = new JSONArray();
                        // UIToastMessage.show(this, response.getMsg());
                        UIToastMessage.show(this, "Crop not found");
                    }
                }

                // For inter Crop
                if (i == 6) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        interCropJSONArray = response.getData();
                    } else {
                        interCropJSONArray = new JSONArray();
                        // UIToastMessage.show(this, response.getMsg());
                        UIToastMessage.show(this, "Inter Crop not found");
                    }
                }


                if (i == 7) {
                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        cropVerityJSONArray = response.getData();
                    } else {
                        cropVerityJSONArray = new JSONArray();
                        UIToastMessage.show(this, response.getMsg());
                    }
                }

                if (i == 8) {

                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        JSONArray cropAreaArray = response.getData();
                        JSONObject cropAreaJSON = cropAreaArray.getJSONObject(0);
                        String planArea = cropAreaJSON.getString("row_ceiling_limit");

                        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
                            totDemoAreaET.setText(planArea);
                            totDemoAreaET.setEnabled(false);
                        } else {
                            totFFSAreaET.setText(planArea);
                            totFFSAreaET.setEnabled(false);
                        }

                    } else {
                        UIToastMessage.show(this, response.getMsg());
                        totDemoAreaET.setText("");
                        totFFSAreaET.setText("");
                        totFFSAreaET.setEnabled(true);
                        totDemoAreaET.setEnabled(true);
                    }
                }


                if (i == 9) {
                    ResponseModel response = new ResponseModel(jsonObject);

                    if (response.isStatus()) {
                        String planId = jsonObject.getString("data");
                        String area = "0";
                        if (cropingSystemID == CroppingSystem.CROP_SYS_BASED.id() && planArea.equalsIgnoreCase("")){
                            area = String.valueOf(Integer.parseInt(kharifPlanArea) + Integer.parseInt(rabiPlanArea)) ;
                        }else {
                            area = planArea;
                        }
                        Intent host_farmer_reg = new Intent(AddPlanActivity.this, D_F_HostFarmerRagistrationActivity.class);
                        host_farmer_reg.putExtra("totalPlanArea", Integer.valueOf(area));
                        host_farmer_reg.putExtra("totalFarmerArea", 0);
                        host_farmer_reg.putExtra("plan_id", Integer.valueOf(planId));
                        host_farmer_reg.putExtra("plan_data", "");
                        host_farmer_reg.putExtra("actionType", "addPlan");
                        startActivity(host_farmer_reg);
                        finish();
                    } else {
                        UIToastMessage.show(this, response.getMsg());
                    }
                }

                if (i == 10) {

                    ResponseModel response = new ResponseModel(jsonObject);
                    if (response.isStatus()) {
                        JSONArray cropAreaArray = response.getData();
                        JSONObject cropAreaJSON = cropAreaArray.getJSONObject(0);
                        String planArea = cropAreaJSON.getString("row_ceiling_limit");

                        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
                            rabiDemoAreaET.setText(planArea);
                            rabiDemoAreaET.setEnabled(false);
                        } else {
                            totRabiFFSAreaET.setText(planArea);
                            totRabiFFSAreaET.setEnabled(false);
                        }

                    } else {
                        UIToastMessage.show(this, response.getMsg());
                        rabiDemoAreaET.setText("");
                        rabiDemoAreaET.setEnabled(true);
                        totRabiFFSAreaET.setText("");
                        totRabiFFSAreaET.setEnabled(true);
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}

