/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 28/12/18 11:58 AM
 */

package com.maha.agri.util;

public interface ApConstants {


    // Comman
    String kMSG               = "Please Wait...";
    String kIN = "IN";
    String kOUT = "OUT";


    //Global Constants
    String kDIR = "KRISI_SMA";
    String kCOMMON_DIR = "common";
    String kVISITS_DIR = "visits";
    String kVISITS_ONLINE_DIR = "Online";
    String kVISITS_OFFLINE_DIR = "Offline";
    String kSHARED_PREF = "maha_agri_sma";
    String kAPP_BUILD_VER = "kAPP_BUILD_VER";


    //Setting Data
    String kIS_LOGGED_IN = "kIS_LOGGED_IN";
    String kUSER_ID = "kUSER_ID";
    String kLOGIN_DATA = "kLOGIN_DATA";
    String kTOKEN = "kTOKEN";

    String kIS_OFFLINE = "kIS_OFFLINE";
    String kOnlineOfflineMode = "kOnlineOfflineMode";

    String kSEASON_ID = "kSEASON_ID";
    String kROLE_ID = "kROLE_ID";

    String kSCHEDULES = "kSCHEDULES";
    String kHISTORY_OF_VISITS = "kHISTORY_OF_VISITS";
    String kCROP_ADVISORY = "kCROP_ADVISORY";


    String kPLOT_ID = "kPLOT_ID";
    String kVISIT_NUM = "kVISIT_NUM";
    String kSCHEDULE_ID = "kSCHEDULE_ID";
    String kVISIT_COUNT = "kVISIT_COUNT";
    String kCROP_NAME = "kCROP_NAME";
    String kINTER_CROP_NAME = "kINTER_CROP_NAME";
    String kINTER_CROP_VISIT_COUNT = "kINTER_CROP_VISIT_COUNT";

    String kDATA = "kDATA";
    String kATTENDANCE = "kATTENDANCE";
    String kATTENDANCE_FILE = "kATTENDANCE_FILE";
    String kATTENDANCE_FILE_LOC = "kATTENDANCE_FILE_LOC";
    String kATTENDANCE_PATH = "kATTENDANCE_PATH";

    String kCROP_UNIQUE_ID = "kCROP_UNIQUE_ID";
    String kVISIT_UNIQUE_ID = "kVISIT_UNIQUE_ID";

    String kSOIL_TEST_REPORT_FILE = "kSOIL_TEST_REPORT_FILE";
    String kYIELD_ATTENDANCE = "kYIELD_ATTENDANCE";

    String kAA_ATTENDANCE = "kAA_ATTENDANCE";
    String kAA_ATTENDANCE_ID = "kAA_ATTENDANCE_ID";
    String kAA_CLUSTER_DATA = "kAA_CLUSTER_DATA";


    //Global constant
    String kPDF_EXTENSION = "pdf";
    String kSERVER_TIME_STAMP = "kSERVER_TIME_STAMP";
    String kDOJ = "kDOJ";


    // Dashboard
    String kAB_REASON = "kAB_REASON";

    // Sync Image
    String kIMG_IN = "check_in";
    String kIMG_OUT = "check_out";

    String MONTH_FILTER = "month_filter";
    String DISTRICT_LIST = "district_list";
    String TALUKA_LIST = "taluka_list";
    String VILLAGE_LIST = "village_list";
    String FARMER_LIST ="farmer_list";
    String SCHEME_LIST ="SCHEME_LIST";


    String kATTENDANCE_LIST = "kATTENDANCE_LIST";
    String kATTENDANCE_LIST_FILE = "kATTENDANCE_LIST_FILE";
    String kATTENDANCE_LIST_FILE_LOC = "kATTENDANCE_LIST_FILE_LOC";
    String kATTENDANCE_LIST_PATH = "kATTENDANCE_LIST_PATH";



    // For Farmer registration
    String kSLED_ACTIVITY = "kSLED_ACTIVITY";
    String kFARMER_REG_TYPE = "kFARMER_REG_TYPE";
    String kFARMER_FFS_REG = "FFS";
    String kFARMER_DEMO_REG = "DEMO";

    // For Farmer Selection
    String kVILLAGE_ID_DEMO_FFS = "kVILLAGE_ID_DEMO_FFS";
    String kFARMER_ID_DEMO_FFS = "kFARMER_ID_DEMO_FFS";
    String kPLAN_ID_DEMO_FFS = "kPLAN_ID_DEMO_FFS";
    String kCROP_ID_DEMO_FFS = "kCROP_ID_DEMO_FFS";
    String kCROP_VERITY_ID_DEMO_FFS = "kCROP_VERITY_ID_DEMO_FFS";


    // For Pre Showing
    String kPRE_SHOWING_IMG1_URL = "kPRE_SHOWING_IMG1_URL";
    String kPRE_SHOWING_IMG2_URL = "kPRE_SHOWING_IMG2_URL";

    // FOR FFS
    String kSLED_SEASON_ID = "kSLED_SEASON_ID";
    String kSEASON_LIST = "kSEASON_LIST";

    // For Technology Demon
    String kTECH_DEMO = "kTECH_DEMO";
    String kINPUT_DEMO = "kINPUT_DEMO";
    String kTECH_DEMO_PATH1 = "kTECH_DEMO_PATH1";
    String kTECH_DEMO_FILE1 = "kTECH_DEMO_FILE1";
    String kTECH_DEMO_FILE1_LOC = "kTECH_DEMO_FILE1_LOC";
    String kTECH_DEMO_PATH2 = "kTECH_DEMO_PATH2";
    String kTECH_DEMO_FILE2 = "kTECH_DEMO_FILE2";
    String kTECH_DEMO_FILE2_LOC = "kTECH_DEMO_FILE2_LOC";
    //String kTECH_DEMO_SCHEME_ID = "kDEMO_SCHEME_ID";

    // For Observation
    String kOBSERVATIONS = "kOBSERVATIONS";
    String kOBS_FILE1 = "kOBS_FILE1";
    String kOBS_FILE2 = "kOBS_FILE2";
    String kOBS_FILE3 = "kOBS_FILE3";
    String kOBS_FILE4 = "kOBS_FILE4";
    String kOBS_FILE1_LOC = "kOBS_FILE1_LOC";
    String kOBS_FILE2_LOC = "kOBS_FILE2_LOC";
    String kOBS_FILE3_LOC = "kOBS_FILE3_LOC";
    String kOBS_FILE4_LOC = "kOBS_FILE4_LOC";
    String kOBS_PATH1 = "kOBS_PATH1";
    String kOBS_PATH2 = "kOBS_PATH2";
    String kOBS_PATH3 = "kOBS_PATH3";
    String kOBS_PATH4 = "kOBS_PATH4";

    String kNO_DISEASE = "kNO_DISEASE";


    String kOBS_WEATHER_NAME = "kOBS_WEATHER_NAME";
    String kOBS_WEATHER_ID = "kOBS_WEATHER_ID";
    String kOBS_WIND_NAME = "kOBS_WIND_NAME";
    String kOBS_WIND_ID = "kOBS_WIND_ID";
    String kOBS_RAINFALL_NAME = "kOBS_RAINFALL_NAME";
    String kOBS_RAINFALL_ID = "kOBS_RAINFALL_ID";

    String kOBS_DATE_SOWING = "kOBS_DATE_SOWING";
    String kOBS_METHOD_SOWING = "kOBS_METHOD_SOWING";
    String kOBS_CROP_VARIETY = "kOBS_CROP_VARIETY";
    String kOBS_IRRIGATION_METHOD = "kOBS_IRRIGATION_METHOD";


    // for mb recording
    String  QTY_SOIL_ID = "QTY_SOIL_ID";
    String QTY_SOFT_MURUM_ID = "QTY_SOFT_MURUM_ID";
    String QTY_HARD_MURUM_ID = "QTY_HARD_MURUM_ID";
    String HEIGHT_VERTICAL_WALL_HEIGHT_ID = "HEIGHT_VERTICAL_WALL_HEIGHT_ID";
    String MB_FARMER_NAME ="MB_FARMER_NAME";
    String MB_SCHEME_NAME ="MB_SCHEME_NAME";
    String SURVEY_NAME ="SURVEY_NAME";
    String PCC_QTY_BEAM = "PCC_QTY_BEAM";
    String PCC_VERTICAL_WALL = "PCC_VERTICAL_WALL";
    String MB_STAGE_LAVAL = "1";

    String  LIFT_TO_SOIL_ID = "0";
    String LIFT_TO_SOFT_MURUM = "LIFT_TO_SOFT_MURUM";
    String LIFT_TO_HARD_MURUM = "LIFT_TO_HARD_MURUM";
    String LIFT_TO_HARD_MAN = "LIFT_TO_HARD_MAN";
    String LIFT_TO_HARD_MAN_BOULDER = "LIFT_TO_HARD_MAN_BOULDER";
    String LIFT_TO_SOFT_ROCK = "LIFT_TO_SOFT_ROCK";
    String LIFT_TO_JAMBA = "LIFT_TO_JAMBA";
    String LIFT_TO_HARD_ROCK = "LIFT_TO_HARD_ROCK";

    //sprinkler list
    String SPRINKLER_LIST_ID = "SPRINKLER_LIST_ID";

    //For Demo AESA Form
    String kOBS_CROP_B_NORMAL = "Below Normal";
    String kOBS_CROP_NORMAL = "Normal";
    String kOBS_CROP_GOOD = "Good";
    String kOBS_CROP_EXCELLENT = "Excellent";

}

