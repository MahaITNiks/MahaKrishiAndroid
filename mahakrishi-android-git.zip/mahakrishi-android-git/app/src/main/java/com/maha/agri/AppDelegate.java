package com.maha.agri;

import android.app.Application;
import androidx.room.Room;
import android.content.Context;

import com.maha.agri.ffs.ffs_db.FfsDatabase;
import com.maha.agri.util.ApConstants;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.settings.AppSettings;

public class AppDelegate extends Application {

    private static Context mContext;
    private FfsDatabase ffsDatabase;
    private final String DATABASE_NAME = "ffs_database";

    private static AppDelegate mInstance = null;
    public static AppDelegate getInstance(Context context) {
        if (mInstance == null) {
            mContext = context;
            mInstance = new AppDelegate();
        }
        return mInstance;
    }



    @Override
    public void onCreate() {
        super.onCreate();
        AppSettings.getInstance().initAppSettings(ApConstants.kSHARED_PREF);
        DebugLog.getInstance().initLoggingEnabled(true);
    }

    public FfsDatabase getFfsDatabase() {
        ffsDatabase = Room.databaseBuilder(mContext, FfsDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .build();
        return ffsDatabase;
    }
}
