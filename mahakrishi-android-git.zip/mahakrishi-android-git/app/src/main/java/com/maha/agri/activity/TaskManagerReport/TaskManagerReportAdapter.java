package com.maha.agri.activity.TaskManagerReport;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TaskManagerReportAdapter extends RecyclerView.Adapter<TaskManagerReportAdapter.MyViewHolder>  {
    private JSONArray task_manager_array_list;
    private int[] task_manager_background;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView task_manager_single_background;
        private TextView task_manager_single_title,countTV;
        private RelativeLayout task_manager_single_item_rl;



        public MyViewHolder(View itemView) {
            super(itemView);
            this.task_manager_single_background =  itemView.findViewById(R.id.task_manager_back_single_image_view);
            this.task_manager_single_title = itemView.findViewById(R.id.task_manager_single_text_view);
            this.task_manager_single_item_rl = itemView.findViewById(R.id.task_manager_single_item_rl);
            this.countTV = itemView.findViewById(R.id.countTV);


        }
    }

    public TaskManagerReportAdapter(PreferenceManager preferenceManager, JSONArray task_manager_array_list, int[] task_manager_background, Context context) {
        this.preferencemanager = preferenceManager;
        this.task_manager_array_list = task_manager_array_list;
        this.task_manager_background = task_manager_background;
        this.context = context;

    }

    @Override
    public TaskManagerReportAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                    int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_manager_report_single_item, parent, false);

        TaskManagerReportAdapter.MyViewHolder myViewHolder = new TaskManagerReportAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final TaskManagerReportAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = task_manager_array_list.getJSONObject(listPosition);

            holder.task_manager_single_item_rl.setTag(listPosition);

            holder.task_manager_single_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = task_manager_array_list.getJSONObject(index).getString("id");
                        if(id.equalsIgnoreCase("1")){
                            Intent scheme =  new Intent(context, SchemeReportActivity.class);
                            context.startActivity(scheme);
                        }

                        if(id.equalsIgnoreCase("2")){
                            Intent scheme =  new Intent(context, NonSchemeListReportActivity.class);
                            context.startActivity(scheme);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
            {
                holder.task_manager_single_title.setText(jsonObject.getString("name"));
                holder.countTV.setText(jsonObject.getString("activity_count"));
                holder.task_manager_single_background.setImageResource(task_manager_background[listPosition]);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if(task_manager_array_list!=null){
            return task_manager_array_list.length();
        }
        else{
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private TaskManagerReportAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final TaskManagerReportAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
