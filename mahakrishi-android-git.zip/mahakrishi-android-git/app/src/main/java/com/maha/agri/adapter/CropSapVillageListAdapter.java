package com.maha.agri.adapter;

import android.content.Context;

import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.maha.agri.R;
import com.maha.agri.dept_cropsap.FarmerListActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CropSapVillageListAdapter extends RecyclerView.Adapter<CropSapVillageListAdapter.MyViewHolder> {
    private JSONArray village_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView village_name_single_title,village_code_single_tv,village_cropsap_count_single_text_view;
        private RelativeLayout village_list_rl;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.village_name_single_title = itemView.findViewById(R.id.village_single_text_view);
            this.village_code_single_tv = itemView.findViewById(R.id.village_code_single_text_view);
            this.village_cropsap_count_single_text_view = itemView.findViewById(R.id.village_cropsap_count_single_text_view);
            this.village_list_rl = itemView.findViewById(R.id.village_list_rl);
        }
    }

    public CropSapVillageListAdapter(JSONArray village_array_list, Context context) {
        this.village_array_list = village_array_list;
        this.context = context;

    }

    @Override
    public CropSapVillageListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cropsapvillagelist_single_item, parent, false);

        CropSapVillageListAdapter.MyViewHolder myViewHolder = new CropSapVillageListAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final CropSapVillageListAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = village_array_list.getJSONObject(listPosition);

            holder.village_list_rl.setTag(listPosition);

            holder.village_list_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = village_array_list.getJSONObject(index).getString("village_id");
                        Intent intent = new Intent(context, FarmerListActivity.class);
                        intent.putExtra("village_id",id);
                        intent.putExtra("name","roshan");
                        context.startActivity(intent);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

                holder.village_name_single_title.setText(jsonObject.getString("village_name"));
                holder.village_code_single_tv.setText(jsonObject.getString("village_id"));
                holder.village_cropsap_count_single_text_view.setText(jsonObject.getString("cnt"));



        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (village_array_list != null) {
            return village_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private CropSapVillageListAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CropSapVillageListAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
