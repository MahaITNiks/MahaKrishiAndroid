/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.adaptor;

import android.content.Context;
import android.os.Vibrator;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.ffs.model.OffDiseaseTypeModel;
import com.maha.agri.util.ApConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;

import static android.content.Context.VIBRATOR_SERVICE;

public class DiseaseSeverityAdapter extends RecyclerView.Adapter<DiseaseSeverityAdapter.ViewHolder> {


    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;
    private int requestCode;
    private int severityId = 0;


    public DiseaseSeverityAdapter(Context mContext, int requestCode, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.requestCode = requestCode;
        this.listener = listener;
        this.mDataArray = jsonArray;
    }


    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.recycler_disease_severity, parent, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            holder.onBind(mDataArray.getJSONObject(position), listener);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView nameTextView;
        //private ImageView trashImageView;
        private RadioGroup radioGroup;
        private RadioButton lRadioButton;
        private RadioButton mRadioButton;
        private RadioButton hRadioButton;


        public ViewHolder(View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.nameTextView);
            //trashImageView = itemView.findViewById(R.id.trashImageView);
            radioGroup = itemView.findViewById(R.id.radioGroup);
            lRadioButton = itemView.findViewById(R.id.lRadioButton);
            mRadioButton = itemView.findViewById(R.id.mRadioButton);
            hRadioButton = itemView.findViewById(R.id.hRadioButton);

        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            final Vibrator vibrator = (Vibrator)mContext.getSystemService(VIBRATOR_SERVICE);

            OffDiseaseTypeModel model = new OffDiseaseTypeModel(jsonObject);

            nameTextView.setText(model.getName());

           /* trashImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onMultiRecyclerViewItemClick(requestCode, jsonObject);
                }
            });
*/
            if (model.getIs_severity() == 1) {
                lRadioButton.setChecked(true);
                mRadioButton.setChecked(false);
                hRadioButton.setChecked(false);

            } else if (model.getIs_severity() == 2) {
                lRadioButton.setChecked(false);
                mRadioButton.setChecked(true);
                hRadioButton.setChecked(false);

            } else if (model.getIs_severity() == 3) {
                lRadioButton.setChecked(false);
                mRadioButton.setChecked(false);
                hRadioButton.setChecked(true);

            } else {
                lRadioButton.setChecked(false);
                mRadioButton.setChecked(false);
                hRadioButton.setChecked(false);
            }

            if (model.getName().equalsIgnoreCase(ApConstants.kNO_DISEASE)) {
                lRadioButton.setEnabled(false);
                mRadioButton.setEnabled(false);
                hRadioButton.setEnabled(false);
                lRadioButton.setChecked(false);
                mRadioButton.setChecked(false);
                hRadioButton.setChecked(false);
            }

            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                      @Override
                                                      public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                          if (checkedId == R.id.lRadioButton) {
                                                              severityId = 1;
                                                              try {
                                                                  jsonObject.put("is_severity", 1);
                                                                  if (requestCode == 6) {
                                                                      listener.onMultiRecyclerViewItemClick(66, jsonObject);

                                                                  } else {
                                                                      listener.onMultiRecyclerViewItemClick(77, jsonObject);

                                                                  }
                                                              } catch (JSONException e) {
                                                                  e.printStackTrace();
                                                              }
                                                          } else if (checkedId == R.id.mRadioButton) {
                                                              severityId = 2;
                                                              try {
                                                                  jsonObject.put("is_severity", 2);
                                                                  if (requestCode == 6) {
                                                                      listener.onMultiRecyclerViewItemClick(66, jsonObject);

                                                                  } else {
                                                                      listener.onMultiRecyclerViewItemClick(77, jsonObject);

                                                                  }
                                                              } catch (JSONException e) {
                                                                  e.printStackTrace();
                                                              }
                                                          } else if (checkedId == R.id.hRadioButton) {
                                                              severityId = 3;
                                                              try {
                                                                  jsonObject.put("is_severity", 3);
                                                                  if (requestCode == 6) {
                                                                      listener.onMultiRecyclerViewItemClick(66, jsonObject);

                                                                  } else {
                                                                      listener.onMultiRecyclerViewItemClick(77, jsonObject);

                                                                  }
                                                              } catch (JSONException e) {
                                                                  e.printStackTrace();
                                                              }
                                                          }
                                                      }
                                                  }
            );


            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (vibrator != null) {
                        vibrator.vibrate(100);
                    }
                    listener.onMultiRecyclerViewItemClick(requestCode, jsonObject);

                    return true;
                }
            });

            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onMultiRecyclerViewItemClick(requestCode, jsonObject);
                }
            });*/

        }

    }


}