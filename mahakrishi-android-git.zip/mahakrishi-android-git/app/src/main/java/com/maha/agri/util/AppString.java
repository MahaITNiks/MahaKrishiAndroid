/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 28/12/18 11:58 AM
 */

package com.maha.agri.util;

import android.content.Context;

import com.maha.agri.R;


public class AppString {

    private Context mContext = null;

    private String kMSG_WAIT;
    private String kNETWORK;
    private String kUNAUTHORISED;


    public AppString(Context mContext) {
        this.mContext = mContext;

    }

    public String getAppName() {
        return mContext.getResources().getString(R.string.app_name);
    }

    public String getLogoutAlertMsg() {
        return mContext.getResources().getString(R.string.logout_alert);
    }

    public String getHomeAlertMsg() {
        return mContext.getResources().getString(R.string.home_alert);
    }

    public String getOK() {
        return mContext.getResources().getString(R.string.ok);
    }

    public String getCANCEL() {
        return mContext.getResources().getString(R.string.cancel);
    }


    public String getYES() {
        return mContext.getResources().getString(R.string.yes);
    }


    public String getNO() {
        return mContext.getResources().getString(R.string.no);
    }


    public String getkMSG_WAIT() {
        kMSG_WAIT = mContext.getResources().getString(R.string.please_wait);
        return kMSG_WAIT;
    }

    public String getkNETWORK() {
        kNETWORK = mContext.getResources().getString(R.string.no_internet);
        return kNETWORK;
    }

    public String getkUNAUTHORISED() {
        kUNAUTHORISED = mContext.getResources().getString(R.string.unauthorised);
        return kUNAUTHORISED;
    }






    public String getGuestFarmer() {
        return mContext.getResources().getString(R.string.guest_farmer);
    }



    //::TODO GENDER
    public String getMale() {
        return mContext.getResources().getString(R.string.male);
    }

    public String getFemale() {
        return mContext.getResources().getString(R.string.female);
    }

    public String getTransgender() {
        return mContext.getResources().getString(R.string.transgender);
    }



    //::TODO landcategory
    public String getLandMarginal() {
        return mContext.getResources().getString(R.string.land_marginal);
    }
    public String getLandSmall() {
        return mContext.getResources().getString(R.string.land_small);
    }

    public String getLandOthers() {
        return mContext.getResources().getString(R.string.land_others);
    }


    public String getLoading() {
        return mContext.getResources().getString(R.string.loading);
    }

    /*public  String getActivateAcc() {
        return mContext.getResources().getString(R.string.ca_activate);
    }

    public  String getDeActivateAcc() {
        return mContext.getResources().getString(R.string.ca_deactivate);
    }*/


    public String getHostFarmerName() {
        return mContext.getResources().getString(R.string.schedule_host_name);
    }

    public String getGuestFarmerName() {
        return mContext.getResources().getString(R.string.schedule_host_name);
    }



    public String getPlotNum() {
        return mContext.getResources().getString(R.string.schedule_plot);
    }

    public String getPlanName() {
        return mContext.getResources().getString(R.string.schedule_plan);
    }

    public String getInterCropName() {
        return mContext.getResources().getString(R.string.schedule_inter_crop);
    }

    public String getCroppingName() {
        return mContext.getResources().getString(R.string.schedule_cropping);
    }

    public String getCroppingSole() {
        return mContext.getResources().getString(R.string.schedule_cropping_s);
    }

    public String getCroppingInter() {
        return mContext.getResources().getString(R.string.schedule_cropping_i);
    }

    public String getVillage() {
        return mContext.getResources().getString(R.string.schedule_village);
    }

    public String getDay() {
        return mContext.getResources().getString(R.string.schedule_day);
    }

    public String getScheduleDate() {
        return mContext.getResources().getString(R.string.schedule_date);
    }

    public String getVisit() {
        return mContext.getResources().getString(R.string.visit_number);
    }

    public String getHostFarmer() {
        return mContext.getResources().getString(R.string.attendance_host);
    }


    public String getMobile() {
        return mContext.getResources().getString(R.string.attendance_mobile);
    }

    public String getEmail() {
        return mContext.getResources().getString(R.string.attendance_email);
    }


    //::TODO History Of Visits
    public String getHisVillage() {
        return mContext.getResources().getString(R.string.his_history_vill);
    }
    public String getHisName() {
        return mContext.getResources().getString(R.string.his_history_name);
    }

    public String getHisPlot() {
        return mContext.getResources().getString(R.string.his_history_plot);
    }
    public String getHisDate() {
        return mContext.getResources().getString(R.string.his_history_date);
    }

    //::TODO Crop Advisory
    public String getCropAdvisoryWeek() {
        return mContext.getResources().getString(R.string.crop_crop_advisory_week);
    }

    //::TODO VILLAGE LIST ADAPTER

    public String villageName() {
        return mContext.getResources().getString(R.string.village_list_name);
    }

    public String villageCensusCode() {
        return mContext.getResources().getString(R.string.village_list_census);
    }

    public String villageTaluka() {
        return mContext.getResources().getString(R.string.village_list_taluka);
    }

    public String villageSubdivision() {
        return mContext.getResources().getString(R.string.village_list_div);
    }

    public String villageGramPanchayatName() {
        return mContext.getResources().getString(R.string.village_list_gram_p);
    }

    public String villageGramPanchayatCode() {
        return mContext.getResources().getString(R.string.village_list_gp_code);
    }

    public String villageDistrict() {
        return mContext.getResources().getString(R.string.village_list_district);
    }

    public String soilTestReportDone() {
        return mContext.getResources().getString(R.string.soil_test_done);
    }

    public String soilTestReportNotDone() {
        return mContext.getResources().getString(R.string.soil_test_not_done);
    }

    public String inputUsedTestReportDone() {
        return mContext.getResources().getString(R.string.input_test_done);
    }

    public String inputUsedTestReportNotDone() {
        return mContext.getResources().getString(R.string.input_test_not_done);
    }

}
