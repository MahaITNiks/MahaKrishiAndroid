package com.maha.agri.dept_cropsap;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.maha.agri.R;
import com.maha.agri.adapter.CropSapVillageListAdapter;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;

import org.json.JSONArray;
import org.json.JSONException;

public class DepartmentCropSapVillageList extends AppCompatActivity {
    private JSONArray village_list;
    private RecyclerView village_list_rv;
    private String data;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_crop_sap_village_list);
        getSupportActionBar().setTitle("Village List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(DepartmentCropSapVillageList.this);
        sharedPref = new SharedPref(DepartmentCropSapVillageList.this);
        village_list_rv = (RecyclerView) findViewById(R.id.village_list_rv);
        village_list_rv.setLayoutManager(new LinearLayoutManager(this));

        data = preferenceManager.getPreferenceValues(Preference_Constant.FARMER_VILLAGE_LIST_WITH_CROPSAP_COUNT);
        try {
            village_list = new JSONArray(data);
            village_list_rv.setAdapter(new CropSapVillageListAdapter(village_list,DepartmentCropSapVillageList.this));
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
