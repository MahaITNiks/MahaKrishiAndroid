package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GreenHouseLastActivity extends AppCompatActivity implements ApiCallbackCode {
    private TextView green_house2_datetv,green_house2_beneficiary_name,green_house2_villagetv,green_house2_talukatv,green_house2_districttv,green_house2_surveyno,
            green_house2_vargvari,green_house2_bab,green_house2_pre_date,green_house2_pre_area;
    
    private RadioGroup green_house2_permission_rg;
    private RadioButton green_house2_permission_yes,green_house2_permission_no;
    private ImageView green_house2_dateiv;
    private EditText green_house2_length,green_house2_breadth,green_house2_height,green_house2_fieldfruit,green_house2_babet,green_house2_ekak,green_house2_mapdand,
            green_house2_spendrow,green_house2_dar,green_house2_given_cost,green_house2_field9,green_house2_field11;
    private Button green_house2_save;
    private CheckBox green_house2_checkbox;
    private SweetAlertDialog sweetAlertDialog;
    private int mYear, mMonth, mDay;
    private DatePickerDialog green_house2_datepicker;
    private String green_house2_date="0",permission="0",fruit_str="";
    private double fruit_int=0;
    //Akshay
    private float field_shetrafal_int=0,field9_int=0,field10_int=0,field11_int=0,field12_int=0,field13_int=0,field14_int=0;
    private String field_shetrafal_str="",field9_str="",field10_str="",field11_str="",field12_str="",field13_str="",field14_str="",green_house2_fieldfruit_str;
    private TextView green_house2_field10,green_house2_field12,green_house2_field13,green_house2_field14;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_green_house_last);
        getSupportActionBar().setTitle("Green House and Shade Net House ");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(GreenHouseLastActivity.this);

        ids();
        functions();
    }
    
    private void ids(){
        //Textview
        green_house2_datetv = (TextView) findViewById(R.id.green_house2_datetv);
        green_house2_beneficiary_name = (TextView) findViewById(R.id.green_house2_beneficiary_name);
        green_house2_villagetv = (TextView) findViewById(R.id.green_house2_villagetv);
        green_house2_talukatv = (TextView) findViewById(R.id.green_house2_talukatv);
        green_house2_districttv = (TextView) findViewById(R.id.green_house2_districttv);
        green_house2_surveyno = (TextView) findViewById(R.id.green_house2_surveyno);
        green_house2_vargvari = (TextView) findViewById(R.id.green_house2_vargvari);
        green_house2_bab = (TextView) findViewById(R.id.green_house2_bab);
        green_house2_pre_date = (TextView) findViewById(R.id.green_house2_pre_date);
        green_house2_pre_area = (TextView) findViewById(R.id.green_house2_pre_area);
        green_house2_field10 = (TextView) findViewById(R.id.green_house2_field10);
        green_house2_field12 = (TextView) findViewById(R.id.green_house2_field12);
        green_house2_field13 = (TextView) findViewById(R.id.green_house2_field13);
        green_house2_field14 = (TextView) findViewById(R.id.green_house2_field14);
        //Edittext
        green_house2_length = (EditText) findViewById(R.id.green_house2_length);
        green_house2_breadth = (EditText) findViewById(R.id.green_house2_breadth);
        green_house2_height = (EditText) findViewById(R.id.green_house2_height);
        green_house2_fieldfruit = (EditText) findViewById(R.id.green_house2_fieldfruit);
        green_house2_babet = (EditText) findViewById(R.id.green_house2_babet);
        green_house2_ekak = (EditText) findViewById(R.id.green_house2_ekak);
        green_house2_mapdand = (EditText) findViewById(R.id.green_house2_mapdand);
        green_house2_spendrow = (EditText) findViewById(R.id.green_house2_spendrow);
        green_house2_dar = (EditText) findViewById(R.id.green_house2_dar);
        green_house2_given_cost = (EditText) findViewById(R.id.green_house2_given_cost);
        green_house2_field9 = (EditText) findViewById(R.id.green_house2_field9);
        green_house2_field11 = (EditText) findViewById(R.id.green_house2_field11);
        //Imageview
        //green_house2_dateiv = (ImageView) findViewById(R.id.green_house2_dateiv);

        green_house2_save = (Button) findViewById(R.id.green_house2_save);
        green_house2_checkbox = (CheckBox) findViewById(R.id.green_house2_checkbox);
        green_house2_permission_rg = (RadioGroup) findViewById(R.id.green_house2_permission_rg);
        green_house2_permission_yes = (RadioButton) findViewById(R.id.green_house2_permission_yes);
        green_house2_permission_no = (RadioButton) findViewById(R.id.green_house2_permission_no);

        green_house2_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        green_house2_datetv.setText(green_house2_date);
    }
    
    private void functions(){
        /*green_house2_dateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                green_house2_date_service();
            }
        });*/

        green_house2_permission_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.green_house2_permission_yes:
                        green_house2_permission_yes.setChecked(true);
                        permission = "1";
                        break;

                    case R.id.green_house2_permission_no:
                        green_house2_permission_no.setChecked(true);
                        permission = "2";
                        break;
                }
            }
        });

        green_house2_fieldfruit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                field_shetrafal_str=green_house2_fieldfruit.getText().toString().trim();
                field9_str= green_house2_field9.getText().toString().trim();

                if(!field11_str.equals("")){
                    green_house2_field11.setText("");
                }

                if((field_shetrafal_str.equals("")) || (field_shetrafal_str.equals("0")) ){
                    field_shetrafal_int=1;
                    green_house2_field9.setText("");
                    green_house2_field10.setText("");
                }
                else if(field9_str.equals("")){
                    field9_int=0;
                    if( field_shetrafal_str.equals("") ){
                        field_shetrafal_int=1;
                    }
                    field10_int=field9_int/1;
                    green_house2_field10.setText(Float.toString(field10_int));
                }
                else{
                    field_shetrafal_int=Integer.parseInt(field_shetrafal_str);
                    field9_int=Float.parseFloat(field9_str);
                    field10_int=field9_int/field_shetrafal_int;
                    green_house2_field10.setText(Float.toString(field10_int));
                }

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        green_house2_field11.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                field11_str = green_house2_field11.getText().toString().trim();
                if(field11_str.equals("")){
                    field11_int=0;
                    if(field10_int <= field11_int){
                        green_house2_field12.setText(Float.toString(field10_int));
                        field12_int=field10_int * field_shetrafal_int;
                        green_house2_field13.setText(Float.toString(field12_int));
                        field13_int=field12_int/2;
                        green_house2_field14.setText(Float.toString(field13_int));
                    }
                    else{
                        green_house2_field12.setText(Float.toString(field11_int));
                        field12_int=field11_int * field_shetrafal_int;;
                        green_house2_field13.setText(Float.toString(field12_int));
                        field13_int=field12_int/2;
                        green_house2_field14.setText(Float.toString(field13_int));
                    }
                }
                else{
                    field11_int = Float.parseFloat(field11_str);
                    if(field10_int <= field11_int){
                        green_house2_field12.setText(Float.toString(field10_int));
                        field12_int=field10_int * field_shetrafal_int;
                        green_house2_field13.setText(Float.toString(field12_int));
                        field13_int=field12_int/2;
                        green_house2_field14.setText(Float.toString(field13_int));
                    }
                    else{
                        green_house2_field12.setText(Float.toString(field11_int));
                        field12_int=field11_int * field_shetrafal_int;
                        green_house2_field13.setText(Float.toString(field12_int));
                        field13_int=field12_int/2;
                        green_house2_field14.setText(Float.toString(field13_int));
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });




        green_house2_field9.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                field_shetrafal_str=green_house2_fieldfruit.getText().toString().trim();
                field9_str= green_house2_field9.getText().toString().trim();

                if((field_shetrafal_str.equals("")) || (field_shetrafal_str.equals("0")) ){
                    field_shetrafal_int=1;
                }
                else if(field9_str.equals("")){
                    field9_int=0;
                    System.out.println("CAUGHT");
                }
                else{
                    field_shetrafal_int=Integer.parseInt(field_shetrafal_str);
                    field9_int=Float.parseFloat(field9_str);
                }
                field10_int=field9_int/field_shetrafal_int;
                green_house2_field10.setText(Float.toString(field10_int));
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        green_house2_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //green_house2_save_service();
            }
        });
    }

    private void green_house2_date_service(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        green_house2_datepicker = new DatePickerDialog(GreenHouseLastActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        green_house2_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        green_house2_datetv.setText(green_house2_date);
                    }
                }, mYear, mMonth, mDay);

        green_house2_datepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        green_house2_datepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        green_house2_datepicker.show();
    }

    private void green_house2_save_service(){
        if(green_house2_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select तपासणी दिनांक", Toast.LENGTH_SHORT).show();
        }else if(green_house2_length.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter लांबी", Toast.LENGTH_SHORT).show();
        }else if(green_house2_breadth.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter रुंदी", Toast.LENGTH_SHORT).show();
        }else if(green_house2_height.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter उंची", Toast.LENGTH_SHORT).show();
        }else if(green_house2_fieldfruit.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter क्षेत्रफळ", Toast.LENGTH_SHORT).show();
        }else if(green_house2_babet.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter बाब", Toast.LENGTH_SHORT).show();
        }else if(green_house2_ekak.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter एकक", Toast.LENGTH_SHORT).show();
        }else if(green_house2_mapdand.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मापदंडाप्रमाणे शिफारशीत परिमाण", Toast.LENGTH_SHORT).show();
        }else if(green_house2_spendrow.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्ष देयकाप्रमाणे वापरलेले परिमाण", Toast.LENGTH_SHORT).show();
        }else if(green_house2_dar.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter दर", Toast.LENGTH_SHORT).show();
        }else if(green_house2_given_cost.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter देयकाप्रमाणे किंमत", Toast.LENGTH_SHORT).show();
        }else if(green_house2_field9.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter उपरोक्त परिशिष्टाप्रमाणे वापरण्यात आलेल्या साहित्याची एकुण किंमत (प्रत्यक्ष खर्च)", Toast.LENGTH_SHORT).show();
        }else if(green_house2_field11.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शक सूचनेत उपरोक्त मोंडेलसाठी शिफारस केलेला प्रती चौ.मी. दर", Toast.LENGTH_SHORT).show();
        }else if(!green_house2_checkbox.isChecked()){
            Toast.makeText(getApplicationContext(), "Accept the terms", Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("date_gh", green_house2_date);
                param.put("farmer_name", "0");
                param.put("village_id", "0");
                param.put("taluka_id", "0");
                param.put("district_id", "0");
                param.put("survey_no", "0");
                param.put("vargvari", "0");
                param.put("bab", "0");
                param.put("previous_date", "0");
                param.put("pre_area", "0");
                param.put("permission", permission);
                param.put("length", green_house2_length.getText().toString().trim());
                param.put("breadth", green_house2_breadth.getText().toString().trim());
                param.put("height", green_house2_height.getText().toString().trim());
                param.put("fieldfruit", green_house2_fieldfruit.getText().toString().trim());
                param.put("bab_et", green_house2_babet.getText().toString().trim());
                param.put("ekak", green_house2_ekak.getText().toString().trim());
                param.put("mapdand", green_house2_mapdand.getText().toString().trim());
                param.put("spend", green_house2_spendrow.getText().toString().trim());
                param.put("dar", green_house2_dar.getText().toString().trim());
                param.put("given_cost", green_house2_given_cost.getText().toString().trim());
                param.put("field9", green_house2_field9.getText().toString().trim());
                param.put("field10", field10_str);
                param.put("field11", green_house2_field11.getText().toString().trim());
                param.put("field12", field12_str);
                param.put("field13", field13_str);
                param.put("field14", field14_str);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Green House and Shade Net House");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    /*Intent intent = new Intent(GreenHouseActivity.this,GIPipesActivity.class);
                                    startActivity(intent);*/
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
