package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SoyabeanOtherWorkActivity extends AppCompatActivity implements ApiCallbackCode {
    static final Integer CAMERA = 0x5;
    //Image
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    public double lat, lang;
    Spinner sp_technicalname_insecticide_soyabeanOA, sp_technicalname_fungicide_soyabeanOA, sp_weedicide_technicalname_soyabeanOA, sp_irrigation_given_soyabeanOA;
    EditText edt_tradename_weedicide_soyabeanOA, edt_quantity_used_acre_weedicide_soyabeanOA, edt_fertilizer_soyabeanOA_N, edt_fertilizer_soyabeanOA_P, edt_fertilizer_soyabeanOA_K, edt_fertilizername_soyabeanOA,
            edt_quantity_used_acre_fertilizer_soyabeanOA, edt_tradename_insecticide_soyabeanOA, edt_quantity_used_acre_insecticide_soyabeanOA, edt_tradename_fungicide_soyabeanOA,
            edt_quantity_used_acre_fungicide_soyabeanOA;
    RadioButton insecticide_soyabeanOA_yes, insecticide_soyabeanOA_no, fungicide_soyabeanOA_yes, fungicide_soyabeanOA_no, weedicide_soyabeanOA_yes, weedicide_soyabeanOA_no,
            fertilizer_soyabeanOA_yes, fertilizer_soyabeanOA_no, weeding_soyabeanOA_rb, hoeing_soyabeanOA_rb, detopping_soyabeanOA_rb, none_soyabeanOA_rb,
            irrigation_soyabeanOA_yes, irrigation_soyabeanOA_no;
    RadioGroup insecticide_radio_group_soyabeanOA, fungicide_radio_group_soyabeanOA, weedicide_radio_group_soyabeanOA, fertilizer_radio_group_soyabeanOA,
            radio_group_intercultural_soyabeanOA, radio_group_irrigation_field_soyabeanOA;
    ImageView pest_soyabeanOA_photo, crop_growth_soyabeanOA_photo;
    Button btn_submit_soyabean_OA;
    LinearLayout ll_insecticide_layout_soyabeanOA, ll_fungicide_layout_soyabeanOA, ll_weedicide_layout_soyabeanOA, ll_fertilizer_layout_soyabeanOA;
    RelativeLayout rl_irrigation_layout_soyabeanOA;
    SharedPref sharedPref;
    int count = 1;
    String type, currentTime;
    private String insecticide_yes = "", fungicide_yes = "", weedicide_yes = "", fertilizer_yes = "", intercultural = "", irrigation_yes = "";
    private PreferenceManager preferenceManager;
    private int district_id = 0, taluka_id = 0, village_id = 0, farmer_id = 0;
    private String technicalname_insecticide = "", technicalname_fungicide = "", weedicide_technicalname = "", irrigation_given = "";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private String imagePath1, imagePath2;
    private String image_1_file_name, image_2_file_name;
    private Transformation transformation;
    private AppLocationManager locationManager;
    private String trap1_spodoptera="",trap2_spodoptera="",trap1_helicoverpa="",trap2_helicoverpa="";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soyabean_other_work);
        getSupportActionBar().setTitle("Other Works");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(SoyabeanOtherWorkActivity.this);
        sharedPref = new SharedPref(SoyabeanOtherWorkActivity.this);
        locationManager = new AppLocationManager(this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        village_id = intent.getIntExtra("village_id", 0);
        farmer_id = intent.getIntExtra("farmer_id", 0);
        trap1_spodoptera = intent.getStringExtra("trap1_spodoptera");
        trap2_spodoptera = intent.getStringExtra("trap2_spodoptera");
        trap1_helicoverpa = intent.getStringExtra("trap1_helicoverpa");
        trap2_helicoverpa = intent.getStringExtra("trap2_helicoverpa");

        initView();
        setListners();
    }


    private void initView() {
        sp_technicalname_insecticide_soyabeanOA = findViewById(R.id.sp_technicalname_insecticide_soyabeanOA);
        sp_technicalname_fungicide_soyabeanOA = findViewById(R.id.sp_technicalname_fungicide_soyabeanOA);
        sp_weedicide_technicalname_soyabeanOA = findViewById(R.id.sp_weedicide_technicalname_soyabeanOA);
        sp_irrigation_given_soyabeanOA = findViewById(R.id.sp_irrigation_given_soyabeanOA);
        edt_tradename_weedicide_soyabeanOA = findViewById(R.id.edt_tradename_weedicide_soyabeanOA);
        edt_quantity_used_acre_weedicide_soyabeanOA = findViewById(R.id.edt_quantity_used_acre_weedicide_soyabeanOA);
        edt_fertilizer_soyabeanOA_N = findViewById(R.id.edt_fertilizer_soyabeanOA_N);
        edt_fertilizer_soyabeanOA_P = findViewById(R.id.edt_fertilizer_soyabeanOA_P);
        edt_fertilizer_soyabeanOA_K = findViewById(R.id.edt_fertilizer_soyabeanOA_K);
        edt_fertilizername_soyabeanOA = findViewById(R.id.edt_fertilizername_soyabeanOA);
        edt_quantity_used_acre_fertilizer_soyabeanOA = findViewById(R.id.edt_quantity_used_acre_fertilizer_soyabeanOA);
        edt_tradename_insecticide_soyabeanOA = findViewById(R.id.edt_tradename_insecticide_soyabeanOA);
        edt_quantity_used_acre_insecticide_soyabeanOA = findViewById(R.id.edt_quantity_used_acre_insecticide_soyabeanOA);
        edt_tradename_fungicide_soyabeanOA = findViewById(R.id.edt_tradename_fungicide_soyabeanOA);
        edt_quantity_used_acre_fungicide_soyabeanOA = findViewById(R.id.edt_quantity_used_acre_fungicide_soyabeanOA);
        insecticide_soyabeanOA_yes = findViewById(R.id.insecticide_soyabeanOA_yes);
        insecticide_soyabeanOA_no = findViewById(R.id.insecticide_soyabeanOA_no);
        fungicide_soyabeanOA_yes = findViewById(R.id.fungicide_soyabeanOA_yes);
        fungicide_soyabeanOA_no = findViewById(R.id.fungicide_soyabeanOA_no);
        weedicide_soyabeanOA_yes = findViewById(R.id.weedicide_soyabeanOA_yes);
        weedicide_soyabeanOA_no = findViewById(R.id.weedicide_soyabeanOA_no);
        fertilizer_soyabeanOA_yes = findViewById(R.id.fertilizer_soyabeanOA_yes);
        fertilizer_soyabeanOA_no = findViewById(R.id.fertilizer_soyabeanOA_no);
        weeding_soyabeanOA_rb = findViewById(R.id.weeding_soyabeanOA_rb);
        hoeing_soyabeanOA_rb = findViewById(R.id.hoeing_soyabeanOA_rb);
        detopping_soyabeanOA_rb = findViewById(R.id.detopping_soyabeanOA_rb);
        none_soyabeanOA_rb = findViewById(R.id.none_soyabeanOA_rb);
        irrigation_soyabeanOA_yes = findViewById(R.id.irrigation_soyabeanOA_yes);
        irrigation_soyabeanOA_no = findViewById(R.id.irrigation_soyabeanOA_no);
        insecticide_radio_group_soyabeanOA = findViewById(R.id.insecticide_radio_group_soyabeanOA);
        fungicide_radio_group_soyabeanOA = findViewById(R.id.fungicide_radio_group_soyabeanOA);
        weedicide_radio_group_soyabeanOA = findViewById(R.id.weedicide_radio_group_soyabeanOA);
        fertilizer_radio_group_soyabeanOA = findViewById(R.id.fertilizer_radio_group_soyabeanOA);
        radio_group_intercultural_soyabeanOA = findViewById(R.id.radio_group_intercultural_soyabeanOA);
        radio_group_irrigation_field_soyabeanOA = findViewById(R.id.radio_group_irrigation_field_soyabeanOA);
        //pest_soyabeanOA_photo = findViewById(R.id.pest_soyabeanOA_photo);
        crop_growth_soyabeanOA_photo = findViewById(R.id.crop_growth_soyabeanOA_photo);
        btn_submit_soyabean_OA = findViewById(R.id.btn_submit_soyabean_OA);

        ll_insecticide_layout_soyabeanOA = findViewById(R.id.ll_insecticide_layout_soyabeanOA);
        ll_fungicide_layout_soyabeanOA = findViewById(R.id.ll_fungicide_layout_soyabeanOA);
        ll_weedicide_layout_soyabeanOA = findViewById(R.id.ll_weedicide_layout_soyabeanOA);
        ll_fertilizer_layout_soyabeanOA = findViewById(R.id.ll_fertilizer_layout_soyabeanOA);
        rl_irrigation_layout_soyabeanOA = findViewById(R.id.rl_irrigation_layout_soyabeanOA);
        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();


        crop_growth_soyabeanOA_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

    }


    private void setListners() {

        insecticide_radio_group_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.insecticide_soyabeanOA_yes:
                        insecticide_soyabeanOA_yes.setChecked(true);
                        ll_insecticide_layout_soyabeanOA.setVisibility(View.VISIBLE);
                        insecticide_yes = insecticide_soyabeanOA_yes.getText().toString();
                        break;

                    case R.id.insecticide_soyabeanOA_no:
                        insecticide_soyabeanOA_no.setChecked(true);
                        ll_insecticide_layout_soyabeanOA.setVisibility(View.GONE);
                        insecticide_yes = insecticide_soyabeanOA_no.getText().toString();
                        break;
                }
            }
        });

        fungicide_radio_group_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fungicide_soyabeanOA_yes:
                        fungicide_soyabeanOA_yes.setChecked(true);
                        ll_fungicide_layout_soyabeanOA.setVisibility(View.VISIBLE);
                        fungicide_yes = fungicide_soyabeanOA_yes.getText().toString();
                        break;

                    case R.id.fungicide_soyabeanOA_no:
                        fungicide_soyabeanOA_no.setChecked(true);
                        ll_fungicide_layout_soyabeanOA.setVisibility(View.GONE);
                        fungicide_yes = fungicide_soyabeanOA_no.getText().toString();
                        break;
                }
            }
        });

        weedicide_radio_group_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.weedicide_soyabeanOA_yes:
                        weedicide_soyabeanOA_yes.setChecked(true);
                        ll_weedicide_layout_soyabeanOA.setVisibility(View.VISIBLE);
                        weedicide_yes = weedicide_soyabeanOA_yes.getText().toString();
                        break;

                    case R.id.weedicide_soyabeanOA_no:
                        weedicide_soyabeanOA_no.setChecked(true);
                        ll_weedicide_layout_soyabeanOA.setVisibility(View.GONE);
                        weedicide_yes = weedicide_soyabeanOA_no.getText().toString();
                        break;
                }
            }
        });


        fertilizer_radio_group_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fertilizer_soyabeanOA_yes:
                        fertilizer_soyabeanOA_yes.setChecked(true);
                        ll_fertilizer_layout_soyabeanOA.setVisibility(View.VISIBLE);
                        fertilizer_yes = fertilizer_soyabeanOA_yes.getText().toString();
                        break;

                    case R.id.fertilizer_soyabeanOA_no:
                        fertilizer_soyabeanOA_no.setChecked(true);
                        ll_fertilizer_layout_soyabeanOA.setVisibility(View.GONE);
                        fertilizer_yes = fertilizer_soyabeanOA_no.getText().toString();
                        break;
                }
            }
        });

        radio_group_intercultural_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.weeding_soyabeanOA_rb:
                        weeding_soyabeanOA_rb.setChecked(true);
                        intercultural = weeding_soyabeanOA_rb.getText().toString();
                        break;

                    case R.id.hoeing_soyabeanOA_rb:
                        hoeing_soyabeanOA_rb.setChecked(true);
                        intercultural = hoeing_soyabeanOA_rb.getText().toString();
                        break;

                    case R.id.detopping_soyabeanOA_rb:
                        detopping_soyabeanOA_rb.setChecked(true);
                        intercultural = detopping_soyabeanOA_rb.getText().toString();
                        break;

                    case R.id.none_soyabeanOA_rb:
                        none_soyabeanOA_rb.setChecked(true);
                        intercultural = none_soyabeanOA_rb.getText().toString();
                        break;
                }
            }
        });

        radio_group_irrigation_field_soyabeanOA.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.irrigation_soyabeanOA_yes:
                        irrigation_soyabeanOA_yes.setChecked(true);
                        rl_irrigation_layout_soyabeanOA.setVisibility(View.VISIBLE);
                        irrigation_yes = irrigation_soyabeanOA_yes.getText().toString();
                        break;

                    case R.id.irrigation_soyabeanOA_no:
                        irrigation_soyabeanOA_no.setChecked(true);
                        rl_irrigation_layout_soyabeanOA.setVisibility(View.GONE);
                        irrigation_yes = irrigation_soyabeanOA_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_insecticide_soyabeanOA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int arg2, long arg3) {

                technicalname_insecticide = sp_technicalname_insecticide_soyabeanOA.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        sp_technicalname_fungicide_soyabeanOA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int arg2, long arg3) {

                technicalname_fungicide = sp_technicalname_fungicide_soyabeanOA.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });


        sp_weedicide_technicalname_soyabeanOA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int arg2, long arg3) {

                weedicide_technicalname = sp_weedicide_technicalname_soyabeanOA.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        sp_irrigation_given_soyabeanOA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int arg2, long arg3) {

                irrigation_given = sp_irrigation_given_soyabeanOA.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        /*pest_soyabeanOA_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });*/

        crop_growth_soyabeanOA_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SoyabeanOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });


        btn_submit_soyabean_OA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Soyabean_Crop_Pheromone_Save_Service();
            }
        });
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(SoyabeanOtherWorkActivity.this, com.maha.agri.activity.task_manager.SchemeListActivity.class);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(SoyabeanOtherWorkActivity.this, SoyabeanGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            /*if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else*/ if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        /*if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pest_soyabeanOA_photo.getWidth(), pest_soyabeanOA_photo.getHeight())
                                    .centerCrop()
                                    .into(pest_soyabeanOA_photo);

                            uploadImage1OnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else*/ if (type.equalsIgnoreCase("2")) {


            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(crop_growth_soyabeanOA_photo.getWidth(), crop_growth_soyabeanOA_photo.getHeight())
                                    .centerCrop()
                                    .into(crop_growth_soyabeanOA_photo);

                            uploadImage2OnServer(imagePath2);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void chickpea_plant_list() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.soyabean_spot_list();
        api.postRequest(responseCall, this, 1);
    }


    /*private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_soyabean_save_image(partBody, params);
            api.postRequest(responseCall, this, 1);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

    private void uploadImage2OnServer(String imagePath2) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath2);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_soyabean_save_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void Soyabean_Crop_Pheromone_Save_Service() {

         if (insecticide_yes.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Insecticide", Toast.LENGTH_SHORT).show();
        } else if (fungicide_yes.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Fungicide", Toast.LENGTH_SHORT).show();
        } else if (weedicide_yes.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Weedicide", Toast.LENGTH_SHORT).show();
        } else if (fertilizer_yes.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Fertilizers", Toast.LENGTH_SHORT).show();
        } else if (intercultural.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Intercultural operations", Toast.LENGTH_SHORT).show();
        } else if (irrigation_yes.isEmpty()) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Select Irrigation", Toast.LENGTH_SHORT).show();
        } /*else if (photoFile1 == null) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Click Pest/disease photo", Toast.LENGTH_SHORT).show();
        }*/ else if (photoFile2 == null) {
            Toast.makeText(SoyabeanOtherWorkActivity.this, "Click Crop growth stage photo", Toast.LENGTH_SHORT).show();
        } else {


            JSONObject param = new JSONObject();
            try {
                param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("last_id","1");
                param.put("district_id",district_id);
                param.put("taluka_id",taluka_id);
                param.put("village_id",village_id);
                param.put("trap1_Spodoptera", trap1_spodoptera);
                param.put("trap2_Spodoptera", trap2_spodoptera);
                param.put("trap1_Helicoverpa", trap1_helicoverpa);
                param.put("trap2_Helicoverpa", trap2_helicoverpa);
                param.put("tradename_weedicide", edt_tradename_weedicide_soyabeanOA.getText().toString().trim());
                param.put("quantity_weedicide", edt_quantity_used_acre_weedicide_soyabeanOA.getText().toString().trim());
                param.put("fertilizer_N", edt_fertilizer_soyabeanOA_N.getText().toString().trim());
                param.put("fertilizer_P", edt_fertilizer_soyabeanOA_P.getText().toString().trim());
                param.put("fertilizer_K", edt_fertilizer_soyabeanOA_K.getText().toString().trim());
                param.put("fertilizername", edt_fertilizername_soyabeanOA.getText().toString().trim());
                param.put("quantity_fertilizer", edt_quantity_used_acre_fertilizer_soyabeanOA.getText().toString().trim());
                param.put("tradename_insecticide", edt_tradename_insecticide_soyabeanOA.getText().toString().trim());
                param.put("quantity_insecticide", edt_quantity_used_acre_insecticide_soyabeanOA.getText().toString().trim());
                param.put("tradename_fungicide", edt_tradename_fungicide_soyabeanOA.getText().toString().trim());
                param.put("quantity_fungicide", edt_quantity_used_acre_fungicide_soyabeanOA.getText().toString().trim());
                param.put("insecticide_yes", insecticide_yes);
                param.put("fungicide_yes", fungicide_yes);
                param.put("weedicide_yes", weedicide_yes);
                param.put("fertilizer_yes", fertilizer_yes);
                param.put("intercultural", intercultural);
                param.put("irrigation_yes", irrigation_yes);
                param.put("pest_photo", "1");
                param.put("crop_growt_photo", image_2_file_name);
                param.put("technicalname_insecticide", technicalname_insecticide);
                param.put("technicalname_fungicide", technicalname_fungicide);
                param.put("weedicide_technicalname", weedicide_technicalname);
                param.put("irrigation_given", irrigation_given);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.crop_soyabean_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 3);
        }
    }
    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                /*if (i == 1) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");

                        }

                    }
                }*/

                if (i == 2) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            JSONObject data = jsonObject.getJSONObject("data");
                            image_2_file_name = data.getString("file_name");
                        }

                    }

                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Soybean Other Works Completed")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    }).show();
                        }

                    }

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
