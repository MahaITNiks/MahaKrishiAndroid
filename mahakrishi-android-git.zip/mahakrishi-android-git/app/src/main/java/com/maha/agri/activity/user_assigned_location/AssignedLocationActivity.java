package com.maha.agri.activity.user_assigned_location;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.AssignedLocationAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AssignedLocationActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {

    private RecyclerView assigned_location_rView;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private int juniorRoleId;
    private int userRoleId;
    private boolean responseFail = true;
    private JSONArray userJunierRoleArray;
    private String userIdByLocation = "";
    private String userRoleIdByLocation = "";
    private String userLocationID = "";
    private String userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assigned_location);

        preferenceManager = new PreferenceManager(this);
        sharedPref = new SharedPref(this);

        getSupportActionBar().setTitle("Assigned Location");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();
        defaultConfig();
    }


    public void init() {

        userId = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        String uRoleId = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);

        userRoleId = Integer.valueOf(uRoleId);
        juniorRoleId = userRoleId;


        /*String junRoleId = preferenceManager.getPreferenceValues(Preference_Constant.JUNIER_ROLE_ID);
        if (!junRoleId.equalsIgnoreCase("")) {
            juniorRoleId = Integer.valueOf(junRoleId);
        } else {
            UIToastMessage.show(this, "Detail not found");
        }*/

        /*if (!junRoleId.equalsIgnoreCase("0")){
            juniorRoleId = Integer.valueOf(junRoleId);
        }else {
            juniorRoleId = 1;
        }*/
        assigned_location_rView = (RecyclerView) findViewById(R.id.assigned_location_rView);
        assigned_location_rView.setLayoutManager(new LinearLayoutManager(this));
        assigned_location_rView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        userJunierRoleArray = new JSONArray();
        addUserJuniorRole(userId, uRoleId, userLocationID);
    }

    public void defaultConfig() {
        checkAndGetLocation();
    }


    private void addUserJuniorRole(String userId, String junRoleId, String userLocationID) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("user_id", userId);
            jsonObject.put("junior_role_id", junRoleId);
            jsonObject.put("location_id", userLocationID);
            userJunierRoleArray.put(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (juniorRoleId < userRoleId ) {
                    juniorRoleId++;
                    checkAndGetLocation();
                } else {
                    finish();
                    return true;
                }

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        if (juniorRoleId < userRoleId) {
            juniorRoleId++;
            checkAndGetLocation();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

        JSONObject jsonObject = (JSONObject) o;
        try {
            //String UserId = jsonObject.getString("UserID");
            String juniorRoleId = jsonObject.getString("junior_role_id");
            String juniorLocationId = jsonObject.getString("location_id");
            addUserJuniorRole(userId, juniorRoleId, juniorLocationId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (juniorRoleId > 1 && !responseFail) {
            juniorRoleId--;
            checkAndGetLocation();
        }
    }


    private void checkAndGetLocation() {

        try {
            for (int i = 0; i < userJunierRoleArray.length(); i++) {
                JSONObject jsonObject = userJunierRoleArray.getJSONObject(i);
                String jRoleId = jsonObject.getString("junior_role_id");

                if (jRoleId.equalsIgnoreCase(String.valueOf(juniorRoleId))) {
                    userIdByLocation = jsonObject.getString("user_id");
                    userRoleIdByLocation = jsonObject.getString("junior_role_id");
                    userLocationID = jsonObject.getString("location_id");
                }
            }

            if (!userIdByLocation.equalsIgnoreCase("") && !userRoleIdByLocation.equalsIgnoreCase("")) {
                getAssignedLocation();
            } else {
                UIToastMessage.show(this, "Location detail not found");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void getAssignedLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("role_id", userRoleIdByLocation);
            param.put("user_id", userIdByLocation);
            param.put("location_id", userLocationID);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ASSIGNED_VILLAGE_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assignedLocationUrl(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {

                        getSupportActionBar().setTitle(responseModel.getMsg());
                        JSONArray assignedLocationList = jsonObject.getJSONArray("data");
                        responseFail = false;
                        if (assignedLocationList.length() > 0) {
                            assigned_location_rView.setAdapter(new AssignedLocationAdapter(this, assignedLocationList, this));
                        } else {
                            responseFail = true;
                            juniorRoleId++;
                            UIToastMessage.show(this, responseModel.getMsg());
                            assigned_location_rView.setAdapter(new AssignedLocationAdapter(this, new JSONArray(), this));
                        }

                    } else {
                        responseFail = true;
                        juniorRoleId++;
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}

