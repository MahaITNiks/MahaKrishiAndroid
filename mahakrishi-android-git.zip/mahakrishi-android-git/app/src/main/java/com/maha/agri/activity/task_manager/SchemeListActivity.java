package com.maha.agri.activity.task_manager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SchemeAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SchemeListActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView schemerv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private JSONArray schemeList;
    String strJson;
    int schemePos;
    JSONObject jsonObject;
    private String schemeId, scheme_sr_no;
    private DBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_list);
        preferenceManager = new PreferenceManager(SchemeListActivity.this);
        sharedPref = new SharedPref(SchemeListActivity.this);
        getSupportActionBar().setTitle("Scheme List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dbHandler = new DBHandler(this);

        init();
        //default_config();

        if (isNetworkAvailable()) {
            getSchemeListWebservice();
        } else {
            getOfflineSchemeList();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    private void init() {
        schemerv = (RecyclerView) findViewById(R.id.scheme_recyclerView);
        schemerv.setLayoutManager(new LinearLayoutManager(this));
        schemerv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));

    }

    /*private void default_config(){

        schemerv.addOnItemTouchListener(new SchemeAdapter.RecyclerTouchListener(this, schemerv, new SchemeAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {


               switch (position){

                   case 0 :
                       Intent scheme_1 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_1.putExtra("schemeList", schemeList.toString());
                       scheme_1.putExtra("position", position);
                       startActivity(scheme_1);
                       finish();
                       break;

                   case 1 :
                       Intent scheme_2 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_2.putExtra("schemeList", schemeList.toString());
                       scheme_2.putExtra("position", position);
                       startActivity(scheme_2);
                       finish();
                       break;

                   case 2 :
                       Intent scheme_3 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_3.putExtra("schemeList", schemeList.toString());
                       scheme_3.putExtra("position", position);
                       startActivity(scheme_3);
                       finish();
                       break;

                   case 3 :
                       Intent scheme_4 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_4.putExtra("schemeList", schemeList.toString());
                       scheme_4.putExtra("position", position);
                       startActivity(scheme_4);
                       finish();
                       break;


                   case 4 :
                       Intent scheme_5 = new Intent(SchemeListActivity.this, CropSapFarmerSelection.class);
                       startActivity(scheme_5);
                       finish();
                       break;

                   case 5 :
                       Intent scheme_6 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_6.putExtra("schemeList", schemeList.toString());
                       scheme_6.putExtra("position", position);
                       startActivity(scheme_6);
                       finish();
                       break;

                   case 6 :
                       Intent scheme_7 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_7.putExtra("schemeList", schemeList.toString());
                       scheme_7.putExtra("position", position);
                       startActivity(scheme_7);
                       break;

                   case 7 :
                       Intent scheme_8 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_8.putExtra("schemeList", schemeList.toString());
                       scheme_8.putExtra("position", position);
                       startActivity(scheme_8);
                       finish();
                       break;

                   case 8 :
                       Intent scheme_9 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_9.putExtra("schemeList", schemeList.toString());
                       scheme_9.putExtra("position", position);
                       startActivity(scheme_9);
                       finish();
                       break;

                   case 9 :
                       Intent scheme_10 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_10.putExtra("schemeList", schemeList.toString());
                       scheme_10.putExtra("position", position);
                       startActivity(scheme_10);
                       finish();
                       break;

                   case 10 :
                       Intent scheme_11 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_11.putExtra("schemeList", schemeList.toString());
                       scheme_11.putExtra("position", position);
                       startActivity(scheme_11);
                       finish();
                       break;

                   case 11 :
                       Intent scheme_12 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_12.putExtra("schemeList", schemeList.toString());
                       scheme_12.putExtra("position", position);
                       startActivity(scheme_12);
                       finish();
                       break;

                   case 12 :
                       Intent scheme_13 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_13.putExtra("schemeList", schemeList.toString());
                       scheme_13.putExtra("position", position);
                       startActivity(scheme_13);
                       finish();
                       break;

                   case 13 :
                       Intent scheme_14 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_14.putExtra("schemeList", schemeList.toString());
                       scheme_14.putExtra("position", position);
                       startActivity(scheme_14);
                       finish();
                       break;

                   case 14 :
                       Intent scheme_15 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_15.putExtra("schemeList", schemeList.toString());
                       scheme_15.putExtra("position", position);
                       startActivity(scheme_15);
                       finish();
                       break;

                   case 15 :
                       Intent scheme_16 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_16.putExtra("schemeList", schemeList.toString());
                       scheme_16.putExtra("position", position);
                       startActivity(scheme_16);
                       finish();
                       break;

                   case 16 :
                       Intent scheme_17 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_17.putExtra("schemeList", schemeList.toString());
                       scheme_17.putExtra("position", position);
                       startActivity(scheme_17);
                       finish();
                       break;

                   case 17 :
                       Intent scheme_18 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_18.putExtra("schemeList", schemeList.toString());
                       scheme_18.putExtra("position", position);
                       startActivity(scheme_18);
                       finish();
                       break;

                   case 18 :
                       Intent scheme_19 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_19.putExtra("schemeList", schemeList.toString());
                       scheme_19.putExtra("position", position);
                       startActivity(scheme_19);
                       finish();
                       break;

                   case 19 :
                       Intent scheme_20 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_20.putExtra("schemeList", schemeList.toString());
                       scheme_20.putExtra("position", position);
                       startActivity(scheme_20);
                       finish();
                       break;

                   case 20 :
                       Intent scheme_21 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_21.putExtra("schemeList", schemeList.toString());
                       scheme_21.putExtra("position", position);
                       startActivity(scheme_21);
                       finish();
                       break;

                   case 21 :
                       Intent scheme_22 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_22.putExtra("schemeList", schemeList.toString());
                       scheme_22.putExtra("position", position);
                       startActivity(scheme_22);
                       finish();
                       break;

                   case 22 :
                       Intent scheme_23 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_23.putExtra("schemeList", schemeList.toString());
                       scheme_23.putExtra("position", position);
                       startActivity(scheme_23);
                       finish();
                       break;

                   case 23 :
                       Intent scheme_24 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_24.putExtra("schemeList", schemeList.toString());
                       scheme_24.putExtra("position", position);
                       startActivity(scheme_24);
                       finish();
                       break;

                   case 24 :
                       Intent scheme_25 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_25.putExtra("schemeList", schemeList.toString());
                       scheme_25.putExtra("position", position);
                       startActivity(scheme_25);
                       finish();
                       break;

                   case 25 :
                       Intent scheme_26 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_26.putExtra("schemeList", schemeList.toString());
                       scheme_26.putExtra("position", position);
                       startActivity(scheme_26);
                       finish();
                       break;

                   case 26 :
                       Intent scheme_27 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_27.putExtra("schemeList", schemeList.toString());
                       scheme_27.putExtra("position", position);
                       startActivity(scheme_27);
                       finish();
                       break;

                   case 27 :
                       Intent scheme_28 = new Intent(SchemeListActivity.this, SchemeActListActivity.class);
                       scheme_28.putExtra("schemeList", schemeList.toString());
                       scheme_28.putExtra("position", position);
                       startActivity(scheme_28);
                       finish();
                       break;

               }

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }*/

    private void getOfflineSchemeList() {
        schemeList = dbHandler.getSchemeList("1");
        schemerv.setAdapter(new SchemeAdapter(this, schemeList, preferenceManager));

    }


    private void getSchemeListWebservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("typeId", "1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeList(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            schemeList = jsonObject.getJSONArray("data");
                            if (preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("3") || preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("4") || preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("5") || preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("6") || preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("7")) {
                                schemeList.remove(4);
                                schemerv.setAdapter(new SchemeAdapter(this, schemeList, preferenceManager));

                            }
                            schemerv.setAdapter(new SchemeAdapter(this, schemeList, preferenceManager));
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}