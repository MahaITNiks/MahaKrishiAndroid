package com.maha.agri.mb_recording;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Reinforced_Cement_Concrete_Activity extends AppCompatActivity implements ApiCallbackCode {

    private AppLocationManager locationManager;
    private int soil_lavel;
    public double lat;
    public double lang;
    private String soil_id = "1";
    private String soilName;

    // For Image upload
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private File photoFile1 = null;
    static final Integer CAMERA = 0x5;
    String imagePath, currentTime;
    private Transformation transformation;
    String type;

    private String image1URL;
    private String image2URL;

    Button btn_submit_RainForced;
    String beam_total, vertical_wall_total;
    EditText edt_volume_reinforced, edt_material_required_reinforced, edt_qty_kg_reinforced, edt_qty_mt_reinforced;
    String str_farmer_name, step_id;
    TextView txt_farmer_name;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    String str_volume_reinforced, str_material_required_reinforced, str_qty_kg_reinforced, strt_qty_mt_reinforced;
    ImageView farmers_photo_Reinforced, farmers_photo_Reinforced_1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reinforced_cement_concrete_);
        getSupportActionBar().setTitle("Reinforced Cement Concrete");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(Reinforced_Cement_Concrete_Activity.this);
        sharedPref = new SharedPref(Reinforced_Cement_Concrete_Activity.this);
        soil_lavel = AppSettings.getInstance().getIntValue(this, ApConstants.MB_STAGE_LAVAL, 0);
        init();

        beam_total = AppSettings.getInstance().getValue(Reinforced_Cement_Concrete_Activity.this, ApConstants.PCC_QTY_BEAM, "");
        vertical_wall_total = AppSettings.getInstance().getValue(Reinforced_Cement_Concrete_Activity.this, ApConstants.PCC_VERTICAL_WALL, "");

        double beam_total_1 = 0;
        double vertical_wall_total_1 = 0;

        if (!beam_total.equalsIgnoreCase("")) {
            beam_total_1 = Double.parseDouble(beam_total);
        }
        if (!vertical_wall_total.equalsIgnoreCase("")) {
            vertical_wall_total_1 = Double.parseDouble(vertical_wall_total);
        }

        edt_volume_reinforced.setText(String.valueOf(beam_total_1 + vertical_wall_total_1));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {
        soil_id = getIntent().getStringExtra("soilId");
        soilName = getIntent().getStringExtra("soilName");
        locationManager = new AppLocationManager(this);

        farmers_photo_Reinforced = (ImageView) findViewById(R.id.farmers_photo_Reinforced);
        farmers_photo_Reinforced_1 = (ImageView) findViewById(R.id.farmers_photo_Reinforced_1);
        btn_submit_RainForced = (Button) findViewById(R.id.btn_submit_RainForced);
        edt_volume_reinforced = (EditText) findViewById(R.id.edt_volume_reinforced);
        edt_material_required_reinforced = (EditText) findViewById(R.id.edt_material_required_reinforced);
        edt_qty_kg_reinforced = (EditText) findViewById(R.id.edt_qty_kg_reinforced);
        edt_qty_mt_reinforced = (EditText) findViewById(R.id.edt_qty_mt_reinforced);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        String soilData = getIntent().getStringExtra("soilData");
        if (!soilData.equalsIgnoreCase("")){
            setSoilDetail(soilData);
        }

        farmers_photo_Reinforced.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {

                    type = "0";
                    takeImage0FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        farmers_photo_Reinforced_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Reinforced_Cement_Concrete_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {

                    type = "1";
                    takeImage1FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        txt_farmer_name = (TextView) findViewById(R.id.txt_farmer_name);

        str_farmer_name = AppSettings.getInstance().getValue(Reinforced_Cement_Concrete_Activity.this, ApConstants.MB_FARMER_NAME, "");
        txt_farmer_name.setText(str_farmer_name);


        edt_material_required_reinforced.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1 = 0;
                double value2 = 0;
                String v1 = edt_volume_reinforced.getText().toString();
                String v2 = edt_material_required_reinforced.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
                edt_qty_kg_reinforced.setText(String.valueOf(value1 * value2));
            }
        });

        edt_qty_kg_reinforced.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double value1 = 0;
                double value2 = 0;
                String v1 = edt_volume_reinforced.getText().toString();
                String v2 = edt_material_required_reinforced.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }

                edt_qty_mt_reinforced.setText(String.valueOf(0.001 * (value1 * value2)));
            }
        });


        btn_submit_RainForced.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  uploadImage0OnServer(imagePath);
                uploadImage1OnServer(imagePath);*/
                Reinforced_Cement_Concrete_Save_Service();
            }
        });
    }

    private void setSoilDetail(String soilData) {
        btn_submit_RainForced.setVisibility(View.INVISIBLE);
        try {
            JSONObject soilJSON = new JSONObject(soilData);
            String volume = soilJSON.getString("str_volume_reinforced");
            String material = soilJSON.getString("str_material_required_reinforced");
            String qtyInKg = soilJSON.getString("str_qty_kg_reinforced");
            String qtyInMt = soilJSON.getString("strt_qty_mt_reinforced");

            edt_volume_reinforced.setText(volume);
            edt_material_required_reinforced.setText(material);
            edt_qty_kg_reinforced.setText(qtyInKg);
            edt_qty_mt_reinforced.setText(qtyInMt);

            String img1URL = soilJSON.getString("img1Url");
            if (!img1URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img1URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_Reinforced);
            }

            String img2URL = soilJSON.getString("img2Url");
            if (!img2URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img2URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_Reinforced_1);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void takeImage0FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (type.equalsIgnoreCase("0")) {

                if (photoFile.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                           /* Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_Reinforced.getWidth(), farmers_photo_Reinforced.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Reinforced);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage0OnServer(imagePath);

                }
            }
        }

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            /*Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_Reinforced_1.getWidth(), farmers_photo_Reinforced_1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Reinforced_1);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage1OnServer(imagePath);
                }
            }
        }
    }

    private void uploadImage0OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage1OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // save
    private void Reinforced_Cement_Concrete_Save_Service() {

        str_volume_reinforced = edt_volume_reinforced.getText().toString().trim();
        str_material_required_reinforced = edt_material_required_reinforced.getText().toString().trim();
        str_qty_kg_reinforced = edt_qty_kg_reinforced.getText().toString().trim();
        strt_qty_mt_reinforced = edt_qty_mt_reinforced.getText().toString().trim();
        str_farmer_name = txt_farmer_name.getText().toString().trim();

        if (str_volume_reinforced.isEmpty()) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Volume Reinforced", Toast.LENGTH_SHORT).show();
        } else if (str_material_required_reinforced.isEmpty()) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Material Reinforced", Toast.LENGTH_SHORT).show();
        } else if (str_qty_kg_reinforced.isEmpty()) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Qty Kg Reinforced", Toast.LENGTH_SHORT).show();
        } else if (strt_qty_mt_reinforced.isEmpty()) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Qty Mt Reinforced", Toast.LENGTH_SHORT).show();
        } else if (str_farmer_name.isEmpty()) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Farmer Name", Toast.LENGTH_SHORT).show();
        } else if (photoFile == null) {
            Toast.makeText(Reinforced_Cement_Concrete_Activity.this, "Input Reinforced Cement photo", Toast.LENGTH_SHORT).show();
        } else {

            soil_lavel++;
            JSONObject param = new JSONObject();
            try {
                param.put("farmer_reg_id", Integer.valueOf(preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID)));
                param.put("soil_id", Integer.valueOf(soil_id));
                param.put("soil_name", soilName);
                param.put("stepID", soil_lavel);
                param.put("str_volume_reinforced", str_volume_reinforced);
                param.put("str_material_required_reinforced", str_material_required_reinforced);
                param.put("str_qty_kg_reinforced", str_qty_kg_reinforced);
                param.put("strt_qty_mt_reinforced", strt_qty_mt_reinforced);
                param.put("str_farmer_name", str_farmer_name);
                param.put("img1Url", image1URL);
                param.put("img2Url", image2URL);
                param.put("lat", lat);
                param.put("lang", lang);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.soil_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                //save1
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        AppSettings.getInstance().setIntValue(Reinforced_Cement_Concrete_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                        finish();
                    } else {
                        soil_lavel--;
                        AppSettings.getInstance().setIntValue(Reinforced_Cement_Concrete_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image1URL = data.getString("file_url");
                        if (!image1URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image1URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_Reinforced.getWidth(), farmers_photo_Reinforced.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Reinforced);
                        }
                    } else {
                        UIToastMessage.show(Reinforced_Cement_Concrete_Activity.this, jsonObject.getString("response"));
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image2URL = data.getString("file_url");
                        if (!image2URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image2URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_Reinforced_1.getWidth(), farmers_photo_Reinforced_1.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Reinforced_1);
                        }
                    } else {
                        UIToastMessage.show(Reinforced_Cement_Concrete_Activity.this, jsonObject.getString("response"));
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
