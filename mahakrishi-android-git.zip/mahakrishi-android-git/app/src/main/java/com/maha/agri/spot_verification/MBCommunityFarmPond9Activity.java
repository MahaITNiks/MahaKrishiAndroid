package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.adapter.MBCommunityFarmPond9Adapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBCommunityFarmPond9Activity extends AppCompatActivity implements ApiCallbackCode {
    
    private TextView mb_pond9_obsdate,mb_pond9_beneficiary_name,mb_pond9_villagetv,mb_pond9_talukatv,mb_pond9_districttv,mb_pond9_surveyno,mb_pond9_vargvari,
            mb_pond9_bab1tv,mb_pond9_bab2tv,mb_pond9_bab3tv,mb_pond9_previousdatetv,mb_pond9_previous_accepteddate,mb_pond9_previous_area,
            mb_pond9_form8_inspectiondate,mb_pond9_preobs_length,mb_pond9_preobs_breadth,mb_pond9_preobs_height,mb_pond9_preobs_fieldfruit,
            mb_pond9_crop_type,mb_pond9_crop_name;

    private EditText mb_pond9_bis_name,mb_pond9_bis_address,mb_pond9_durdhvani_no,mb_pond9_bhraman_no,mb_pond9_proof_row1,mb_pond9_proof_row2,mb_pond9_proof_row3,
            mb_pond9_proof_row4,mb_pond9_proof_row5,mb_pond9_total_proof_row7,mb_pond9_actualcost_row1,mb_pond9_actualcost_row2,mb_pond9_actualcost_row3,
            mb_pond9_actualcost_row4,mb_pond9_actualcost_row5,mb_pond9_actualcost_row6,mb_pond9_total_actualcost_row7,mb_pond9_subsidy_row1,mb_pond9_subsidy_row2,
            mb_pond9_subsidy_row3,mb_pond9_subsidy_row4,mb_pond9_subsidy_row5,mb_pond9_subsidy_row6,mb_pond9_total_subsidy_row7,mb_pond9_total_subsidygiven,
            mb_pond8_crop_area;

    private ImageView mb_pond9_obsdate_iv,mb_pond9_previousdateiv,mb_pond9_photo;

    private RadioGroup mb_pond9_permission_rg,mb_pond9_preinsp_permission_rg,mb_pond9_bis1_rg,mb_pond9_bis2_rg,mb_pond9_bis3_rg,mb_pond9_bis4_rg,mb_pond9_bis5_rg,
            mb_pond9_bis6_rg,mb_pond9_bis7_rg,mb_pond9_bis8_rg,mb_pond9_waterrelated_rg;
    
    private RadioButton mb_pond9_permission_yes,mb_pond9_permission_no,mb_pond9_preinsp_permission_yes,mb_pond9_preinsp_permission_no,mb_pond9_bis1_yes,mb_pond9_bis1_no,
            mb_pond9_bis2_yes,mb_pond9_bis2_no,mb_pond9_bis3_yes,mb_pond9_bis3_no,mb_pond9_bis4_yes,mb_pond9_bis4_no,mb_pond9_bis5_yes,mb_pond9_bis5_no,mb_pond9_bis6_yes,
            mb_pond9_bis6_no,mb_pond9_bis7_yes,mb_pond9_bis7_no,mb_pond9_bis8_yes,mb_pond9_bis8_no,mb_pond9_waterrelated_yes,mb_pond9_waterrelated_no;
    
    private Button mb_pond9_save,mb_pond8_add_btn;
    private RecyclerView mb_pond8_crop_details_rv;

    private String permission="0",pre_permission="0",bis1="0",bis2="0",bis3="0",bis4="0",bis5="0",bis6="0",bis7="0",bis8="0",water_related="0";
    private SweetAlertDialog sweetAlertDialog;
    private int mYear, mMonth, mDay;
    private DatePickerDialog mb_pond9_datepicker,mb_pond9_predate_picker;
    private String mb_pond9_date="0",mb_pond9_pre_date="0",crop_type_name="",crop_name="",farmer_name="";
    private int crop_type_id = 0,crop_id = 0;
    private JSONArray multiple_crop_area = new JSONArray();

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private String imagePath1="";
    private String image_1_file_name="";
    private AppLocationManager locationManager;
    public double lat,lang;
    private PreferenceManager preferenceManager;
    private int  district_id,taluka_id,village_id,farmer_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_community_farm_pond9);
        getSupportActionBar().setTitle("MB Community Farm Pond Form 9");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBCommunityFarmPond9Activity.this);
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        farmer_name = intent.getStringExtra("farmer_name");

        ids();
        functions();
    }
    
    private void ids(){
        //Textview
        mb_pond9_obsdate = (TextView) findViewById(R.id.mb_pond9_obsdate);
        mb_pond9_beneficiary_name = (TextView) findViewById(R.id.mb_pond9_beneficiary_name);
        mb_pond9_beneficiary_name.setText(farmer_name);
        mb_pond9_villagetv = (TextView) findViewById(R.id.mb_pond9_villagetv);
        mb_pond9_talukatv = (TextView) findViewById(R.id.mb_pond9_talukatv);
        mb_pond9_districttv = (TextView) findViewById(R.id.mb_pond9_districttv);
        mb_pond9_surveyno = (TextView) findViewById(R.id.mb_pond9_surveyno);
        mb_pond9_vargvari = (TextView) findViewById(R.id.mb_pond9_vargvari);
        mb_pond9_bab1tv = (TextView) findViewById(R.id.mb_pond9_bab1tv);
        mb_pond9_bab2tv = (TextView) findViewById(R.id.mb_pond9_bab2tv);
        mb_pond9_bab3tv = (TextView) findViewById(R.id.mb_pond9_bab3tv);
        mb_pond9_previous_accepteddate = (TextView) findViewById(R.id.mb_pond9_previous_accepteddate);
        //mb_pond9_previousdatetv = (TextView) findViewById(R.id.mb_pond9_previousdatetv);
        mb_pond9_previous_area = (TextView) findViewById(R.id.mb_pond9_previous_area);
        mb_pond9_form8_inspectiondate = (TextView) findViewById(R.id.mb_pond9_form8_inspectiondate);
        mb_pond9_preobs_length = (TextView) findViewById(R.id.mb_pond9_preobs_length);
        mb_pond9_preobs_breadth = (TextView) findViewById(R.id.mb_pond9_preobs_breadth);
        mb_pond9_preobs_height = (TextView) findViewById(R.id.mb_pond9_preobs_height);
        mb_pond9_preobs_fieldfruit = (TextView) findViewById(R.id.mb_pond9_preobs_fieldfruit);
        mb_pond9_crop_type = (TextView) findViewById(R.id.mb_pond9_crop_type);
        mb_pond9_crop_name = (TextView) findViewById(R.id.mb_pond9_crop_name);
        //Edittext
        mb_pond9_bis_name = (EditText) findViewById(R.id.mb_pond9_bis_name);
        mb_pond9_bis_address = (EditText) findViewById(R.id.mb_pond9_bis_address);
        mb_pond9_durdhvani_no = (EditText) findViewById(R.id.mb_pond9_durdhvani_no);
        mb_pond9_bhraman_no = (EditText) findViewById(R.id.mb_pond9_bhraman_no);
        mb_pond9_proof_row1 = (EditText) findViewById(R.id.mb_pond9_proof_row1);
        mb_pond9_proof_row2 = (EditText) findViewById(R.id.mb_pond9_proof_row2);
        mb_pond9_proof_row3 = (EditText) findViewById(R.id.mb_pond9_proof_row3);
        mb_pond9_proof_row4 = (EditText) findViewById(R.id.mb_pond9_proof_row4);
        mb_pond9_proof_row5 = (EditText) findViewById(R.id.mb_pond9_proof_row5);
        mb_pond9_total_proof_row7 = (EditText) findViewById(R.id.mb_pond9_total_proof_row7);
        mb_pond9_actualcost_row1 = (EditText) findViewById(R.id.mb_pond9_actualcost_row1);
        mb_pond9_actualcost_row2 = (EditText) findViewById(R.id.mb_pond9_actualcost_row2);
        mb_pond9_actualcost_row3 = (EditText) findViewById(R.id.mb_pond9_actualcost_row3);
        mb_pond9_actualcost_row4 = (EditText) findViewById(R.id.mb_pond9_actualcost_row4);
        mb_pond9_actualcost_row5 = (EditText) findViewById(R.id.mb_pond9_actualcost_row5);
        mb_pond9_actualcost_row6 = (EditText) findViewById(R.id.mb_pond9_actualcost_row6);
        mb_pond9_total_actualcost_row7 = (EditText) findViewById(R.id.mb_pond9_total_actualcost_row7);
        mb_pond9_subsidy_row1 = (EditText) findViewById(R.id.mb_pond9_subsidy_row1);
        mb_pond9_subsidy_row2 = (EditText) findViewById(R.id.mb_pond9_subsidy_row2);
        mb_pond9_subsidy_row3 = (EditText) findViewById(R.id.mb_pond9_subsidy_row3);
        mb_pond9_subsidy_row4 = (EditText) findViewById(R.id.mb_pond9_subsidy_row4);
        mb_pond9_subsidy_row5 = (EditText) findViewById(R.id.mb_pond9_subsidy_row5);
        mb_pond9_subsidy_row6 = (EditText) findViewById(R.id.mb_pond9_subsidy_row6);
        mb_pond9_total_subsidy_row7 = (EditText) findViewById(R.id.mb_pond9_total_subsidy_row7);
        mb_pond9_total_subsidygiven = (EditText) findViewById(R.id.mb_pond9_total_subsidygiven);
        mb_pond8_crop_area = (EditText) findViewById(R.id.mb_pond8_crop_area);
        //Imageview
        //mb_pond9_obsdate_iv = (ImageView) findViewById(R.id.mb_pond9_obsdate_iv);
        //mb_pond9_previousdateiv = (ImageView) findViewById(R.id.mb_pond9_previousdateiv);
        mb_pond9_photo = (ImageView) findViewById(R.id.mb_pond9_photo);
        //Radiogroup
        mb_pond9_permission_rg = (RadioGroup) findViewById(R.id.mb_pond9_permission_rg);
        mb_pond9_preinsp_permission_rg = (RadioGroup) findViewById(R.id.mb_pond9_preinsp_permission_rg);
        mb_pond9_bis1_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis1_rg);
        mb_pond9_bis2_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis2_rg);
        mb_pond9_bis3_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis3_rg);
        mb_pond9_bis4_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis4_rg);
        mb_pond9_bis5_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis5_rg);
        mb_pond9_bis6_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis6_rg);
        mb_pond9_bis7_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis7_rg);
        mb_pond9_bis8_rg = (RadioGroup) findViewById(R.id.mb_pond9_bis8_rg);
        mb_pond9_waterrelated_rg = (RadioGroup) findViewById(R.id.mb_pond9_waterrelated_rg);
        //Radiobutton
        mb_pond9_permission_yes = (RadioButton) findViewById(R.id.mb_pond9_permission_yes);
        mb_pond9_permission_no = (RadioButton) findViewById(R.id.mb_pond9_permission_no);
        mb_pond9_preinsp_permission_yes = (RadioButton) findViewById(R.id.mb_pond9_preinsp_permission_yes);
        mb_pond9_preinsp_permission_no = (RadioButton) findViewById(R.id.mb_pond9_preinsp_permission_no);
        mb_pond9_bis1_yes = (RadioButton) findViewById(R.id.mb_pond9_bis1_yes);
        mb_pond9_bis1_no = (RadioButton) findViewById(R.id.mb_pond9_bis1_no);
        mb_pond9_bis2_yes = (RadioButton) findViewById(R.id.mb_pond9_bis2_yes);
        mb_pond9_bis2_no = (RadioButton) findViewById(R.id.mb_pond9_bis2_no);
        mb_pond9_bis3_yes = (RadioButton) findViewById(R.id.mb_pond9_bis3_yes);
        mb_pond9_bis3_no = (RadioButton) findViewById(R.id.mb_pond9_bis3_no);
        mb_pond9_bis4_yes = (RadioButton) findViewById(R.id.mb_pond9_bis4_yes);
        mb_pond9_bis4_no = (RadioButton) findViewById(R.id.mb_pond9_bis4_no);
        mb_pond9_bis5_yes = (RadioButton) findViewById(R.id.mb_pond9_bis5_yes);
        mb_pond9_bis5_no = (RadioButton) findViewById(R.id.mb_pond9_bis5_no);
        mb_pond9_bis6_yes = (RadioButton) findViewById(R.id.mb_pond9_bis6_yes);
        mb_pond9_bis6_no = (RadioButton) findViewById(R.id.mb_pond9_bis6_no);
        mb_pond9_bis7_yes = (RadioButton) findViewById(R.id.mb_pond9_bis7_yes);
        mb_pond9_bis7_no = (RadioButton) findViewById(R.id.mb_pond9_bis7_no);
        mb_pond9_bis8_yes = (RadioButton) findViewById(R.id.mb_pond9_bis8_yes);
        mb_pond9_bis8_no = (RadioButton) findViewById(R.id.mb_pond9_bis8_no);
        mb_pond9_waterrelated_yes = (RadioButton) findViewById(R.id.mb_pond9_waterrelated_yes);
        mb_pond9_waterrelated_no = (RadioButton) findViewById(R.id.mb_pond9_waterrelated_no);

        mb_pond9_save = (Button) findViewById(R.id.mb_pond9_save);
        mb_pond8_add_btn = (Button) findViewById(R.id.mb_pond8_add_btn);
        mb_pond8_crop_details_rv = (RecyclerView) findViewById(R.id.mb_pond8_crop_details_rv);
        mb_pond9_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        mb_pond9_obsdate.setText(mb_pond9_date);
    }
    
    private void functions(){

        /*mb_pond9_obsdate_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_pond9_date_service();
            }
        });*/

       /* mb_pond9_previousdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_pond9_predate_service();
            }
        });*/

        mb_pond9_permission_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_permission_yes:
                        mb_pond9_permission_yes.setChecked(true);
                        permission = "1";
                        break;

                    case R.id.mb_pond9_permission_no:
                        mb_pond9_permission_no.setChecked(true);
                        permission = "2";
                        break;
                }
            }
        });

        mb_pond9_preinsp_permission_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_preinsp_permission_yes:
                        mb_pond9_preinsp_permission_yes.setChecked(true);
                        pre_permission = "1";
                        break;

                    case R.id.mb_pond9_preinsp_permission_no:
                        mb_pond9_preinsp_permission_no.setChecked(true);
                        pre_permission = "2";
                        break;
                }
            }
        });

        mb_pond9_bis1_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis1_yes:
                        mb_pond9_bis1_yes.setChecked(true);
                        bis1 = "1";
                        break;

                    case R.id.mb_pond9_bis1_no:
                        mb_pond9_bis1_no.setChecked(true);
                        bis1 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis2_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis2_yes:
                        mb_pond9_bis2_yes.setChecked(true);
                        bis2 = "1";
                        break;

                    case R.id.mb_pond9_bis2_no:
                        mb_pond9_bis2_no.setChecked(true);
                        bis2 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis3_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis3_yes:
                        mb_pond9_bis3_yes.setChecked(true);
                        bis3 = "1";
                        break;

                    case R.id.mb_pond9_bis3_no:
                        mb_pond9_bis3_no.setChecked(true);
                        bis3 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis4_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis4_yes:
                        mb_pond9_bis4_yes.setChecked(true);
                        bis4 = "1";
                        break;

                    case R.id.mb_pond9_bis4_no:
                        mb_pond9_bis4_no.setChecked(true);
                        bis4 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis5_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis5_yes:
                        mb_pond9_bis5_yes.setChecked(true);
                        bis5 = "1";
                        break;

                    case R.id.mb_pond9_bis5_no:
                        mb_pond9_bis5_no.setChecked(true);
                        bis5 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis6_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis6_yes:
                        mb_pond9_bis6_yes.setChecked(true);
                        bis6 = "1";
                        break;

                    case R.id.mb_pond9_bis6_no:
                        mb_pond9_bis6_no.setChecked(true);
                        bis6 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis7_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis7_yes:
                        mb_pond9_bis7_yes.setChecked(true);
                        bis7 = "1";
                        break;

                    case R.id.mb_pond9_bis7_no:
                        mb_pond9_bis7_no.setChecked(true);
                        bis7 = "2";
                        break;
                }
            }
        });

        mb_pond9_bis8_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_bis8_yes:
                        mb_pond9_bis8_yes.setChecked(true);
                        bis8 = "1";
                        break;

                    case R.id.mb_pond9_bis8_no:
                        mb_pond9_bis8_no.setChecked(true);
                        bis8 = "2";
                        break;
                }
            }
        });

        mb_pond9_waterrelated_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_pond9_waterrelated_yes:
                        mb_pond9_waterrelated_yes.setChecked(true);
                        water_related = "1";
                        break;

                    case R.id.mb_pond9_waterrelated_no:
                        mb_pond9_waterrelated_no.setChecked(true);
                        water_related = "2";
                        break;
                }
            }
        });

        mb_pond9_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(MBCommunityFarmPond9Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MBCommunityFarmPond9Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MBCommunityFarmPond9Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(MBCommunityFarmPond9Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        mb_pond8_add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(crop_type_id!=0 && crop_id!=0  && !mb_pond8_crop_area.getText().toString().trim().equalsIgnoreCase("")){
                    add_crop_details(crop_id,crop_type_id,crop_type_name,crop_name,mb_pond8_crop_area.getText().toString().trim());
                }else{
                    final Toast toast = Toast.makeText(MBCommunityFarmPond9Activity.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 1000);
                }
            }
        });
        
        mb_pond9_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_pond9_save_service();
            }
        });
    }

    private void add_crop_details(int crop_id,int crop_type_id,String crop_type_name,String crop_name,String crop_area){

            JSONObject add_multiple_area = new JSONObject();
            try{
                add_multiple_area.put("crop_id", crop_id);
                add_multiple_area.put("crop_type_id", crop_type_id);
                add_multiple_area.put("crop_type_name", crop_type_name);
                add_multiple_area.put("crop_name", crop_name);
                add_multiple_area.put("crop_area", crop_area);
                multiple_crop_area.put(add_multiple_area);

            }catch (Exception e){
                e.printStackTrace();
            }

            if(multiple_crop_area.length()>0){
                mb_pond8_crop_details_rv.setLayoutManager(new LinearLayoutManager(MBCommunityFarmPond9Activity.this));
                MBCommunityFarmPond9Adapter mbCommunityFarmPond9Adapter = new MBCommunityFarmPond9Adapter(preferenceManager, multiple_crop_area, MBCommunityFarmPond9Activity.this);
                mb_pond8_crop_details_rv.setAdapter(mbCommunityFarmPond9Adapter);
                mbCommunityFarmPond9Adapter.notifyDataSetChanged();
                mb_pond9_crop_type.setText("Select");
                mb_pond9_crop_name.setText("Select");
                mb_pond8_crop_area.setText("");
            }else{
                final Toast toast = Toast.makeText(MBCommunityFarmPond9Activity.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 1000);
            }
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;

            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1= null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (photoFile1.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath1 = "file://" + photoFile1;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath1)
                                .resize(mb_pond9_photo.getWidth(), mb_pond9_photo.getHeight())
                                .centerCrop()
                                .into(mb_pond9_photo);

                        uploadImageOnServer(imagePath1);
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile1);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();
            params.put("district_id","1");
            params.put("taluka_id","1");
            params.put("village_id","1");
            params.put("farmer_id","1");
            params.put("lat","1");
            params.put("long","1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save_image(partBody, params);
            api.postRequest(responseCall, this, 1);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mb_pond9_date_service(){

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        mb_pond9_datepicker = new DatePickerDialog(MBCommunityFarmPond9Activity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        mb_pond9_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        mb_pond9_obsdate.setText(mb_pond9_date);
                    }
                }, mYear, mMonth, mDay);

        mb_pond9_datepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        mb_pond9_datepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        mb_pond9_datepicker.show();
    }

    private void mb_pond9_predate_service() {

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        mb_pond9_predate_picker = new DatePickerDialog(MBCommunityFarmPond9Activity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        mb_pond9_pre_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        mb_pond9_previousdatetv.setText(mb_pond9_pre_date);
                    }
                }, mYear, mMonth, mDay);

        mb_pond9_predate_picker.getDatePicker().setMaxDate(System.currentTimeMillis());
        mb_pond9_predate_picker.getDatePicker().setMinDate(newDate.getTime());
        mb_pond9_predate_picker.show();
    }

    private void mb_pond9_save_service(){
        if(mb_pond9_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select दिनांक", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_pre_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select खोदाई पूर्व स्थळ पाहणो अहवालाचा दिनांक", Toast.LENGTH_SHORT).show();
        }else if(permission.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "टखोदाई पूर्व स्थळ पाहणो अहवालानुसार शेततळे खोदाईसाठी पुर्वसंमती दिली आहे किंवा नाही ?", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_bis_name.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter BIS नोंदणीकृत सेवा पुरवठादाराचे नाव", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_bis_address.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter पत्ता", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_durdhvani_no.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter दूरध्वनी क्र.", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_bhraman_no.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter भ्रमणध्वनी क्र.", Toast.LENGTH_SHORT).show();
        }else if(bis1.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "शेततळ्यासाठी BIS Standard ५०० मायक्रॉन रोइनफोसंडू एचडीपोई जोओ मेंबरेन फिल्म IS 15351:2015 Type II या द्जाचो आहे किंबा नाही ?", Toast.LENGTH_SHORT).show();
        }else if(bis2.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "रिइनफोर्सड् एचडोपोइ जिओमेंबरेन ५०० मायक्रांन फिल्मसाठी आवश्यक गुणधर्म (IS:15351:2015 Type II) प्रपत्र प्रमाणे पास कॉपो बिलासोबत आहे किंवा नाहो?", Toast.LENGTH_SHORT).show();
        }else if(bis3.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "फिल्म शेततळयाच्या काठापासुन बंद (अँकरोंग) करून संपूर्ण शेततळयात अशा प्रकारे बसवलेलो आहे किंवा नाही को ज्यामुळे फिल्म पाण्याच्या वजनामुळे खाली घसरणार नाही व शेततळयातील साठलेले पाणी जमिनोमध्ये मुरणार नाही?", Toast.LENGTH_SHORT).show();
        }else if(bis4.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "तारेच्या जाळीचे कुंपण शेततळयाच्या बाहेरील बाजूस केलेले आहे किंबा नाही ?", Toast.LENGTH_SHORT).show();
        }else if(bis5.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "शेततळयांमध्ये पाणी भरलेले आहे किंवा नाही ?", Toast.LENGTH_SHORT).show();
        }else if(bis6.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "शेततळ्याच्या बाजूने गवत लागवड केली आहे / नाहो?", Toast.LENGTH_SHORT).show();
        }else if(bis7.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "एकात्मिक फलोत्पादन विकास अभियानांतर्गत पुर्ण झालेल्या शेततळ्याची माहिती असलेला बोर्ड लावलेला आहे/नाही?", Toast.LENGTH_SHORT).show();
        }else if(bis8.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "पाण्याच्या वजनामुळे खाली घसरणार नाही व शेततळयातील साठलेले पाणी जमिनोमध्ये मुरणार नाही?", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_proof_row1.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण for खोदकाम", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_proof_row2.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण for अस्तरीकरण प्लास्टिक फिल्म", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_proof_row3.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण for अस्तरीकरण फिल्म लावण्याचे खर्च", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_proof_row4.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण for तलावाच्या बाजुची इतर कामे-गवत बी लागवड इ.", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_proof_row5.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण for संरक्षित कुंपण", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_total_proof_row7.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter परिमाण total", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row1.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for खोदकाम", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row2.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for अस्तरीकरण प्लास्टिक फिल्म", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row3.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for अस्तरीकरण फिल्म लावण्याचे खर्च", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row4.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for तलावाच्या बाजुची इतर कामे-गवत बी लागवड इ.", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row5.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for संरक्षित कुंपण", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_actualcost_row6.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च for आकस्मिक खर्च", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_total_actualcost_row7.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्यक्षक खर्च total", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row1.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for खोदकाम", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row2.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for अस्तरीकरण प्लास्टिक फिल्म", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row3.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for अस्तरीकरण फिल्म लावण्याचे खर्च", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row4.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for तलावाच्या बाजुची इतर कामे-गवत बी लागवड इ.", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row5.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for संरक्षित कुंपण", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_subsidy_row6.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान for आकस्मिक खर्च", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_total_subsidy_row7.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शकसूचनेनुसार,मंजूर आकारमानानुसार देय अनुदान total", Toast.LENGTH_SHORT).show();
        }else if(water_related.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "शेततळयाच्या पाण्याच्या कार्यक्षम वापरासाठी संरक्षित सिंचनाची सोय शेतकरी समुहाने केली आहे अथवा नाही?", Toast.LENGTH_SHORT).show();
        }/*else if(multiple_crop_area.length()==0){
            Toast.makeText(getApplicationContext(), "Enter fill details for atleast one crop", Toast.LENGTH_SHORT).show();
        }*/else if(photoFile1 == null){
            Toast.makeText(getApplicationContext(), "Click the photo", Toast.LENGTH_SHORT).show();
        }else if(mb_pond9_total_subsidygiven.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter अंतिम देय रक्कम रु.", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("date_mb9", mb_pond9_date);
                param.put("farmer_name", farmer_id);
                param.put("village_id", village_id);
                param.put("taluka_id", taluka_id);
                param.put("district_id", district_id);
                param.put("survey_no", "0");
                param.put("vargvari", "0");
                param.put("bab1", "0");
                param.put("bab2", "0");
                param.put("bab3", "0");
                param.put("previous_date", "1");
                param.put("permission_rb", permission);
                param.put("pre_accepted_date", "0");
                param.put("pre_area", "0");
                param.put("inspect_date", "0");
                param.put("pre_permission_rb", pre_permission);
                param.put("pre_length", "0");
                param.put("pre_breadth", "0");
                param.put("pre_height", "0");
                param.put("pre_field_fruit", "0");
                param.put("bis_name", mb_pond9_bis_name.getText().toString().trim());
                param.put("bis_address", mb_pond9_bis_address.getText().toString().trim());
                param.put("durdhvani", mb_pond9_durdhvani_no.getText().toString().trim());
                param.put("bhraman", mb_pond9_bhraman_no.getText().toString().trim());
                param.put("bis1", bis1);
                param.put("bis2", bis2);
                param.put("bis3", bis3);
                param.put("bis4", bis4);
                param.put("bis5", bis5);
                param.put("bis6", bis6);
                param.put("bis7", bis7);
                param.put("bis8", bis8);
                param.put("proof1", mb_pond9_proof_row1.getText().toString().trim());
                param.put("proof2", mb_pond9_proof_row2.getText().toString().trim());
                param.put("proof3", mb_pond9_proof_row3.getText().toString().trim());
                param.put("proof4", mb_pond9_proof_row4.getText().toString().trim());
                param.put("proof5", mb_pond9_proof_row5.getText().toString().trim());
                param.put("proof6", mb_pond9_total_proof_row7.getText().toString().trim());
                param.put("actual11", mb_pond9_actualcost_row1.getText().toString().trim());
                param.put("actual12", mb_pond9_actualcost_row2.getText().toString().trim());
                param.put("actual13", mb_pond9_actualcost_row3.getText().toString().trim());
                param.put("actual14", mb_pond9_actualcost_row4.getText().toString().trim());
                param.put("actual15", mb_pond9_actualcost_row5.getText().toString().trim());
                param.put("actual16", mb_pond9_actualcost_row6.getText().toString().trim());
                param.put("actual17", mb_pond9_total_actualcost_row7.getText().toString().trim());
                param.put("subsidy1", mb_pond9_subsidy_row1.getText().toString().trim());
                param.put("subsidy2", mb_pond9_subsidy_row2.getText().toString().trim());
                param.put("subsidy3", mb_pond9_subsidy_row3.getText().toString().trim());
                param.put("subsidy4", mb_pond9_subsidy_row4.getText().toString().trim());
                param.put("subsidy5", mb_pond9_subsidy_row5.getText().toString().trim());
                param.put("subsidy6", mb_pond9_subsidy_row6.getText().toString().trim());
                param.put("subsidy7", mb_pond9_total_subsidy_row7.getText().toString().trim());
                param.put("water_related", water_related);
                param.put("crop_details", "0");
                param.put("image", image_1_file_name);
                param.put("total", mb_pond9_total_subsidygiven.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Community Farm Pond Form 9");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
