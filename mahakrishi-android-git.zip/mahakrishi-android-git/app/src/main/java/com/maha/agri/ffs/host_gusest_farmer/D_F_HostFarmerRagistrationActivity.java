package com.maha.agri.ffs.host_gusest_farmer;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.ffs.D_F_ScheduleListActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.ApiJSONObjCallback;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_HostFarmerRagistrationActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private PreferenceManager preferenceManager;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private AppLocationManager locationManager;
    private String reg_type;
    private int totalDemoArea;
    private int totalFarmerArea;
    private int planId;

    private EditText last_name_edt;
    private String lName;
    private EditText middle_name_edt;
    private String mName;
    private EditText first_name_edt;
    private String fName;
    private RadioGroup gender_radio_group;
    private int genderID = 0;

    private TextView soc_cat_tv;
    private int socialCatID = 0;
    private JSONArray socialCatArray = new JSONArray();

    private EditText mobile_no_edt;
    private String mobile;
    private EditText survey_number_edt;
    private String surNumber;
    private EditText area8A_edt;
    private String area8A;
    private TextInputLayout areaUnderDemoInputLayout;
    private EditText areaUnderDemoEditText;
    private TextInputLayout areaUnderFFSInputLayout;
    private EditText areaUnderFFSEditText;
    private String areaBroughtUnder;

    private TextView irri_source_tv;
    private String irri_source_name;
    private int irri_sourceID;
    private JSONArray irrigationJSONArray = new JSONArray();

    private TextView soil_type_tv;
    private String soil_type_name;
    private int soil_typeID = 0;
    private JSONArray soilTypeJSONArray = new JSONArray();

    private RadioGroup challenged_radio_group;
    private RadioButton no_challange_radio_btn;
    private int physicallyID = 2;

    private Button submitButton;
    private String concern = "0";
    private String actionType = "addPlan";
    private String planData = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_host_farmer_ragistration);
        getSupportActionBar().setTitle("Host Farmer");
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(D_F_HostFarmerRagistrationActivity.this);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        actionType = getIntent().getStringExtra("actionType");
        init();
        defaultConfig();
    }

    private void init() {

        locationManager = new AppLocationManager(this);

        first_name_edt = (EditText) findViewById(R.id.first_name_edt);
        middle_name_edt = (EditText) findViewById(R.id.middle_name_edt);
        last_name_edt = (EditText) findViewById(R.id.last_name_edt);
        gender_radio_group = (RadioGroup) findViewById(R.id.gender_radio_group);
        mobile_no_edt = (EditText) findViewById(R.id.mobile_no_edt);
        survey_number_edt = (EditText) findViewById(R.id.survey_number_edt);
        area8A_edt = (EditText) findViewById(R.id.area8A_edt);
        areaUnderDemoInputLayout = (TextInputLayout) findViewById(R.id.areaUnderDemoInputLayout);
        areaUnderDemoEditText = (EditText) findViewById(R.id.areaUnderDemoEditText);
        areaUnderFFSInputLayout = (TextInputLayout) findViewById(R.id.areaUnderFFSInputLayout);
        areaUnderFFSEditText = (EditText) findViewById(R.id.areaUnderFFSEditText);

        soil_type_tv = (TextView) findViewById(R.id.soil_type_tv);
        irri_source_tv = (TextView) findViewById(R.id.irri_source_tv);
        soc_cat_tv = (TextView) findViewById(R.id.soc_cat_tv);
        challenged_radio_group = (RadioGroup) findViewById(R.id.challenged_radio_group);
        no_challange_radio_btn = (RadioButton) findViewById(R.id.no_challange_radio_btn);
        submitButton = (Button) findViewById(R.id.submitButton);


        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            areaUnderDemoInputLayout.setVisibility(View.VISIBLE);
            areaUnderFFSInputLayout.setVisibility(View.GONE);
        } else {
            areaUnderDemoInputLayout.setVisibility(View.GONE);
            areaUnderFFSInputLayout.setVisibility(View.VISIBLE);
        }
        fetchSocialCategoryMasterData();
        totalDemoArea = getIntent().getIntExtra("totalPlanArea", 10);
        totalFarmerArea = getIntent().getIntExtra("totalFarmerArea",0);
        planId = getIntent().getIntExtra("plan_id",0);
        planData = getIntent().getStringExtra("plan_data");

    }

    private void defaultConfig() {

        soc_cat_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (socialCatArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(socialCatArray, 1, "Select Social Category", "name", "id", D_F_HostFarmerRagistrationActivity.this, D_F_HostFarmerRagistrationActivity.this);
                } else {
                    fetchSocialCategoryMasterData();
                }
            }
        });

        irri_source_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (irrigationJSONArray == null) {
                    fetchIrrigationMasterData();
                } else {
                    AppUtility.getInstance().showListDialogIndex(irrigationJSONArray, 2, "Select Irrigation Source", "name", "id", D_F_HostFarmerRagistrationActivity.this, D_F_HostFarmerRagistrationActivity.this);
                }
            }
        });

        soil_type_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (soilTypeJSONArray == null) {
                    fetchSoilTypeMasterData();
                } else {
                    AppUtility.getInstance().showListDialogIndex(soilTypeJSONArray, 3, "Select Soil Type", "name", "id", D_F_HostFarmerRagistrationActivity.this, D_F_HostFarmerRagistrationActivity.this);
                }
            }
        });


        // For Gender
        gender_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                          @Override
                                                          public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                              if (checkedId == R.id.male_radio_btn) {
                                                                  genderID = 1;
                                                              } else if (checkedId == R.id.female_radio_btn) {
                                                                  genderID = 2;
                                                              } else {
                                                                  genderID = 3;
                                                              }
                                                          }
                                                      }
        );

        // For physically challenged
        challenged_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                              @Override
                                                              public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                                  if (checkedId == R.id.yes_challange_radio_btn) {
                                                                      physicallyID = 1;
                                                                  } else if (checkedId == R.id.no_challange_radio_btn) {
                                                                      physicallyID = 2;
                                                                  }
                                                              }
                                                          }
        );

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitButtonAction();
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        // super.onBackPressed();
    }

    private void fetchSocialCategoryMasterData() {

        String url = APIServices.kSocialCat;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {
                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                socialCatArray = response.getData();
                            } else {
                                UIToastMessage.show(D_F_HostFarmerRagistrationActivity.this, response.getMsg().trim());
                            }
                            fetchIrrigationMasterData();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    private void fetchIrrigationMasterData() {

        String url = APIServices.kIrrigation;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                irrigationJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(D_F_HostFarmerRagistrationActivity.this, response.getMsg().trim());
                            }
                            fetchSoilTypeMasterData();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }

    private void fetchSoilTypeMasterData() {

        String url = APIServices.kSoilTypes;

        AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, new AppSession(this).getToken(), new AppString(this).getkMSG_WAIT(), false);
        api.getRequestData(url, new ApiJSONObjCallback() {
            @Override
            public void onResponse(JSONObject jsonObject, int i) {
                try {
                    if (i == 1) {

                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                soilTypeJSONArray = response.getData();
                            } else {
                                UIToastMessage.show(D_F_HostFarmerRagistrationActivity.this, response.getMsg().trim());
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Throwable throwable, int i) {

            }
        }, 1);

        DebugLog.getInstance().d(url);
    }


    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            socialCatID = Integer.parseInt(s1);
            soc_cat_tv.setText(s);
        }

        if (i == 2) {
            irri_sourceID = Integer.parseInt(s1);
            irri_source_tv.setText(s);
        }

        if (i == 3) {
            soil_typeID = Integer.parseInt(s1);
            soil_type_tv.setText(s);
        }
    }


    private void clearFormData() {
        first_name_edt.setText("");
        middle_name_edt.setText("");
        last_name_edt.setText("");
        gender_radio_group.clearCheck();
        soc_cat_tv.setText("");
        socialCatID = 0;
        mobile_no_edt.setText("");
        survey_number_edt.setText("");
        area8A_edt.setText("");
        areaUnderDemoEditText.setText("");
        areaUnderFFSEditText.setText("");
        irri_source_tv.setText("");
        irri_sourceID = 0;
        soil_type_tv.setText("");
        socialCatID = 0;
        no_challange_radio_btn.setSelected(true);
        physicallyID = 2;
        first_name_edt.setFocusable(true);
        first_name_edt.requestFocus();
    }


    public void showAlert(String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // alertDialogBuilder.setTitle(title);
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                concern = "0";
                totalFarmerArea = totalFarmerArea - Integer.valueOf(areaBroughtUnder);
                dialog.cancel();
            }
        });

        alertDialogBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                concern = "1";
                dialog.cancel();
                addFarmerAPI();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void submitButtonAction() {

        fName = first_name_edt.getText().toString().trim();
        mName = middle_name_edt.getText().toString().trim();
        lName = last_name_edt.getText().toString().trim();
        mobile = mobile_no_edt.getText().toString().trim();
        surNumber = survey_number_edt.getText().toString().trim();
        area8A = area8A_edt.getText().toString().trim();

        if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
            areaBroughtUnder = areaUnderDemoEditText.getText().toString().trim();
        } else {
            areaBroughtUnder = areaUnderFFSEditText.getText().toString().trim();
        }

        if (fName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter first name");
        } else if (mName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter middle name");
        } else if (lName.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter last name");
        } else if (genderID == 0) {
            UIToastMessage.show(this, "Select gender");
        } else if (socialCatID == 0) {
            UIToastMessage.show(this, "Select social category");
        } else if (physicallyID == 0) {
            UIToastMessage.show(this, "Select Physically Challenged option");
        } else if (mobile.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter mobile number");
        } else if (!AppUtility.getInstance().isValidPhoneNumber(mobile)) {
            UIToastMessage.show(this, "Enter valid mobile number");
        } else if (surNumber.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter serve number");
        } else if (area8A.equalsIgnoreCase("")) {
            UIToastMessage.show(this, "Enter Area As per 8a(HA)");
        } else if (areaBroughtUnder.equalsIgnoreCase("")) {
            if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_FFS_REG)) {
                UIToastMessage.show(this, "Enter area Brought Under FFS");
            } else if (!reg_type.equalsIgnoreCase(ApConstants.kFARMER_FFS_REG) && (Integer.valueOf(areaBroughtUnder)>Integer.valueOf(area8A))){
                UIToastMessage.show(this, "FFS area should be less or equal to Area As per 8a(HA)");
            }else if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
                UIToastMessage.show(this, "Enter area Brought Under demonstration");
            }else if (!reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && (Integer.valueOf(areaBroughtUnder)>Integer.valueOf(area8A))){
                UIToastMessage.show(this, "Demonstration area should be less or equal to Area As per 8a(HA)");
            }
        } else if (irri_sourceID == 0) {
            UIToastMessage.show(this, "Select irrigation source");
        } else if (soil_typeID == 0) {
            UIToastMessage.show(this, "Select soil type");
        } else {

            totalFarmerArea = totalFarmerArea + Integer.valueOf(areaBroughtUnder);

            if (totalFarmerArea > totalDemoArea) {
                String message = "";
                if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
                     message = "Demonstration area exceeds the ceiling limit of " + totalDemoArea + " hector." + "Therefore grant will be given only for " + totalDemoArea + " hector.";
                }else {
                     message = "FFS area exceeds the ceiling limit of " + totalDemoArea + " hector." + "Therefore grant will be given only for " + totalDemoArea + " hector.";
                }
                showAlert(message);
            } else {
                addFarmerAPI();
            }
        }
    }

    private void addFarmerAPI() {

        try {
            double lat = locationManager.getLatitude();
            double lang = locationManager.getLongitude();

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("role_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID));
            jsonObject.put("created_by", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("plan_id", planId);
            jsonObject.put("first_name", fName);
            jsonObject.put("middle_name", mName);
            jsonObject.put("last_name", lName);
            jsonObject.put("gender", genderID);
            jsonObject.put("social_category_id", socialCatID);
            jsonObject.put("mobile", mobile);
            jsonObject.put("survey_number", surNumber);
            jsonObject.put("area_8a", area8A);
            jsonObject.put("area_under_crop", areaBroughtUnder);
            jsonObject.put("irrigation_source", irri_sourceID);
            jsonObject.put("soil_type_id", soil_typeID);
            jsonObject.put("physically_challenged", physicallyID);
            jsonObject.put("year", AppUtility.getInstance().getCurrentSyncDateTime());
            jsonObject.put("reg_type", reg_type);
            jsonObject.put("concern", concern);
            jsonObject.put("lat", String.valueOf(lat));
            jsonObject.put("lon", String.valueOf(lang));

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.registerHostFarmer(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            if (i == 1) {
                ResponseModel response = new ResponseModel(jsonObject);
                if (response.isStatus()) {

                    if (totalFarmerArea >= totalDemoArea) {
                        UIToastMessage.show(this, response.getMsg().trim() );
                        if (actionType.equalsIgnoreCase("addPlan")){
                            Intent guest_farmer_reg = new Intent(D_F_HostFarmerRagistrationActivity.this, D_F_GuestFarmerRegisrationActivity.class);
                            guest_farmer_reg.putExtra("plan_id", planId);
                            startActivity(guest_farmer_reg);
                            finish();
                        }else if (actionType.equalsIgnoreCase("selectPlan")){
                            Intent intent = new Intent(D_F_HostFarmerRagistrationActivity.this, D_F_ScheduleListActivity.class);
                            intent.putExtra("cropDetail",planData);
                            startActivity(intent);
                            finish();
                        }

                    } else {
                        clearFormData();
                        UIToastMessage.show(this, response.getMsg().trim());
                    }

                } else {
                    totalFarmerArea = totalFarmerArea - Integer.valueOf(areaBroughtUnder);
                    UIToastMessage.show(this, response.getMsg().trim());
                }
            }
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
