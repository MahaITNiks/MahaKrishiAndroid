package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SprinklerFormDetailActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {

    private Intent intent;
    private String form_details;
    private int form_position;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;

    private TextView spot_verification_sprinkler_select_tv;
    private EditText billTotalETS,actualTotalETS;
    /*As per bill*/
    private EditText billBatchNoETS,billCMLEtS,billQtyETS,billPriceUnitETS;
    /*Actual*/
    private EditText actualBatchNoETS,actualCMLEtS,actualQtyETS,actualPriceUnitETS;
    /*Save and Reset*/
    private Button sprinkler_spot_verification_bill_data_save_btn,sprinkler_spot_verification_bill_data_reset_btn;
    private JSONArray sprinkler_form_details_list,filled_data;
    private int village_id,farmer_id,district_id,takula_id;
    private int type_id;
    private String sprinkler_bill_id="";
    private String actualBatchNoETStr = "",actualQtyETStr = "",actualPriceUnitETStr = "",actual_total_priceETStr = "",type_name = "",type_id_str = "";
    private String billBatchNoETStr = "",billQtyETStr = "",billPriceUnitETStr = "",asperbill_total_price = "";
    private int billBatchNoEtint = 0,billQtyEtint = 0,billPriceUnitEtint = 0;
    private int actualBatchNoEtint= 0 ,actualQtyEtint = 0 ,actualPriceUnitEtint = 0;

    private String item_code = "";
    private int  manuf_code = 0, item_description_code = 0;
    private JSONArray item_description_rate_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sprinkler_form_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Form Details");
        preferenceManager = new PreferenceManager(SprinklerFormDetailActivity.this);
        sharedPref = new SharedPref(SprinklerFormDetailActivity.this);
        intent=getIntent();
        form_position=intent.getIntExtra("form_position",0);
        village_id=intent.getIntExtra("village_id",0);
        takula_id=intent.getIntExtra("takula_id",0);
        farmer_id=intent.getIntExtra("farmer_id",0);
        district_id=intent.getIntExtra("district_id",0);
        item_code = intent.getStringExtra("item_code");
        manuf_code = intent.getIntExtra("manuf_code",0);

        init();
        default_config();
        get_field_drip_bill_data();
    }


    private void init() {
        spot_verification_sprinkler_select_tv=(TextView)findViewById(R.id.spot_verification_sprinkler_select_tv);
        /*As per bill*/
        billBatchNoETS=(EditText)findViewById(R.id.billBatchNoEtS);
        billCMLEtS=(EditText)findViewById(R.id.billCMLEtS);
        billQtyETS=(EditText)findViewById(R.id.billQtyEtS);
        billPriceUnitETS=(EditText)findViewById(R.id.billPriceUnitEtS);
        billTotalETS=(EditText) findViewById(R.id.billTotalETS);
        /*Actual*/
        actualBatchNoETS=(EditText)findViewById(R.id.actualBatchNoEtS);
        actualCMLEtS=(EditText)findViewById(R.id.actualCMLEtS);
        actualQtyETS=(EditText)findViewById(R.id.actualQtyEtS);
        actualPriceUnitETS=(EditText)findViewById(R.id.actualPriceUnitEtS);
        actualTotalETS=(EditText) findViewById(R.id.actualTotalETS);

        sprinkler_form_details_list = new JSONArray();
        item_description_rate_list = new JSONArray();
        filled_data = new JSONArray();
        /*Button*/
        sprinkler_spot_verification_bill_data_save_btn=(Button)findViewById(R.id.sprinkler_spot_verification_bill_data_save_btn);
        sprinkler_spot_verification_bill_data_reset_btn=(Button)findViewById(R.id.sprinkler_spot_verification_bill_data_reset_btn);
    }

    private void default_config() {
        spot_verification_sprinkler_select_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sprinkler_form_details_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_form_details_list, 1, "Select", "item_desc", "comp_code", SprinklerFormDetailActivity.this, SprinklerFormDetailActivity.this);
                }
            }
        });

        sprinkler_spot_verification_bill_data_save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drip_final_save_form();
            }
        });

        sprinkler_spot_verification_bill_data_reset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                spot_verification_sprinkler_select_tv.setEnabled(true);
                billBatchNoETS.setEnabled(true);
                billCMLEtS.setEnabled(true);
                billQtyETS.setEnabled(true);
                billPriceUnitETS.setEnabled(true);
                billTotalETS.setEnabled(true);
                actualBatchNoETS.setEnabled(true);
                actualCMLEtS.setEnabled(true);
                actualQtyETS.setEnabled(true);
                actualPriceUnitETS.setEnabled(true);
                actualTotalETS.setEnabled(true);
                sprinkler_spot_verification_bill_data_save_btn.setEnabled(true);
                sprinkler_spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.button_color));
            }
        });
        get_filled_data();
    }

    private void get_field_drip_bill_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("item_code",item_code);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString()); // CHANGE URL AND DELETE
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.spot_veri_desc_list(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void rate_data(){
        JSONObject param = new JSONObject();
        try {
            param.put("item_code", item_code);
            param.put("manuf_code", manuf_code);
            param.put("comp_code", item_description_code);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.spot_veri_rate_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void drip_final_save_form() {

        billBatchNoETStr=billBatchNoETS.getText().toString().trim();
        billQtyETStr=billQtyETS.getText().toString().trim();
        billPriceUnitETStr=billPriceUnitETS.getText().toString().trim();

        actualBatchNoETStr=actualBatchNoETS.getText().toString().trim();
        actualQtyETStr=actualQtyETS.getText().toString().trim();
        actualPriceUnitETStr=actualPriceUnitETS.getText().toString().trim();

        if(type_name.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Please select value",Toast.LENGTH_LONG).show();
        }else if(billBatchNoETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter batch number for bill",Toast.LENGTH_LONG).show();
        }else if(billCMLEtS.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter CML number for bill",Toast.LENGTH_LONG).show();
        }else if(billQtyETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter quantity number for bill",Toast.LENGTH_LONG).show();
        }else if(billPriceUnitETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter price unit for bill",Toast.LENGTH_LONG).show();
        }else if(billTotalETS.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter total value for bill",Toast.LENGTH_LONG).show();
        }else if(actualBatchNoETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter batch number for actual",Toast.LENGTH_LONG).show();
        }else if(actualCMLEtS.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter CML number for actual",Toast.LENGTH_LONG).show();
        }else if(actualQtyETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter quantity number for actual",Toast.LENGTH_LONG).show();
        }else if(actualPriceUnitETStr.equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter price unit for actual",Toast.LENGTH_LONG).show();
        }else if(actualTotalETS.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(SprinklerFormDetailActivity.this,"Enter total value for actual",Toast.LENGTH_LONG).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("village_id", village_id);
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", takula_id);
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

                param.put("sprinkler_bill_id",sprinkler_bill_id);
                param.put("type", type_id);
                param.put("asperbill_batch_no", billBatchNoETS.getText().toString().trim());
                param.put("asperbill_cml_no", billCMLEtS.getText().toString().trim());
                param.put("asperbill_quantity", billQtyETS.getText().toString().trim());
                param.put("asperbill_unit_rate", billPriceUnitETS.getText().toString().trim());
                param.put("asperbill_total_price", billTotalETS.getText().toString().trim());

                param.put("actual_batch_no", actualBatchNoETS.getText().toString().trim());
                param.put("actual_cml_no", actualCMLEtS.getText().toString().trim());
                param.put("actual_quantity", actualQtyETS.getText().toString().trim());
                param.put("actual_unit_rate", actualPriceUnitETS.getText().toString().trim());
                param.put("actual_total_price", actualTotalETS.getText().toString().trim());

            }
            catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.spot_verification_sprinkler_bill_against_id_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 4);
        }

    }

    private void get_filled_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("sprinkler_bill_id",sprinkler_bill_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.spot_verification_sprinkler_bill_list_against_id(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_form_details_list= jsonObject.getJSONArray("data");
                        }

                    }
                }

                if(i == 2){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            item_description_rate_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= item_description_rate_list.length(); j++) {
                                JSONObject rate_json_object = item_description_rate_list.getJSONObject(j);
                                String asper_bill_rate = rate_json_object.getString("item_mrp");
                                billPriceUnitETS.setText(asper_bill_rate);
                            }
                        }

                    }else {
                        Toast.makeText(SprinklerFormDetailActivity.this,"Rate of that particular component is not found",Toast.LENGTH_LONG).show();
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            filled_data = jsonObject.getJSONArray("data");
                            for(int j = 0;j<filled_data.length();j++){
                                JSONObject filled_json_object = filled_data.getJSONObject(j);
                                type_name = filled_json_object.getString("type_name");
                                billBatchNoETStr = filled_json_object.getString("asperbill_batch_no");
                                billQtyETStr = filled_json_object.getString("asperbill_quantity");
                                billPriceUnitETStr = filled_json_object.getString("asperbill_unit_rate");
                                asperbill_total_price = filled_json_object.getString("asperbill_total_price");
                                actualBatchNoETStr = filled_json_object.getString("actual_batch_no");
                                actualQtyETStr = filled_json_object.getString("actual_quantity");
                                actualPriceUnitETStr = filled_json_object.getString("actual_unit_rate");
                                actual_total_priceETStr = filled_json_object.getString("actual_total_price");
                                set_filled_data();
                            }
                        }

                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void set_filled_data() {
        if( !type_name.equalsIgnoreCase("") && !billBatchNoETStr.equalsIgnoreCase("") && !billQtyETStr.equalsIgnoreCase("") &&!billPriceUnitETStr.equalsIgnoreCase("")&&!asperbill_total_price.equalsIgnoreCase("")&&!actualBatchNoETStr.equalsIgnoreCase("")
                &&!actualQtyETStr.equalsIgnoreCase("")&&!actualPriceUnitETStr.equalsIgnoreCase("")&&!actual_total_priceETStr.equalsIgnoreCase("")){

            spot_verification_sprinkler_select_tv.setText(type_name);
            /*As per bill*/
            billBatchNoETS.setText(billBatchNoETStr);
            billQtyETS.setText(billBatchNoETStr);
            billPriceUnitETS.setText(billPriceUnitETStr);
            billTotalETS.setText(asperbill_total_price);
            /*Actual*/
            actualBatchNoETS.setText(actualBatchNoETStr);
            actualQtyETS.setText(actualQtyETStr);
            actualPriceUnitETS.setText(actualPriceUnitETStr);
            actualTotalETS.setText(actual_total_priceETStr);
            spot_verification_sprinkler_select_tv.setEnabled(false);
            billBatchNoETS.setEnabled(false);
            billQtyETS.setEnabled(false);
            billPriceUnitETS.setEnabled(false);
            billTotalETS.setEnabled(false);
            actualBatchNoETS.setEnabled(false);
            actualQtyETS.setEnabled(false);
            actualPriceUnitETS.setEnabled(false);
            actualTotalETS.setEnabled(false);
            sprinkler_spot_verification_bill_data_save_btn.setEnabled(false);
            sprinkler_spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.grey_button_backy));
        }else {
            spot_verification_sprinkler_select_tv.setEnabled(true);
            billBatchNoETS.setEnabled(true);
            billQtyETS.setEnabled(true);
            billPriceUnitETS.setEnabled(true);
            billTotalETS.setEnabled(true);
            actualBatchNoETS.setEnabled(true);
            actualQtyETS.setEnabled(true);
            actualPriceUnitETS.setEnabled(true);
            actualTotalETS.setEnabled(true);
            sprinkler_spot_verification_bill_data_save_btn.setEnabled(true);
            sprinkler_spot_verification_bill_data_save_btn.setBackground(getResources().getDrawable(R.drawable.button_color));
        }
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i==1){
            item_description_code = Integer.parseInt(s1);
            type_name = s;
            spot_verification_sprinkler_select_tv.setText(type_name);
            rate_data();
            /*As per bill*/
            billBatchNoETS.setText("");
            billCMLEtS.setText("");
            billQtyETS.setText("");
            billPriceUnitETS.setText("");
            billTotalETS.setText("");
            /*Actual*/
            actualBatchNoETS.setText("");
            actualCMLEtS.setText("");
            actualQtyETS.setText("");
            actualPriceUnitETS.setText("");
            actualTotalETS.setText("");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
