package com.maha.agri.activity.task_manager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.NonSchemeActAdapter;
import com.maha.agri.adapter.TaskManagerAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class NonSchemeListActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView nonschemerv;
    private int  nonschemeId;
    private JSONArray nonschemeList, orchardSurveyList;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private DBHandler dbHandler;
    private String user_id="";
    private int sajja_id=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_scheme_list);
        preferenceManager = new PreferenceManager(NonSchemeListActivity.this);
        sharedPref = new SharedPref(NonSchemeListActivity.this);
        getSupportActionBar().setTitle("Non-Scheme Activity List");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        dbHandler = new DBHandler(this);

        init();
        default_config();

        if(isNetworkAvailable()) {
               // getNonSchemeActivityWebservice();
                getOrchardSurveyList();


        } else {
            getOfflineNonSchemeActivity();
        }

}

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.offline_sync, menu);
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

           /* case R.id.offline_sync:
                Intent intent = new Intent(NonSchemeListActivity.this,SyncOfflineDataActivity.class);
                startActivity(intent);*/

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void init(){
        nonschemerv = (RecyclerView) findViewById(R.id.non_scheme_recyclerView);
        nonschemerv.setLayoutManager(new LinearLayoutManager(this));
        nonschemerv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));
        user_id = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        sajja_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));


    }

    private void default_config(){

        nonschemerv.addOnItemTouchListener(new TaskManagerAdapter.RecyclerTouchListener(this, nonschemerv, new TaskManagerAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                /*if(isNetworkAvailable()) {

                    if (dbHandler.getAllOfflineSchemeWorkDetails().length() > 0) {
                        UIToastMessage.show(NonSchemeListActivity.this, "Please sync offline task details");
                    }
                    else if (position == 0) {
                        Intent scheme = new Intent(NonSchemeListActivity.this, DepartmentCategoryPanchnamaActivity.class);
                        startActivity(scheme);
                    } else if (position == 1) {
                        Intent intent = new Intent(NonSchemeListActivity.this, CropSowingReportActivity.class);
                        startActivity(intent);
                    } else if (position == 2) {
                        Toast toast= Toast.makeText(getApplicationContext(), "Coming Soon !", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                        toast.show();
                    }
                }*/
            }


            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }


    private void getOfflineNonSchemeActivity(){
        nonschemeList = dbHandler.getSchemeActivity("2","0");
        nonschemerv.setAdapter(new NonSchemeActAdapter(this, nonschemeList, orchardSurveyList,preferenceManager));
    }

    private void getNonSchemeActivityWebservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("typeId",preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_TYPE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeListTypes(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }



    private void getOrchardSurveyList() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",user_id);
            param.put("sajja_id",sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.orchard_survey_list(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {


        try {

            if (jsonObject != null) {

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            nonschemeList = jsonObject.getJSONArray("data");
                            if(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("3")||
                                    preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("4")||
                                    preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("5")||
                                    preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("6")||
                                    preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("7")){
                                nonschemeList.remove(6);
                                nonschemerv.setAdapter(new NonSchemeActAdapter(this,nonschemeList,orchardSurveyList,preferenceManager));

                            }/*else if(preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("1")){
                                nonschemeList.remove(0);
                                nonschemerv.setAdapter(new NonSchemeActAdapter(this,nonschemeList,preferenceManager));
                            }*/else{
                                nonschemerv.setAdapter(new NonSchemeActAdapter(this, nonschemeList, orchardSurveyList,preferenceManager));
                                //UIToastMessage.show(this, jsonObject.getString("response"));
                            }
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }


                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            orchardSurveyList = jsonObject.getJSONArray("data");
                            getNonSchemeActivityWebservice();
                        }
                    } else {
                        //UIToastMessage.show(this, jsonObject.getString("response"));
                        getNonSchemeActivityWebservice();
                    }
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    }
