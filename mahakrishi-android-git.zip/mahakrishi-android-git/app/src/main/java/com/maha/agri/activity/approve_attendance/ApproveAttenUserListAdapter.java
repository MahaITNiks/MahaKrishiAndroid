package com.maha.agri.activity.approve_attendance;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ApproveAttenUserListAdapter extends RecyclerView.Adapter<ApproveAttenUserListAdapter.MyViewHolder>  {
    private Context mContext;
    private JSONArray mDataArray;
    String id,name;
    PreferenceManager preferenceManager;
    private JSONObject jsonObject;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView statusImageView;
        private TextView nameTextView;
        private TextView codeTextView;
        private LinearLayout approve_ll;



        public MyViewHolder(View itemView) {
            super(itemView);
            this.statusImageView = itemView.findViewById(R.id.statusImageView);
            this.nameTextView = itemView.findViewById(R.id.nameTextView);
            //this.codeTextView = itemView.findViewById(R.id.codeTextView);
            this.approve_ll = itemView.findViewById(R.id.approve_ll);

        }
    }

    public ApproveAttenUserListAdapter(Context mContext, JSONArray mDataArray, PreferenceManager preferenceManager) {
        this.mContext = mContext;
        this.mDataArray = mDataArray;
        this.preferenceManager = preferenceManager;
    }


    @Override
    public ApproveAttenUserListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                       int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_aprov_user_list, parent, false);

        ApproveAttenUserListAdapter.MyViewHolder myViewHolder = new ApproveAttenUserListAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final ApproveAttenUserListAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = mDataArray.getJSONObject(listPosition);

            {
                String fName = jsonObject.getString("first_name");
                String mName =  jsonObject.getString("middle_name");
                String lName =  jsonObject.getString("last_name");
                String  isCompleted = jsonObject.getString("is_completed");
                //preferenceManager.putPreferenceValues(Preference_Constant.IS_COMPLETED,isCompleted);
                name = fName + " " + mName + " " + lName;
                holder.nameTextView.setText(name);
                //holder.codeTextView.setText(jsonObject.getString("id"));
                if(isCompleted.equalsIgnoreCase("0")){
                    holder.statusImageView.setImageResource(R.drawable.ic_close_red);
                } else {
                    holder.statusImageView.setImageResource(R.drawable.ic_done_green);
                }

            holder.approve_ll.setTag(listPosition);

            holder.approve_ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = mDataArray.getJSONObject(index).getString("id");
                        String Full_Name = mDataArray.getJSONObject(index).getString("first_name") + " " + mDataArray.getJSONObject(index).getString("middle_name") + " " + mDataArray.getJSONObject(index).getString("last_name");;
                        Intent intent = new Intent(mContext,ApproveAttendActivity.class);
                        intent.putExtra("junior_id",id);
                        intent.putExtra("name",Full_Name);
                        mContext.startActivity(intent);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ApproveAttenUserListAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ApproveAttenUserListAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
