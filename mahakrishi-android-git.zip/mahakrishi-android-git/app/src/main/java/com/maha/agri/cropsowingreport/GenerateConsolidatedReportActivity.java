package com.maha.agri.cropsowingreport;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.task_manager.NonSchemeListActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateConsolidatedReportActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button consolidated_report_submit_btn, consolidated_report_cancel_btn;
    private String multi_area_add;
    private int crop_type_id,horti_type_id,season_id,divison_id = 0,district_id = 0, taluka_id = 0, sajja_id = 0, village_id = 0;
    private int affectedArea_int = 0, previous_value, current_value, total_value;
    private RecyclerView generate_consolidated_report_add_more_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray multiple_crop_area_year = new JSONArray();
    JSONArray village_wise_crop_data = new JSONArray();
    private String current_date = "",current_week="",last_week="";
    private String cureent_day = "";
    private SweetAlertDialog sweetAlertDialog;
    private ExpandableListView consolidated_report_expandableListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_consolidated_report);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Generate Consolidated Report");

        preferenceManager = new PreferenceManager(GenerateConsolidatedReportActivity.this);
        sharedPref = new SharedPref(GenerateConsolidatedReportActivity.this);
        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_id = intent.getIntExtra("sajja_id",0);
        village_id = intent.getIntExtra("village_id",0);
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        multi_area_add = intent.getStringExtra("multi_consolreport_data");
        current_week = intent.getStringExtra("current_week");
        last_week = intent.getStringExtra("last_week");
        init();
        default_config();
    }

    private void init() {
        generate_consolidated_report_add_more_rv = (RecyclerView)findViewById(R.id.generate_consolidated_report_add_more_rv);
        //consolidated_report_expandableListView = (ExpandableListView)findViewById(R.id.consolidated_report_expandableListView);
        consolidated_report_submit_btn = (Button) findViewById(R.id.consolidated_report_submit_btn);
        consolidated_report_cancel_btn = (Button) findViewById(R.id.consolidated_report_cancel_btn);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        current_date = df.format(c);
        cureent_day = sdf.format(d);

        consolidated_report_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                consolidate_report_save();
            }
        });

        consolidated_report_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });
    }

    private void default_config() {
        try {
            multiple_crop_area_year = new JSONArray(multi_area_add);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        generate_consolidated_report_add_more_rv.setLayoutManager(new LinearLayoutManager(GenerateConsolidatedReportActivity.this));
        GenerateConsolidatedReportAdapter generateConsolidatedReportAdapter = new GenerateConsolidatedReportAdapter(preferenceManager, multiple_crop_area_year, GenerateConsolidatedReportActivity.this);
        generate_consolidated_report_add_more_rv.setAdapter(generateConsolidatedReportAdapter);
        generateConsolidatedReportAdapter.notifyDataSetChanged();

    }

    /*private void Village_wise_crop_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("village_wise_c_data", multiple_crop_area_year);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.primary_report_village_wise_crop_data(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }*/

    private void consolidate_report_save() {

            JSONObject jsonObject = new JSONObject();

            try {
                jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                jsonObject.put("division_id", divison_id);
                jsonObject.put("district_id", district_id);
                jsonObject.put("taluka_id", taluka_id);
                jsonObject.put("sajja_id", sajja_id);
                jsonObject.put("village_id", village_id);
                jsonObject.put("season_id", season_id);
                jsonObject.put("crop_type_id", crop_type_id);
                jsonObject.put("horti_type_id", horti_type_id);
                jsonObject.put("current_week",current_week);
                jsonObject.put("last_week",last_week);
                jsonObject.put("current_day",cureent_day);
                jsonObject.put("current_date",current_date);
                jsonObject.put("multi_consolreport_data", multiple_crop_area_year);
                jsonObject.put("weeksNo", "");
                jsonObject.put("monthsVal", "");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.consolidated_report_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {

                /*if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_wise_crop_data = jsonObject.getJSONArray("data");
                            ConsolidatedExpandableAdapter consolidatedexpandableadapter = new ConsolidatedExpandableAdapter(GenerateConsolidatedReportActivity.this,village_wise_crop_data);
                            consolidated_report_expandableListView.destroyDrawingCache();
                            consolidated_report_expandableListView.setAdapter(consolidatedexpandableadapter);
                            consolidatedexpandableadapter.notifyDataSetChanged();
                        }
                    }
                }
*/

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                    sweetAlertDialog.setTitleText("Consolidated Report Submitted Successfully");
                                    sweetAlertDialog.setCancelable(false);
                                    sweetAlertDialog.setConfirmText("Ok");
                                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Intent intent = new Intent(GenerateConsolidatedReportActivity.this, NonSchemeListActivity.class);
                                            //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    });
                                    sweetAlertDialog.show();
                        }
                    }
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
