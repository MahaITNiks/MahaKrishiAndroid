package com.maha.agri.mb_recording;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Refilling_Activity extends AppCompatActivity implements ApiCallbackCode {
    private AppLocationManager locationManager;
    private int soil_lavel;
    public double lat;
    public double lang;
    private String soil_id = "";
    private String soilName;

    // For Image upload
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    static final Integer CAMERA = 0x5;
    String imagePath, currentTime;
    private Transformation transformation;
    String type;

    private String image1URL;
    private String image2URL;

    Button btn_submit_refiling;
    EditText edt_soil_qty_refilling, edt_soft_murum_qty_refilling, edt_hard_murum_qty_refilling, edt_total_qty_refilling;
    EditText edt_diameter_deduct, edt_height_deduct, edt_total_qty_deduct, edt_total_qty_dwpt;
    TextView tv_net_qty_deduct;
    String qty_soil, qty_soft_murum, qty_hard_murum;
    String total_qty_refilling = "", total_qty_deduct = "", net_qty_deduct;
    String str_farmer_name, step_id;
    TextView txt_farmer_name;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    String str_soil_qty_refilling, str_soft_murum_qty_refilling, str_hard_murum_qty_refilling, str_total_qty_refilling;
    String str_diameter_deduct, str_height_deduct, str_total_qty_deduct, str_total_qty_dwpt;
    ImageView farmers_photo_Refilling, farmers_photo_deduct_well;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refilling_);
        getSupportActionBar().setTitle("Refilling");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(Refilling_Activity.this);
        sharedPref = new SharedPref(Refilling_Activity.this);
        soil_lavel = AppSettings.getInstance().getIntValue(this, ApConstants.MB_STAGE_LAVAL, 0);

        init();

        qty_soil = AppSettings.getInstance().getValue(Refilling_Activity.this, ApConstants.QTY_SOIL_ID, "");
        edt_soil_qty_refilling.setText(qty_soil);
        qty_soft_murum = AppSettings.getInstance().getValue(Refilling_Activity.this, ApConstants.QTY_SOFT_MURUM_ID, "");
        edt_soft_murum_qty_refilling.setText(qty_soft_murum);
        qty_hard_murum = AppSettings.getInstance().getValue(Refilling_Activity.this, ApConstants.QTY_HARD_MURUM_ID, "");
        edt_hard_murum_qty_refilling.setText(qty_hard_murum);
        qty_hard_murum = AppSettings.getInstance().getValue(Refilling_Activity.this, ApConstants.HEIGHT_VERTICAL_WALL_HEIGHT_ID, "");
        edt_height_deduct.setText(qty_hard_murum);

        double height_1 = 0;
        String height = edt_height_deduct.getText().toString();

        if (!height.equalsIgnoreCase("")) {
            height_1 = Double.parseDouble(height);
        }
        edt_height_deduct.setText(String.valueOf(height_1 - (1.5)));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {
        soil_id = getIntent().getStringExtra("soilId");
        soilName = getIntent().getStringExtra("soilName");
        locationManager = new AppLocationManager(this);

        farmers_photo_Refilling = (ImageView) findViewById(R.id.farmers_photo_Refilling);
        farmers_photo_deduct_well = (ImageView) findViewById(R.id.farmers_photo_deduct_well);
        btn_submit_refiling = (Button) findViewById(R.id.btn_submit_refiling);

        edt_soil_qty_refilling = (EditText) findViewById(R.id.edt_soil_qty_refilling);
        edt_soft_murum_qty_refilling = (EditText) findViewById(R.id.edt_soft_murum_qty_refilling);
        edt_hard_murum_qty_refilling = (EditText) findViewById(R.id.edt_hard_murum_qty_refilling);
        edt_total_qty_refilling = (EditText) findViewById(R.id.edt_total_qty_refilling);

        edt_diameter_deduct = (EditText) findViewById(R.id.edt_diameter_deduct);
        edt_height_deduct = (EditText) findViewById(R.id.edt_height_deduct);
        edt_total_qty_deduct = (EditText) findViewById(R.id.edt_total_qty_deduct);

        tv_net_qty_deduct = (TextView) findViewById(R.id.tv_net_qty_deduct);
        edt_total_qty_dwpt = (EditText) findViewById(R.id.edt_total_qty_dwpt);


        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        String soilData = getIntent().getStringExtra("soilData");
        if (!soilData.equalsIgnoreCase("")){
            setSoilDetail(soilData);
        }

        farmers_photo_Refilling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "1";
                    takeImage1FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        farmers_photo_deduct_well.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(Refilling_Activity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImage2FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        txt_farmer_name = (TextView) findViewById(R.id.txt_farmer_name);
        str_farmer_name = AppSettings.getInstance().getValue(Refilling_Activity.this, ApConstants.MB_FARMER_NAME, "");
        txt_farmer_name.setText(str_farmer_name);

        edt_hard_murum_qty_refilling.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               /* int value1 = Integer.parseInt(edt_list_from_soil.getText().toString());
                int value2 = Integer.parseInt(edt_lift_to_soil.getText().toString());*/
                double value1 = 0;
                double value2 = 0;
                double value3 = 0;
                String v1 = edt_soil_qty_refilling.getText().toString();
                String v2 = edt_soft_murum_qty_refilling.getText().toString();
                String v3 = edt_hard_murum_qty_refilling.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
                if (!v3.equalsIgnoreCase("")) {
                    value3 = Double.parseDouble(v3);
                }

               /* total_qty_refilling = String.valueOf(value1+value2+value3);
                edt_total_qty_refilling.setText(total_qty_refilling);*/

                edt_total_qty_refilling.setText(String.valueOf(value1 + value2 + value3));
                total_qty_refilling = edt_total_qty_refilling.getText().toString();
            }
        });

        edt_diameter_deduct.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               /* int value1 = Integer.parseInt(edt_list_from_soil.getText().toString());
                int value2 = Integer.parseInt(edt_lift_to_soil.getText().toString());*/
                double value1 = 0;
                double value2 = 0;
                String v1 = edt_diameter_deduct.getText().toString();
                String v2 = edt_height_deduct.getText().toString();
                if (!v1.equalsIgnoreCase("")) {
                    value1 = Double.parseDouble(v1);
                }
                if (!v2.equalsIgnoreCase("")) {
                    value2 = Double.parseDouble(v2);
                }
               /* total_qty_deduct = String.valueOf(0.785*(value1*value1)*value2);
                edt_total_qty_deduct.setText(total_qty_deduct);*/
                edt_total_qty_deduct.setText(String.valueOf(0.785 * (value1 * value1) * value2));
                total_qty_deduct = edt_total_qty_deduct.getText().toString();
            }
        });


        edt_total_qty_deduct.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                double total_qty_refilling_1 = 0;
                double total_qty_deduct_2 = 0;

                String total_qty_refilling = edt_total_qty_refilling.getText().toString();
                String total_qty_deduct = edt_total_qty_deduct.getText().toString();

                if (!total_qty_refilling.equalsIgnoreCase("")) {
                    total_qty_refilling_1 = Double.parseDouble(total_qty_refilling);
                }
                if (!total_qty_deduct.equalsIgnoreCase("")) {
                    total_qty_deduct_2 = Double.parseDouble(total_qty_deduct);
                }
                tv_net_qty_deduct.setText(String.valueOf(total_qty_refilling_1 - total_qty_deduct_2));
                net_qty_deduct = tv_net_qty_deduct.getText().toString();
                edt_total_qty_dwpt.setText(net_qty_deduct);
            }
        });


        btn_submit_refiling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dewatering_Save_Service();
            }
        });
    }

    private void setSoilDetail(String soilData) {
        btn_submit_refiling.setVisibility(View.INVISIBLE);
        try {
            JSONObject soilJSON = new JSONObject(soilData);
            String qty_refilling = soilJSON.getString("soil_qty_refilling");
            String s_murum_qty_refilling = soilJSON.getString("soft_murum_qty_refilling");
            String h_murum_qty_refilling = soilJSON.getString("hard_murum_qty_refilling");
            String total_qty_refilling = soilJSON.getString("str_total_qty_refilling");

            String diameter_deduct = soilJSON.getString("str_diameter_deduct");
            String height_deduct = soilJSON.getString("str_height_deduct");
            String total_qty_deduct = soilJSON.getString("str_total_qty_deduct");
            String total_qty_dwpt = soilJSON.getString("str_total_qty_dwpt");

            edt_soil_qty_refilling.setText(qty_refilling);
            edt_soft_murum_qty_refilling.setText(s_murum_qty_refilling);
            edt_hard_murum_qty_refilling.setText(h_murum_qty_refilling);
            edt_total_qty_refilling.setText(total_qty_refilling);

            edt_diameter_deduct.setText(diameter_deduct);
            edt_height_deduct.setText(height_deduct);
            edt_total_qty_deduct.setText(total_qty_deduct);
            edt_total_qty_dwpt.setText(total_qty_dwpt);

            String img1URL = soilJSON.getString("img1Url");
            if (!img1URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img1URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_Refilling);
            }

            String img2URL = soilJSON.getString("img2Url");
            if (!img2URL.equalsIgnoreCase("")){
                Picasso.get()
                        .load(img2URL)
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .into(farmers_photo_deduct_well);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage2FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
            } else {
                photoURI = Uri.fromFile(photoFile2);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void uploadImage1OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage2OnServer(String imagePath) {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLatitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);
            Map<String, String> params = new HashMap<>();
            params.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));
            params.put("soil_id", String.valueOf(Integer.valueOf(soil_id)));

            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.image_mb_recording(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                           /* Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_Refilling.getWidth(), farmers_photo_Refilling.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Refilling);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage1OnServer(imagePath);
                }
            }
        }


        if (photoFile2 != null) {

            if (type.equalsIgnoreCase("2")) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            /*Picasso.get()
                                    .load(imagePath)
                                    .transform(transformation)
                                    .resize(farmers_photo_deduct_well.getWidth(), farmers_photo_deduct_well.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_deduct_well);*/

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    uploadImage2OnServer(imagePath);
                }
            }
        }


    }

    private void Dewatering_Save_Service() {
        str_soil_qty_refilling = edt_soil_qty_refilling.getText().toString().trim();
        str_soft_murum_qty_refilling = edt_soft_murum_qty_refilling.getText().toString().trim();
        str_hard_murum_qty_refilling = edt_hard_murum_qty_refilling.getText().toString().trim();
        str_total_qty_refilling = edt_total_qty_refilling.getText().toString().trim();

        str_diameter_deduct = edt_diameter_deduct.getText().toString().trim();
        str_height_deduct = edt_height_deduct.getText().toString().trim();
        str_total_qty_deduct = edt_total_qty_deduct.getText().toString().trim();
        str_total_qty_dwpt = edt_total_qty_dwpt.getText().toString().trim();

        str_farmer_name = txt_farmer_name.getText().toString().trim();

        /*if (str_soil_qty_refilling.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "select Soil qty Refiling", Toast.LENGTH_SHORT).show();
        } else if (str_height_deduct.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "select Height Refiling", Toast.LENGTH_SHORT).show();
        } else if (str_total_qty_refilling.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "select Total Qty Refiling", Toast.LENGTH_SHORT).show();
        } else if (str_total_qty_dwpt_refilling.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "select Total Qty Mt Refiling", Toast.LENGTH_SHORT).show();
        } else if (photoFile1 == null) {
            Toast.makeText(Refilling_Activity.this, "select Refilling photo", Toast.LENGTH_SHORT).show();
        } else*/ if (str_diameter_deduct.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "Input Diameter Deduct", Toast.LENGTH_SHORT).show();
        } else if (str_height_deduct.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "Input Height Deduct", Toast.LENGTH_SHORT).show();
        } else if (str_total_qty_deduct.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "Input Total ", Toast.LENGTH_SHORT).show();
        } else if (str_total_qty_dwpt.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "Input Qty Mt Reinforced", Toast.LENGTH_SHORT).show();
        } else if (photoFile1 == null) {
            Toast.makeText(Refilling_Activity.this, "Input Diameter deduct photo", Toast.LENGTH_SHORT).show();
        } else if (str_farmer_name.isEmpty()) {
            Toast.makeText(Refilling_Activity.this, "Input Farmer Name", Toast.LENGTH_SHORT).show();
        } else {

            soil_lavel++;
            JSONObject param = new JSONObject();
            try {
                param.put("farmer_reg_id", Integer.valueOf(preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID)));
                param.put("soil_id", Integer.valueOf(soil_id));
                param.put("soil_name", soilName);
                param.put("stepID", soil_lavel);

                param.put("soil_qty_refilling", str_soil_qty_refilling);
                param.put("soft_murum_qty_refilling", str_soft_murum_qty_refilling);
                param.put("hard_murum_qty_refilling", str_hard_murum_qty_refilling);
                param.put("str_total_qty_refilling", str_total_qty_refilling);

                param.put("str_diameter_deduct", str_diameter_deduct);
                param.put("str_height_deduct", str_height_deduct);
                param.put("str_total_qty_deduct", str_total_qty_deduct);
                param.put("str_total_qty_dwpt", str_total_qty_dwpt);

                param.put("str_farmer_name", str_farmer_name);
                param.put("img1Url", image1URL);
                param.put("img2Url", image2URL);
                param.put("lat", lat);
                param.put("lang", lang);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.soil_registration_mb_recording(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                //save1
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        AppSettings.getInstance().setIntValue(Refilling_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                        finish();
                    } else {
                        soil_lavel--;
                        AppSettings.getInstance().setIntValue(Refilling_Activity.this, ApConstants.MB_STAGE_LAVAL, soil_lavel);
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image1URL = data.getString("file_url");
                        if (!image1URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image1URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_Refilling.getWidth(), farmers_photo_Refilling.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_Refilling);
                        }
                    } else {
                        UIToastMessage.show(Refilling_Activity.this, jsonObject.getString("response"));
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, jsonObject.getString("response"), Toast.LENGTH_SHORT).show();
                        JSONObject data = jsonObject.getJSONObject("data");
                        image2URL = data.getString("file_url");
                        if (!image2URL.equalsIgnoreCase("")) {
                            Picasso.get()
                                    .load(image2URL)
                                    .transform(transformation)
                                    .resize(farmers_photo_deduct_well.getWidth(), farmers_photo_deduct_well.getHeight())
                                    .centerCrop()
                                    .into(farmers_photo_deduct_well);
                        }
                    } else {
                        UIToastMessage.show(Refilling_Activity.this, jsonObject.getString("response"));
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
