package com.maha.agri.activity.TaskManagerReport;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.SchemeAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SchemeReportActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView schemerv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private JSONArray schemeList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_report);
        preferenceManager = new PreferenceManager(SchemeReportActivity.this);
        sharedPref = new SharedPref(SchemeReportActivity.this);
        getSupportActionBar().setTitle("Scheme List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        init();

        default_config();
        getSchemeListWebservice();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    private void init(){
        schemerv = (RecyclerView) findViewById(R.id.scheme_recyclerView);
        schemerv.setLayoutManager(new LinearLayoutManager(this));
        schemerv.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));

    }

    private void default_config(){

        schemerv.addOnItemTouchListener(new SchemeAdapter.RecyclerTouchListener(this, schemerv, new SchemeAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                try {
                    JSONObject jsonObject = schemeList.getJSONObject(position);
                    String id = jsonObject.getString("id");
                    Intent intent = new Intent(SchemeReportActivity.this,SchemeListReportActivity.class);
                    intent.putExtra("schemeList", schemeList.toString());
                    intent.putExtra("position", position);
                    intent.putExtra("id", id);
                    startActivity(intent);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }


    private void getSchemeListWebservice() {

        JSONObject param = new JSONObject();
        try {
            param.put("typeId","1");
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.schemeReportList(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            schemeList = jsonObject.getJSONArray("data");
                            schemerv.setAdapter(new SchemeListSubTypeReportAdapter(this,schemeList,preferenceManager));
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}