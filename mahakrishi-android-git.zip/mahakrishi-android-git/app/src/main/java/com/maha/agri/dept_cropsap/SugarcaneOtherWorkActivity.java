package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SugarcaneOtherWorkActivity extends AppCompatActivity implements ApiCallbackCode {

    private EditText tradename_insecticide_sugarcaneOW, quantity_used_acre_insecticide_sugarcaneOW,tradename_fungicide_sugarcaneOW,quantity_used_acre_fungicide_sugarcaneOW,
            tradename_weedicide_sugarcaneOW, quantity_used_acre_weedicide_sugarcaneOW,fertilizer_sugarcaneOW_N,fertilizer_sugarcaneOW_P,
            fertilizer_sugarcaneOW_K, fertilizername_sugarcaneOW, quantity_used_acre_fertilizer_sugarcaneOW;
    private ImageView pest_sugarcaneOW_photo, crop_growth_sugarcaneOW_photo;
    private Button btn_submit_sugarcaneOW_pheromone;
    private Spinner sp_technicalname_insecticide_sugarcaneOW,sp_technicalname_fungicide_sugarcaneOW,sp_weedicide_technicalname_sugarcaneOW,
            sp_irrigation_given_sugarcaneOW;
    private RadioGroup insecticide_radio_group_sugarcaneOW,fungicide_radio_group_sugarcaneOW,weedicide_radio_group_sugarcaneOW,
            fertilizer_radio_group_sugarcaneOW, radio_group_intercultural_sugarcaneOW, radio_group_irrigation_field_sugarcaneOW;
    private RadioButton insecticide_sugarcaneOW_yes,insecticide_sugarcaneOW_no,fungicide_sugarcaneOW_yes,fungicide_sugarcaneOW_no,
            weedicide_sugarcaneOW_yes,weedicide_sugarcaneOW_no,fertilizer_sugarcaneOW_yes,fertilizer_sugarcaneOW_no,
            weeding_sugarcaneOW_rb,hoeing_sugarcaneOW_rb,detopping_sugarcaneOW_rb,none_sugarcaneOW_rb,irrigation_sugarcaneOW_yes,
            irrigation_sugarcaneOW_no;
    private LinearLayout ll_insecticide_layout_sugarcaneOW,ll_fungicide_layout_sugarcaneOW,ll_weedicide_layout_sugarcaneOW,
            ll_fertilizer_layout_sugarcaneOW;
    private RelativeLayout irrigation_layout_sugarcaneOW;
    private String insecticide = "",fungicide = "",weedicide = "",fertilizer = "",irrigation = "",intercultural = "";
    private String insecticide_tech_name="",fungicide_tech_name="",weedicide_tech_name="",irrigation_name="";

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private AppLocationManager locationManager;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private String imagePath1="", imagePath2="", type="";
    private String image_1_file_name="",image_2_file_name="";
    public double lat,lang;

    private int district_id=0, taluka_id=0, village_id=0, farmer_id=0;
    private String pher_trap1 = "",pher_trap2="",pher_trap1_photo="",pher_trap2_photo="";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugarcane_other_work);

        getSupportActionBar().setTitle("Other Works");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(SugarcaneOtherWorkActivity.this);
        sharedPref = new SharedPref(SugarcaneOtherWorkActivity.this);
        locationManager = new AppLocationManager(this);

        initView();
        setListners();

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        pher_trap1 = intent.getStringExtra("pher_trap1");
        pher_trap2 = intent.getStringExtra("pher_trap2");
        pher_trap1_photo = intent.getStringExtra("pher_trap1_photo");
        pher_trap2_photo = intent.getStringExtra("pher_trap2_photo");
    }

    private void initView() {

        //Spinner
        sp_technicalname_insecticide_sugarcaneOW= (Spinner)findViewById(R.id.sp_technicalname_insecticide_sugarcaneOW);
        sp_technicalname_fungicide_sugarcaneOW = (Spinner)findViewById(R.id.sp_technicalname_fungicide_sugarcaneOW);
        sp_weedicide_technicalname_sugarcaneOW = (Spinner)findViewById(R.id.sp_weedicide_technicalname_sugarcaneOW);
        sp_irrigation_given_sugarcaneOW = (Spinner)findViewById(R.id.sp_irrigation_given_sugarcaneOW);

        //Edit text
        tradename_insecticide_sugarcaneOW = (EditText)findViewById(R.id.tradename_insecticide_sugarcaneOW);
        quantity_used_acre_insecticide_sugarcaneOW = (EditText)findViewById(R.id.quantity_used_acre_insecticide_sugarcaneOW);
        tradename_fungicide_sugarcaneOW = (EditText)findViewById(R.id.tradename_fungicide_sugarcaneOW);
        quantity_used_acre_fungicide_sugarcaneOW= (EditText)findViewById(R.id.quantity_used_acre_fungicide_sugarcaneOW);
        tradename_weedicide_sugarcaneOW = (EditText)findViewById(R.id.tradename_weedicide_sugarcaneOW);
        quantity_used_acre_weedicide_sugarcaneOW = (EditText)findViewById(R.id.quantity_used_acre_weedicide_sugarcaneOW);
        fertilizer_sugarcaneOW_N = (EditText)findViewById(R.id.fertilizer_sugarcaneOW_N);
        fertilizer_sugarcaneOW_P = (EditText)findViewById(R.id.fertilizer_sugarcaneOW_P);
        fertilizer_sugarcaneOW_K = (EditText)findViewById(R.id.fertilizer_sugarcaneOW_K);
        fertilizername_sugarcaneOW = (EditText)findViewById(R.id.fertilizername_sugarcaneOW);
        quantity_used_acre_fertilizer_sugarcaneOW = (EditText)findViewById(R.id.quantity_used_acre_fertilizer_sugarcaneOW);

        //Imageview
        //pest_sugarcaneOW_photo = (ImageView) findViewById(R.id.pest_sugarcaneOW_photo);
        crop_growth_sugarcaneOW_photo = (ImageView) findViewById(R.id.crop_growth_sugarcaneOW_photo);

        //Radiogroup
        insecticide_radio_group_sugarcaneOW= (RadioGroup) findViewById(R.id.insecticide_radio_group_sugarcaneOW);
        fungicide_radio_group_sugarcaneOW = (RadioGroup) findViewById(R.id.fungicide_radio_group_sugarcaneOW);
        weedicide_radio_group_sugarcaneOW= (RadioGroup) findViewById(R.id.weedicide_radio_group_sugarcaneOW);
        fertilizer_radio_group_sugarcaneOW = (RadioGroup) findViewById(R.id.fertilizer_radio_group_sugarcaneOW);
        radio_group_intercultural_sugarcaneOW = (RadioGroup) findViewById(R.id.radio_group_intercultural_sugarcaneOW);
        radio_group_irrigation_field_sugarcaneOW = (RadioGroup) findViewById(R.id.radio_group_irrigation_field_sugarcaneOW);

        //Radiobutton
        insecticide_sugarcaneOW_yes = (RadioButton) findViewById(R.id.insecticide_sugarcaneOW_yes);
        insecticide_sugarcaneOW_no = (RadioButton) findViewById(R.id.insecticide_sugarcaneOW_no);
        fungicide_sugarcaneOW_yes = (RadioButton) findViewById(R.id.fungicide_sugarcaneOW_yes);
        fungicide_sugarcaneOW_no = (RadioButton) findViewById(R.id.fungicide_sugarcaneOW_no);
        weedicide_sugarcaneOW_yes = (RadioButton) findViewById(R.id.weedicide_sugarcaneOW_yes);
        weedicide_sugarcaneOW_no = (RadioButton) findViewById(R.id.weedicide_sugarcaneOW_no);
        fertilizer_sugarcaneOW_yes = (RadioButton) findViewById(R.id.fertilizer_sugarcaneOW_yes);
        fertilizer_sugarcaneOW_no = (RadioButton) findViewById(R.id.fertilizer_sugarcaneOW_no);
        weeding_sugarcaneOW_rb = (RadioButton) findViewById(R.id.weeding_sugarcaneOW_rb);
        hoeing_sugarcaneOW_rb = (RadioButton) findViewById(R.id.hoeing_sugarcaneOW_rb);
        detopping_sugarcaneOW_rb = (RadioButton) findViewById(R.id.detopping_sugarcaneOW_rb);
        none_sugarcaneOW_rb = (RadioButton) findViewById(R.id.none_sugarcaneOW_rb);
        irrigation_sugarcaneOW_yes = (RadioButton) findViewById(R.id.irrigation_sugarcaneOW_yes);
        irrigation_sugarcaneOW_no = (RadioButton) findViewById(R.id.irrigation_sugarcaneOW_no);

        //Linear Layout
        ll_insecticide_layout_sugarcaneOW = (LinearLayout)findViewById(R.id.ll_insecticide_layout_sugarcaneOW);
        ll_fungicide_layout_sugarcaneOW = (LinearLayout)findViewById(R.id.ll_fungicide_layout_sugarcaneOW);
        ll_weedicide_layout_sugarcaneOW = (LinearLayout)findViewById(R.id.ll_weedicide_layout_sugarcaneOW);
        ll_fertilizer_layout_sugarcaneOW = (LinearLayout)findViewById(R.id.ll_fertilizer_layout_sugarcaneOW);
        irrigation_layout_sugarcaneOW = (RelativeLayout) findViewById(R.id.irrigation_layout_sugarcaneOW);

        //Button
        btn_submit_sugarcaneOW_pheromone = (Button)findViewById(R.id.btn_submit_sugarcaneOW_pheromone);
        //btn_save_continue_chickpeaP = (Button)findViewById(R.id.btn_save_continue_chickpeaP);

    }

    private void setListners() {

        insecticide_radio_group_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.insecticide_sugarcaneOW_yes:
                        insecticide_sugarcaneOW_yes.setChecked(true);
                        ll_insecticide_layout_sugarcaneOW.setVisibility(View.VISIBLE);
                        insecticide = insecticide_sugarcaneOW_yes.getText().toString();
                        break;

                    case R.id.insecticide_sugarcaneOW_no:
                        insecticide_sugarcaneOW_no.setChecked(true);
                        ll_insecticide_layout_sugarcaneOW.setVisibility(View.GONE);
                        insecticide = insecticide_sugarcaneOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_insecticide_sugarcaneOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                insecticide_tech_name = sp_technicalname_insecticide_sugarcaneOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        fungicide_radio_group_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fungicide_sugarcaneOW_yes:
                        fungicide_sugarcaneOW_yes.setChecked(true);
                        ll_fungicide_layout_sugarcaneOW.setVisibility(View.VISIBLE);
                        fungicide = fungicide_sugarcaneOW_yes.getText().toString();
                        break;

                    case R.id.fungicide_sugarcaneOW_no:
                        fungicide_sugarcaneOW_no.setChecked(true);
                        ll_fungicide_layout_sugarcaneOW.setVisibility(View.GONE);
                        fungicide = fungicide_sugarcaneOW_no.getText().toString();
                        break;
                }
            }
        });

        weedicide_radio_group_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.weedicide_sugarcaneOW_yes:
                        weedicide_sugarcaneOW_yes.setChecked(true);
                        ll_weedicide_layout_sugarcaneOW.setVisibility(View.VISIBLE);
                        weedicide = weedicide_sugarcaneOW_yes.getText().toString();
                        break;

                    case R.id.weedicide_sugarcaneOW_no:
                        weedicide_sugarcaneOW_no.setChecked(true);
                        ll_weedicide_layout_sugarcaneOW.setVisibility(View.GONE);
                        weedicide = weedicide_sugarcaneOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_fungicide_sugarcaneOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                fungicide_tech_name = sp_technicalname_fungicide_sugarcaneOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fertilizer_radio_group_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fertilizer_sugarcaneOW_yes:
                        fertilizer_sugarcaneOW_yes.setChecked(true);
                        ll_fertilizer_layout_sugarcaneOW.setVisibility(View.VISIBLE);
                        fertilizer = fertilizer_sugarcaneOW_yes.getText().toString();
                        break;

                    case R.id.fertilizer_sugarcaneOW_no:
                        fertilizer_sugarcaneOW_no.setChecked(true);
                        ll_fertilizer_layout_sugarcaneOW.setVisibility(View.GONE);
                        fertilizer = fertilizer_sugarcaneOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_weedicide_technicalname_sugarcaneOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                weedicide_tech_name = sp_weedicide_technicalname_sugarcaneOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        radio_group_intercultural_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.weeding_sugarcaneOW_rb:
                        weeding_sugarcaneOW_rb.setChecked(true);
                        intercultural = weeding_sugarcaneOW_rb.getText().toString();
                        break;

                    case R.id.hoeing_sugarcaneOW_rb:
                        hoeing_sugarcaneOW_rb.setChecked(true);
                        intercultural = hoeing_sugarcaneOW_rb.getText().toString();
                        break;

                    case R.id.detopping_sugarcaneOW_rb:
                        detopping_sugarcaneOW_rb.setChecked(true);
                        intercultural = detopping_sugarcaneOW_rb.getText().toString();
                        break;

                    case R.id.none_sugarcaneOW_rb:
                        none_sugarcaneOW_rb.setChecked(true);
                        intercultural = none_sugarcaneOW_rb.getText().toString();
                        break;
                }
            }
        });

        radio_group_irrigation_field_sugarcaneOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.irrigation_sugarcaneOW_yes:
                        irrigation_sugarcaneOW_yes.setChecked(true);
                        irrigation_layout_sugarcaneOW.setVisibility(View.VISIBLE);
                        irrigation = irrigation_sugarcaneOW_yes.getText().toString();
                        break;

                    case R.id.irrigation_sugarcaneOW_no:
                        irrigation_sugarcaneOW_no.setChecked(true);
                        irrigation_layout_sugarcaneOW.setVisibility(View.GONE);
                        irrigation = irrigation_sugarcaneOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_irrigation_given_sugarcaneOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                irrigation_name = sp_irrigation_given_sugarcaneOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /*pest_sugarcaneOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });*/

        crop_growth_sugarcaneOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(SugarcaneOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }
            }
        });

        btn_submit_sugarcaneOW_pheromone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sugarcaneOW_save_service();
            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            /*if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else*/ if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            //photoFile1 = null;
            photoFile2 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

       /*if(type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pest_sugarcaneOW_photo.getWidth(), pest_sugarcaneOW_photo.getHeight())
                                    .centerCrop()
                                    .into(pest_sugarcaneOW_photo);

                            uploadImage1OnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else*/ if(type.equalsIgnoreCase("2")) {

            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(crop_growth_sugarcaneOW_photo.getWidth(), crop_growth_sugarcaneOW_photo.getHeight())
                                    .centerCrop()
                                    .into(crop_growth_sugarcaneOW_photo);

                            uploadImage2OnServer(imagePath2);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /*private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_sugarcaneOW_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "1");

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_sugarcane_ls_save_image(partBody, params);
            api.postRequest(responseCall, this, 1);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

    private void uploadImage2OnServer(String imagePath2) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath2);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
           // params.put("plant_id", String.valueOf(crop_sugarcaneOW_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "2");
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_sugarcane_ls_save_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(SugarcaneOtherWorkActivity.this,SugarcaneGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void sugarcaneOW_save_service() {

        if (insecticide.isEmpty()) {
            Toast.makeText(this, "Select insecticide", Toast.LENGTH_SHORT).show();
        } else if (fungicide.isEmpty()) {
            Toast.makeText(this, "Select fungicide", Toast.LENGTH_SHORT).show();
        } else if (weedicide.isEmpty()) {
            Toast.makeText(this, "Select weedicide", Toast.LENGTH_SHORT).show();
        } else if (fertilizer.isEmpty()) {
            Toast.makeText(this, "Select fertilizer", Toast.LENGTH_SHORT).show();
        } else if (intercultural.isEmpty()) {
            Toast.makeText(this, "Select intercultural operations", Toast.LENGTH_SHORT).show();
        } else if (irrigation.isEmpty()) {
            Toast.makeText(this, "Select irrigation", Toast.LENGTH_SHORT).show();
        }/* else if (photoFile1 == null) {
            Toast.makeText(this, "Click pest/disease photo", Toast.LENGTH_SHORT).show();
        }*/ else if (photoFile2 == null) {
            Toast.makeText(this, "Click crop growth photo", Toast.LENGTH_SHORT).show();
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("last_id", "1");
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("pher_trap1_sc", pher_trap1);
                param.put("pher_trap2_sc", pher_trap2);
                param.put("tn_insect_sc", tradename_insecticide_sugarcaneOW.getText().toString().trim());
                param.put("tn_fungi_sc", tradename_fungicide_sugarcaneOW.getText().toString().trim());
                param.put("tn_weed_sc", tradename_weedicide_sugarcaneOW.getText().toString().trim());
                param.put("quantity_insect_sc", quantity_used_acre_insecticide_sugarcaneOW.getText().toString().trim());
                param.put("quantity_fungi_sc", quantity_used_acre_fungicide_sugarcaneOW.getText().toString().trim());
                param.put("quantity_weed_sc", quantity_used_acre_weedicide_sugarcaneOW.getText().toString().trim());
                param.put("fert_n_sc", fertilizer_sugarcaneOW_N.getText().toString().trim());
                param.put("fert_p_sc", fertilizer_sugarcaneOW_P.getText().toString().trim());
                param.put("fert_k_sc", fertilizer_sugarcaneOW_K.getText().toString().trim());
                param.put("fertname_sc", fertilizername_sugarcaneOW.getText().toString().trim());
                param.put("quantity_fert_sc", quantity_used_acre_fertilizer_sugarcaneOW.getText().toString().trim());
                param.put("techn_insect_sc", insecticide_tech_name);
                param.put("techn_fungi_sc", fungicide_tech_name);
                param.put("techn_weed_sc", weedicide_tech_name);
                param.put("irrigation_sc", irrigation_name);
                param.put("insect_rb_sc", insecticide);
                param.put("fungi_rb_sc", fungicide);
                param.put("weed_rb_sc", weedicide);
                param.put("fert_rb_sc", fertilizer);
                param.put("inter_rb_sc", intercultural);
                param.put("irrigation_rb_sc", irrigation);
                param.put("pher_image1_sc", pher_trap1_photo);
                param.put("pher_image2_sc", pher_trap2_photo);
                param.put("pest_image_sc", "1");
                param.put("crop_image_sc", image_2_file_name);
            } catch (Exception e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.crop_sugarcane_last_step_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null) {

            try {

               /* if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");

                        }
                    }
                }*/

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_2_file_name = data.getString("file_name");
                        }
                    }
                }

                /*if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_3_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_4_file_name = data.getString("file_name");
                        }
                    }
                }*/

                if(i == 5){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")){
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Sugarcane Other Works Completed")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
