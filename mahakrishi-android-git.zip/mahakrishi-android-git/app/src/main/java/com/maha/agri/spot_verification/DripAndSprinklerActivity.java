package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.PhyVeriCatAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class DripAndSprinklerActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView phy_veri_cat_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String component_id = "",form_id_str = "", scheme_tile_form_name = "", farmer_details = "";
    private int district_id = 0,taluka_id = 0,village_id = 0, form_id = 0, position = 0,scheme_id = 0;
    private JSONArray form_list  = new JSONArray();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drip_and_sprinkler);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Physical Verification");
        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        village_id = intent.getIntExtra("village_id", 0);
        component_id = intent.getStringExtra("component_id");
        farmer_details = intent.getStringExtra("farmer_details");
        position = intent.getIntExtra("position",0);
        scheme_id = intent.getIntExtra("scheme_id",0);

        preferenceManager = new PreferenceManager(DripAndSprinklerActivity.this);
        sharedPref = new SharedPref(DripAndSprinklerActivity.this);
        phy_veri_cat_rv = (RecyclerView) findViewById(R.id.phy_veri_category_rv);
        phy_veri_cat_rv.setLayoutManager(new GridLayoutManager(this, 2));
        phy_veri_cat_rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        phy_veri_form_list();
        click_listner();

    }

    private void click_listner(){
        phy_veri_cat_rv.addOnItemTouchListener(new PhyVeriCatAdapter.RecyclerTouchListener(this, phy_veri_cat_rv, new PhyVeriCatAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                JSONObject form_json_object = null;
                try {
                    form_json_object = form_list.getJSONObject(position);
                    //scheme_tile_form_name = form_json_object.getString("scheme_tile_form_name");
                    form_id_str = form_json_object.getString("id");
                    switch (form_id_str) {

                        case "1":
                            Intent int_1 = new Intent(DripAndSprinklerActivity.this, FarmerMechanizationActivity.class);
                            int_1.putExtra("district_id", district_id);
                            int_1.putExtra("taluka_id", taluka_id);
                            int_1.putExtra("village_id", village_id);
                            int_1.putExtra("farmer_details",farmer_details);
                            int_1.putExtra("position",position);
                            int_1.putExtra("scheme_title_id",component_id);
                            DripAndSprinklerActivity.this.startActivity(int_1);
                            break;

                        case "2":
                            Intent int_2 = new Intent(DripAndSprinklerActivity.this, CustomerHiringCenterActivity.class);
                            int_2.putExtra("district_id", district_id);
                            int_2.putExtra("taluka_id", taluka_id);
                            int_2.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_2);
                            break;

                        case "3":
                            Intent int_3 = new Intent(DripAndSprinklerActivity.this, DripFormActivity.class);
                            int_3.putExtra("district_id", district_id);
                            int_3.putExtra("taluka_id", taluka_id);
                            int_3.putExtra("village_id", village_id);
                            int_3.putExtra("form_id", "3");
                            int_3.putExtra("farmer_details",farmer_details);
                            int_3.putExtra("position",position);
                            int_3.putExtra("scheme_id",scheme_id);
                            DripAndSprinklerActivity.this.startActivity(int_3);
                            break;

                        case "4":
                            Intent int_4 = new Intent(DripAndSprinklerActivity.this, SprinklerActivity.class);
                            int_4.putExtra("district_id", district_id);
                            int_4.putExtra("taluka_id", taluka_id);
                            int_4.putExtra("village_id", village_id);
                            int_4.putExtra("form_id", "4");
                            int_4.putExtra("farmer_details",farmer_details);
                            int_4.putExtra("position",position);
                            int_4.putExtra("scheme_id",scheme_id);
                            DripAndSprinklerActivity.this.startActivity(int_4);
                            break;

                        case "5":
                            Intent int_5 = new Intent(DripAndSprinklerActivity.this, MBCommunityFarmPondActivity.class);
                            int_5.putExtra("district_id", district_id);
                            int_5.putExtra("taluka_id", taluka_id);
                            int_5.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_5);
                            break;

                        case "6":
                            Intent int_6 = new Intent(DripAndSprinklerActivity.this, PipesActivity.class);
                            int_6.putExtra("district_id", district_id);
                            int_6.putExtra("taluka_id", taluka_id);
                            int_6.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_6);
                            break;

                        case "7":
                            Intent int_7 = new Intent(DripAndSprinklerActivity.this, PumpsetActivity.class);
                            int_7.putExtra("district_id", district_id);
                            int_7.putExtra("taluka_id", taluka_id);
                            int_7.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_7);
                            break;

                        case "8":
                            Intent int_8 = new Intent(DripAndSprinklerActivity.this, GreenHouseActivity.class);
                            int_8.putExtra("district_id", district_id);
                            int_8.putExtra("taluka_id", taluka_id);
                            int_8.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_8);
                            break;

                        case "9":
                            Intent int_9 = new Intent(DripAndSprinklerActivity.this, ProtectiveCultivationActivity.class);
                            int_9.putExtra("district_id", district_id);
                            int_9.putExtra("taluka_id", taluka_id);
                            int_9.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_9);
                            break;

                        case "10":
                            Intent int_10 = new Intent(DripAndSprinklerActivity.this, OnionStorageFirstPhysicalActivity1.class);
                            int_10.putExtra("district_id", district_id);
                            int_10.putExtra("taluka_id", taluka_id);
                            int_10.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_10);
                            break;

                        case "11":
                            Intent int_11 = new Intent(DripAndSprinklerActivity.this, PipesActivity.class);
                            int_11.putExtra("district_id", district_id);
                            int_11.putExtra("taluka_id", taluka_id);
                            int_11.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_11);
                            break;

                        case "12":
                            Intent int_12 = new Intent(DripAndSprinklerActivity.this, PumpsetActivity.class);
                            int_12.putExtra("district_id", district_id);
                            int_12.putExtra("taluka_id", taluka_id);
                            int_12.putExtra("village_id", village_id);
                            DripAndSprinklerActivity.this.startActivity(int_12);
                            break;

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }

    private void phy_veri_form_list(){
        JSONObject param = new JSONObject();
        try {
            param.put("scheme_tile_id",Integer.valueOf(component_id));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_form_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            try {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            form_list = jsonObject.getJSONArray("data");
                            phy_veri_cat_rv.setAdapter(new PhyVeriCatAdapter(this, form_list));
                            for (int j = 0; j <= form_list.length(); j++) {
                                JSONObject form_json_object = form_list.getJSONObject(j);
                                scheme_tile_form_name = form_json_object.getString("scheme_tile_form_name");
                                form_id_str = form_json_object.getString("id");
                                form_id = Integer.valueOf(form_id_str);
                            }
                        }
                    }

                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
