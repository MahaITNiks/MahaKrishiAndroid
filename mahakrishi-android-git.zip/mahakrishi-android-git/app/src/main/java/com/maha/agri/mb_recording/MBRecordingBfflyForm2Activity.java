package com.maha.agri.mb_recording;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MBRecordingBfflyForm2Activity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private TextView mb_bffly2_year;
    private RadioGroup mb_bffly2_type_rg;
    private RadioButton mb_bffly2_type_sap,mb_bffly2_type_graft;
    private Button mb_bffly2_next;
    private JSONArray year_list;
    private PreferenceManager preferenceManager;
    private String year="",type="0",farmer_id="",district_id="",taluka_id="",village_id="",response="";
    private int year_id=0;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_b_recording_bffly_form2);
        getSupportActionBar().setTitle("MB Recording BFFLY Form 2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(MBRecordingBfflyForm2Activity.this);
        Intent intent = getIntent();
        farmer_id = intent.getStringExtra("farmer_id");
        district_id = intent.getStringExtra("district_id");
        taluka_id = intent.getStringExtra("taluka_id");
        village_id = intent.getStringExtra("village_id");

        ids();
        functions();
    }

    private void ids(){
        mb_bffly2_year = (TextView) findViewById(R.id.mb_bffly2_year);
        mb_bffly2_type_rg = (RadioGroup) findViewById(R.id.mb_bffly2_type_rg);
        mb_bffly2_type_sap = (RadioButton) findViewById(R.id.mb_bffly2_type_sap);
        mb_bffly2_type_graft = (RadioButton) findViewById(R.id.mb_bffly2_type_graft);
        mb_bffly2_next = (Button) findViewById(R.id.mb_bffly2_next);
        mb_bffly2_next.setEnabled(true);

        year_list = new JSONArray();
        year_list_service();
    }

    private void functions(){
        mb_bffly2_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(year_list,1,"Select Year","year","id",MBRecordingBfflyForm2Activity.this,MBRecordingBfflyForm2Activity.this);
            }
        });

        mb_bffly2_type_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mb_bffly2_type_sap:
                        mb_bffly2_type_sap.setChecked(true);
                        type = "1";
                        break;

                    case R.id.mb_bffly2_type_graft:
                        mb_bffly2_type_graft.setChecked(true);
                        type = "2";
                        break;
                }
            }
        });

        mb_bffly2_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mb_bffly_form2_save_service();
            }
        });
    }

    private void year_list_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.mb_recording_bffly_years();
        api.postRequest(responseCall, this, 1);
    }

    private void mb_bffly_form2_save_service(){
        if(type.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select type of fruit plantation", Toast.LENGTH_SHORT).show();
        }else if(year_id == 0){
            Toast.makeText(getApplicationContext(), "Select year", Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("fruit_pl_rg", type);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mbrecording_bffly_form2_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    private void mb_bffly_form2_is_completed_service(){
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("year_selected", year);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.MB_RECORDING_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mbrecording_bffly_form_check_iscompleted(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 3);
        }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("MB Recording by BFFLY Form 2");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    if(year.equalsIgnoreCase("Year 1")){
                                        Intent intent = new Intent(MBRecordingBfflyForm2Activity.this,MBRecordingBfflyForm3Activity.class);
                                        intent.putExtra("type_sap_graft",type);
                                        intent.putExtra("farmer_id",farmer_id);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }else if(year.equalsIgnoreCase("Year 2")){
                                        Intent intent = new Intent(MBRecordingBfflyForm2Activity.this,MBRecordingBfflyForm4Activity.class);
                                        intent.putExtra("farmer_id",farmer_id);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }else if(year.equalsIgnoreCase("Year 3")){
                                        Intent intent = new Intent(MBRecordingBfflyForm2Activity.this,MBRecordingBfflyForm5Activity.class);
                                        intent.putExtra("farmer_id",farmer_id);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }else{

                                    }
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            response = jsonObject.getString("response");
                            if(response.equalsIgnoreCase("Valid")){
                                mb_bffly2_next.setEnabled(true);
                            }else if(response.equalsIgnoreCase("Not Valid")){
                                mb_bffly2_year.setText("Select");
                                mb_bffly2_next.setEnabled(false);
                                Toast.makeText(this,"Please select correct year",Toast.LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Year 2 Not Filled")){
                                mb_bffly2_next.setEnabled(false);
                                mb_bffly2_year.setText("Select");
                                Toast.makeText(this,"Year 2 is not filled",Toast.LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Data filled for Year 1")){
                                mb_bffly2_next.setEnabled(false);
                                mb_bffly2_year.setText("Select");
                                Toast.makeText(this,"Data is filled for Year 1",Toast.LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Data filled for Year 2")){
                                mb_bffly2_next.setEnabled(false);
                                mb_bffly2_year.setText("Select");
                                Toast.makeText(this,"Data is filled for Year 2",Toast.LENGTH_SHORT).show();
                            }else if(response.equalsIgnoreCase("Data filled for Year 3")){
                                mb_bffly2_next.setEnabled(false);
                                Toast.makeText(this,"Data is filled for Year 3",Toast.LENGTH_SHORT).show();
                                mb_bffly2_year.setText("Select");
                            }else{
                                mb_bffly2_next.setEnabled(false);
                            }
                        }
                    }
                }
            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            year_id = Integer.parseInt(s1);
            year = s;
            mb_bffly2_year.setText(year);
            mb_bffly_form2_is_completed_service();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
