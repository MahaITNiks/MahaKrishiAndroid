package com.maha.agri.farmer;

import android.content.Context;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerPunchnamaDetailsPagerAdapter extends PagerAdapter {
    private LayoutInflater layoutInflater;
    private JSONArray punchnama_details_based_crop_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    private EditText punchnama_history_year_edt,punchnama_history_district_edt,punchnama_history_taluka_edt,punchnama_history_village_edt,punchnama_history_edt_survey_no_group_no,
            punchnama_history_sheticha_prakar_edt,punchnama_history_hangam_edt,punchnama_history_pikvima_edt,punchnama_history_yojna_edt,punchnama_history_pikacha_prakar_edt,
            punchnama_history_pikache_naav_edt,lagwadi_ekkar_edt,lagwadi_guntha_edt,pikvima_ekkar_edt,pikvima_guntha_edt,andajeet_ekkar_edt,andajeet_guntha_edt,
            punchnama_history_nuksanicha_edt,punchnama_history_nuksanicha_karan_edt,punchnama_history_rogache_edt,punchnama_history_keedicha_naav_edt,punchnama_history_takkewari_edt,
            punchnama_hist_nuksanicha_dinaak_edt,punchnama_hist_nuksanicha_notice_dinaak_edt,punchnama_history_total_lagwadi,punchnama_history_total_pikvima,punchnama_history_total_baghadheet;


    private String year,district,taluka,village,gut_no,sheticha_prakar,hangam,pik_vima,yojna,pikache_prakar,pikache_naav,lagwadi_ekkar,lagwadi_guntha="0",pika_vima_ekkar,pik_vima_guntha="0",
            andajeet_ekkar,andajeet_guntha="0",nuksanicha_prakar,nuksanicha_karan,rogache_naav,keedache_naav,crop_insurance_name,nuksanicha_takkewari,nuksanicha_dinaak,nuksanicha_notice_dinaak,total_lagwadi
            ,total_pikvima,total_baghadeet;

    private LinearLayout farmer_panchnama_hist_rogache_naav_ll,farmer_panchnama_hist_keedicha_naav_ll,dept_punchnama_pik_vima_linear_layout,yojna_ll,panchnama_damage_reason_ll,farmer_panchnama_crop_type_ll;

    public FarmerPunchnamaDetailsPagerAdapter(PreferenceManager preferenceManager, JSONArray punchnama_details_based_crop_array_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.punchnama_details_based_crop_array_list = punchnama_details_based_crop_array_list;
        this.context = context;

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.farmer_punchnama_history_detail_single_item, container, false);
        try {
            jsonObject = punchnama_details_based_crop_array_list.getJSONObject(position);
            year = jsonObject.getString("year_name");
            district = jsonObject.getString("district_name");
            taluka = jsonObject.getString("taluka_name");
            village = jsonObject.getString("village_name");
            gut_no = jsonObject.getString("survey_no");
            sheticha_prakar = jsonObject.getString("farm_type_name");
            hangam = jsonObject.getString("season_name");
            pik_vima = jsonObject.getString("crop_insurance");

            yojna = jsonObject.getString("scheme_name_mr");
            pikache_prakar = jsonObject.getString("crop_type_name_mr");
            pikache_naav = jsonObject.getString("crop_name");
            lagwadi_ekkar = jsonObject.getString("area_under_crop_acre");
            lagwadi_guntha = jsonObject.getString("area_under_crop_guntha");
            pika_vima_ekkar = jsonObject.getString("insured_area_under_crop_acre");
            pik_vima_guntha = jsonObject.getString("insured_area_under_crop_guntha");
            andajeet_ekkar = jsonObject.getString("approxmate_area_acre");

            andajeet_guntha = jsonObject.getString("approxmate_area_guntha");
            nuksanicha_prakar = jsonObject.getString("damage_type_name_mr");
            nuksanicha_karan = jsonObject.getString("damage_reason_name");
            rogache_naav = jsonObject.getString("disease_name");
            keedache_naav = jsonObject.getString("pest_name");
            crop_insurance_name = jsonObject.getString("crop_insurance_name");
            nuksanicha_takkewari = jsonObject.getString("nuksani_per");
            nuksanicha_dinaak = jsonObject.getString("nuksani_date");
            //nuksanicha_notice_dinaak = jsonObject.getString("nuksani_notice_date");
            total_lagwadi = jsonObject.getString("total_lagwadi");
            total_pikvima = jsonObject.getString("total_pikvima");
            total_baghadeet = jsonObject.getString("total_baghadeet");

            punchnama_history_year_edt = (EditText) view.findViewById(R.id.punchnama_history_year_edt);
            punchnama_history_district_edt = (EditText) view.findViewById(R.id.punchnama_history_district_edt);
            punchnama_history_taluka_edt = (EditText) view.findViewById(R.id.punchnama_history_taluka_edt);
            punchnama_history_village_edt = (EditText) view.findViewById(R.id.punchnama_history_village_edt);
            punchnama_history_edt_survey_no_group_no = (EditText) view.findViewById(R.id.punchnama_history_edt_survey_no_group_no);
            punchnama_history_sheticha_prakar_edt = (EditText) view.findViewById(R.id.punchnama_history_sheticha_prakar_edt);
            punchnama_history_hangam_edt = (EditText) view.findViewById(R.id.punchnama_history_hangam_edt);
            punchnama_history_pikvima_edt = (EditText) view.findViewById(R.id.punchnama_history_pikvima_edt);
            punchnama_history_yojna_edt = (EditText) view.findViewById(R.id.punchnama_history_yojna_edt);
            punchnama_history_pikacha_prakar_edt = (EditText) view.findViewById(R.id.punchnama_history_pikacha_prakar_edt);
            punchnama_history_pikache_naav_edt = (EditText) view.findViewById(R.id.punchnama_history_pikache_naav_edt);
            lagwadi_ekkar_edt = (EditText) view.findViewById(R.id.punchnama_history_lagwadi_ekkar_edt);
            lagwadi_guntha_edt = (EditText) view.findViewById(R.id.punchnama_history_lagwadi_guntha_edt);
            pikvima_ekkar_edt = (EditText) view.findViewById(R.id.punchnama_history_pikvima_ekkar_edt);
            pikvima_guntha_edt = (EditText) view.findViewById(R.id.punchnama_history_pikvima_guntha_edt);
            andajeet_ekkar_edt = (EditText) view.findViewById(R.id.punchnama_history_andajeet_ekkar_edt);
            andajeet_guntha_edt = (EditText) view.findViewById(R.id.punchnama_history_andajeet_guntha_edt);
            punchnama_history_nuksanicha_edt = (EditText) view.findViewById(R.id.punchnama_history_nuksanicha_edt);
            punchnama_history_nuksanicha_karan_edt = (EditText) view.findViewById(R.id.punchnama_history_nuksanicha_karan_edt);
            punchnama_history_rogache_edt = (EditText) view.findViewById(R.id.punchnama_history_rogache_naav_edt);
            punchnama_history_keedicha_naav_edt = (EditText) view.findViewById(R.id.farmer_panchnama_hist_keedicha_naav_edt);
            punchnama_history_takkewari_edt = (EditText)view.findViewById(R.id.punchnama_history_takkewari_edt);
            punchnama_hist_nuksanicha_dinaak_edt= (EditText)view.findViewById(R.id.punchnama_hist_nuksanicha_dinaak_edt);
            //punchnama_hist_nuksanicha_notice_dinaak_edt= (EditText)view.findViewById(R.id.punchnama_hist_nuksanicha_notice_dinaak_edt);
            punchnama_history_total_lagwadi = (EditText)view.findViewById(R.id.punchnama_history_total_lagwadi);
            punchnama_history_total_pikvima = (EditText)view.findViewById(R.id.punchnama_history_total_pikvima);
            punchnama_history_total_baghadheet = (EditText)view.findViewById(R.id.punchnama_history_total_baghadheet);
            farmer_panchnama_hist_rogache_naav_ll = (LinearLayout)view.findViewById(R.id.farmer_panchnama_hist_rogache_naav_ll);
            farmer_panchnama_hist_keedicha_naav_ll = (LinearLayout)view.findViewById(R.id.farmer_panchnama_hist_keedicha_naav_ll);
            dept_punchnama_pik_vima_linear_layout = (LinearLayout)view.findViewById(R.id.dept_punchnama_pik_vima_linear_layout);
            yojna_ll = (LinearLayout)view.findViewById(R.id.yojna_ll);
            panchnama_damage_reason_ll = (LinearLayout)view.findViewById(R.id.panchnama_damage_reason_ll);
            farmer_panchnama_crop_type_ll = (LinearLayout)view.findViewById(R.id.farmer_panchnama_crop_type_ll);

            punchnama_history_year_edt.setText(year);
            punchnama_history_district_edt.setText(district);
            punchnama_history_taluka_edt.setText(taluka);
            punchnama_history_village_edt.setText(village);
            punchnama_history_edt_survey_no_group_no.setText(gut_no);
            punchnama_history_hangam_edt.setText(hangam);
            punchnama_history_pikvima_edt.setText(crop_insurance_name);
            punchnama_history_sheticha_prakar_edt.setText(sheticha_prakar);
            punchnama_history_pikache_naav_edt.setText(pikache_naav);
            lagwadi_ekkar_edt.setText(lagwadi_ekkar);
            lagwadi_guntha_edt.setText(lagwadi_guntha);
            pikvima_ekkar_edt.setText(pika_vima_ekkar);
            pikvima_guntha_edt.setText(pik_vima_guntha);
            andajeet_ekkar_edt.setText(andajeet_ekkar);
            andajeet_guntha_edt.setText(andajeet_guntha);
            punchnama_history_nuksanicha_edt.setText(nuksanicha_prakar);
            punchnama_history_takkewari_edt.setText(nuksanicha_takkewari);
            punchnama_hist_nuksanicha_dinaak_edt.setText(nuksanicha_dinaak);
            //punchnama_hist_nuksanicha_notice_dinaak_edt.setText(nuksanicha_notice_dinaak);
            punchnama_history_total_lagwadi.setText(total_lagwadi);
            punchnama_history_total_pikvima.setText(total_pikvima);
            punchnama_history_total_baghadheet.setText(total_baghadeet);

            if(!total_pikvima.equalsIgnoreCase("")){
                if(!total_pikvima.equalsIgnoreCase("0")) {
                    dept_punchnama_pik_vima_linear_layout.setVisibility(View.VISIBLE);
                }else{
                    dept_punchnama_pik_vima_linear_layout.setVisibility(View.GONE);
                }
            }

            if(!yojna.equalsIgnoreCase("null")){
                yojna_ll.setVisibility(View.VISIBLE);
                punchnama_history_yojna_edt.setText(yojna);
            }

            if(!nuksanicha_karan.equalsIgnoreCase("")){
                panchnama_damage_reason_ll.setVisibility(View.VISIBLE);
                punchnama_history_nuksanicha_karan_edt.setText(nuksanicha_karan);
            }

            if(!rogache_naav.equalsIgnoreCase("")){
                farmer_panchnama_hist_rogache_naav_ll.setVisibility(View.VISIBLE);
                punchnama_history_rogache_edt.setText(rogache_naav);
            }

            if(!keedache_naav.equalsIgnoreCase("")){
                farmer_panchnama_hist_keedicha_naav_ll.setVisibility(View.VISIBLE);
                punchnama_history_keedicha_naav_edt.setText(keedache_naav);
            }

            if(pikache_prakar.equalsIgnoreCase("null")){
                farmer_panchnama_crop_type_ll.setVisibility(View.GONE);
            }else{
                farmer_panchnama_crop_type_ll.setVisibility(View.VISIBLE);
                punchnama_history_pikacha_prakar_edt.setText(pikache_prakar);
            }
            /*Picasso.get()
                    .load(filename)
                    .into(farmer_cropsap_history_details_iv);*/



        } catch (JSONException e) {
            e.printStackTrace();
        }

        container.addView(view);

        return view;
    }

    @Override
    public int getCount() {
        return punchnama_details_based_crop_array_list.length();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((View) obj);
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
