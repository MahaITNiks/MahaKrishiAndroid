package com.maha.agri.ffs.adaptor;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.widget.UIToastMessage;

public class D_F_PreShowingVisitListAdapter extends RecyclerView.Adapter<D_F_PreShowingVisitListAdapter.ViewHolder> {


    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;


    public D_F_PreShowingVisitListAdapter(Context mContext, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
    }

    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.list_pre_showing_visit, viewGroup, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        try {
            viewHolder.onBind(mDataArray.getJSONObject(i), listener);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView visitTitleTV;
        private ImageView demo_dropImg;

        public ViewHolder(View itemView) {
            super(itemView);
            visitTitleTV = itemView.findViewById(R.id.visitTitleTV);
            demo_dropImg = itemView.findViewById(R.id.demo_dropImg);
        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            try {
                visitTitleTV.setText(jsonObject.getString("pre_visit_days"));

                JSONArray jsonArray = jsonObject.getJSONArray("activities");
                boolean visitDone = false;
                if (jsonArray.length()>0){
                    for (int a=0; a<jsonArray.length();a++){
                        JSONObject actJSON = jsonArray.getJSONObject(a);
                        String isCompleted = actJSON.getString("is_submitted");
                        if (isCompleted.equalsIgnoreCase("0") || isCompleted.equalsIgnoreCase("null")){
                            visitDone = false;
                            break;
                        }else {
                            visitDone = true;
                        }
                    }
                }

                if (visitDone){
                    demo_dropImg.setBackground(mContext.getResources().getDrawable(R.drawable.ic_right_check));
                }else {
                    demo_dropImg.setBackground(mContext.getResources().getDrawable(R.drawable.ic_arrow_drop_down_black_24dp));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    try {
                        JSONArray jsonArray = jsonObject.getJSONArray("activities");
                        boolean visitDone = false;
                        if (jsonArray.length()>0){
                            for (int a=0; a<jsonArray.length();a++){
                                JSONObject actJSON = jsonArray.getJSONObject(a);
                                String isCompleted = actJSON.getString("is_submitted");
                                if (isCompleted.equalsIgnoreCase("0") || isCompleted.equalsIgnoreCase("null")){
                                    visitDone = false;
                                    break;
                                }else {
                                    visitDone = true;
                                }
                            }
                        }
                        if (!visitDone){
                            listener.onMultiRecyclerViewItemClick(1, jsonObject);
                        }else {
                            UIToastMessage.show(mContext,"This visit got completed. Please Try other one");
                        }

                    }catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}


