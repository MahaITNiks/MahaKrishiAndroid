package com.maha.agri.panchnama;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.farmer.FarmerMagazineAdapter;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateFinalReportActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView final_report_rv;
    private JSONArray final_report_listing,final_report_pdf_list,village_list,farm_type_list;
    private int[] task_manager_backy = {R.drawable.dash_assigned_villages,R.drawable.dash_attedance_approved,R.drawable.dash_sync_attendance};
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String  farmer_id,village_id="0",farm_type_id="0",farm_type_name,village_name,data;
    private DBHandler dbHandler;
    HashMap<Integer,String> selected_farmer_id = new HashMap<>();
    HashMap<Integer,String> farm_type_map = new HashMap<>();
    HashMap<Integer,String> village_map = new HashMap<>();

    //Filtering
    private SearchableSpinner generate_final_report_sp_village,generate_final_report_sp_farm_type;
    ArrayList<String> VillageName;
    ArrayList<String> FarmTypeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_final_report);

        getSupportActionBar().setTitle("Final Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(GenerateFinalReportActivity.this);
        sharedPref = new SharedPref(GenerateFinalReportActivity.this);

        dbHandler = new DBHandler(this);

        IdCalling();
        default_Config();
        if(isNetworkAvailable()){
            Farm_type_Service();
            getVillageList();
            getfinalreport();
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        generate_final_report_sp_village = (SearchableSpinner)findViewById(R.id.generate_final_report_sp_village);
        generate_final_report_sp_farm_type = (SearchableSpinner)findViewById(R.id.generate_final_report_sp_farm_type);
        final_report_rv = (RecyclerView)findViewById(R.id.final_report_recyclerview);
        final_report_rv.setLayoutManager(new LinearLayoutManager(this));

    }

    private void default_Config() {

        VillageName = new ArrayList<>();
        FarmTypeName = new ArrayList<>();

        generate_final_report_sp_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = village_map.get(generate_final_report_sp_village.getSelectedItemPosition());
                getfinalreport();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        generate_final_report_sp_farm_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                farm_type_id = farm_type_map.get(generate_final_report_sp_farm_type.getSelectedItemPosition());
                getfinalreport();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final_report_rv.addOnItemTouchListener(new FarmerMagazineAdapter.RecyclerTouchListener(this, final_report_rv, new FarmerMagazineAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                farmer_id = selected_farmer_id.get(position);
                getfinalreportPDF();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }

    private void getVillageList(){
        data = AppSettings.getInstance().getValue(GenerateFinalReportActivity.this, ApConstants.kLOGIN_DATA,"");

        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
            VillageName = new ArrayList<>();
            final int villagelist_number = village_list.length();
            for (int j = 0; j < villagelist_number; j++) {
                JSONObject village_json_object = null;
                try {
                    village_json_object = village_list.getJSONObject(j);
                    village_id = village_json_object.getString("village_id");
                    village_name = village_json_object.getString("village_name");
                    VillageName.add(village_name);
                    village_map.put(j, village_id);
                    village_id = "0";
                    generate_final_report_sp_village.setAdapter(new ArrayAdapter<String>(GenerateFinalReportActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void getfinalreport() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("village_id",village_id);
            param.put("farm_type_id",farm_type_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_panchnama_final_report_list(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    private void getfinalreportPDF() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("farmer_id",farmer_id);
            param.put("village_id",village_id);
            param.put("farm_type_id",farm_type_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.REPORT_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_panchnama_final_report_pdf(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void Farm_type_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_punchnama_farm_type_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Toast.makeText(GenerateFinalReportActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                            final_report_listing = jsonObject.getJSONArray("data");
                            for(int j = 0;j < final_report_listing.length();j++){
                                JSONObject final_report_pdf_json_obj = final_report_listing.getJSONObject(j);
                                farmer_id = final_report_pdf_json_obj.getString("farmer_id");
                                selected_farmer_id.put(j, farmer_id);
                            }
                            FinalReportAdapter finalReportAdapter = new FinalReportAdapter(preferenceManager,final_report_listing,task_manager_backy,this);
                            final_report_rv.setAdapter(finalReportAdapter);
                            finalReportAdapter.notifyDataSetChanged();


                        }
                    }else {
                        Toast.makeText(GenerateFinalReportActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                        final_report_rv.setAdapter(null);
                    }
                }else {}

                if (i == 2) {

                    try {
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                    JSONObject data_json_object = jsonObject.getJSONObject("data");
                                    String pdf_file = data_json_object.getString("file_path");
                                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(pdf_file));
                                    startActivity(browserIntent);
                                }
                            }
                    } catch (JSONException ex) {
                        ex.printStackTrace();
                    }
                } else {
                        //UIToastMessage.show(this, jsonObject.getString("response"));
                    }          //Farm Type
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farm_type_list = jsonObject.getJSONArray("data");
                            final int numberOfItemsInResp = farm_type_list.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject farm_type_json_object = farm_type_list.getJSONObject(j);
                                farm_type_id = farm_type_json_object.getString("id");
                                farm_type_name = farm_type_json_object.getString("name");
                                FarmTypeName.add(farm_type_name);
                                farm_type_map.put(j, farm_type_id);
                                farm_type_id = "0";

                            }

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(GenerateFinalReportActivity.this, android.R.layout.simple_spinner_dropdown_item, FarmTypeName);
                        generate_final_report_sp_farm_type.setAdapter(adapter);
                        getfinalreport();
                    }

                   }

                }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
