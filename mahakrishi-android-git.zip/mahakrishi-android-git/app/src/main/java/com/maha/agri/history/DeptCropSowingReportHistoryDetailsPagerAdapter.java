package com.maha.agri.history;

import android.content.Context;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DeptCropSowingReportHistoryDetailsPagerAdapter extends PagerAdapter {

    private LayoutInflater layoutInflater;
    private JSONArray dept_swoing_report_details_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    private String districtname,talukaname,villagename,seasonname,circle_name,sajja_name,crop_type_name,crop_sub_type_name,crop_sown_name,area_in_last_week,area_in_current_week,finance_year;

    private TextView sowing_report_financial_year_tv,sowing_report_district_tv,sowing_report_taluka_tv,sowing_report_circle_tv,sowing_report_sajja_tv,sowing_report_affected_village_tv,sowing_report_season_tv,sowing_report_crop_type_tv,
            sowing_report_crop_sub_type_tv,sowing_report_crop_sown_tv,sowing_report_area_in_last_week_tv,sowing_report_area_in_current_week_tv,sowing_report_last_year_sown_area_tv;

    private LinearLayout horti_crop_type_ll;

    public DeptCropSowingReportHistoryDetailsPagerAdapter(PreferenceManager preferenceManager, JSONArray dept_swoing_report_details_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.dept_swoing_report_details_list = dept_swoing_report_details_list;
        this.context = context;

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.dept_sowing_report_details_single_item, container, false);
        try {
            jsonObject = dept_swoing_report_details_list.getJSONObject(position);

            finance_year = jsonObject.getString("finance_year");
            districtname = jsonObject.getString("district_name");
            talukaname = jsonObject.getString("taluka_name");
            seasonname = jsonObject.getString("season_name");
            //circle_name = jsonObject.getString("circle_name");
            sajja_name = jsonObject.getString("sajja_name");
            villagename = jsonObject.getString("village_name");
            crop_type_name = jsonObject.getString("crop_type_name");
            crop_sub_type_name = jsonObject.getString("crop_sub_type_name");
            crop_sown_name = jsonObject.getString("crop_sown_name");
            area_in_last_week = jsonObject.getString("area_in_last_week");
            area_in_current_week = jsonObject.getString("area_in_current_week");

            sowing_report_financial_year_tv = (TextView)view.findViewById(R.id.sowing_report_financial_year_tv);
            sowing_report_district_tv = (TextView) view.findViewById(R.id.sowing_report_district_tv);
            sowing_report_taluka_tv = (TextView)view. findViewById(R.id.sowing_report_taluka_tv);
            //sowing_report_circle_tv = (TextView)view.findViewById(R.id.sowing_report_circle_tv);
            sowing_report_sajja_tv = (TextView) view.findViewById(R.id.sowing_report_sajja_tv);
            sowing_report_affected_village_tv = (TextView)view. findViewById(R.id.sowing_report_affected_village_tv);
            sowing_report_season_tv = (TextView) view.findViewById(R.id.sowing_report_season_tv);
            sowing_report_crop_type_tv = (TextView) view.findViewById(R.id.sowing_report_crop_type_tv);
            sowing_report_crop_sub_type_tv = (TextView)view. findViewById(R.id.sowing_report_crop_sub_type_tv);
            sowing_report_crop_sown_tv = (TextView)view. findViewById(R.id.sowing_report_crop_sown_tv);
            sowing_report_area_in_last_week_tv = (TextView) view.findViewById(R.id.sowing_report_area_in_last_week_tv);
            sowing_report_area_in_current_week_tv = (TextView) view.findViewById(R.id.sowing_report_area_in_current_week_tv);
            //horti_crop_type_ll = (LinearLayout)view.findViewById(R.id.horti_crop_type_ll);

            sowing_report_financial_year_tv.setText(finance_year);
            sowing_report_district_tv.setText(districtname);
            sowing_report_taluka_tv.setText(talukaname);
            sowing_report_affected_village_tv.setText(villagename);
            //sowing_report_circle_tv.setText(circle_name);
            sowing_report_sajja_tv.setText(sajja_name);
            sowing_report_season_tv.setText(seasonname);
            sowing_report_crop_type_tv.setText(crop_type_name);
            sowing_report_crop_sub_type_tv.setText(crop_sub_type_name);
            sowing_report_crop_sown_tv.setText(crop_sown_name);
            sowing_report_area_in_current_week_tv.setText(area_in_current_week);
            sowing_report_area_in_last_week_tv.setText(area_in_last_week);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        container.addView(view);

        return view;
    }

    @Override
    public int getCount() {
        return dept_swoing_report_details_list.length();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((View) obj);
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
