package com.maha.agri.cropsowingreport;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;


public class ConsolidatedReportActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String horti_crop_id="";
    private String crop_type = "", crop_name = "";
    private JSONArray CropNameList;
    private SweetAlertDialog sweetAlertDialog;
    private TextView consolidated_report_crop_list_tv;
    private EditText consolidated_report_crop_variety,consolidated_report_zero_to_one_year_edt,consolidated_report_one_to_three_year_edt,consolidated_report_above_three_year_edt,
            consolidated_report_total_edt,csr_con_other_crop_edt;
    private ImageView consolidate_crop_image;
    private Button dept_consolidated_report_generate_btn,consolidated_report_add_more_btn;
    private int crop_id=0;

    private String activityID = "",imagePath,currentTime;
    private int divison_id = 0,district_id = 0,taluka_id = 0,sajja_id = 0, village_id = 0;
    private int crop_type_id,horti_type_id,season_id;
    private String zero_one_str = "", one_three_str = "", above_three_str = "", total_str = "",current_week="",last_week="",first_image_url="",image_name="";
    private int zero_one_int = 0,one_three_int = 0,above_three_int = 0,total_int = 0;

    private JSONArray multiple_crop_area_year = new JSONArray();
    private RecyclerView cr_add_more_rv;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private Transformation transformation;
    private LinearLayout csr_con_other_crop_ll;
    private AppLocationManager appLocationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consolidated_report);
        getSupportActionBar().setTitle("Consolidated Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(ConsolidatedReportActivity.this);
        sharedPref = new SharedPref(ConsolidatedReportActivity.this);
        crop_type = preferenceManager.getPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_CROP_TYPE_ID);
        horti_crop_id = preferenceManager.getPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_HORTI_ID);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();
        init();
        default_confiq();

        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_id = intent.getIntExtra("sajja_id",0);
        village_id = intent.getIntExtra("village_id",0);
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        current_week = intent.getStringExtra("current_week");
        last_week = intent.getStringExtra("last_week");
        crop_list(season_id,crop_type_id,horti_type_id);
    }

    private void init(){

        CropNameList = new JSONArray();
        consolidated_report_crop_list_tv = (TextView)findViewById(R.id.consolidated_report_crop_list_tv);
        consolidated_report_zero_to_one_year_edt = (EditText) findViewById(R.id.consolidated_report_zero_to_one_year_edt);
        consolidated_report_crop_variety = (EditText) findViewById(R.id.consolidated_report_crop_variety);
        consolidated_report_one_to_three_year_edt = (EditText) findViewById(R.id.consolidated_report_one_to_three_year_edt);
        consolidated_report_above_three_year_edt = (EditText) findViewById(R.id.consolidated_report_above_three_year_edt);
        consolidated_report_total_edt = (EditText) findViewById(R.id.consolidated_report_total_edt);
        csr_con_other_crop_edt = (EditText) findViewById(R.id.csr_con_other_crop_edt);
        csr_con_other_crop_ll = (LinearLayout)findViewById(R.id.csr_con_other_crop_ll);
        consolidated_report_total_edt.setEnabled(false);
        cr_add_more_rv = (RecyclerView) findViewById(R.id.cr_add_more_rv);
        consolidate_crop_image = (ImageView) findViewById(R.id.consolidate_crop_image);
        consolidated_report_add_more_btn = (Button) findViewById(R.id.consolidated_report_add_more_btn);
        dept_consolidated_report_generate_btn = (Button) findViewById(R.id.dept_consolidated_report_generate_btn);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
    }

    private void default_confiq(){

        consolidated_report_crop_list_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CropNameList.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(CropNameList, 1, "Select Crop", "crop_english", "id", ConsolidatedReportActivity.this, ConsolidatedReportActivity.this);
                }else{
                    crop_list(season_id,crop_type_id,horti_type_id);
                }
            }
        });

        consolidated_report_zero_to_one_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        consolidated_report_one_to_three_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        consolidated_report_above_three_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        consolidated_report_add_more_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(crop_id != 0 && !consolidated_report_crop_variety.getText().toString().equalsIgnoreCase("") &&
                        !consolidated_report_zero_to_one_year_edt.getText().toString().equalsIgnoreCase("")
                && !consolidated_report_one_to_three_year_edt.getText().toString().equalsIgnoreCase("")
                && !consolidated_report_above_three_year_edt.getText().toString().equalsIgnoreCase("") && !(photoFile == null)){
                    if(crop_name.equalsIgnoreCase("OTHER")){
                        if(!csr_con_other_crop_edt.getText().toString().trim().equalsIgnoreCase("")){
                            crop_name = csr_con_other_crop_edt.getText().toString().trim();
                            uploadImageOnServer(imagePath);
                        }else {
                            final Toast toast = Toast.makeText(ConsolidatedReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
                            toast.show();
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    toast.cancel();
                                }
                            }, 1000);
                        }

                    }else {
                        uploadImageOnServer(imagePath);
                       /* add_multiple_area(crop_id, crop_name, consolidated_report_zero_to_one_year_edt.getText().toString().trim(),
                                consolidated_report_one_to_three_year_edt.getText().toString().trim(), consolidated_report_above_three_year_edt.getText().toString().trim(),
                                consolidated_report_total_edt.getText().toString().trim());
                        crop_id = 0;*/
                    }
                }else{
                    final Toast toast = Toast.makeText(ConsolidatedReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 1000);
                }
            }
        });

        dept_consolidated_report_generate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(multiple_crop_area_year.length()==0) {
                    Toast.makeText(ConsolidatedReportActivity.this,"Add data for atleast crop",Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(ConsolidatedReportActivity.this, GenerateConsolidatedReportActivity.class);
                    intent.putExtra("multi_consolreport_data", multiple_crop_area_year.toString());
                    intent.putExtra("divison_id",divison_id);
                    intent.putExtra("district_id",district_id);
                    intent.putExtra("taluka_id",taluka_id);
                    intent.putExtra("sajja_id",sajja_id);
                    intent.putExtra("village_id",village_id);
                    intent.putExtra("season_id",season_id);
                    intent.putExtra("crop_type_id",crop_type_id);
                    intent.putExtra("horti_type_id",horti_type_id);
                    intent.putExtra("current_week",current_week);
                    intent.putExtra("last_week",last_week);
                    startActivity(intent);
                }
            }
        });

        consolidate_crop_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(ConsolidatedReportActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(ConsolidatedReportActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(ConsolidatedReportActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ConsolidatedReportActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)){
                    takeImageFromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void calculations(){

            zero_one_str=consolidated_report_zero_to_one_year_edt.getText().toString();
            if(zero_one_str.equals("")){
                zero_one_str="0";
            }
            one_three_str=consolidated_report_one_to_three_year_edt.getText().toString();
            if(one_three_str.equals("")){
                one_three_str="0";
            }
            above_three_str=consolidated_report_above_three_year_edt.getText().toString();
            if(above_three_str.equals("")){
                above_three_str="0";
            }
            if((zero_one_str.equals("")) && (one_three_str.equals("")) && (above_three_str.equals("")) ){
                zero_one_int=0;
                one_three_int=0;
                above_three_int=0;
                total_int=zero_one_int + one_three_int + above_three_int ;
                consolidated_report_total_edt.setText(String.valueOf(total_int));
            }
            else if((!zero_one_str.equals("")) &&(one_three_str.equals("")) && (above_three_str.equals("")) ){
                zero_one_int=Integer.parseInt(zero_one_str);
                one_three_int=0;
                above_three_int=0;
                total_int=zero_one_int + one_three_int + above_three_int ;
                consolidated_report_total_edt.setText(String.valueOf(total_int));
            }
            else if((zero_one_str.equals("")) &&(!one_three_str.equals("")) && (above_three_str.equals("")) ){
                zero_one_int=0;
                one_three_int=Integer.parseInt(one_three_str);
                above_three_int=0;
                total_int=zero_one_int + one_three_int + above_three_int ;
                consolidated_report_total_edt.setText(String.valueOf(total_int));
            }
            else if((!zero_one_str.equals("")) &&(!one_three_str.equals("")) && (!above_three_str.equals("")) ){
                zero_one_int=Integer.parseInt(zero_one_str);
                one_three_int=Integer.parseInt(one_three_str);
                above_three_int=Integer.parseInt(above_three_str);
                total_int=zero_one_int + one_three_int + above_three_int ;
                consolidated_report_total_edt.setText(String.valueOf(total_int));
            }
            else {
                zero_one_int=Integer.parseInt(zero_one_str);
                one_three_int=0;
                above_three_int=0;
                total_int=zero_one_int + one_three_int + above_three_int ;
                consolidated_report_total_edt.setText(String.valueOf(total_int));
            }
        }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            onCameraActivityResult();
        }else{
            photoFile = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile!=null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(consolidate_crop_image.getWidth(), consolidate_crop_image.getHeight())
                                .centerCrop()
                                .into(consolidate_crop_image);
                    }
                }, 0);

                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id",String.valueOf(crop_id));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            params.put("district_id",String.valueOf(district_id));
            params.put("taluka_id",String.valueOf(taluka_id));
            params.put("village_id",String.valueOf(village_id));
            params.put("saja_id",String.valueOf(sajja_id));

            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.consolidated_report_img_save(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void crop_list(int season_id,int crop_type_id, int horti_type_id){

        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id",season_id);
            param.put("crop_type",crop_type_id);
            param.put("horti_crop_type_id",horti_type_id);
            param.put("fieldsubmenu_id","");
            param.put("primary_report_id","");
            param.put("panchname_scheme_id","0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void add_multiple_area(int crop_id, String crop_name, String zero_one_year, String ont_three_year, String above_three_years, String total_area){

        JSONObject add_multiple_area = new JSONObject();
        try{
            add_multiple_area.put("crop_sown_id", crop_id);
            add_multiple_area.put("crop_name", crop_name);
            add_multiple_area.put("area_zero_one_year", zero_one_year);
            add_multiple_area.put("area_one_three_year", ont_three_year);
            add_multiple_area.put("area_above_three_year", above_three_years);
            add_multiple_area.put("total_area",total_area);
            add_multiple_area.put("image_url",first_image_url);
            add_multiple_area.put("image_name",image_name);
            multiple_crop_area_year.put(add_multiple_area);

        }catch (Exception e){
            e.printStackTrace();
        }

        if(multiple_crop_area_year.length()>0){
            cr_add_more_rv.setLayoutManager(new LinearLayoutManager(ConsolidatedReportActivity.this));
            ConsolidateReportAreaYearAdapter consolidateReportAreaYearAdapter = new ConsolidateReportAreaYearAdapter(preferenceManager, multiple_crop_area_year, ConsolidatedReportActivity.this);
            cr_add_more_rv.setAdapter(consolidateReportAreaYearAdapter);
            consolidateReportAreaYearAdapter.notifyDataSetChanged();
            consolidated_report_crop_list_tv.setText("Select");
            consolidated_report_crop_variety.setText("");
            consolidated_report_zero_to_one_year_edt.setText("");
            consolidated_report_one_to_three_year_edt.setText("");
            consolidated_report_above_three_year_edt.setText("");
            consolidated_report_total_edt.setText("");
            csr_con_other_crop_ll.setVisibility(View.GONE);
            csr_con_other_crop_edt.setText("");
            photoFile = null;
            consolidate_crop_image.setImageResource(R.drawable.camera);
        }else{
            final Toast toast = Toast.makeText(ConsolidatedReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {
            try {
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            CropNameList = jsonObject.getJSONArray("data");
                        }
                    }else {
                        final Toast toast = Toast.makeText(ConsolidatedReportActivity.this, "Crops not available", Toast.LENGTH_SHORT);
                        toast.show();
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                toast.cancel();
                            }
                        }, 1000);
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            first_image_url = data.getString("file_url");
                            image_name = data.getString("file_name");
                            add_multiple_area(crop_id,crop_name,consolidated_report_zero_to_one_year_edt.getText().toString().trim(),
                                    consolidated_report_one_to_three_year_edt.getText().toString().trim(),consolidated_report_above_three_year_edt.getText().toString().trim(),
                                    consolidated_report_total_edt.getText().toString().trim());
                            crop_id = 0;
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_id = Integer.parseInt(s1);
            crop_name = s;
            consolidated_report_crop_list_tv.setText(crop_name);
            /*if(multiple_crop_area_year.toString().contains(crop_name) == CropNameList.toString().contains(crop_name)){
                if(crop_name.contains("OTHER")){

                }else{
                    sweetAlertDialog = new SweetAlertDialog(ConsolidatedReportActivity.this, SweetAlertDialog.WARNING_TYPE);
                    sweetAlertDialog.setContentText("Cannot add data for same crop again");
                    sweetAlertDialog.setConfirmText("OK");
                    sweetAlertDialog.setCanceledOnTouchOutside(false);
                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                            consolidated_report_crop_list_tv.setText("Select");
                        }
                    }).show();
                }
            }else{

            }*/

            if(crop_name.equalsIgnoreCase("OTHER")){
                csr_con_other_crop_ll.setVisibility(View.VISIBLE);
            }else {
                csr_con_other_crop_ll.setVisibility(View.GONE);
                csr_con_other_crop_edt.setText("");
            }

            consolidated_report_crop_variety.setText("");
            consolidated_report_zero_to_one_year_edt.setText("");
            consolidated_report_one_to_three_year_edt.setText("");
            consolidated_report_above_three_year_edt.setText("");
            consolidated_report_total_edt.setText("");
            csr_con_other_crop_edt.setText("");
            photoFile = null;
            consolidate_crop_image.setImageResource(R.drawable.camera);
        }
    }
}
