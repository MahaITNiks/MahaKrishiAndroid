package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_DiseaseTypeDAO {

    @Query("SELECT * FROM M_DiseaseTypeEY")
    List<M_DiseaseTypeEY> getAll();

    @Query("SELECT * FROM M_DiseaseTypeEY WHERE uid IN (:userIds)")
    List<M_DiseaseTypeEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_DiseaseTypeEY WHERE uid = :id")
    List<M_DiseaseTypeEY> checkIdExists(int id);

    @Query("SELECT * FROM M_DiseaseTypeEY WHERE crop_id = :crop_id ")
    List<M_DiseaseTypeEY> getCropDiseaseAll(int crop_id);

    @Insert
    void insertAll(M_DiseaseTypeEY... m_diseaseTypeEYS);

    @Insert
    void insertOnlySingle(M_DiseaseTypeEY m_diseaseTypeEY);


}
