package com.maha.agri.activity.approve_attendance;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AprovAttUserListActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {
    private TextView approvedtv,pendingtv,totaltv;
    private RecyclerView approve_userList_recyclerView;
    private JSONArray approve_attendance_userList;
    private PreferenceManager preferenceManager;
    private SharedPref sharedPref;
    private String month,year,id;
    private int approvedDay = 0;
    private int pendingDay = 0;
    JSONObject calJson;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aprov_att_user_list);
        getSupportActionBar().setTitle("Approve Attendance");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(AprovAttUserListActivity.this);
        sharedPref = new SharedPref(AprovAttUserListActivity.this);
        init();
        getApprove_UserList();

    }

    private void init(){

        approvedtv = (TextView) findViewById(R.id.approvedTextView);
        pendingtv = (TextView) findViewById(R.id.pendingTextView);
        totaltv = (TextView) findViewById(R.id.totalTextView);
        approve_userList_recyclerView = (RecyclerView) findViewById(R.id.approve_userList_recyclerView);
        approve_userList_recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Calendar calander = Calendar.getInstance();
        SimpleDateFormat month_date = new SimpleDateFormat("MMMM");
        month = String.valueOf(calander.get(Calendar.MONTH));
        year = String.valueOf(calander.get(Calendar.YEAR));


    }

        @Override
        public void onRestart() {
            super.onRestart();
            finish();
            startActivity(getIntent());
        }



    private void toCalculateApproved(JSONArray approve_attendance_userList) {

        if (approve_attendance_userList.length()>0){
            for (int i=0; i<approve_attendance_userList.length(); i++){
                try {
                    calJson = approve_attendance_userList.getJSONObject(i);
                    String is_completed= calJson.getString("is_completed");
                    id = calJson.getString("id");
                    if (is_completed.equalsIgnoreCase("1")){
                        approvedDay++;
                    }else {
                        pendingDay++;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            approvedtv.setText(String.valueOf(approvedDay));
            pendingtv.setText(String.valueOf(pendingDay));
            int total_ca = approve_attendance_userList.length();
            totaltv.setText(String.valueOf(total_ca));
        }

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getApprove_UserList() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("junior_role_id", preferenceManager.getPreferenceValues(Preference_Constant.JUNIER_ROLE_ID));
            param.put("month", month);
            param.put("year", year);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.ASSIGNED_VILLAGE_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.approve_attendance_user_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }



    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {
                    if (jsonObject.getString("status").equals("200")) {
                        approve_attendance_userList = jsonObject.getJSONArray("data");
                        approve_userList_recyclerView.setAdapter(new ApproveAttenUserListAdapter(this, approve_attendance_userList,preferenceManager));
                        toCalculateApproved(approve_attendance_userList);
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

    }
}

