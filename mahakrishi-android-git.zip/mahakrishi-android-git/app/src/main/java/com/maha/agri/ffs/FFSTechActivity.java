package com.maha.agri.ffs;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ffs.adaptor.FFSTechAdapter;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.model.TechDemoModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppString;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FFSTechActivity extends AppCompatActivity implements OnMultiRecyclerItemClickListener, ApiCallbackCode {

    private AppLocationManager locationManager;
    private DBHandler dbHandler;
    private String userID;
    private String activityID;
    private int cropID;
    private String planId;

    // For Image upload
    private File photoFile = null;
    private Transformation transformation;
    private String selectedImage = "0";
    private String currentImglatLong = "";
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    String currentTime;
    private File imgFile = null;
    private double lat1;
    private double lang1;

    private File imgFile2 = null;
    private double lat2;
    private double lang2;

    private RecyclerView recyclerView;
    private ImageView attch1ImageView;
    private ImageView attch2ImageView;
    private FFSTechAdapter ffsTechAdapter;

    private int update_visit = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech_demo);
        getSupportActionBar().setTitle(getResources().getString(R.string.tech_title));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        currentTime = ApUtil.getCurrentTimeStamp();
        dbHandler = new DBHandler(FFSTechActivity.this);
        locationManager = new AppLocationManager(this);

        userID = AppSettings.getInstance().getValue(this,ApConstants.kUSER_ID,ApConstants.kUSER_ID);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);

        initComponents();
        setConfiguration();
    }



    private void initComponents() {

        recyclerView = findViewById(R.id.recyclerView);
        attch1ImageView = findViewById(R.id.attch1ImageView);
        attch2ImageView = findViewById(R.id.attch2ImageView);

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

        locationManager = new AppLocationManager(this);

    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (getIntent() != null && getIntent().hasExtra("update_visit")) {
            update_visit = getIntent().getIntExtra("update_visit", 0);
        }

        DebugLog.getInstance().d("update_visit=" + update_visit);
        cropID = getIntent().getIntExtra("crop_id", -1);

        if (update_visit == 1) {
            findViewById(R.id.headingTextView).setVisibility(View.GONE);
            findViewById(R.id.imgRelativeLayout).setVisibility(View.GONE);
        } else {
            findViewById(R.id.headingTextView).setVisibility(View.VISIBLE);
            findViewById(R.id.imgRelativeLayout).setVisibility(View.VISIBLE);
        }

        fetchTechnologyList();

        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitButtonAction();
            }
        });

        attch1ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedImage = "1";
                if ((ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    // && (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ){
                    locationManager = new AppLocationManager(FFSTechActivity.this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        attch2ImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedImage = "2";
                if ((ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(FFSTechActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    // && (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ){
                    locationManager = new AppLocationManager(FFSTechActivity.this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_PATH1, ApConstants.kTECH_DEMO_PATH1);
                AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_PATH2, ApConstants.kTECH_DEMO_PATH2);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }


    private void submitButtonAction() {

        try {
            JSONArray jsonArray = new JSONArray();

            if (ffsTechAdapter != null && ffsTechAdapter.mDataArray != null) {
                for (int i = 0; i < ffsTechAdapter.mDataArray.length(); i++) {
                    JSONObject jsonObject = ffsTechAdapter.mDataArray.getJSONObject(i);
                    TechDemoModel model = new TechDemoModel(jsonObject);
                    if (model.getIs_selected() == 1) {
                        jsonArray.put(jsonObject);
                    }
                }
            }


            if (update_visit == 1) {
                if (jsonArray.length() == 0) {
                    UIToastMessage.show(this, getResources().getString(R.string.tech_attach_photo_err));
                } else {
                    AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO, jsonArray.toString());
                    EventBus.getDefault().post(new EventModel("update_2"));
                    finish();
                }
            } else {
                if (jsonArray.length() == 0) {
                    UIToastMessage.show(this, getResources().getString(R.string.tech_attach_photo_err));
                } else if (photoFile == null) {
                    UIToastMessage.show(this, getResources().getString(R.string.tech_attach_photo));
                } else {
                    AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO, jsonArray.toString());
                    EventBus.getDefault().post(new EventModel("update_2"));
                    finish();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

    }

    /*private void fetchDatabaseData() {

        final AppSession session = new AppSession(this);
        final Context mContext = this;

        new Thread(new Runnable() {
            @Override
            public void run() {

                FfsDatabase db = AppDelegate.getInstance(mContext).getAppDatabase();
                List<M_Tech_DemoEY> mDataArray = db.tech_demoDAO().getTechDemoForCrop(session.getVisitNumber());
                final JSONArray jsonArray = new JSONArray();

                for(M_Tech_DemoEY data : mDataArray) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("id", data.getUid());
                        jsonObject.put("name", data.getName());

                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                db.close();

                FFSTechActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        FFSTechAdapter = new FFSTechAdapter(FFSTechActivity.this, FFSTechActivity.this, jsonArray);
                        recyclerView.setAdapter(FFSTechAdapter);
                    }
                });


            }
        }).start();
    }*/


    private void fetchTechnologyList() {
        String visit_number = getIntent().getStringExtra("visit_num");
        try {

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("crop_id", cropID);
                jsonObject.put("visit_number",  visit_number);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchTechDemos(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, new ApiCallbackCode() {
                @Override
                public void onResponse(JSONObject jsonObject, int i) {
                    try {
                        if (i == 1) {

                            if (jsonObject != null) {

                                DebugLog.getInstance().d("onResponse=" + jsonObject);
                                ResponseModel response = new ResponseModel(jsonObject);

                                if (response.isStatus()) {
                                    JSONArray jsonArray = response.getData();
                                    ffsTechAdapter = new FFSTechAdapter(FFSTechActivity.this, FFSTechActivity.this, jsonArray);
                                    recyclerView.setAdapter(ffsTechAdapter);
                                } else {
                                    UIToastMessage.show(FFSTechActivity.this, response.getMsg());
                                }
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Object o, Throwable throwable, int i) {

                }
            }, 1);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // For Image upload
    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userID + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (selectedImage.equalsIgnoreCase("1") ){
                            imgFile = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat1 = locationManager.getLatitude();
                            lang1 = locationManager.getLatitude();
                        }else if (selectedImage.equalsIgnoreCase("2")){
                            imgFile2 = new File(imagePath);
                            uploadImageOnServer(imagePath);
                            lat2 = locationManager.getLatitude();
                            lang2 = locationManager.getLatitude();
                        }
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(FFSTechActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {

            currentImglatLong = locationManager.getLatitude()+ "_" + locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", userID);
            params.put("crop_id", String.valueOf(cropID));
            params.put("ima_sr_no", selectedImage);

            //creating a file
            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("image_name", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.visit_image_upload(partBody, params);
            api.postRequest(responseCall, this, 33);

            DebugLog.getInstance().d("technology_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("technology_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            DebugLog.getInstance().d("onResponse=" + jsonObject.toString());
            ResponseModel response = new ResponseModel(jsonObject);
            if (response.isStatus()) {

                JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                String imgUrl = jsonObject1.getString("file_url");
                if (selectedImage.equalsIgnoreCase("1")) {

                    AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1, jsonObject.toString());
                    if (currentImglatLong.equalsIgnoreCase("")){
                        AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1_LOC, currentImglatLong);
                    }else {
                        AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE1_LOC, ApConstants.kTECH_DEMO_FILE1_LOC);
                    }

                    if (imgUrl != null){
                        Picasso.get()
                                .load(imgUrl)
                                .transform(transformation)
                                .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                .centerCrop()
                                .into(attch1ImageView);
                    }


                } else {
                    AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2, jsonObject.toString());
                    if (currentImglatLong.equalsIgnoreCase("")){
                        AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2_LOC, currentImglatLong);
                    }else {
                        AppSettings.getInstance().setValue(this, ApConstants.kTECH_DEMO_FILE2_LOC, ApConstants.kTECH_DEMO_FILE2_LOC);
                    }
                    if (imgUrl != null){
                        Picasso.get()
                                .load(imgUrl)
                                .transform(transformation)
                                .resize(attch1ImageView.getWidth(), attch1ImageView.getHeight())
                                .centerCrop()
                                .into(attch2ImageView);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
