package com.maha.agri.farmer;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerMagazineActivity extends AppCompatActivity implements ApiCallbackCode {
    private RecyclerView farmer_magazine_rv;
    private JSONArray farmer_magazine_list,farmer_month_list;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String  month_id,year,id,magazine_title;
    private DBHandler dbHandler;
    HashMap<Integer,String> selected_month_id = new HashMap<>();
    View parentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_magazine);
        Intent intent = getIntent();

        magazine_title = intent.getStringExtra("magazine_title");
        if (magazine_title.equalsIgnoreCase("farmer")){
            getSupportActionBar().setTitle("शेतकरी मासिक");
        } else if(magazine_title.equalsIgnoreCase("dept")){
            getSupportActionBar().setTitle("Farmer Magazine");
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerMagazineActivity.this);
        sharedPref = new SharedPref(FarmerMagazineActivity.this);
        dbHandler = new DBHandler(this);
        parentLayout = findViewById(android.R.id.content);

        if(isNetworkAvailable()){
            IdCalling();
            default_Config();
            getTaskManagerListWebservie();
        }else{
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        }


    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void IdCalling(){
        farmer_magazine_rv = (RecyclerView)findViewById(R.id.farmer_magazine_rv);
        farmer_magazine_rv.setLayoutManager(new GridLayoutManager(this, 2));

        Calendar calander = Calendar.getInstance();
        year = String.valueOf(calander.get(Calendar.YEAR));

    }

    private void default_Config() {

        farmer_magazine_rv.addOnItemTouchListener(new FarmerMagazineAdapter.RecyclerTouchListener(this, farmer_magazine_rv, new FarmerMagazineAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                id = selected_month_id.get(position);
                getPDFWebservie();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }



    private void getTaskManagerListWebservie() {

        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.farmer_magazine_url(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    private void getPDFWebservie() {

        JSONObject param = new JSONObject();
        try {
            param.put("month", id);
            param.put("year", year);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.farmer_magazine_pdf_url(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_month_list = jsonObject.getJSONArray("data");
                            for(int j = 0;j < farmer_month_list.length();j++){
                                JSONObject month_json_obj = farmer_month_list.getJSONObject(j);
                                month_id = month_json_obj.getString("id");
                                selected_month_id.put(j, month_id);
                            }


                            farmer_magazine_rv.setAdapter(new FarmerMagazineAdapter(preferenceManager, farmer_month_list, this));

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_magazine_list = jsonObject.getJSONArray("data");
                            for (int j = 0; j < farmer_magazine_list.length(); j++) {
                                JSONObject pdf_json_object = farmer_magazine_list.getJSONObject(j);
                                String pdf_file = pdf_json_object.getString("pdf_file");
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(pdf_file));
                                startActivity(browserIntent);
                            }

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
    }
