package com.maha.agri.activity.attendance;

import android.app.Dialog;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.AttendanceAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AttedanceCalenderActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView attendancerv, monthly_calendar_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private JSONArray attendanceList, attendance_Month_filter_List;
    String month_Filter,month,year;

    private TextView totPresentDay;
    private int presentDay = 0;
    private TextView totAbsentDay;
    private int absentDay = 0;
    private int totalDay=0;
    private TextView totWorkHourDay,totTotalDays;
    private int workedHourDay,month_filter_pos;
    JSONObject calendraJson;
    int total_days;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attedance_calender);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setTitle("Attendance");
        preferenceManager = new PreferenceManager(AttedanceCalenderActivity.this);
        sharedPref = new SharedPref(AttedanceCalenderActivity.this);
        init();
        default_config();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.filter_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.filter_menu:
                final Dialog dialog = new Dialog(AttedanceCalenderActivity.this);
                dialog.setContentView(R.layout.calendar_custom_dialog);
                dialog.setTitle("Filter");
                dialog.setCanceledOnTouchOutside(true);
                Button applybtn = (Button) dialog.findViewById(R.id.apply_btn);
                Button cancelbtn = (Button) dialog.findViewById(R.id.cancel_btn);
                monthly_calendar_rv = (RecyclerView) dialog.findViewById(R.id.month_recycler_view);
                monthly_calendar_rv.setLayoutManager(new LinearLayoutManager(this));
                monthly_calendar_rv.addItemDecoration(new DividerItemDecoration(this,
                        DividerItemDecoration.VERTICAL));

                /*try {
                    month_filter_pos = preferenceManager.getPreferenceIntValues(Preference_Constant.MONTH_FILTER_POS);
                    calendraJson = attendance_Month_filter_List.getJSONObject(month_filter_pos);
                    month = calendraJson.getString("month");
                    year = calendraJson.getString("year");
                    month_Filter = month + " " + year;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
*/
                AttendanceFilterMonthList();


                applybtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        /*try {
                            month_filter_pos = preferenceManager.getPreferenceIntValues(Preference_Constant.MONTH_FILTER_POS);
                            calendraJson = attendance_Month_filter_List.getJSONObject(month_filter_pos);
                            month = calendraJson.getString("month");
                            year = calendraJson.getString("year");
                            month_Filter = month + " " + year;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }*/
                        month_Filter = preferenceManager.getPreferenceValues(Preference_Constant.MONTH_FILTER);
                        AttendanceListWebservice(month_Filter, "");
                        getSupportActionBar().setTitle(month_Filter);
                        dialog.dismiss();


                    }
                });

                cancelbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();

                    }
                });

                dialog.show();


            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void init(){
        attendancerv = (RecyclerView) findViewById(R.id.attendancerv);
        attendancerv.setLayoutManager(new GridLayoutManager(this, 5));

        totPresentDay = (TextView)findViewById(R.id.totPresentDay);
        totAbsentDay = (TextView)findViewById(R.id.totAbsentDay);
        totWorkHourDay = (TextView)findViewById(R.id.totWorkHourDay);
        //totTotalDays = (TextView) findViewById(R.id.tottotalDay);



    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    private void default_config(){

        Calendar calander = Calendar.getInstance();
        SimpleDateFormat month_date = new SimpleDateFormat("MMMM");
        String month = month_date.format(calander.getTime());
       // month = String.valueOf(calander.get(Calendar.MONTH));
        String year = String.valueOf(calander.get(Calendar.YEAR));
        getSupportActionBar().setTitle(month + " - " + year);

       AttendanceListWebservice(month,year);

    }

    private void AttendanceListWebservice(String month, String year) {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("month", month);
            param.put("year", year);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.userattendancedetailsurl(requestBody);
        DebugLog.getInstance().d("attendance_url_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("attendance_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void AttendanceFilterMonthList() {

        JSONObject param = new JSONObject();
        try {
            param.put("year", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.attendanceMonthFilter(requestBody);
        DebugLog.getInstance().d("attendance_url_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("attendance_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    private void toCalculateWorkHour(JSONArray attendanceList) {
        presentDay = 0;
        absentDay = 0;
        if (attendanceList.length()>0){
            for (int i=0; i<attendanceList.length(); i++){
                try {
                    JSONObject calJson = attendanceList.getJSONObject(i);
                    total_days = attendanceList.length();
                    String isPresent = calJson.getString("is_present");
                    String isHoliday = calJson.getString("is_holiday");
                    if (isPresent.equalsIgnoreCase("1")){
                        String workedHour = calJson.getString("hours");
                        presentDay++;
                        workedHourDay = workedHourDay +Integer.valueOf(workedHour);
                    } else if (isHoliday.equalsIgnoreCase("0")){
                        absentDay++;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            totPresentDay.setText(String.valueOf(presentDay));
            totWorkHourDay.setText(String.valueOf(workedHourDay));
            totAbsentDay.setText(String.valueOf(absentDay));
            //totTotalDays.setText(String.valueOf(total_days));
        }

    }



    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            attendanceList = jsonObject.getJSONArray("data");
                            attendancerv.setAdapter(new AttendanceAdapter(this, attendanceList));
                            toCalculateWorkHour(attendanceList);
                        }

                    } else {
                    }

                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            attendance_Month_filter_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(this,ApConstants.MONTH_FILTER,attendance_Month_filter_List.toString());
                            AttendanceCalendarAdapter attendanceCalendarAdapter = new AttendanceCalendarAdapter(this,attendance_Month_filter_List,preferenceManager);
                            monthly_calendar_rv.setAdapter(attendanceCalendarAdapter);
                            attendanceCalendarAdapter.notifyDataSetChanged();


                        } else {

                        }

                    } else {
                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
