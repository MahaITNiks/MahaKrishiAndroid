package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ForgotPasswordActivity extends AppCompatActivity implements ApiCallbackCode {
    private Button submitBtn;
    private EditText otpEText;
    private TextView resend_otp_txt;
    private String otp,mobile_number;
    private JSONObject forgotpass_json_object;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        getSupportActionBar().setTitle("Verify OTP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sharedPref = new SharedPref(ForgotPasswordActivity.this);
        preferenceManager = new PreferenceManager(ForgotPasswordActivity.this);
        Intent intent = getIntent();
        mobile_number = intent.getStringExtra("mobile_number");
        init();
        default_confiq();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


        private void init () {
            submitBtn = (Button) findViewById(R.id.submitBtn);
            otpEText = (EditText) findViewById(R.id.otpEText);
            resend_otp_txt = (TextView) findViewById(R.id.resend_otp_txt);

        }

        private void default_confiq () {
            otp = otpEText.getText().toString().trim();
            submitBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    validateotpWebservice();
                }
            });
            resend_otp_txt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    resendotpWebservice();
                }
            });

        }

        private void validateotpWebservice () {
        if(otpEText.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter the OTP for further process");
        } else {

            JSONObject param = new JSONObject();

            try {
                param.put("mobile", mobile_number);
                param.put("otp", otpEText.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.validate_otp(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
        }


    private void resendotpWebservice () {

        JSONObject param = new JSONObject();
        try {
            param.put("mobile", mobile_number);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.resend_otp(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    @Override
        public void onResponse (JSONObject jsonObject,int i){

            try {

                if (jsonObject != null) {
                    // District Response
                    if (i == 1) {

                        if (jsonObject.getString("status").equals("200")) {
                            Intent intent = new Intent(ForgotPasswordActivity.this,EnterNewPasswordActivity.class);
                            intent.putExtra("mobile_number",mobile_number);
                            startActivity(intent);
                            finish();

                        } else {
                            UIToastMessage.show(this, jsonObject.getString("response"));
                        }


                    }

                    if (i == 2) {

                        if (jsonObject.getString("status").equals("200")) {
                            UIToastMessage.show(this, jsonObject.getString("response"));
                        } else {
                            UIToastMessage.show(this, jsonObject.getString("response"));
                        }


                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }


        }

        @Override
        public void onFailure (Object o, Throwable throwable,int i){

        }

}
