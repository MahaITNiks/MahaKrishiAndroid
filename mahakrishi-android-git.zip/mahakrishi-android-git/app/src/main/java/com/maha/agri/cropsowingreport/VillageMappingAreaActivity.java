package com.maha.agri.cropsowingreport;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.DecimalDigitsInputFilter;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class VillageMappingAreaActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView village_map_area_districttv,village_map_area_talukatv,village_map_area_circle,village_map_area_saja,village_mapping_area_sajja_list_name_tv,village_map_area_village;
    private EditText village_map_area_geo_area,village_map_area_cult_area;
    private Button village_map_area_save,village_map_area_edit;
    private LinearLayout village_mapping_area_sajja_ll,village_mapping_area_sajja_list_ll;
    private JSONArray district_tal_list,village_list;
    private String divison_id_str = "", district_id_str = "", taluka_id_str = "", circle_id_str = "", sajja_id_str = "",
            divison_name = "", district_name = "", taluka_name = "", circle_name = "", sajja_name = "", village_name = "",geo_area_str="",cult_area_str="";
    private int divison_id = 0, district_id = 0, taluka_id = 0, circle_id = 0, sajja_id = 0, village_id = 0, geo_area_int = 0, cult_area_int = 0;
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;
    private JSONArray data = new JSONArray();
    private JSONArray sajja_list = new JSONArray();

    //response data
    int res_divison_id = 0;
    int res_district_id = 0;
    int res_taluka_id = 0;
    int res_circle_id = 0;
    int res_sajja_id = 0;
    int res_village_id = 0;
    String res_district_name = "";
    String res_taluka_name = "";
    String res_circle_name = "";
    String res_sajja_name = "";
    String res_village_name = "";
    private String geo_area = "";
    private String cul_area = "";
    private boolean isdatapresent = false;
    private String role_id = "", role_chare_id = "", role_officer_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_village_mapping_area);
        getSupportActionBar().setTitle("Village Mapping Area");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(VillageMappingAreaActivity.this);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);
        role_chare_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID);
        role_officer_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID);
        circle_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        sajja_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));

        ids();
        functionality();

    }

    private void ids(){
        village_mapping_area_sajja_ll = (LinearLayout)findViewById(R.id.village_mapping_area_sajja_ll);
        village_mapping_area_sajja_list_ll = (LinearLayout)findViewById(R.id.village_mapping_area_sajja_list_ll);
        village_map_area_districttv = (TextView) findViewById(R.id.village_map_area_districttv);
        village_map_area_talukatv = (TextView) findViewById(R.id.village_map_area_talukatv);
        village_map_area_circle = (TextView) findViewById(R.id.village_map_area_circle);
        village_map_area_saja = (TextView) findViewById(R.id.village_map_area_saja);
        village_mapping_area_sajja_list_name_tv = (TextView)findViewById(R.id.village_mapping_area_sajja_list_name_tv);
        village_map_area_village = (TextView) findViewById(R.id.village_map_area_village);
        village_map_area_geo_area = (EditText) findViewById(R.id.village_map_area_geo_area);
        village_map_area_cult_area = (EditText) findViewById(R.id.village_map_area_cult_area);
        village_map_area_save = (Button) findViewById(R.id.village_map_area_save);
        village_map_area_edit = (Button) findViewById(R.id.village_map_area_et);
        village_map_area_geo_area.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(9,2)});
        village_map_area_cult_area.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(9,2)});
        district_tal_list = new JSONArray();
        village_list = new JSONArray();
        village_map_area_village.setText("Select");
        village_map_area_save.setEnabled(true);
        village_map_area_circle.setText(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_NAME));
        village_map_area_saja.setText(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_NAME));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void functionality(){

        if(role_chare_id.equalsIgnoreCase("1")&&role_officer_id.equalsIgnoreCase("2")){
            village_mapping_area_sajja_ll.setVisibility(View.GONE);
            village_mapping_area_sajja_list_ll.setVisibility(View.VISIBLE);
            get_district_taluka();
            getSajjaLocation();
            village_mapping_area_sajja_list_name_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (sajja_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(sajja_list, 2, "Select Saja", "sajja_name", "sajja_id", VillageMappingAreaActivity.this, VillageMappingAreaActivity.this);
                    }
                }
            });

            village_map_area_village.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getVillageLocation();
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 4, "Select Village", "village_name", "village_id", VillageMappingAreaActivity.this, VillageMappingAreaActivity.this);
                    }
                }
            });

        }else{
            village_mapping_area_sajja_ll.setVisibility(View.VISIBLE);
            village_mapping_area_sajja_list_ll.setVisibility(View.GONE);
            get_district_taluka();
            village_map_area_village.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getVillageLocation();
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 3, "Select Village", "village_name", "village_id", VillageMappingAreaActivity.this, VillageMappingAreaActivity.this);
                    }
                }
            });
        }

        village_map_area_cult_area.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                geo_area_str = village_map_area_geo_area.getText().toString();
                try{
                    geo_area_int = Integer.parseInt(geo_area_str);
                }catch(NumberFormatException ex){

                }
                cult_area_str = village_map_area_cult_area.getText().toString();

                if(!cult_area_str.equalsIgnoreCase("")){
                    cult_area_int = Integer.parseInt(cult_area_str);
                    if(cult_area_int >= geo_area_int){
                        sweetAlertDialog = new SweetAlertDialog(VillageMappingAreaActivity.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Cultivable area should not be greater than geographical area");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                village_map_area_cult_area.setText("");
                                cult_area_str = "";
                            }
                        }).show();
                    }
                }else{
                    cult_area_int = 0;
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        village_map_area_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(village_id == 0){
                    Toast.makeText(VillageMappingAreaActivity.this,"Select village",Toast.LENGTH_SHORT).show();
                }else if(village_map_area_geo_area.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(VillageMappingAreaActivity.this,"Enter geographical area(ha)",Toast.LENGTH_SHORT).show();
                }else if(village_map_area_cult_area.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(VillageMappingAreaActivity.this,"Enter cultivable area(ha)",Toast.LENGTH_SHORT).show();
                }else{
                    save_village_mapping_area();
                }
            }
        });

        village_map_area_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                village_map_area_geo_area.setEnabled(true);
                village_map_area_cult_area.setEnabled(true);
                village_map_area_save.setEnabled(true);
            }
        });

        /*if (isdatapresent) {
            village_map_area_districttv.setText(res_district_name);
            village_map_area_talukatv.setText(res_taluka_name);
            village_map_area_village.setText(res_village_name);
            village_map_area_geo_area.setText(geo_area);
            village_map_area_cult_area.setText(cul_area);
            village_mapping_area_sajja_list_name_tv.setText(res_sajja_name);
            village_map_area_saja.setText(res_sajja_name);
            village_mapping_area_sajja_list_name_tv.setEnabled(false);
            village_map_area_village.setEnabled(false);
            village_map_area_geo_area.setEnabled(false);
            village_map_area_cult_area.setEnabled(false);
            village_map_area_save.setEnabled(false);
        }else {
            resetAlldata();
        }*/
    }

    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void getSajjaLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_sajja_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
            param.put("sajja_id", preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_village_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void normalVillageList() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("sajja_id", sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);

    }

    private void save_village_mapping_area() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("divison_id", divison_id);
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("circle_id", circle_id);
            param.put("sajja_id", sajja_id);
            param.put("village_id", village_id);
            param.put("geographical_area", geo_area_int);
            param.put("cultivated_area", cult_area_int);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.village_mapping_area_save(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void get_filled_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("sajja_id",sajja_id);
            param.put("village_id",village_id);
            param.put("circle_id", circle_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.village_mapping_area_get_filled_data(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try{

            if(jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_tal_list = jsonObject.getJSONArray("data");
                            if (district_tal_list.length() > 0) {
                                for (int j = 0; j <= district_tal_list.length(); j++) {
                                    JSONObject district_json_object = district_tal_list.getJSONObject(j);
                                    divison_id_str = district_json_object.getString("division_id");
                                    divison_name = district_json_object.getString("division_name");
                                    district_id_str = district_json_object.getString("district_id");
                                    district_name = district_json_object.getString("district_name");
                                    taluka_id_str = district_json_object.getString("taluka_id");
                                    taluka_name = district_json_object.getString("taluka_name");
                                    divison_id = Integer.valueOf(divison_id_str);
                                    district_id = Integer.valueOf(district_id_str);
                                    taluka_id = Integer.valueOf(taluka_id_str);
                                    village_map_area_districttv.setText(district_name);
                                    village_map_area_talukatv.setText(taluka_name);
                                    getVillageLocation();
                                }
                            }
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sajja_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(VillageMappingAreaActivity.this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setContentText("Submitted Successfully");
                            sweetAlertDialog.setConfirmText("OK");
                            sweetAlertDialog.setCanceledOnTouchOutside(false);
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    sDialog.dismissWithAnimation();
                                    finish();
                                }
                            }).show();

                        }
                    }
                }
                if (i == 6) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            res_divison_id = Integer.parseInt(jsonObject.getString("division_id"));
                            res_district_id = Integer.parseInt(jsonObject.getString("district_id"));
                            res_taluka_id = Integer.parseInt(jsonObject.getString("taluka_id"));
                            res_circle_id = Integer.parseInt(jsonObject.getString("circle_id"));
                            res_sajja_id = Integer.parseInt(jsonObject.getString("sajja_id"));
                            res_village_id = Integer.parseInt(jsonObject.getString("village_id"));
                            res_district_name = jsonObject.getString("district_name");
                            res_taluka_name = jsonObject.getString("taluka_name");
                            res_circle_name = jsonObject.getString("circle_name");
                            res_sajja_name = jsonObject.getString("sajja_name");
                            res_village_name = jsonObject.getString("village_name");
                            geo_area = jsonObject.getString("geographical_area");
                            cul_area = jsonObject.getString("cultivated_area");
                            
                            if(res_circle_id==circle_id){
                                village_map_area_districttv.setText(res_district_name);
                                village_map_area_talukatv.setText(res_taluka_name);
                                village_map_area_village.setText(res_village_name);
                                village_map_area_geo_area.setText(geo_area);
                                village_map_area_cult_area.setText(cul_area);
                                village_map_area_circle.setText(res_circle_name);
                                village_mapping_area_sajja_list_name_tv.setText(res_sajja_name);
                                village_map_area_saja.setText(res_sajja_name);
                                //village_mapping_area_sajja_list_name_tv.setEnabled(false);
                                //village_map_area_village.setEnabled(false);
                                village_map_area_geo_area.setEnabled(false);
                                village_map_area_cult_area.setEnabled(false);
                                village_map_area_save.setEnabled(false);
                            }else {
                                resetAlldata();
                            }
                        }
                    }else{
                        village_map_area_geo_area.setEnabled(true);
                        village_map_area_cult_area.setEnabled(true);
                        village_map_area_save.setEnabled(true);
                    }
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 2) {
            sajja_id = Integer.parseInt(s1);
            sajja_name = s;
            village_mapping_area_sajja_list_name_tv.setText(sajja_name);
            normalVillageList();
            village_map_area_village.setText("Select");
        }

        if (i == 3) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            village_map_area_village.setText(village_name);
            village_map_area_geo_area.setText("");
            village_map_area_cult_area.setText("");
            get_filled_data();
        }

        if (i == 4) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            village_map_area_village.setText(village_name);
            village_map_area_geo_area.setText("");
            village_map_area_cult_area.setText("");
            get_filled_data();
        }
    }

    private void resetAlldata(){
        village_mapping_area_sajja_list_name_tv.setText("Select");
        village_map_area_village.setText("Select");
        village_map_area_village.setEnabled(true);
        village_mapping_area_sajja_list_name_tv.setEnabled(true);
        village_map_area_geo_area.setEnabled(true);
        village_map_area_cult_area.setEnabled(true);
        village_map_area_save.setEnabled(true);
    }
}