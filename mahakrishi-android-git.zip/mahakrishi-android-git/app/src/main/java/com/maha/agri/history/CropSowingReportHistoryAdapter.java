package com.maha.agri.history;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CropSowingReportHistoryAdapter extends RecyclerView.Adapter<CropSowingReportHistoryAdapter.MyViewHolder> {
    private JSONArray csr_village_count_list;
    private Context context;
    private PreferenceManager preferencemanager;
    String id;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout csr_history_village_count_rl;
        private TextView csr_history_village_name_tv,csr_history_village_count_tv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.csr_history_village_count_rl = itemView.findViewById(R.id.csr_history_village_count_rl);
            this.csr_history_village_name_tv = itemView.findViewById(R.id.csr_history_village_name_tv);
            this.csr_history_village_count_tv = itemView.findViewById(R.id.csr_history_village_count_tv);

        }
    }

    public CropSowingReportHistoryAdapter(JSONArray csr_village_count_list, Context context) {
        this.csr_village_count_list = csr_village_count_list;
        this.context = context;

    }

    @Override
    public CropSowingReportHistoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                         int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.csr_history_village_count_single_item, parent, false);

        CropSowingReportHistoryAdapter.MyViewHolder myViewHolder = new CropSowingReportHistoryAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final CropSowingReportHistoryAdapter.MyViewHolder holder, final int listPosition) {
        try {
            JSONObject jsonObject = csr_village_count_list.getJSONObject(listPosition);
            holder.csr_history_village_name_tv.setText(jsonObject.getString("village_name"));
            holder.csr_history_village_count_tv.setText(jsonObject.getString("count"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (csr_village_count_list != null) {
            return csr_village_count_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private CropSowingReportHistoryAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CropSowingReportHistoryAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}

