package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_WeedsTypeIntensityDAO {

    @Query("SELECT * FROM M_WeedsTypeIntensityEY")
    List<M_WeedsTypeIntensityEY> getAll();

    @Query("SELECT * FROM M_WeedsTypeIntensityEY WHERE uid IN (:userIds)")
    List<M_WeedsTypeIntensityEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_WeedsTypeIntensityEY WHERE uid = :id")
    List<M_WeedsTypeIntensityEY> checkIdExists(int id);

    @Insert
    void insertAll(M_WeedsTypeIntensityEY... m_weedsTypeIntensityEYS);

    @Insert
    void insertOnlySingle(M_WeedsTypeIntensityEY m_weedsTypeIntensityEY);


}
