package com.maha.agri.farmer;

import android.content.Context;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerCropSapDetailsPagerAdapter extends PagerAdapter {

    private LayoutInflater layoutInflater;
    private JSONArray farmer_cropsap_details_based_crop_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    private TextView farmer_cropsap_history_details_district_tv,farmer_cropsap_history_details_taluka_tv,farmer_cropsap_history_details_village_tv,farmer_cropsap_history_details_seasonname_tv,farmer_cropsap_history_details_cropname_tv,farmer_cropsap_history_details_survey_no_tv,farmer_cropsap_history_details_comment_tv,
            farmer_cropsap_history_details_crop_condt_tv,farmer_cropsap_history_details_other_cropname_tv;
    private ImageView farmer_cropsap_history_details_iv;
    private String id,name,districtname,talukaname,cropname,villagename,seasonname,filename,survey_no,comment,crop_condt,other_crop_name;
    private LinearLayout dept_cropsap_other_crop_name_ll,dept_cropsap_crop_name_ll;

    public FarmerCropSapDetailsPagerAdapter(PreferenceManager preferenceManager, JSONArray farmer_cropsap_details_based_crop_array_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.farmer_cropsap_details_based_crop_array_list = farmer_cropsap_details_based_crop_array_list;
        this.context = context;

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.farmer_cropsap_history_detail_single_item, container, false);
        try {
            jsonObject = farmer_cropsap_details_based_crop_array_list.getJSONObject(position);
            districtname = jsonObject.getString("district_name");
            talukaname = jsonObject.getString("taluka_name");
            villagename = jsonObject.getString("village_name");
            seasonname = jsonObject.getString("season_name");
            cropname = jsonObject.getString("crop_name");
            survey_no = jsonObject.getString("survey_no");
            comment = jsonObject.getString("comment");
            filename = jsonObject.getString("filename");
            other_crop_name = jsonObject.getString("crop_name_ed");

            farmer_cropsap_history_details_district_tv = (TextView) view.findViewById(R.id.farmer_cropsap_history_details_district_tv);
            farmer_cropsap_history_details_taluka_tv = (TextView)view. findViewById(R.id.farmer_cropsap_history_details_taluka_tv);
            farmer_cropsap_history_details_village_tv = (TextView) view.findViewById(R.id.farmer_cropsap_history_details_village_tv);
            farmer_cropsap_history_details_seasonname_tv = (TextView)view. findViewById(R.id.farmer_cropsap_history_details_seasonname_tv);
            farmer_cropsap_history_details_cropname_tv = (TextView) view.findViewById(R.id.farmer_cropsap_history_details_cropname_tv);
            farmer_cropsap_history_details_survey_no_tv = (TextView) view.findViewById(R.id.farmer_cropsap_history_details_survey_no_tv);
            farmer_cropsap_history_details_comment_tv = (TextView)view. findViewById(R.id.farmer_cropsap_history_details_comment_tv);
            farmer_cropsap_history_details_other_cropname_tv = (TextView)view.findViewById(R.id.farmer_cropsap_history_details_other_cropname_tv);
            farmer_cropsap_history_details_iv = (ImageView) view. findViewById(R.id.farmer_cropsap_history_details_iv);
            dept_cropsap_other_crop_name_ll = (LinearLayout)view.findViewById(R.id.dept_cropsap_other_crop_name_ll);
            dept_cropsap_crop_name_ll = (LinearLayout)view.findViewById(R.id.dept_cropsap_crop_name_ll);

            if(!other_crop_name.isEmpty()){
                dept_cropsap_other_crop_name_ll.setVisibility(View.VISIBLE);
                dept_cropsap_crop_name_ll.setVisibility(View.GONE);
                farmer_cropsap_history_details_other_cropname_tv.setText(other_crop_name);
            }else {
                dept_cropsap_other_crop_name_ll.setVisibility(View.GONE);
                dept_cropsap_crop_name_ll.setVisibility(View.VISIBLE);
            }

            farmer_cropsap_history_details_district_tv.setText(districtname);
            farmer_cropsap_history_details_taluka_tv.setText(talukaname);
            farmer_cropsap_history_details_village_tv.setText(villagename);
            farmer_cropsap_history_details_seasonname_tv.setText(seasonname);
            farmer_cropsap_history_details_survey_no_tv.setText(survey_no);
            farmer_cropsap_history_details_cropname_tv.setText(cropname);
            farmer_cropsap_history_details_comment_tv.setText(comment);


            Picasso.get()
                    .load(filename)
                    .into(farmer_cropsap_history_details_iv);



        } catch (JSONException e) {
            e.printStackTrace();
        }

        container.addView(view);

        return view;
    }

    @Override
    public int getCount() {
        return farmer_cropsap_details_based_crop_array_list.length();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((View) obj);
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
