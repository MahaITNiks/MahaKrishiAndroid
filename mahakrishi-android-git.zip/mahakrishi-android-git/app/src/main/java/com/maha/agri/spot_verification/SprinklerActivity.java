package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SprinklerActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private int district_id, taluka_id, village_id, farmer_id;
    private TextView tv_sprinkler_name_of_the_beneficiary, tv_sprinkler_application_no, tv_sprinkler_social_categroy_of_the_beneficiary,
            tv_sprinkler_name_of_the_component, tv_sprinkler_name_of_the_scheme, tv_sprinkler_crop_name,
            sprinkler_spacing_app, sprinkler_coupler_dia_app,sprinkler_manufacturer,sprinkler_dealer, tv_sprinkler_area_as_per_application,
            tv_sprinkler_bill_invoice_no, tv_sprinkler_bill_invoice_date, tv_sprinkler_bill_invoice_amount, tv_sprinkler_GSTN,
            tv_sprinkler_date_of_presanction, tv_sprinkler_date_of_spot_verification,sprinkler_bill_invoice_date_actual_edt,sprinkler_system_type,
            sprinkler_spacing_actual,sprinkler_coupler_dia_actual;

    private EditText sprinkler_crop_name_actual,sprinkler_area_of_application_actual_edt,sprinkler_area_benefitted_in_last_7_years,
            sprinkler_bill_invoice_no_actual_edt, sprinkler_bill_invoice_amount_actual_edt,sprinkler_GSTN_actual_edt;

    private LinearLayout sprinkler_spacing_app_ll,sprinkler_coupler_app_ll,sprinkler_coupler_actual_diameter_ll,sprinkler_spacing_actual_ll;
    private ImageView sprinkler_bill_invoice_date_actual_iv;
    private String sprinkler_bill_invoice_date_actual = "",str_sprinkler_date_of_spot_verification="",sprinkler_system_name="",sprinkler_spacing_name="",
            sprinkler_coupler_name="",str_sprinkler_name_of_the_beneficiary,str_sprinkler_application_no,str_sprinkler_social_categroy_of_the_beneficiary,
            str_sprinkler_name_of_the_component,str_sprinkler_name_of_the_scheme,str_sprinkler_crop_name,str_sprinkler_manufacturer,str_sprinkler_dealer,
            str_sprinkler_area_as_per_application,str_sprinkler_bill_invoice_no,str_sprinkler_bill_invoice_date,str_sprinkler_bill_invoice_amount,
            str_sprinkler_GSTN,str_sprinkler_date_of_presanction;
    private int mYear, mMonth, mDay;
    private DatePickerDialog datePickerDialog;
    private JSONArray sprinkler_field_data,sprinkler_system_type_list,sprinkler_spacing_list,sprinkler_coupler_list,sprinkler_manufacturer_list,
            sprinkler_dealer_list;
    private int sprinkler_system_id,sprinkler_spacing_id,sprinkler_coupler_id,sprinkler_manufacturer_id,sprinkler_dealer_id;
    private String sprinkler_manuf_name = "", sprinkler_dealer_name = "";

    private Button sprinkler_next_btn;

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String str_master_id = "";
    private String form_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sprinkler);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Sprinkler");
        preferenceManager = new PreferenceManager(SprinklerActivity.this);
        sharedPref = new SharedPref(SprinklerActivity.this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id", 0);
        taluka_id = intent.getIntExtra("taluka_id", 0);
        village_id = intent.getIntExtra("village_id", 0);
        farmer_id = intent.getIntExtra("farmer_id", 0);
        form_id = intent.getStringExtra("form_id");
        init();
        default_confiq();
        Sprinkler_list();
        sprinkler_system_service();
        sprinkler_manufacturers_service();
        sprinkler_dealers_service();
    }

    private void init() {

        tv_sprinkler_name_of_the_beneficiary = (TextView) findViewById(R.id.tv_sprinkler_name_of_the_beneficiary);
        tv_sprinkler_application_no = (TextView) findViewById(R.id.tv_sprinkler_application_no);
        tv_sprinkler_social_categroy_of_the_beneficiary = (TextView) findViewById(R.id.tv_sprinkler_social_categroy_of_the_beneficiary);
        tv_sprinkler_name_of_the_component = (TextView) findViewById(R.id.tv_sprinkler_name_of_the_component);
        tv_sprinkler_name_of_the_scheme = (TextView) findViewById(R.id.tv_sprinkler_name_of_the_scheme);
        tv_sprinkler_crop_name = (TextView) findViewById(R.id.tv_sprinkler_crop_name);
        sprinkler_system_type = (TextView) findViewById(R.id.sprinkler_system_type);
        sprinkler_spacing_app = (TextView) findViewById(R.id.sprinkler_spacing_app);
        sprinkler_spacing_actual = (TextView) findViewById(R.id.sprinkler_spacing_actual);
        sprinkler_coupler_dia_app = (TextView) findViewById(R.id.sprinkler_coupler_dia_app);
        sprinkler_coupler_dia_actual = (TextView) findViewById(R.id.sprinkler_coupler_dia_actual);
        sprinkler_manufacturer = (TextView) findViewById(R.id.sprinkler_manufacturer);
        sprinkler_dealer = (TextView) findViewById(R.id.sprinkler_dealer);
        tv_sprinkler_area_as_per_application = (TextView) findViewById(R.id.tv_sprinkler_area_as_per_application);
        tv_sprinkler_bill_invoice_no = (TextView) findViewById(R.id.tv_sprinkler_bill_invoice_no);
        tv_sprinkler_bill_invoice_date = (TextView) findViewById(R.id.tv_sprinkler_bill_invoice_date);
        tv_sprinkler_bill_invoice_amount = (TextView) findViewById(R.id.tv_sprinkler_bill_invoice_amount);
        tv_sprinkler_GSTN = (TextView) findViewById(R.id.tv_sprinkler_GSTN);
        tv_sprinkler_date_of_presanction = (TextView) findViewById(R.id.tv_sprinkler_date_of_presanction);
        tv_sprinkler_date_of_spot_verification = (TextView) findViewById(R.id.tv_sprinkler_date_of_spot_verification);
        sprinkler_bill_invoice_date_actual_edt = (TextView) findViewById(R.id.sprinkler_bill_invoice_date_actual_edt);
        //Edittext
        sprinkler_crop_name_actual = (EditText) findViewById(R.id.sprinkler_crop_name_actual);
        sprinkler_area_of_application_actual_edt = (EditText) findViewById(R.id.sprinkler_area_of_application_actual_edt);
        sprinkler_area_benefitted_in_last_7_years = (EditText) findViewById(R.id.sprinkler_area_benefitted_in_last_7_years);
        sprinkler_bill_invoice_no_actual_edt = (EditText) findViewById(R.id.sprinkler_bill_invoice_no_actual_edt);
        sprinkler_bill_invoice_amount_actual_edt = (EditText) findViewById(R.id.sprinkler_bill_invoice_amount_actual_edt);
        sprinkler_GSTN_actual_edt = (EditText) findViewById(R.id.sprinkler_GSTN_actual_edt);
        sprinkler_bill_invoice_date_actual_iv = (ImageView) findViewById(R.id.sprinkler_bill_invoice_date_actual_iv);
        sprinkler_spacing_app_ll = (LinearLayout) findViewById(R.id.sprinkler_spacing_app_ll);
        sprinkler_coupler_app_ll = (LinearLayout) findViewById(R.id.sprinkler_coupler_app_ll);
        sprinkler_coupler_actual_diameter_ll = (LinearLayout)findViewById(R.id.sprinkler_coupler_actual_diameter_ll);
        sprinkler_spacing_actual_ll = (LinearLayout)findViewById(R.id.sprinkler_spacing_actual_ll);

        str_sprinkler_date_of_spot_verification = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        tv_sprinkler_date_of_spot_verification.setText(str_sprinkler_date_of_spot_verification);
        sprinkler_next_btn = (Button) findViewById(R.id.sprinkler_next_btn);

        sprinkler_field_data = new JSONArray();
        sprinkler_system_type_list = new JSONArray();
        sprinkler_spacing_list = new JSONArray();
        sprinkler_coupler_list= new JSONArray();
        sprinkler_manufacturer_list = new JSONArray();
        sprinkler_dealer_list = new JSONArray();
    }

    private void default_confiq(){
        sprinkler_bill_invoice_date_actual_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date_Picker();
            }
        });

        sprinkler_next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SprinklerActivity.this,SprinklerSpotVerificationActivity.class);
                i.putExtra("district_id",district_id);
                i.putExtra("taluka_id",taluka_id);
                i.putExtra("village_id",village_id);
                i.putExtra("farmer_id",farmer_id);
                i.putExtra("manuf_code",sprinkler_manufacturer_id);
                i.putExtra("form_id",form_id);
                startActivity(i);
                //sprinkler_save_service();
            }
        });

        sprinkler_system_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sprinkler_system_type_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_system_type_list, 2, "Select sprinkler system type", "type_name", "id", SprinklerActivity.this, SprinklerActivity.this);
                }
            }
        });

        sprinkler_spacing_actual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sprinkler_spacing_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_spacing_list, 3, "Select sprinkler spacing type", "spacing", "id", SprinklerActivity.this, SprinklerActivity.this);
                }
            }
        });

        sprinkler_coupler_dia_actual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sprinkler_coupler_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_coupler_list, 4, "Select coupler diameter", "spacing", "id", SprinklerActivity.this, SprinklerActivity.this);
                }
            }
        });

        sprinkler_manufacturer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sprinkler_manufacturer_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_manufacturer_list, 5, "Select manufacturer", "manuf_name", "manuf_code", SprinklerActivity.this, SprinklerActivity.this);
                }
            }
        });

        sprinkler_dealer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sprinkler_dealer_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(sprinkler_dealer_list, 6, "Select dealer", "dealer_name", "id", SprinklerActivity.this, SprinklerActivity.this);
                }
            }
        });
    }

    private void date_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        c.add(Calendar.DAY_OF_YEAR, -730);
        Date newDate = c.getTime();

        datePickerDialog = new DatePickerDialog(SprinklerActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        sprinkler_bill_invoice_date_actual = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                        sprinkler_bill_invoice_date_actual_edt.setText(sprinkler_bill_invoice_date_actual);
                    }
                }, mYear, mMonth, mDay);

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        datePickerDialog.show();
    }

    private void Sprinkler_list() {

        JSONObject param = new JSONObject();
        try {
            param.put("village_id", village_id);
            param.put("farmer_id", farmer_id);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.sprinkler_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        api.postRequest(responseCall, this, 1);
    }

    private void sprinkler_system_service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.spot_veri_type_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void sprinkler_spacing_service(){
        JSONObject param = new JSONObject();
        try {
        param.put("type_id",sprinkler_system_id);
        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.spot_veri_type_spacing(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void sprinkler_coupler_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("type_id",sprinkler_system_id);
        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.spot_veri_type_spacing(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void sprinkler_manufacturers_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_manufacture_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void sprinkler_dealers_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("manuf_id",sprinkler_manufacturer_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_dealer_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 6);
    }

    private void sprinkler_save_service(){
        if(sprinkler_crop_name_actual.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter name of the crop(actual)",Toast.LENGTH_LONG).show();
        }else if(sprinkler_system_name.equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Select sprinkler system type",Toast.LENGTH_LONG).show();
        }else if(str_sprinkler_manufacturer.equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Select manufacturer",Toast.LENGTH_LONG).show();
        }else if(str_sprinkler_dealer.equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Select dealer",Toast.LENGTH_LONG).show();
        }else if(sprinkler_area_of_application_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter area in HA(Actual)",Toast.LENGTH_LONG).show();
        }else if(sprinkler_area_benefitted_in_last_7_years.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter area benefited in last 7 years",Toast.LENGTH_LONG).show();
        }else if(sprinkler_bill_invoice_no_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter bill invoice no(Actual)",Toast.LENGTH_LONG).show();
        }else if(sprinkler_bill_invoice_date_actual.equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Select bill invoice date",Toast.LENGTH_LONG).show();
        }else if(sprinkler_bill_invoice_amount_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter bill invoice amount(Rs.)(Actual)",Toast.LENGTH_LONG).show();
        }else if(sprinkler_GSTN_actual_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SprinklerActivity.this,"Enter GSTN(Actual)",Toast.LENGTH_LONG).show();
        }else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("village_id", village_id);
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("date_spot",str_sprinkler_date_of_spot_verification);
                param.put("name_benef", tv_sprinkler_name_of_the_beneficiary);
                param.put("app_no", str_sprinkler_application_no);
                param.put("social_cat", str_sprinkler_social_categroy_of_the_beneficiary);
                param.put("name_comp", str_sprinkler_name_of_the_component);
                param.put("scheme_name", str_sprinkler_name_of_the_scheme);
                param.put("crop_name_app", str_sprinkler_crop_name);
                param.put("crop_name_actual", sprinkler_crop_name_actual.getText().toString().trim());
                param.put("sprinkler_system_id", sprinkler_system_id);
                param.put("spacing_app", sprinkler_spacing_app.getText().toString().trim());
                param.put("spacing_actual", sprinkler_spacing_id);
                param.put("coupler_dia", sprinkler_coupler_id);
                param.put("manufacturer_id", sprinkler_manufacturer_id);
                param.put("dealer_id", sprinkler_dealer_id);
                param.put("area_app", str_sprinkler_area_as_per_application);
                param.put("area_actual", sprinkler_area_of_application_actual_edt.getText().toString().trim());
                param.put("area_seven_years", sprinkler_area_benefitted_in_last_7_years.getText().toString().trim());
                param.put("bill_invoice_no_app", str_sprinkler_bill_invoice_no);
                param.put("bill_invoice_no_actual", sprinkler_bill_invoice_no_actual_edt.getText().toString().trim());
                param.put("bill_invoice_date_app", str_sprinkler_bill_invoice_date);
                param.put("bill_invoice_date_actual", sprinkler_bill_invoice_date_actual);
                param.put("bill_invoice_amt_app", str_sprinkler_bill_invoice_amount);
                param.put("bill_invoice_amt_actual", sprinkler_bill_invoice_amount_actual_edt.getText().toString().trim());
                param.put("bill_invoice_doc", str_sprinkler_bill_invoice_date);
                param.put("gstn_app", str_sprinkler_GSTN);
                param.put("gstn_actual", sprinkler_GSTN_actual_edt.getText().toString().trim());
                param.put("date_pre_sanction", str_sprinkler_date_of_presanction);
                param.put("pre_letter_doc", str_sprinkler_date_of_presanction);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.spot_verification_drip_bill_against_id_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 7);

        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {
                // activity image upload response
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        sprinkler_field_data = jsonObject.getJSONArray("data");

                        for (int j = 0; j < sprinkler_field_data.length(); j++) {
                            JSONObject jsonObject1 = sprinkler_field_data.getJSONObject(j);

                            str_sprinkler_name_of_the_beneficiary = jsonObject1.getString("beneficiary_name");
                            tv_sprinkler_name_of_the_beneficiary.setText(str_sprinkler_name_of_the_beneficiary);

                            str_sprinkler_application_no = jsonObject1.getString("Application_number");
                            tv_sprinkler_application_no.setText(str_sprinkler_application_no);

                            str_sprinkler_social_categroy_of_the_beneficiary = jsonObject1.getString("categroy_beneficiary");
                            tv_sprinkler_social_categroy_of_the_beneficiary.setText(str_sprinkler_social_categroy_of_the_beneficiary);

                            str_sprinkler_name_of_the_component = jsonObject1.getString("component_name");
                            tv_sprinkler_name_of_the_component.setText(str_sprinkler_name_of_the_component);

                            /*String str_sprinkler_specification_of_the_component = jsonObject1.getString("Specification_component");
                            tv_sprinkler_specification_of_the_component.setText(str_sprinkler_specification_of_the_component);*/

                            str_sprinkler_name_of_the_scheme = jsonObject1.getString("Name_of_the_scheme");
                            tv_sprinkler_name_of_the_scheme.setText(str_sprinkler_name_of_the_scheme);

                            str_sprinkler_crop_name = jsonObject1.getString("Crop_name");
                            tv_sprinkler_crop_name.setText(str_sprinkler_crop_name);

                            str_sprinkler_area_as_per_application = jsonObject1.getString("Area_as_per_application");
                            tv_sprinkler_area_as_per_application.setText(str_sprinkler_area_as_per_application);

                            String str_sprinkler_area_benefitted_in_last_7_years = jsonObject1.getString("Area_benefitted_7yrs");
                            //tv_sprinkler_area_benefitted_in_last_7_years.setText(str_sprinkler_area_benefitted_in_last_7_years);

                            str_sprinkler_bill_invoice_no = jsonObject1.getString("Bill_invoice_no");
                            tv_sprinkler_bill_invoice_no.setText(str_sprinkler_bill_invoice_no);

                            str_sprinkler_bill_invoice_date = jsonObject1.getString("Bill_invoice_date");
                            tv_sprinkler_bill_invoice_date.setText(str_sprinkler_bill_invoice_date);

                            str_sprinkler_bill_invoice_amount = jsonObject1.getString("Bill_invoice_amount");
                            tv_sprinkler_bill_invoice_amount.setText(str_sprinkler_bill_invoice_amount);

                            str_sprinkler_GSTN = jsonObject1.getString("GSTN");
                            tv_sprinkler_GSTN.setText(str_sprinkler_GSTN);

                            str_sprinkler_date_of_presanction = jsonObject1.getString("Date_of_presanction");
                            tv_sprinkler_date_of_presanction.setText(str_sprinkler_date_of_presanction);

                            String str_sprinkler_date_of_spot_verification = jsonObject1.getString("Date_spot_veri");
                            //tv_sprinkler_date_of_spot_verification.setText(str_sprinkler_date_of_spot_verification);
                            
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_system_type_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_spacing_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_coupler_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_manufacturer_list = jsonObject.getJSONArray("data");
                        }
                    }else{
                        Toast.makeText(SprinklerActivity.this,"No manufacturer present in this district",Toast.LENGTH_LONG).show();
                    }
                }

                if (i == 6) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sprinkler_dealer_list = jsonObject.getJSONArray("data");
                        }
                    }else{
                        Toast.makeText(SprinklerActivity.this,"No dealers present against this manufacturer",Toast.LENGTH_LONG).show();
                    }
                }
                
                if (i == 7) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("Submitted Successfully")
                                .setContentText(jsonObject.getString("response"))
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();
                    } else {
                        UIToastMessage.show(SprinklerActivity.this, jsonObject.getString("response"));
                    }
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 2) {
            sprinkler_system_id = Integer.parseInt(s1);
            sprinkler_system_name = s;
            sprinkler_system_type.setText(sprinkler_system_name);
            if(sprinkler_system_id==3||sprinkler_system_id==4){
                sprinkler_coupler_actual_diameter_ll.setVisibility(View.GONE);
                sprinkler_coupler_app_ll.setVisibility(View.GONE);
                sprinkler_spacing_actual_ll.setVisibility(View.VISIBLE);
                sprinkler_spacing_app_ll.setVisibility(View.VISIBLE);
                sprinkler_spacing_service();
                sprinkler_spacing_list = new JSONArray();
                sprinkler_spacing_actual.setText("Select");
            }else {
                sprinkler_coupler_actual_diameter_ll.setVisibility(View.VISIBLE);
                sprinkler_coupler_app_ll.setVisibility(View.VISIBLE);
                sprinkler_spacing_actual_ll.setVisibility(View.GONE);
                sprinkler_spacing_app_ll.setVisibility(View.GONE);
                sprinkler_coupler_service();
                sprinkler_coupler_list = new JSONArray();
                sprinkler_coupler_dia_actual.setText("Select");
            }
        }

        if (i == 3) {
            sprinkler_spacing_id = Integer.parseInt(s1);
            sprinkler_spacing_name = s;
            sprinkler_spacing_actual.setText(sprinkler_spacing_name);
        }

        if (i == 4) {
            sprinkler_coupler_id = Integer.parseInt(s1);
            sprinkler_coupler_name = s;
            sprinkler_coupler_dia_actual.setText(sprinkler_coupler_name);

        }

        if (i == 5) {
            sprinkler_manufacturer_id = Integer.parseInt(s1);
            sprinkler_manuf_name = s;
            sprinkler_manufacturer.setText(sprinkler_manuf_name);
            sprinkler_dealers_service();
            sprinkler_dealer_list = new JSONArray();
            sprinkler_dealer.setText("Select");

        }

        if (i == 6) {
            sprinkler_dealer_id = Integer.parseInt(s1);
            sprinkler_dealer_name = s;
            sprinkler_dealer.setText(sprinkler_dealer_name);

        }
    }
}
