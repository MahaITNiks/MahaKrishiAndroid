package com.maha.agri.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;


public class LoginDetailModel {


    private String id;
    private String last_name;
    private String first_name;
    private String middle_name;
    private String email;
    private String mobile;
    private String role_desg;
    private String profile_pic;
    private String userId;
    private JSONArray work_location;
    private JSONArray villages_location;
    private JSONObject jsonObject;


    public LoginDetailModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public JSONArray getData() {
        try {
            return this.jsonObject.getJSONArray("data");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


    public String getId() {
        return id = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "id");
    }

    public String getLast_name() {
        return last_name = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "last_name");
    }

    public String getFirst_name() {
        return first_name = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "first_name");
    }

    public String getMiddle_name() {
        return middle_name = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "middle_name");
    }

    public String getEmail() {
        return email = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "email");
    }

    public String getMobile() {
        return mobile = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "mobile");
    }

    public String getRole_desg() {
        return role_desg = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "role_desg");
    }

    public String getProfile_pic() {
        return profile_pic = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "profile_pic");
    }

    public String getUserId() {
        return userId = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "userId");
    }

    public JSONArray getWork_location() {
        return work_location = AppUtility.getInstance().sanitizeArrayJSONObj(jsonObject, "work_location");
    }

    public JSONArray getVillages_location() {
        return villages_location = AppUtility.getInstance().sanitizeArrayJSONObj(jsonObject, "villages_location");
    }


}
