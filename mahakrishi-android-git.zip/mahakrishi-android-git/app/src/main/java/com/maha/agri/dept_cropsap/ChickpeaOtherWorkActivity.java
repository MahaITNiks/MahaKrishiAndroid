package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ChickpeaOtherWorkActivity extends AppCompatActivity implements ApiCallbackCode {

    private EditText tradename_insecticide_chickpeaOW, quantity_used_acre_insecticide_chickpeaOW,tradename_fungicide_chickpeaOW,quantity_used_acre_fungicide_chickpeaOW,
            tradename_weedicide_chickpeaOW, quantity_used_acre_weedicide_chickpeaOW,fertilizer_chickpeaOW_N,fertilizer_chickpeaOW_P,fertilizer_chickpeaOW_K,
            fertilizername_chickpeaOW, quantity_used_acre_fertilizer_chickpeaOW;
    private ImageView pest_chickpeaOW_photo,crop_growth_chickpeaOW_photo;
    private Button btn_submit_chickpeaOW_pheromone;
    private Spinner sp_technicalname_insecticide_chickpeaOW,sp_technicalname_fungicide_chickpeaOW,sp_weedicide_technicalname_chickpeaOW,
            sp_irrigation_given_chickpeaOW;
    private RadioGroup insecticide_radio_group_chickpeaOW,fungicide_radio_group_chickpeaOW,weedicide_radio_group_chickpeaOW,
            fertilizer_radio_group_chickpeaOW, radio_group_intercultural_chickpeaOW, radio_group_irrigation_field_chickpeaOW;
    private RadioButton insecticide_chickpeaOW_yes,insecticide_chickpeaOW_no,fungicide_chickpeaOW_yes,fungicide_chickpeaOW_no,
            weedicide_chickpeaOW_yes,weedicide_chickpeaOW_no,fertilizer_chickpeaOW_yes,fertilizer_chickpeaOW_no,
            weeding_chickpeaOW_rb,hoeing_chickpeaOW_rb,detopping_chickpeaOW_rb,none_chickpeaOW_rb,irrigation_chickpeaOW_yes,
            irrigation_chickpeaOW_no;
    private LinearLayout ll_insecticide_layout_chickpeaOW,ll_fungicide_layout_chickpeaOW,ll_weedicide_layout_chickpeaOW,
            ll_fertilizer_layout_chickpeaOW;
    private RelativeLayout irrigation_layout_chickpeaOW;
    private TextView btn_otherpest;
    private String insecticide = "",fungicide = "",weedicide = "",fertilizer = "",irrigation = "",intercultural = "";

    private String insecticide_tech_name="",fungicide_tech_name="",weedicide_tech_name="",irrigation_name="";

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private AppLocationManager locationManager;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    private String imagePath1="", imagePath2="",type="";
    private String image_1_file_name="",image_2_file_name="";
    public double lat,lang;

    private int district_id=0, taluka_id=0, village_id=0, farmer_id=0;
    private String heli_trap1="",heli_trap2="",other="",heli_trap1_photo="",heli_trap2_photo="";
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chickpea_other_work);
        getSupportActionBar().setTitle("Other Works");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(ChickpeaOtherWorkActivity.this);
        sharedPref = new SharedPref(ChickpeaOtherWorkActivity.this);
        locationManager = new AppLocationManager(this);

        initView();
        setListners();

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        heli_trap1 = intent.getStringExtra("heli_trap1");
        heli_trap2 = intent.getStringExtra("heli_trap2");
        other = intent.getStringExtra("other");
        heli_trap1_photo = intent.getStringExtra("heli_trap1_photo");
        heli_trap2_photo = intent.getStringExtra("heli_trap2_photo");
    }

    private void initView() {
        //Spinner
        sp_technicalname_insecticide_chickpeaOW = (Spinner)findViewById(R.id.sp_technicalname_insecticide_chickpeaOW);
        sp_technicalname_fungicide_chickpeaOW = (Spinner)findViewById(R.id.sp_technicalname_fungicide_chickpeaOW);
        sp_weedicide_technicalname_chickpeaOW = (Spinner)findViewById(R.id.sp_weedicide_technicalname_chickpeaOW);
        sp_irrigation_given_chickpeaOW = (Spinner)findViewById(R.id.sp_irrigation_given_chickpeaOW);

        //Edit text
        tradename_insecticide_chickpeaOW = (EditText)findViewById(R.id.tradename_insecticide_chickpeaOW);
        quantity_used_acre_insecticide_chickpeaOW = (EditText)findViewById(R.id.quantity_used_acre_insecticide_chickpeaOW);
        tradename_fungicide_chickpeaOW = (EditText)findViewById(R.id.tradename_fungicide_chickpeaOW);
        quantity_used_acre_fungicide_chickpeaOW = (EditText)findViewById(R.id.quantity_used_acre_fungicide_chickpeaOW);
        tradename_weedicide_chickpeaOW = (EditText)findViewById(R.id.tradename_weedicide_chickpeaOW);
        quantity_used_acre_weedicide_chickpeaOW = (EditText)findViewById(R.id.quantity_used_acre_weedicide_chickpeaOW);
        fertilizer_chickpeaOW_N = (EditText)findViewById(R.id.fertilizer_chickpeaOW_N);
        fertilizer_chickpeaOW_P = (EditText)findViewById(R.id.fertilizer_chickpeaOW_P);
        fertilizer_chickpeaOW_K = (EditText)findViewById(R.id.fertilizer_chickpeaOW_K);
        fertilizername_chickpeaOW = (EditText)findViewById(R.id.fertilizername_chickpeaOW);
        quantity_used_acre_fertilizer_chickpeaOW = (EditText)findViewById(R.id.quantity_used_acre_fertilizer_chickpeaOW);

        //Imageview
        //pest_chickpeaOW_photo = (ImageView) findViewById(R.id.pest_chickpeaOW_photo);
        crop_growth_chickpeaOW_photo = (ImageView) findViewById(R.id.crop_growth_chickpeaOW_photo);

        //Radiogroup
        insecticide_radio_group_chickpeaOW = (RadioGroup) findViewById(R.id.insecticide_radio_group_chickpeaOW);
        fungicide_radio_group_chickpeaOW = (RadioGroup) findViewById(R.id.fungicide_radio_group_chickpeaOW);
        weedicide_radio_group_chickpeaOW = (RadioGroup) findViewById(R.id.weedicide_radio_group_chickpeaOW);
        fertilizer_radio_group_chickpeaOW = (RadioGroup) findViewById(R.id.fertilizer_radio_group_chickpeaOW);
        radio_group_intercultural_chickpeaOW = (RadioGroup) findViewById(R.id.radio_group_intercultural_chickpeaOW);
        radio_group_irrigation_field_chickpeaOW = (RadioGroup) findViewById(R.id.radio_group_irrigation_field_chickpeaOW);

        //Radiobutton
        insecticide_chickpeaOW_yes = (RadioButton) findViewById(R.id.insecticide_chickpeaOW_yes);
        insecticide_chickpeaOW_no = (RadioButton) findViewById(R.id.insecticide_chickpeaOW_no);
        fungicide_chickpeaOW_yes = (RadioButton) findViewById(R.id.fungicide_chickpeaOW_yes);
        fungicide_chickpeaOW_no = (RadioButton) findViewById(R.id.fungicide_chickpeaOW_no);
        weedicide_chickpeaOW_yes = (RadioButton) findViewById(R.id.weedicide_chickpeaOW_yes);
        weedicide_chickpeaOW_no = (RadioButton) findViewById(R.id.weedicide_chickpeaOW_no);
        fertilizer_chickpeaOW_yes = (RadioButton) findViewById(R.id.fertilizer_chickpeaOW_yes);
        fertilizer_chickpeaOW_no = (RadioButton) findViewById(R.id.fertilizer_chickpeaOW_no);
        weeding_chickpeaOW_rb = (RadioButton) findViewById(R.id.weeding_chickpeaOW_rb);
        hoeing_chickpeaOW_rb = (RadioButton) findViewById(R.id.hoeing_chickpeaOW_rb);
        detopping_chickpeaOW_rb = (RadioButton) findViewById(R.id.detopping_chickpeaOW_rb);
        none_chickpeaOW_rb = (RadioButton) findViewById(R.id.none_chickpeaOW_rb);
        irrigation_chickpeaOW_yes = (RadioButton) findViewById(R.id.irrigation_chickpeaOW_yes);
        irrigation_chickpeaOW_no = (RadioButton) findViewById(R.id.irrigation_chickpeaOW_no);

        //Linear Layout
        ll_insecticide_layout_chickpeaOW = (LinearLayout)findViewById(R.id.ll_insecticide_layout_chickpeaOW);
        ll_fungicide_layout_chickpeaOW = (LinearLayout)findViewById(R.id.ll_fungicide_layout_chickpeaOW);
        ll_weedicide_layout_chickpeaOW = (LinearLayout)findViewById(R.id.ll_weedicide_layout_chickpeaOW);
        ll_fertilizer_layout_chickpeaOW = (LinearLayout)findViewById(R.id.ll_fertilizer_layout_chickpeaOW);
        irrigation_layout_chickpeaOW = (RelativeLayout) findViewById(R.id.irrigation_layout_chickpeaOW);

        //Button
        btn_submit_chickpeaOW_pheromone = (Button)findViewById(R.id.btn_submit_chickpeaOW_pheromone);
    }

    private void setListners() {

        insecticide_radio_group_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.insecticide_chickpeaOW_yes:
                        insecticide_chickpeaOW_yes.setChecked(true);
                        ll_insecticide_layout_chickpeaOW.setVisibility(View.VISIBLE);
                        insecticide = insecticide_chickpeaOW_yes.getText().toString();
                        break;

                    case R.id.insecticide_chickpeaOW_no:
                        insecticide_chickpeaOW_no.setChecked(true);
                        ll_insecticide_layout_chickpeaOW.setVisibility(View.GONE);
                        insecticide = insecticide_chickpeaOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_insecticide_chickpeaOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                insecticide_tech_name = sp_technicalname_insecticide_chickpeaOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fungicide_radio_group_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fungicide_chickpeaOW_yes:
                        fungicide_chickpeaOW_yes.setChecked(true);
                        ll_fungicide_layout_chickpeaOW.setVisibility(View.VISIBLE);
                        fungicide = fungicide_chickpeaOW_yes.getText().toString();
                        break;

                    case R.id.fungicide_chickpeaOW_no:
                        fungicide_chickpeaOW_no.setChecked(true);
                        ll_fungicide_layout_chickpeaOW.setVisibility(View.GONE);
                        fungicide = fungicide_chickpeaOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_technicalname_fungicide_chickpeaOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                fungicide_tech_name = sp_technicalname_fungicide_chickpeaOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        weedicide_radio_group_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.weedicide_chickpeaOW_yes:
                        weedicide_chickpeaOW_yes.setChecked(true);
                        ll_weedicide_layout_chickpeaOW.setVisibility(View.VISIBLE);
                        weedicide = weedicide_chickpeaOW_yes.getText().toString();
                        break;

                    case R.id.weedicide_chickpeaOW_no:
                        weedicide_chickpeaOW_no.setChecked(true);
                        ll_weedicide_layout_chickpeaOW.setVisibility(View.GONE);
                        weedicide = weedicide_chickpeaOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_weedicide_technicalname_chickpeaOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                weedicide_tech_name = sp_weedicide_technicalname_chickpeaOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fertilizer_radio_group_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.fertilizer_chickpeaOW_yes:
                        fertilizer_chickpeaOW_yes.setChecked(true);
                        ll_fertilizer_layout_chickpeaOW.setVisibility(View.VISIBLE);
                        fertilizer = fertilizer_chickpeaOW_yes.getText().toString();
                        break;

                    case R.id.fertilizer_chickpeaOW_no:
                        fertilizer_chickpeaOW_no.setChecked(true);
                        ll_fertilizer_layout_chickpeaOW.setVisibility(View.GONE);
                        fertilizer = fertilizer_chickpeaOW_no.getText().toString();
                        break;
                }
            }
        });

        radio_group_intercultural_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.weeding_chickpeaOW_rb:
                        weeding_chickpeaOW_rb.setChecked(true);
                        intercultural = weeding_chickpeaOW_rb.getText().toString();
                        break;

                    case R.id.hoeing_chickpeaOW_rb:
                        hoeing_chickpeaOW_rb.setChecked(true);
                        intercultural = hoeing_chickpeaOW_rb.getText().toString();
                        break;

                    case R.id.detopping_chickpeaOW_rb:
                        detopping_chickpeaOW_rb.setChecked(true);
                        intercultural = detopping_chickpeaOW_rb.getText().toString();
                        break;

                    case R.id.none_chickpeaOW_rb:
                        none_chickpeaOW_rb.setChecked(true);
                        intercultural = none_chickpeaOW_rb.getText().toString();
                        break;
                }
            }
        });

        radio_group_irrigation_field_chickpeaOW.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.irrigation_chickpeaOW_yes:
                        irrigation_chickpeaOW_yes.setChecked(true);
                        irrigation_layout_chickpeaOW.setVisibility(View.VISIBLE);
                        irrigation = irrigation_chickpeaOW_yes.getText().toString();
                        break;

                    case R.id.irrigation_chickpeaOW_no:
                        irrigation_chickpeaOW_no.setChecked(true);
                        irrigation_layout_chickpeaOW.setVisibility(View.GONE);
                        irrigation = irrigation_chickpeaOW_no.getText().toString();
                        break;
                }
            }
        });

        sp_irrigation_given_chickpeaOW.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                irrigation_name = sp_irrigation_given_chickpeaOW.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /*pest_chickpeaOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });*/

        crop_growth_chickpeaOW_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)&& (ContextCompat.checkSelfPermission(ChickpeaOtherWorkActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    type = "2";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_submit_chickpeaOW_pheromone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chickpea_save_service();
            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            /*if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            } else */if (type.equalsIgnoreCase("2")) {
                photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;
                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
                } else {
                    photoURI = Uri.fromFile(photoFile2);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            //photoFile1 = null;
            photoFile2 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        /*if (type.equalsIgnoreCase("1")) {

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(pest_chickpeaOW_photo.getWidth(), pest_chickpeaOW_photo.getHeight())
                                    .centerCrop()
                                    .into(pest_chickpeaOW_photo);

                            uploadImage1OnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else */if(type.equalsIgnoreCase("2")) {


            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .resize(crop_growth_chickpeaOW_photo.getWidth(), crop_growth_chickpeaOW_photo.getHeight())
                                    .centerCrop()
                                    .into(crop_growth_chickpeaOW_photo);

                            uploadImage2OnServer(imagePath2);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /*private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "1");

            File file = new File(photoFile1.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 1);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

    private void uploadImage2OnServer(String imagePath2) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath2);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            //params.put("plant_id", String.valueOf(crop_chickpea_plant_id));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("last_id", preferenceManager.getPreferenceValues(Preference_Constant.CROPSAP_COTTON_CROP_LAST_INSERTED_ID));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            //params.put("section_flag", "2");
            //params.put("id", String.valueOf(responseID));
            //creating a file
            File file = new File(photoFile2.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.crop_chickpea_save_ls_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(ChickpeaOtherWorkActivity.this,ChickpeaGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void chickpea_save_service() {

        if (insecticide.isEmpty()) {
            Toast.makeText(this, "Select insecticide", Toast.LENGTH_SHORT).show();
        } else if (fungicide.isEmpty()) {
            Toast.makeText(this, "Select fungicide", Toast.LENGTH_SHORT).show();
        } else if (weedicide.isEmpty()) {
            Toast.makeText(this, "Select weedicide", Toast.LENGTH_SHORT).show();
        } else if (fertilizer.isEmpty()) {
            Toast.makeText(this, "Select fertilizer", Toast.LENGTH_SHORT).show();
        } else if (intercultural.isEmpty()) {
            Toast.makeText(this, "Select intercultural operations", Toast.LENGTH_SHORT).show();
        } else if (irrigation.isEmpty()) {
            Toast.makeText(this, "Select irrigation", Toast.LENGTH_SHORT).show();
        } /*else if (photoFile1 == null) {
            Toast.makeText(this, "Click pest/disease photo", Toast.LENGTH_SHORT).show();
        }*/ else if (photoFile2 == null) {
            Toast.makeText(this, "Click crop growth photo", Toast.LENGTH_SHORT).show();
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("last_id", "1");
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("helicover_trap1_cp", heli_trap1);
                param.put("helicoverpa_trap2_cp", heli_trap2);
                param.put("other_pest_cp", other);
                param.put("tn_insect_cp", tradename_insecticide_chickpeaOW.getText().toString().trim());
                param.put("tn_fungi_cp", tradename_fungicide_chickpeaOW.getText().toString().trim());
                param.put("tn_weed_cp", tradename_weedicide_chickpeaOW.getText().toString().trim());
                param.put("quantity_insect_cp", quantity_used_acre_insecticide_chickpeaOW.getText().toString().trim());
                param.put("quantity_fungi_cp", quantity_used_acre_fungicide_chickpeaOW.getText().toString().trim());
                param.put("quantity_weed_cp", quantity_used_acre_weedicide_chickpeaOW.getText().toString().trim());
                param.put("fert_n_cp", fertilizer_chickpeaOW_N.getText().toString().trim());
                param.put("fert_p_cp", fertilizer_chickpeaOW_P.getText().toString().trim());
                param.put("fert_k_cp", fertilizer_chickpeaOW_K.getText().toString().trim());
                param.put("fertname_cp", fertilizername_chickpeaOW.getText().toString().trim());
                param.put("quantity_fert_cp", quantity_used_acre_fertilizer_chickpeaOW.getText().toString().trim());
                param.put("techn_insect_cp", insecticide_tech_name);
                param.put("techn_fungi_cp", fungicide_tech_name);
                param.put("techn_weed_cp", weedicide_tech_name);
                param.put("irrigation_cp", irrigation_name);
                param.put("insect_rb_cp", insecticide);
                param.put("fungi_rb_cp", fungicide);
                param.put("weed_rb_cp", weedicide);
                param.put("fert_rb_cp", fertilizer);
                param.put("inter_rb_cp", intercultural);
                param.put("irrigation_rb_cp", irrigation);
                param.put("helicover_image1_cp", heli_trap1_photo);
                param.put("helicover_image2_cp", heli_trap2_photo);
                param.put("pest_image_cp", "0");
                param.put("crop_image_cp", image_2_file_name);
            } catch (Exception e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.crop_chickpea_last_step_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 5);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null) {

            try {

                /*if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");

                        }
                    }
                }*/

                if (i == 2) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_2_file_name = data.getString("file_name");
                        }

                    }

                }

               /* if (i == 3) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_3_file_name = data.getString("file_name");
                        }

                    }

                }

                if (i == 4) {


                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_4_file_name = data.getString("file_name");
                        }

                    }

                }*/

                if(i == 5){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")){
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Chickpea/Gram Other Works Completed")
                                    .setContentText(jsonObject.getString("response"))
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            finish();
                                        }
                                    })
                                    .show();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
