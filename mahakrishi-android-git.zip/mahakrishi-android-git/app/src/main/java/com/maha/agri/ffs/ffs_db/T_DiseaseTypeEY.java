package com.maha.agri.ffs.ffs_db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class T_DiseaseTypeEY {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int uid;
    private String name;
    private String value;
    private int crop_id;
    private int cropping_system;
    private int plot_obs;
    private int is_severity;


    public T_DiseaseTypeEY() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    public int getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(int crop_id) {
        this.crop_id = crop_id;
    }

    public int getCropping_system() {
        return cropping_system;
    }

    public void setCropping_system(int cropping_system) {
        this.cropping_system = cropping_system;
    }

    public int getPlot_obs() {
        return plot_obs;
    }

    public void setPlot_obs(int plot_obs) {
        this.plot_obs = plot_obs;
    }

    public int getIs_severity() {
        return is_severity;
    }

    public void setIs_severity(int is_severity) {
        this.is_severity = is_severity;
    }

}
