package com.maha.agri.cropsowingreport;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.task_manager.NonSchemeListActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GenerateSowingReportActivity extends AppCompatActivity implements ApiCallbackCode {

    //private TextView total_affected_crop_count, total_affected_area_count;
    private Button sowing_report_submit_btn, sowing_report_cancel_btn;
    private String district_name, taluka_name, sajja_name, season_name, genrate_sowing_report_data;
    private int divison_id = 0, district_id = 0, taluka_id = 0, circle_id = 0, sajja_id = 0;
    private int affectedArea_int = 0, previous_value, current_value, total_value,season_id,crop_type_id,horti_type_id;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray multiple_crop_field_add = new JSONArray();
    JSONArray village_wise_crop_data = new JSONArray();
    private JSONObject add_multiple_json_object;
    private String current_date = "",other_crop="";
    private String cureent_day = "",current_week1="",current_week2="",last_week1="",last_week2="",field_type="";
    private SweetAlertDialog sweetAlertDialog;
    private ExpandableListView crop_sown_report_expandableListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_sowing_report);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Generate Sowing Report");
        preferenceManager = new PreferenceManager(GenerateSowingReportActivity.this);
        sharedPref = new SharedPref(GenerateSowingReportActivity.this);
        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_name = intent.getStringExtra("district_name");
        district_id = intent.getIntExtra("district_id",0);
        taluka_name = intent.getStringExtra("taluka_name");
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_name = intent.getStringExtra("sajja_name");
        sajja_id = intent.getIntExtra("sajja_id",0);
        season_name = intent.getStringExtra("season_name");
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        genrate_sowing_report_data = intent.getStringExtra("add_multiple_crop_array");
        other_crop = intent.getStringExtra("other_crop");
        field_type = intent.getStringExtra("field_type");
        current_week1 = intent.getStringExtra("current_week1");
        current_week2 = intent.getStringExtra("current_week2");
        last_week1 = intent.getStringExtra("last_week1");
        last_week2 = intent.getStringExtra("last_week2");
        init();
        default_config();

    }

    private void init() {
        crop_sown_report_expandableListView = (ExpandableListView)findViewById(R.id.crop_sown_report_expandableListView);
        sowing_report_submit_btn = (Button) findViewById(R.id.sowing_report_submit_btn);
        sowing_report_cancel_btn = (Button) findViewById(R.id.sowing_report_cancel_btn);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        current_date = df.format(c);
        cureent_day = sdf.format(d);

        sowing_report_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SowingReportSave();
            }
        });

        sowing_report_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });

    }

    private void default_config() {

        try {
            multiple_crop_field_add = new JSONArray(genrate_sowing_report_data);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Village_wise_crop_data();

    }

    private void Village_wise_crop_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("village_wise_c_data", multiple_crop_field_add);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_village_wise_crop_data(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void SowingReportSave() {
        JSONObject param = new JSONObject();
        try {
            param.put("year","2020-21");
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("division_id", divison_id);
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("sajja_id", sajja_id);
            param.put("season_id", season_id);
            param.put("crop_type_id",crop_type_id);
            param.put("start_current_week",current_week1);
            param.put("end_current_week",current_week2);
            param.put("start_lastweek",last_week1);
            param.put("end_lastweek",last_week2);
            param.put("current_day",cureent_day);
            param.put("current_date",current_date);
            param.put("multipleSownCrop", multiple_crop_field_add);
            param.put("weeksNo", "");
            param.put("monthsVal", "");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_submit(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_wise_crop_data = jsonObject.getJSONArray("data");
                            CropSowingExpandableAdapter cropsowingexpandableadapter = new CropSowingExpandableAdapter(GenerateSowingReportActivity.this,village_wise_crop_data);
                            crop_sown_report_expandableListView.destroyDrawingCache();
                            crop_sown_report_expandableListView.setAdapter(cropsowingexpandableadapter);
                            cropsowingexpandableadapter.notifyDataSetChanged();
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setCancelable(false);
                                    sweetAlertDialog.setTitleText("Crop Sowing Report");
                                    sweetAlertDialog.setContentText("Submitted Successfully");
                                    sweetAlertDialog.setConfirmText("Ok");
                                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Intent intent = new Intent(GenerateSowingReportActivity.this,NonSchemeListActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    });
                                    sweetAlertDialog.show();


                        }
                    }
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
