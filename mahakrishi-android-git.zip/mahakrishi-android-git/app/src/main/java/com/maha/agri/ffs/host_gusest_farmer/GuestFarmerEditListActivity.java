/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.host_gusest_farmer;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.GuestFarmerEditAdapter;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.HostFarmerEditModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.widget.UIToastMessage;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GuestFarmerEditListActivity extends AppCompatActivity implements OnMultiRecyclerItemClickListener, ApiCallbackCode {
    private PreferenceManager preferenceManager;

    private RecyclerView recyclerView;
    private HostFarmerEditModel model = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_farmer_list);
        preferenceManager = new PreferenceManager(GuestFarmerEditListActivity.this);

        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        recyclerView = findViewById(R.id.recyclerView);
    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        EventBus.getDefault().register(this);


        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());


        String data = null;
        if (getIntent().getStringExtra("mDetails") != null) {
            data = getIntent().getStringExtra("mDetails");
        }

        try {
            JSONObject jsonObject = new JSONObject(data);
            model = new HostFarmerEditModel(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String guest = this.getResources().getString(R.string.guest_farmer_list_title);
        setTitle(model.getVillage_name()+" "+guest);

        fetchData(model.getHost_farmer_id());

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFire(EventModel event) {

        if (event != null) {

            DebugLog.getInstance().d("onEventFire=" + event.getEvent());

            if (event.getEvent().equalsIgnoreCase("update_1")) {
                fetchData(model.getHost_farmer_id());
            }
        }
    };



    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject)o;
        Intent intent = new Intent(this, EditGuestFarmerActivity.class);
        intent.putExtra("mDetails", jsonObject.toString());
        startActivity(intent);
    }




    private void fetchData(int farmerId) {
        try {

            JSONObject jsonObject = new JSONObject();

            jsonObject.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            jsonObject.put("village_id", farmerId);
            jsonObject.put("host_farmer_id", farmerId);
            jsonObject.put("reg_type", farmerId);

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.BASE_API, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchGuestFarmerListRequest(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {
            if (i == 1 && jsonObject != null) {
                ResponseModel response = new ResponseModel(jsonObject);

                if (response.isStatus()) {
                    JSONArray mDataArray = response.getData();

                    GuestFarmerEditAdapter hostFarmerAdapter = new GuestFarmerEditAdapter(this, this, mDataArray);
                    recyclerView.setAdapter(hostFarmerAdapter);
                    hostFarmerAdapter.notifyDataSetChanged();

                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}


