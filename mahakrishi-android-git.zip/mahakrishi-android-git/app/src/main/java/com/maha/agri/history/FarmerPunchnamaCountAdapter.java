package com.maha.agri.history;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerPunchnamaCountAdapter extends RecyclerView.Adapter<FarmerPunchnamaCountAdapter.MyViewHolder> {
    private JSONArray punchnama_count_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    String id;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView farmer_punchnama_crop_name_tv,farmer_punchnama_crop_count_tv;
        private RelativeLayout farmer_punchnama_crop_count_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.farmer_punchnama_crop_name_tv = itemView.findViewById(R.id.farmer_cropsap_crop_name_tv);
            this.farmer_punchnama_crop_count_tv = itemView.findViewById(R.id.farmer_cropsap_crop_count_tv);
            this.farmer_punchnama_crop_count_rl = itemView.findViewById(R.id.farmer_cropsap_crop_count_rl);

        }
    }

    public FarmerPunchnamaCountAdapter(PreferenceManager preferenceManager, JSONArray punchnama_count_array_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.punchnama_count_array_list = punchnama_count_array_list;
        this.context = context;

    }

    @Override
    public FarmerPunchnamaCountAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_cropsap_crop_count_single_item, parent, false);

        FarmerPunchnamaCountAdapter.MyViewHolder myViewHolder = new FarmerPunchnamaCountAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final FarmerPunchnamaCountAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = punchnama_count_array_list.getJSONObject(listPosition);

            holder.farmer_punchnama_crop_count_rl.setTag(listPosition);

            holder.farmer_punchnama_crop_count_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        id = punchnama_count_array_list.getJSONObject(index).getString("crop_id");
                        Intent intent = new Intent(context, FarmerPunchnamaHistoryActivity.class);
                        intent.putExtra("crop_id",id);
                        context.startActivity(intent);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

            holder.farmer_punchnama_crop_name_tv.setText(jsonObject.getString("crop_name"));
            holder.farmer_punchnama_crop_count_tv.setText("( " + jsonObject.getString("cnt") + " )");


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (punchnama_count_array_list != null) {
            return punchnama_count_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FarmerPunchnamaCountAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FarmerPunchnamaCountAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
