package com.maha.agri.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AssignFarmerListAdapter extends RecyclerView.Adapter<AssignFarmerListAdapter.MyViewHolder>  {
    private JSONArray dash_title;
    private Context context;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView farmer_single_text_view;



        public MyViewHolder(View itemView) {
            super(itemView);

            this.farmer_single_text_view = itemView.findViewById(R.id.farmer_single_text_view);

        }
    }

    public AssignFarmerListAdapter(JSONArray dash_title, Context context) {
        this.dash_title = dash_title;
        this.context = context;

    }

    @Override
    public AssignFarmerListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                             int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_list_single_item, parent, false);


        AssignFarmerListAdapter.MyViewHolder myViewHolder = new AssignFarmerListAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final AssignFarmerListAdapter.MyViewHolder holder, final int listPosition) {
        try {
            if(dash_title.length()>=2) {
                JSONObject jsonObject = dash_title.getJSONObject(listPosition);
                holder.farmer_single_text_view.setText(jsonObject.getString("first_name"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return dash_title.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private AssignFarmerListAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final AssignFarmerListAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
