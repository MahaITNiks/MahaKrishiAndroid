package com.maha.agri.ochard_mapping;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.ochard_mapping.model.CropType;
import com.maha.agri.ochard_mapping.model.FarmerCategory;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class OrchardMappingActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private NestedScrollView orchard_nested_scroll_view;
    private TextView orchard_district, orchard_taluka, orchard_village, farmer_category, orchard_year, orchard_croptype,
            orchard_crop, orchard_crop_age;
    private EditText orchard_farmer1, orchard_farmer2, orchard_farmer3, orchard_farmer_phone, orchard_survey_gat, orchard_khata_no, orchard_area_hectares, orchard_no_of_plant, orchard_plant_dist,
            orchard_row_dist, orchard_other_crop;
    private RadioGroup orchard_sur_gut_rg;
    private RadioButton orchard_survey, orchard_gut;
    private LinearLayout orchard_other_crop_ll, csr_sajja_linear_layout, csr_sajja_list_linear_layout;
    private ImageView orchard_photo1, orchard_photo2;
    private Button orchard_mapping_add_more_btn, orchard_generate_report;
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private Calendar calendar;

    static final Integer CAMERA = 0x5;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null, photoFile2 = null;
    private String imagePath1 = "", imagePath2 = "", first_image_url1 = "", first_image_url2 = "", currentTime = "";
    ///
    private String type = "0", district_name = "", taluka_name = "", crop_name = "", revenue_circle_name = "",
            gram_panch_name = "", year_name = "", total_age_str = "", district_id_str = "", taluka_id_str = "", village_name = "", farmer_category_name = "", croptypename = "";
    private int selected_crop_id = 0, selected_croptype_id = 0, season_id = 0, year_of_plantationsid = 0, revenue_id = 0, gram_panch_id = 0, district_id = 0, taluka_id = 0, village_id = 0, year_int = 0,
            total_age_int = 0, year = 0;
    private JSONArray cropTypeJArray, crop_list, village_list, year_plantation_list, district_list, revenue_list, gram_panch_list, Sajja_List, farmer_categoryJArray;
    ArrayList<String> VillageName;
    HashMap<Integer, String> village_map = new HashMap<Integer, String>();
    private String activityID = "";
    private Transformation transformation;
    private AppLocationManager appLocationManager;
    private RecyclerView orchard_mapping_add_more_rv;
    private JSONArray multiple_crop_field_add = new JSONArray();
    private boolean isCropPresent = false;
    private boolean isSurveyGatSelected = false;

    private String role_id = "", role_chare_id = "", role_officer_id = "";
    private int circle_id = 0, sajja_id = 0;
    private TextView ns_cropSR_sajja_name_tv, ns_cropSR_sajja_list_name_tv;
    private String sajja_name = "";
    JSONArray orchardSurvey_list;
    // Change gps
    // gps changes
    AppLocationManager gps;
    double latitude = 0.0;
    double longitude = 0.0;
    double accuracy = 0.0;
    String complete_address;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    TextView tv_lat_long, tv_accuracy;
    SweetAlertDialog sweetAlertDialog;
    private PeriodicWorkRequest mPeriodicWorkRequest;
    private String imageFlag = "0";
    boolean Lat_Long_Flag = true;
    String Check_Accuracy = "";
    private double maxHectrevalue = 0.0;
    private double availableHectrevalue = 0.0;
    private double OriginalavailableHA = 0.0;// if crop already exist popup shows, that time it will reassign to "availableHectrevalue"
    private double remaining_area = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orchard_mapping);
        getSupportActionBar().setTitle("Orchard Mapping");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(OrchardMappingActivity.this);
        sharedPref = new SharedPref(OrchardMappingActivity.this);
        role_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID);
        role_chare_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID);
        role_officer_id = preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID);
        circle_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        sajja_id = Integer.parseInt(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        appLocationManager = new AppLocationManager(this);
        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
        //get data from gps lat and long

        if (Build.VERSION.SDK_INT < 19) {
            getLocation();
        } else {
            if (checkLocationPermission()) {
                getLocation();
            }
        }

// get data from orchad survey list intent
        Intent intent = getIntent();

        try {
            String getorchardSurvey_list = intent.getStringExtra("orchardSurvey_list");
            if (getorchardSurvey_list != null)
                orchardSurvey_list = new JSONArray(getorchardSurvey_list);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ids();
        functions();
    }

    private boolean checkLocationPermission() {
        //check the location permissions and return true or false.
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            //permissions granted
            // Toast.makeText(getApplicationContext(), "permissions granted", Toast.LENGTH_LONG).show();
            // getLocation();

            return true;
        } else {
            //permissions NOT granted
            //if permissions are NOT granted, ask for permissions
            Toast.makeText(getApplicationContext(), "Please enable permissions", Toast.LENGTH_LONG).show();
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Permissions request")
                        .setMessage("we need your permission for location in order to show you this example")
                        .setPositiveButton("Ok, I agree", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(OrchardMappingActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        }
    }

    // To get Lat & long
    private void getLocation() {
        gps = new AppLocationManager(this);
        // Check if GPS enabled

        if (ActivityCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(OrchardMappingActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        } else {

            if (gps.canGetLocation()) {

                latitude = gps.getLatitude();
                longitude = gps.getLongitude();
                accuracy = gps.location.getAccuracy();
                System.out.println("*********confirm lat and long" + latitude + " " + longitude + "" + accuracy);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Geocoder geocoder = new Geocoder(OrchardMappingActivity.this, Locale.getDefault());
                        List<Address> addresses = null;
                        try {
                            addresses = (List<Address>) geocoder.getFromLocation(latitude, longitude, 1);
                            if (addresses != null) {
                                complete_address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                                System.out.println("*****************" + complete_address);
                                String lat = latitude + " " + longitude;
                                String addres = complete_address;

                                String Accuracys = " Accuracy(M) : " + Math.round(accuracy * 100) / 100;

                                BigDecimal rounded = BigDecimal.valueOf(latitude).setScale(4, RoundingMode.HALF_DOWN);
                                BigDecimal rounded1 = BigDecimal.valueOf(longitude).setScale(4, RoundingMode.HALF_DOWN);
                                String latandlong = "Lat : " + rounded + " long : " + rounded1;
                                // Toast.makeText(getApplicationContext(), +latitude + longitude + "check", Toast.LENGTH_SHORT).show();
                                tv_lat_long.setText(latandlong);
                                tv_accuracy.setText(Accuracys);
                                Log.e("##Chekinhg", latandlong + "" + Accuracys);
                                /*latitude = 0.0;
                                longitude = 0.0;*/
                                if (accuracy != 0.0 && accuracy <= 20.99) {
                                    Lat_Long_Flag = false;
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


                    }
                }, 1000);


            } else {
                // Can't get location.
                // GPS or network is not enabled.
                // Ask user to enable GPS/network in settings.
                showSettingsAlert();
            }
        }
    }

    public void showSettingsAlert() {
        android.app.AlertDialog.Builder alertDialog = new android.app.AlertDialog.Builder(this);

        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings");

        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");

        // On pressing the Settings button.
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });


        // On pressing the cancel button
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }


    private void ids() {
        crop_list = new JSONArray();
        cropTypeJArray = new JSONArray();
        year_plantation_list = new JSONArray();
        Sajja_List = new JSONArray();
        farmer_categoryJArray = new JSONArray();
        village_list = new JSONArray();
        revenue_list = new JSONArray();
        gram_panch_list = new JSONArray();
        orchard_nested_scroll_view = (NestedScrollView) findViewById(R.id.orchard_nested_scroll_view);
        //Textview
        orchard_district = (TextView) findViewById(R.id.orchard_district);
        orchard_taluka = (TextView) findViewById(R.id.orchard_taluka);
        orchard_village = (TextView) findViewById(R.id.orchard_village);
        farmer_category = (TextView) findViewById(R.id.farmer_category);
        orchard_year = (TextView) findViewById(R.id.orchard_year);
        orchard_crop = (TextView) findViewById(R.id.orchard_crop);
        orchard_croptype = (TextView) findViewById(R.id.orchard_croptype);
        orchard_crop_age = (TextView) findViewById(R.id.orchard_crop_age);
        //Edittext
        orchard_farmer1 = (EditText) findViewById(R.id.orchard_farmer1);
        orchard_farmer2 = (EditText) findViewById(R.id.orchard_farmer2);
        orchard_farmer3 = (EditText) findViewById(R.id.orchard_farmer3);
        orchard_farmer_phone = (EditText) findViewById(R.id.orchard_farmer_phone);
        orchard_survey_gat = (EditText) findViewById(R.id.orchard_survey_gat);
        orchard_khata_no = (EditText) findViewById(R.id.orchard_khata_no);
        orchard_area_hectares = (EditText) findViewById(R.id.orchard_area_hectares);
        orchard_no_of_plant = (EditText) findViewById(R.id.orchard_no_of_plant);
        orchard_plant_dist = (EditText) findViewById(R.id.orchard_plant_dist);
        orchard_row_dist = (EditText) findViewById(R.id.orchard_row_dist);
        orchard_other_crop = (EditText) findViewById(R.id.orchard_other_crop);
        //Radio
        orchard_sur_gut_rg = (RadioGroup) findViewById(R.id.orchard_sur_gut_rg);
        orchard_survey = (RadioButton) findViewById(R.id.orchard_survey_rb);
        orchard_gut = (RadioButton) findViewById(R.id.orchard_gut_rb);

        orchard_other_crop_ll = (LinearLayout) findViewById(R.id.orchard_other_crop_ll);
        csr_sajja_linear_layout = (LinearLayout) findViewById(R.id.csr_sajja_linear_layout);
        csr_sajja_list_linear_layout = (LinearLayout) findViewById(R.id.csr_sajja_list_linear_layout);

        ns_cropSR_sajja_name_tv = (TextView) findViewById(R.id.ns_cropSR_sajja_name_tv);
        ns_cropSR_sajja_list_name_tv = (TextView) findViewById(R.id.ns_cropSR_sajja_list_name_tv);

        orchard_photo1 = (ImageView) findViewById(R.id.orchard_photo1);
        orchard_photo2 = (ImageView) findViewById(R.id.orchard_photo2);
        tv_lat_long = (TextView) findViewById(R.id.tv_lat_long);
        tv_accuracy = (TextView) findViewById(R.id.tv_accuracy);
        orchard_mapping_add_more_rv = (RecyclerView) findViewById(R.id.orchard_mapping_add_more_rv);
        orchard_mapping_add_more_btn = (Button) findViewById(R.id.orchard_mapping_add_more_btn);
        orchard_generate_report = (Button) findViewById(R.id.orchard_generate_report);

        orchard_survey.setChecked(false);
        orchard_gut.setChecked(false);


        orchard_area_hectares.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        orchard_khata_no.setInputType(InputType.TYPE_CLASS_NUMBER);
        orchard_plant_dist.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        orchard_row_dist.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        year_plantation_service();
        get_district_taluka();
        crop_service(activityID);


        orchard_sur_gut_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.orchard_survey_rb:
                        if (orchard_survey.isChecked()) {

                        }
                        orchard_gut.setChecked(false);
                        orchard_survey.setChecked(true);
                        orchard_survey_gat.setKeyListener(DigitsKeyListener.getInstance("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/"));
                        orchard_survey_gat.setRawInputType(InputType.TYPE_CLASS_TEXT);
                        type = orchard_survey.getText().toString();
                        orchard_survey_gat.setText("");
                        break;

                    case R.id.orchard_gut_rb:
                        if (orchard_gut.isChecked()) {

                        }
                        orchard_gut.setChecked(true);
                        orchard_survey.setChecked(false);
                        orchard_survey_gat.setInputType(InputType.TYPE_CLASS_TEXT);
                        type = orchard_gut.getText().toString();
                        orchard_survey_gat.setText("");
                        break;
                }
            }
        });


    }

    private void functions() {

        ArrayList<CropType> cropTypes = new ArrayList<CropType>();
        cropTypes.add(new CropType(1, "Main Crop"));
        cropTypes.add(new CropType(2, "Border Crop"));
        for (int i = 0; i < cropTypes.size(); i++) {
            cropTypeJArray.put(cropTypes.get(i).getJSONObject());
        }


        ArrayList<FarmerCategory> categories = new ArrayList<FarmerCategory>();
        categories.add(new FarmerCategory(1, "Marginal-Less than 1 Ha."));
        categories.add(new FarmerCategory(2, "Small-1-2 Ha."));
        categories.add(new FarmerCategory(3, "Medium-2-4 Ha."));
        categories.add(new FarmerCategory(4, "Large-More than 4 Ha."));
        for (int i = 0; i < categories.size(); i++) {
            farmer_categoryJArray.put(categories.get(i).getJSONObject());
        }


        if (role_chare_id.equalsIgnoreCase("1") && role_officer_id.equalsIgnoreCase("2")) {
            csr_sajja_linear_layout.setVisibility(View.GONE);
            csr_sajja_list_linear_layout.setVisibility(View.VISIBLE);
            get_district_taluka();
            getSajjaLocation();
            ns_cropSR_sajja_list_name_tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Sajja_List.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(Sajja_List, 7, "Select Saja", "sajja_name", "sajja_id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                    }
                }
            });

            orchard_village.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 14, "Select Village", "village_name", "village_id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                    }
                }
            });

        } else {
            csr_sajja_linear_layout.setVisibility(View.VISIBLE);
            csr_sajja_list_linear_layout.setVisibility(View.GONE);
            ns_cropSR_sajja_name_tv.setText(preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_NAME));
            get_district_taluka();
            orchard_village.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (village_list.length() > 0) {
                        AppUtility.getInstance().showListDialogIndex(village_list, 12, "Select Village", "village_name", "village_id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                    }
                }
            });
        }


        orchard_village.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (village_list != null && village_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(village_list, 5, "Select Village", "village_name", "village_id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                }

            }
        });


        orchard_croptype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (cropTypeJArray != null && cropTypeJArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(cropTypeJArray, 16, "Select Crop Type", "croptype", "id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                }
            }
        });

        farmer_category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (farmer_categoryJArray != null && farmer_categoryJArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(farmer_categoryJArray, 15, "Select Category", "category", "id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                }

            }
        });


        orchard_farmer_phone.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                if (s.toString().length() == 1) {
                    if ((!s.toString().equals("7")) && (!s.toString().equals("8")) && (!s.toString().equals("9"))) {
                        orchard_farmer_phone.setText("");
                        new SweetAlertDialog(OrchardMappingActivity.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText("")
                                .setContentText("Please enter valid mobile no")
                                .setConfirmText("Close")
                                .show();
                    }
                }

                if (s.length() == 10) {

                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("mobile_no", orchard_farmer_phone.getText().toString().trim());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
                    AppinventorApi api = new AppinventorApi(OrchardMappingActivity.this, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, true);
                    Retrofit retrofit = api.getRetrofitInstance();
                    APIRequest apiRequest = retrofit.create(APIRequest.class);
                    Call<JsonObject> responseCall = apiRequest.orchard_mobile_exists(requestBody);
                    api.postRequest(responseCall, OrchardMappingActivity.this, 15);
                }

            }
        });


        orchard_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (year_plantation_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(year_plantation_list, 6, "Select Year of Plantation", "year", "id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                } else {
                    year_plantation_service();
                }
            }
        });

        orchard_mapping_add_more_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (village_id == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select Village", Toast.LENGTH_LONG);
                    toast.show();
                } else if (orchard_farmer1.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's first name", Toast.LENGTH_LONG).show();
                } else if (orchard_farmer2.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's middle name", Toast.LENGTH_LONG).show();
                } else if (orchard_farmer3.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's last name", Toast.LENGTH_LONG).show();
                } else if ((orchard_farmer_phone.getText().toString().equalsIgnoreCase("")) || (orchard_farmer_phone.getText().toString().length() != 10)) {
                    Toast.makeText(getApplicationContext(), "Enter valid mobile number", Toast.LENGTH_LONG).show();
                } else if (farmer_category.getText().toString().trim().equalsIgnoreCase("select")) {
                    Toast.makeText(getApplicationContext(), "Please select category", Toast.LENGTH_LONG).show();
                } else if (orchard_khata_no.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Please enter 8A Khata number", Toast.LENGTH_LONG).show();
                } else if (type.equalsIgnoreCase("0")) {
                    Toast.makeText(OrchardMappingActivity.this, "Please choose Survey/Gat", Toast.LENGTH_LONG).show();
                } else if (orchard_survey_gat.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Enter survey/gat value", Toast.LENGTH_LONG).show();
                } else if (selected_croptype_id == 0) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Select Crop Type", Toast.LENGTH_LONG).show();
                } else if (selected_crop_id == 0) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Select Crop", Toast.LENGTH_LONG).show();
                } else if (crop_name.equalsIgnoreCase("OTHER")) {
                    if (orchard_other_crop.getText().toString().trim().equalsIgnoreCase("")) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Enter crop name", Toast.LENGTH_LONG).show();
                    } else if (year_of_plantationsid == 0) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Select Year of Plantation", Toast.LENGTH_LONG).show();
                    } else if (orchard_area_hectares.getText().toString().equalsIgnoreCase("")) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Enter Area", Toast.LENGTH_LONG).show();
                    } else if (orchard_no_of_plant.getText().toString().equalsIgnoreCase("")) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Enter no of plant", Toast.LENGTH_LONG).show();
                    } else if (orchard_plant_dist.getText().toString().equalsIgnoreCase("")) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Enter Plant to Plant", Toast.LENGTH_LONG).show();
                    } else if (orchard_row_dist.getText().toString().equalsIgnoreCase("")) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Enter Row to Row", Toast.LENGTH_LONG).show();
                    } else if (photoFile1 == null) {
                        Toast.makeText(OrchardMappingActivity.this, "Please Click Photo", Toast.LENGTH_LONG).show();
                    } else {
                        crop_name = orchard_other_crop.getText().toString().trim();
                        add_multiple_crop_array(village_id, farmer_category_name,
                                orchard_khata_no.getText().toString().trim(), type, orchard_survey_gat.getText().toString().trim(), selected_crop_id, crop_name, year_of_plantationsid, orchard_crop_age.getText().toString().trim(), orchard_area_hectares.getText().toString().trim(), orchard_plant_dist.getText().toString().trim(), orchard_row_dist.getText().toString().trim(), first_image_url1, first_image_url2, latitude, longitude, accuracy, "OTHER", selected_croptype_id, orchard_no_of_plant.getText().toString().trim());
                        Lat_Long_Flag = true;
                        //multiple_clear_data();
                    }
                } else if (year_of_plantationsid == 0) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Select Year of Plantation", Toast.LENGTH_LONG).show();
                } else if (orchard_area_hectares.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Enter Area", Toast.LENGTH_LONG).show();
                } else if (orchard_no_of_plant.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Enter no of plant", Toast.LENGTH_LONG).show();
                } else if (IsMainOrBorder()) {

                } else if (photoFile1 == null) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Click Photo 1", Toast.LENGTH_LONG).show();
                } else if (photoFile2 == null) {
                    Toast.makeText(OrchardMappingActivity.this, "Please Click Photo 2", Toast.LENGTH_LONG).show();
                } else if (accuracy > 20.99) {
                    ShowAlert();
                } else if (farmerCategotyValidation()) {

                } else {
                    add_multiple_crop_array(village_id, farmer_category_name, orchard_khata_no.getText().toString().trim(), type, orchard_survey_gat.getText().toString().trim(), selected_crop_id, crop_name, year_of_plantationsid, orchard_crop_age.getText().toString().trim(), orchard_area_hectares.getText().toString().trim(), orchard_plant_dist.getText().toString().trim(), orchard_row_dist.getText().toString().trim(), first_image_url1, first_image_url2, latitude, longitude, accuracy, "LIST", selected_croptype_id, orchard_no_of_plant.getText().toString().trim());
                    Lat_Long_Flag = true;
                    //multiple_clear_data();
                }
            }

            private boolean farmerCategotyValidation() {

                boolean flag = false;
                String farmerCategory = farmer_category.getText().toString().trim();
                double orchard_area_hectare = Double.parseDouble(orchard_area_hectares.getText().toString().trim());

                OriginalavailableHA = availableHectrevalue;
                if (farmerCategory.equalsIgnoreCase("Marginal-Less than 1 Ha.")) {
                    if (orchard_area_hectare > 0.0 && orchard_area_hectare <= 1.00 && maxHectrevalue == 0.0) {
                        maxHectrevalue = 1.00;
                        availableHectrevalue = 1.00 - orchard_area_hectare;
                        flag = false;
                    } else if (maxHectrevalue > 0.0 && availableHectrevalue > 0.0) {
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;
                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as Less than 1 HA");
                            flag = true;
                        }

                    } else if (remaining_area > 0.0) {
                        maxHectrevalue = 1.00;
                        availableHectrevalue = remaining_area;
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;

                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as 2-4 HA");
                            flag = true;
                        }
                        remaining_area = 0.0;

                    } else {
                        flag = true;
                        farmerCategoryValidationAlert("Please Enter Area in Hectares between 0.00 - 0.99");
                    }
                }
                if (farmerCategory.equalsIgnoreCase("Small-1-2 Ha.")) {
                    if (orchard_area_hectare > 0.0 && orchard_area_hectare <= 2.00 && maxHectrevalue == 0.0) {
                        maxHectrevalue = 2.00;
                        availableHectrevalue = 2.00 - orchard_area_hectare;
                        flag = false;
                    } else if (maxHectrevalue > 0.0 && availableHectrevalue > 0.0) {
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;
                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as 1-2 HA");
                            flag = true;
                        }

                    } else if (remaining_area > 0.0) {
                        maxHectrevalue = 2.00;
                        availableHectrevalue = remaining_area;
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;

                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as 2-4 HA");
                            flag = true;
                        }
                        remaining_area = 0.0;

                    } else {
                        flag = true;
                        farmerCategoryValidationAlert("Please Enter Area in Hectares between 1 - 1.99");
                    }
                }
                if (farmerCategory.equalsIgnoreCase("Medium-2-4 Ha.")) {
                    if (orchard_area_hectare > 0.0 && orchard_area_hectare <= 4.00 && maxHectrevalue == 0.0) {
                        maxHectrevalue = 4.00;
                        availableHectrevalue = 4.00 - orchard_area_hectare;
                        flag = false;
                    } else if (maxHectrevalue > 0.0 && availableHectrevalue > 0.0) {
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;

                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as 2-4 HA");
                            flag = true;
                        }

                    } else if (remaining_area > 0.0) {
                        maxHectrevalue = 4.00;
                        availableHectrevalue = remaining_area;
                        if (orchard_area_hectare > 0.0 && orchard_area_hectare < availableHectrevalue) {
                            availableHectrevalue = availableHectrevalue - orchard_area_hectare;
                            flag = false;

                        } else {
                            farmerCategoryValidationAlert("You have excessed Marginal farmer category limit as 2-4 HA");
                            flag = true;
                        }
                        remaining_area = 0.0;

                    } else {
                        flag = true;
                        farmerCategoryValidationAlert("Please Enter Area in Hectares between 2 - 3.99");
                    }
                }
                if (farmerCategory.equalsIgnoreCase("Large-More than 4 Ha.")) {
                    if (orchard_area_hectare > 0.0) {
                        maxHectrevalue = 4.00;
                        flag = false;
                    } else {
                        flag = true;
                        farmerCategoryValidationAlert("Please enter value above 4 ");
                    }
                }

                return flag;
            }

            private void ShowAlert() {
                new SweetAlertDialog(OrchardMappingActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Orchard Mapping")
                        .setContentText("Data is not saved - Location accuracy limit of 20 meters has been exceeded")
                        .setConfirmText("Close")
                        .show();

            }
        });


        orchard_crop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (crop_list != null) {
                    AppUtility.getInstance().showListDialogIndex(crop_list, 8, "Select Crop", "crop_english", "id", OrchardMappingActivity.this, OrchardMappingActivity.this);
                } else {
                    crop_service(activityID);
                }
            }
        });

        orchard_photo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageFlag = "1";
                if ((ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri1();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        orchard_photo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageFlag = "2";
                if ((ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(OrchardMappingActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri2();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        orchard_generate_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (village_id == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Select Village", Toast.LENGTH_LONG);
                    toast.show();
                } else if (orchard_farmer1.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's first name", Toast.LENGTH_LONG).show();
                } else if (orchard_farmer2.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's middle name", Toast.LENGTH_LONG).show();
                } else if (orchard_farmer3.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's last name", Toast.LENGTH_LONG).show();
                } else if (orchard_farmer_phone.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Enter Farmer's mobile number", Toast.LENGTH_LONG).show();
                } else if (orchard_khata_no.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getApplicationContext(), "Please enter 8A Khata number", Toast.LENGTH_LONG).show();
                } else if (multiple_crop_field_add.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Add details for atleast one crop", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(OrchardMappingActivity.this, GenerateOrchardMappingActivity.class);
                    intent.putExtra("division_id", "0");
                    intent.putExtra("district_id", district_id);
                    intent.putExtra("taluka_id", taluka_id);
                    intent.putExtra("revenue_id", revenue_id);
                    intent.putExtra("gram_panchayat_id", gram_panch_id);
                    intent.putExtra("sajja_id", sajja_id);
                    intent.putExtra("village_id", village_id);
                    intent.putExtra("first_name", orchard_farmer1.getText().toString().trim());
                    intent.putExtra("middle_name", orchard_farmer2.getText().toString().trim());
                    intent.putExtra("last_name", orchard_farmer3.getText().toString().trim());
                    intent.putExtra("mobile", orchard_farmer_phone.getText().toString().trim());
                    intent.putExtra("khata_number", orchard_khata_no.getText().toString().trim());
                    intent.putExtra("add_more_data", multiple_crop_field_add.toString());
                    startActivity(intent);
                }
            }
        });

    }

    private boolean IsMainOrBorder() {
        boolean flag = false;
        if (selected_croptype_id == 1) {
            if (orchard_plant_dist.getText().toString().equalsIgnoreCase("")) {
                Toast.makeText(OrchardMappingActivity.this, "Please Enter Plant to Plant", Toast.LENGTH_LONG).show();
                flag = true;
            } else if (orchard_row_dist.getText().toString().equalsIgnoreCase("")) {
                Toast.makeText(OrchardMappingActivity.this, "Please Enter Row to Row", Toast.LENGTH_LONG).show();
                flag = true;

            }
        }
        return flag;
    }

    private void farmerCategoryValidationAlert(String range) {
        new SweetAlertDialog(OrchardMappingActivity.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(farmer_category_name)
                .setContentText(range)
                .setConfirmText("Close")
                .show();

    }

    private void takeImageFromCameraUri1() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

          //  File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            File photoDirectory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    private void takeImageFromCameraUri2() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

         //   File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            File photoDirectory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), IMAGE_DIRECTORY);

            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
            } else {
                photoURI = Uri.fromFile(photoFile2);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {

                //  if (accuracy == 0.0 || accuracy >= 100.99)


                onCameraActivityResult();
                if (Lat_Long_Flag) {
                    getLocation();
                }

            }
        } else {
            photoFile1 = null;
            photoFile2 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (imageFlag.equals("1")) {
            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .transform(transformation)
                                    .resize(orchard_photo1.getWidth(), orchard_photo1.getHeight())
                                    .centerCrop()
                                    .into(orchard_photo1);

                            if (accuracy != 0.0 && accuracy <= 20.99) {
                                uploadImageOnServer1(imagePath1);
                            } else {
                                new SweetAlertDialog(OrchardMappingActivity.this, SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("")
                                        .setContentText("Accuracy limit is exceeded more than 20 Meters, Please try to capture Image from Another Location.")
                                        .setConfirmText("Close")
                                        .show();
                            }

                        }
                    }, 100);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        if (imageFlag.equals("2")) {
            if (photoFile2 != null) {

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .transform(transformation)
                                    .resize(orchard_photo2.getWidth(), orchard_photo2.getHeight())
                                    .centerCrop()
                                    .into(orchard_photo2);
                            if (accuracy != 0.0 && accuracy <= 20.99) {
                                uploadImageOnServer2(imagePath2);
                            } else {
                                new SweetAlertDialog(OrchardMappingActivity.this, SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("")
                                        .setContentText("Accuracy limit is exceeded more than 20 Meters, Please try to capture Image from Another Location.")
                                        .setConfirmText("Close")
                                        .show();
                            }

                        }
                    }, 100);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }

    private void add_multiple_crop_array(int village_id, String farmer_category, String khata_number, String surveyorgutid, String surveyorgutvalue, int crop_id, String crop_name, int year_of_plantationsid, String crop_age, String area, String plantfeet, String rowfeet, String first_image_url, String second_image_url, Double lat, Double lang, Double accuracy, String type, int cropType, String no_of_plant) {

        JSONObject multiple_crop_field_add_json_object = new JSONObject();
        try {
            multiple_crop_field_add_json_object.put("village_id", village_id);
            multiple_crop_field_add_json_object.put("farmer_category", farmer_category);
            multiple_crop_field_add_json_object.put("khata_number", khata_number);
            multiple_crop_field_add_json_object.put("surveyorgutid", surveyorgutid);
            multiple_crop_field_add_json_object.put("surveyorgutvalue", surveyorgutvalue);
            multiple_crop_field_add_json_object.put("crop_id", crop_id);
            multiple_crop_field_add_json_object.put("crop_name", crop_name);
            multiple_crop_field_add_json_object.put("year_of_plantationsid", year_of_plantationsid);
            multiple_crop_field_add_json_object.put("crop_age", crop_age);
            multiple_crop_field_add_json_object.put("area", area);
            multiple_crop_field_add_json_object.put("plantfeet", plantfeet);
            multiple_crop_field_add_json_object.put("rowfeet", rowfeet);
            multiple_crop_field_add_json_object.put("first_image_url_1", first_image_url);
            multiple_crop_field_add_json_object.put("second_image_url_2", second_image_url);
            multiple_crop_field_add_json_object.put("lat", lat);
            multiple_crop_field_add_json_object.put("long", lang);
            multiple_crop_field_add_json_object.put("accuracy", accuracy);
            multiple_crop_field_add_json_object.put("type", type);
            multiple_crop_field_add_json_object.put("crop_type", cropType);
            multiple_crop_field_add_json_object.put("no_of_plant", no_of_plant);
            isCropPresent = false;

            for (int i = 0; i < multiple_crop_field_add.length(); i++) {
                JSONObject multiple_data_json_object = multiple_crop_field_add.getJSONObject(i);
                int crop_id_stored = Integer.parseInt(multiple_data_json_object.getString("crop_id"));
                int village_id_stored = Integer.parseInt(multiple_data_json_object.getString("village_id"));
                String SurveyorGatvalue_Stored = multiple_data_json_object.getString("surveyorgutvalue");
                String Khata_Number_Stored = multiple_data_json_object.getString("khata_number");
                String crop_name_stored = multiple_data_json_object.getString("crop_name");
                String crop_type = multiple_data_json_object.getString("type");
                String Crop_name = orchard_other_crop.getText().toString().trim();
                String Khata_number = orchard_khata_no.getText().toString().trim();
                String surveyorgatvalue = orchard_survey_gat.getText().toString().trim();

                if (crop_type.equalsIgnoreCase("LIST")) {
                    String stored_unique_data = village_id_stored + "_" + Khata_Number_Stored + "_" + SurveyorGatvalue_Stored + "_" + crop_id_stored;
                    String unique_data = village_id + "_" + Khata_number + "_" + surveyorgatvalue + "_" + selected_crop_id;
                    if (stored_unique_data.equalsIgnoreCase(unique_data)) {
                        isCropPresent = true;
                        break;
                    }
                } else if (crop_type.equalsIgnoreCase("OTHER")) {
                    String stored_unique_data = village_id_stored + "_" + Khata_Number_Stored + "_" + SurveyorGatvalue_Stored + "_" + crop_name_stored;
                    String unique_data = village_id + "_" + Khata_number + "_" + surveyorgatvalue + "_" + Crop_name;
                    if (stored_unique_data.equalsIgnoreCase(unique_data)) {
                        isCropPresent = true;
                        break;
                    }
                }
            }


            // check data last submit farmer list
            if (orchardSurvey_list != null && orchardSurvey_list.length() > 0) {
                for (int i = 0; i < orchardSurvey_list.length(); i++) {
                    JSONObject multiple_data_json_object = orchardSurvey_list.getJSONObject(i);
                    int crop_id_stored = Integer.parseInt(multiple_data_json_object.getString("crop_id"));
                    int village_id_stored = Integer.parseInt(multiple_data_json_object.getString("village_id"));
                    String SurveyorGatvalue_Stored = multiple_data_json_object.getString("surveyorgutvalue");
                    //String Khata_Number_Stored = multiple_data_json_object.getString("khata_number");
                    String crop_name_stored = multiple_data_json_object.getString("crop_name");
                    String Farmer_fname_stored = multiple_data_json_object.getString("first_name");
                    String Farmer_mname_stored = multiple_data_json_object.getString("middle_name");
                    String Farmer_lname_stored = multiple_data_json_object.getString("last_name");

                    String Crop_name = orchard_other_crop.getText().toString().trim();
                    String Khata_number = orchard_khata_no.getText().toString().trim();
                    String surveyorgatvalue = orchard_survey_gat.getText().toString().trim();
                    String Farmer_fname = orchard_farmer1.getText().toString().trim();
                    String Farmer_mname = orchard_farmer2.getText().toString().trim();
                    String Farmer_lname = orchard_farmer3.getText().toString().trim();


                    String stored_unique_data = village_id_stored + "_" + Farmer_fname_stored + "_" + Farmer_mname_stored + "_" + Farmer_lname_stored + "_" + SurveyorGatvalue_Stored + "_" + crop_id_stored;
                    String unique_data = village_id + "_" + Farmer_fname + "_" + Farmer_mname + "_" + Farmer_lname + "_" + surveyorgatvalue + "_" + selected_crop_id;
                    if (stored_unique_data.equalsIgnoreCase(unique_data)) {
                        isCropPresent = true;
                        break;

                    }
                }
            }


            if (isCropPresent != true) {
                multiple_crop_field_add.put(multiple_crop_field_add_json_object);
            } else {

                availableHectrevalue = OriginalavailableHA;
                Toast.makeText(OrchardMappingActivity.this, "Selected crop is already added", Toast.LENGTH_LONG).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (multiple_crop_field_add.length() > 0) {
            orchard_mapping_add_more_rv.setLayoutManager(new LinearLayoutManager(OrchardMappingActivity.this));
            OrchardMappingAddMoreAdapter orchardMappingAddMoreAdapter = new OrchardMappingAddMoreAdapter(preferenceManager, multiple_crop_field_add, OrchardMappingActivity.this);
            orchard_mapping_add_more_rv.setAdapter(orchardMappingAddMoreAdapter);
            orchardMappingAddMoreAdapter.notifyDataSetChanged();
            crop_service(activityID);
        } else {
            final Toast toast = Toast.makeText(OrchardMappingActivity.this, "Enter data for above fields", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);
        }
        multiple_clear_data();

    }

    private void get_district_taluka() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }


    private void getSajjaLocation() {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_sajja_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 7);

    }


    private void revenue_service(int taluka_id) {
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id", taluka_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_revenue(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);

    }

    private void gram_panch_service(int revenue_id) {
        JSONObject param = new JSONObject();
        try {
            param.put("revenue_id", revenue_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_gram_panchayat(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void village_service(int gramID) {
        JSONObject param = new JSONObject();
        try {
            param.put("gram_id", gramID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_veri_village(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void year_plantation_service() {
        AppinventorApi api = new AppinventorApi(this, APIServices.PHY_VERI_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.phy_veri_year();
        api.postRequest(responseCall, this, 6);
    }

    private void crop_service(String activityID) {
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id", "");
            param.put("crop_type", "");
            param.put("horti_crop_type_id", "");
            param.put("fieldsubmenu_id", "");
            param.put("primary_report_id", "");
            param.put("panchname_scheme_id", "0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 8);
    }

    private void uploadImageOnServer1(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("lat", String.valueOf(latitude));
            params.put("long", String.valueOf(longitude));
            Log.e("#### lat image1", +latitude + "Long" + longitude + "Accuracy" + accuracy);
            params.put("accuracy", String.valueOf(accuracy));      //Add data accuracy satish
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("revenue_id", String.valueOf(revenue_id));
            params.put("gram_id", String.valueOf(gram_panch_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("crop_id", String.valueOf(selected_crop_id));

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.orchard_mapping_save_img(partBody, params);
            api.postRequest(responseCall, this, 9);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImageOnServer2(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("lat", String.valueOf(latitude));
            params.put("long", String.valueOf(longitude));
            params.put("accuracy", String.valueOf(accuracy));      //Add data accuracy satish
            Log.e("#### lat image2", +latitude + "Long" + longitude + "Accuracy" + accuracy);
            params.put("district_id", String.valueOf(district_id_str));
            params.put("taluka_id", String.valueOf(taluka_id_str));
            params.put("revenue_id", String.valueOf(revenue_id));
            params.put("gram_id", String.valueOf(gram_panch_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("crop_id", String.valueOf(selected_crop_id));

            File file = new File(photoFile2.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.ORCHARD_MAPPING_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.orchard_mapping_save_img(partBody, params);
            api.postRequest(responseCall, this, 10);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void getVillageLocation() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("role_charge_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_CHARGE_ID));
            param.put("role_officer_id", preferenceManager.getPreferenceValues(Preference_Constant.ROLE_OFFICER_ID));
            param.put("circle_id", preferenceManager.getPreferenceValues(Preference_Constant.CIRCLE_ID));
            param.put("sajja_id", preferenceManager.getPreferenceValues(Preference_Constant.SAJJA_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.assigned_village_list(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void normalVillageList() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("sajja_id", sajja_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.department_login_get_villages(requestBody);
        DebugLog.getInstance().d("assigned_Location_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("assigned_Location_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 14);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                            if (district_list.length() > 0) {
                                for (int j = 0; j <= district_list.length(); j++) {
                                    JSONObject district_json_object = district_list.getJSONObject(j);
                                    district_name = district_json_object.getString("district_name");
                                    taluka_name = district_json_object.getString("taluka_name");
                                    district_id_str = district_json_object.getString("district_id");
                                    taluka_id_str = district_json_object.getString("taluka_id");
                                    district_id = Integer.parseInt(district_id_str);
                                    taluka_id = Integer.parseInt(taluka_id_str);
                                    orchard_district.setText(district_name);
                                    orchard_taluka.setText(taluka_name);
                                    //revenue_service(taluka_id);
                                    //above line commented because we need village as like crop sowing module...
                                    getVillageLocation();
                                }

                            } else {
                                new AlertDialog.Builder(OrchardMappingActivity.this)
                                        .setTitle("Error!")
                                        .setMessage("You have not been assigned any villages against your saja, please contact Taluka office ")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                finish();
                                            }
                                        }).show();
                            }
                        }
                    }
                }

                if (i == 3) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            revenue_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            gram_panch_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 5) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 6) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            year_plantation_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 7) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Sajja_List = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 8) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            crop_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 9) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            first_image_url1 = data.getString("file_url");
                        }
                    }
                }

                if (i == 10) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            first_image_url2 = data.getString("file_url");
                        }
                    }
                }

                if (i == 12) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 14) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 15) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            String remaining_area_temp = jsonObject.getJSONArray("data").getJSONObject(0).get("remaining_area").toString();
                            remaining_area = Double.parseDouble(remaining_area_temp);

                            String categoryname = jsonObject.getJSONArray("data").getJSONObject(0).get("farmer_category").toString();
                            farmer_category_name = categoryname;
                            farmer_category.setText(farmer_category_name);
                            farmer_category.setEnabled(false);

                            String fName = "";
                            String mName = "";
                            String lName = "";

                            fName = jsonObject.getJSONArray("data").getJSONObject(0).get("first_name").toString();
                            mName = jsonObject.getJSONArray("data").getJSONObject(0).get("middle_name").toString();
                            lName = jsonObject.getJSONArray("data").getJSONObject(0).get("last_name").toString();

                            orchard_farmer1.setText(fName);
                            orchard_farmer2.setText(mName);
                            orchard_farmer3.setText(lName);
                            orchard_farmer1.setEnabled(false);
                            orchard_farmer2.setEnabled(false);
                            orchard_farmer3.setEnabled(false);


                        } else {
                            farmer_category.setEnabled(true);
                            farmer_category.setText("Select");
                            orchard_farmer1.setText("");
                            orchard_farmer2.setText("");
                            orchard_farmer3.setText("");
                            orchard_farmer1.setEnabled(true);
                            orchard_farmer2.setEnabled(true);
                            orchard_farmer3.setEnabled(true);


                        }
                    } else {
                        remaining_area = 0.0;

                        farmer_category.setEnabled(true);
                        farmer_category.setText("Select");
                        orchard_farmer1.setText("");
                        orchard_farmer2.setText("");
                        orchard_farmer3.setText("");
                        orchard_farmer1.setEnabled(true);
                        orchard_farmer2.setEnabled(true);
                        orchard_farmer3.setEnabled(true);

                    }
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 3) {
            revenue_id = Integer.parseInt(s1);
            clear_data();
            gram_panch_list = new JSONArray();
            gram_panch_service(revenue_id);
        }
        if (i == 4) {
            gram_panch_id = Integer.parseInt(s1);
            orchard_village.setText("Select");
            clear_data();
            village_list = new JSONArray();
            village_service(gram_panch_id);
        }
        if (i == 5) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            orchard_village.setText(village_name);
            clear_data();
        }
        if (i == 6) {
            year_of_plantationsid = Integer.parseInt(s1);
            year_name = s;
            orchard_year.setText(year_name);
            orchard_crop_age.setText("");
            orchard_crop_age.setText("");
            orchard_area_hectares.setText("");
            orchard_no_of_plant.setText("");
            orchard_plant_dist.setText("");
            orchard_row_dist.setText("");

            year_int = Integer.parseInt(year_name);
            if (year_int <= year) {
                total_age_int = year - year_int;
                total_age_str = String.valueOf(total_age_int);
                orchard_crop_age.setText(total_age_str);
            }
        }

        if (i == 8) {
            selected_crop_id = Integer.parseInt(s1);
            crop_name = s;
            orchard_crop.setText(crop_name);
            orchard_year.setText("Select");
            orchard_crop_age.setText("");
            orchard_area_hectares.setText("");
            orchard_no_of_plant.setText("");
            orchard_plant_dist.setText("");
            orchard_row_dist.setText("");

            if (crop_name.equalsIgnoreCase("OTHER")) {
                orchard_other_crop_ll.setVisibility(View.VISIBLE);
                orchard_other_crop.setText("");
                orchard_year.setText("Select");
                orchard_crop_age.setText("");
                orchard_area_hectares.setText("");
                orchard_no_of_plant.setText("");
                orchard_plant_dist.setText("");
                orchard_row_dist.setText("");
            } else {
                orchard_other_crop_ll.setVisibility(View.GONE);
                orchard_other_crop.setText("");
            }
        }

        if (i == 7) {
            sajja_id = Integer.parseInt(s1);
            sajja_name = s;
            ns_cropSR_sajja_list_name_tv.setText(sajja_name);
            normalVillageList();
            orchard_village.setText("Select");
        }


        if (i == 12) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            orchard_village.setText(village_name);

            orchard_farmer1.setEnabled(true);
            orchard_farmer2.setEnabled(true);
            orchard_farmer3.setEnabled(true);
            orchard_farmer_phone.setEnabled(true);
            farmer_category.setEnabled(true);
            orchard_khata_no.setEnabled(true);

        }

        if (i == 14) {
            village_id = Integer.parseInt(s1);
            village_name = s;
            orchard_village.setText(village_name);
            orchard_farmer1.setEnabled(true);
            orchard_farmer2.setEnabled(true);
            orchard_farmer3.setEnabled(true);
            orchard_farmer_phone.setEnabled(true);
            farmer_category.setEnabled(true);
            orchard_khata_no.setEnabled(true);


        }

        if (i == 15) {
            farmer_category_name = s;
            farmer_category.setText(farmer_category_name);

        }

        if (i == 16) {
            selected_croptype_id = Integer.parseInt(s1);
            croptypename = s;
            orchard_croptype.setText(croptypename);

        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void clear_data() {
        orchard_nested_scroll_view.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        orchard_nested_scroll_view.setFocusable(true);
        orchard_nested_scroll_view.setFocusableInTouchMode(true);
        orchard_nested_scroll_view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.requestFocusFromTouch();
                return false;
            }
        });
        orchard_farmer1.setText("");
        orchard_farmer2.setText("");
        orchard_farmer3.setText("");
        orchard_farmer_phone.setText("");
        orchard_khata_no.setText("");
        orchard_survey_gat.setText("");
        orchard_crop.setText("Select");
        orchard_croptype.setText("Select");
        orchard_year.setText("Select");
        //  orchard_survey.setChecked(false);
        //  orchard_gut.setChecked(false);
        orchard_crop_age.setText("");
        orchard_area_hectares.setText("");
        orchard_no_of_plant.setText("");
        orchard_plant_dist.setText("");
        orchard_row_dist.setText("");
        orchard_other_crop.setText("");
        orchard_other_crop_ll.setVisibility(View.GONE);
        orchard_mapping_add_more_rv.setAdapter(null);
        orchard_photo1.setImageResource(R.drawable.camera);
        orchard_photo2.setImageResource(R.drawable.camera);
        multiple_crop_field_add = new JSONArray();
        //  type = "0";
        photoFile1 = null;
        photoFile2 = null;


        orchard_farmer1.setEnabled(true);
        orchard_farmer2.setEnabled(true);
        orchard_farmer3.setEnabled(true);
        orchard_farmer_phone.setEnabled(true);
        farmer_category.setEnabled(true);
        orchard_khata_no.setEnabled(true);
    }

    private void multiple_clear_data() {
        orchard_croptype.setText("Select");
        orchard_crop.setText("Select");
        orchard_other_crop.setText("");
        orchard_other_crop_ll.setVisibility(View.GONE);
        orchard_year.setText("Select");
        orchard_crop_age.setText("");
        orchard_area_hectares.setText("");
        orchard_no_of_plant.setText("");
        orchard_plant_dist.setText("");
        orchard_row_dist.setText("");
        orchard_photo1.setImageResource(R.drawable.camera);
        orchard_photo2.setImageResource(R.drawable.camera);
        // type = "0";
        photoFile1 = null;
        photoFile2 = null;
        // orchard_survey.setChecked(false);
        //   orchard_gut.setChecked(false);
        orchard_farmer1.setEnabled(false);
        orchard_farmer2.setEnabled(false);
        orchard_farmer3.setEnabled(false);
        orchard_farmer_phone.setEnabled(false);
        farmer_category.setEnabled(false);
        orchard_khata_no.setEnabled(false);
    }
}
