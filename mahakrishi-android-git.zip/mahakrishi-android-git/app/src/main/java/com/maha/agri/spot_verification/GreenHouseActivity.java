package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GreenHouseActivity extends AppCompatActivity implements ApiCallbackCode {
    private TextView green_house1_datetv,green_house1_beneficiary_name,green_house1_villagetv,green_house1_talukatv,green_house1_districttv,green_house1_surveyno,
            green_house1_vargvari,green_house1_bab,green_house1_pre_date,green_house1_previous_area;

    private ImageView green_house1_dateiv;
    private EditText green_house1_name,green_house1_address,green_house1_mobile_no,green_house1_alternate_no,green_house1_reg_no;
    private Button green_house1_part1_save;
    private SweetAlertDialog sweetAlertDialog;
    private int mYear, mMonth, mDay;
    private DatePickerDialog green_house1_datepicker;
    private String green_house1_date="0";
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_green_house);
        getSupportActionBar().setTitle("Green House and Shade Net House ");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(GreenHouseActivity.this);

        ids();
        functions();
    }

    private void ids(){
        //Textview
        green_house1_datetv = (TextView) findViewById(R.id.green_house1_datetv);
        green_house1_beneficiary_name = (TextView) findViewById(R.id.green_house1_beneficiary_name);
        green_house1_villagetv = (TextView) findViewById(R.id.green_house1_villagetv);
        green_house1_talukatv = (TextView) findViewById(R.id.green_house1_talukatv);
        green_house1_districttv = (TextView) findViewById(R.id.green_house1_districttv);
        green_house1_surveyno = (TextView) findViewById(R.id.green_house1_surveyno);
        green_house1_vargvari = (TextView) findViewById(R.id.green_house1_vargvari);
        green_house1_bab = (TextView) findViewById(R.id.green_house1_bab);
        green_house1_pre_date = (TextView) findViewById(R.id.green_house1_pre_date);
        green_house1_previous_area = (TextView) findViewById(R.id.green_house1_previous_area);
        //Edittext
        green_house1_name = (EditText) findViewById(R.id.green_house1_name);
        green_house1_address = (EditText) findViewById(R.id.green_house1_address);
        green_house1_mobile_no = (EditText) findViewById(R.id.green_house1_mobile_no);
        green_house1_alternate_no = (EditText) findViewById(R.id.green_house1_alternate_no);
        green_house1_reg_no = (EditText) findViewById(R.id.green_house1_reg_no);
        //Imageview
        //green_house1_dateiv = (ImageView) findViewById(R.id.green_house1_dateiv);
        green_house1_part1_save = (Button) findViewById(R.id.green_house1_part1_save);

        green_house1_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        green_house1_datetv.setText(green_house1_date);
    }

    private void functions(){
        /*green_house1_dateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               green_house1_date_service();
            }
        });*/

        green_house1_part1_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GreenHouseActivity.this,GIPipesActivity.class);
                startActivity(intent);
                //green_house1_part1_save_service();
            }
        });
    }

    private void green_house1_date_service(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        green_house1_datepicker = new DatePickerDialog(GreenHouseActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        green_house1_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        green_house1_datetv.setText(green_house1_date);
                    }
                }, mYear, mMonth, mDay);

        green_house1_datepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        green_house1_datepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        green_house1_datepicker.show();
    }

    private void green_house1_part1_save_service(){
        if(green_house1_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select तपासणी दिनांक", Toast.LENGTH_SHORT).show();
        }else if(green_house1_name.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter सेवा पुरवठादाराचे नाव", Toast.LENGTH_SHORT).show();
        }else if(green_house1_address.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter सेवा पुरवठादाराचे पत्ता", Toast.LENGTH_SHORT).show();
        }else if(green_house1_mobile_no.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter दूरध्वनी क्र.", Toast.LENGTH_SHORT).show();
        }else if(green_house1_alternate_no.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter भ्रमणध्वनी क्र.", Toast.LENGTH_SHORT).show();
        }else if(green_house1_reg_no.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter सेवा पुरवठादार यांचा जिल्हा अधिक्षक कृषि अधिकारी यांचेकडील नोंदणी क्रमांक", Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("date_gh", green_house1_date);
                param.put("farmer_name", "0");
                param.put("village_id", "0");
                param.put("taluka_id", "0");
                param.put("district_id", "0");
                param.put("survey_no", "0");
                param.put("vargvari", "0");
                param.put("bab1", "0");
                param.put("previous_date", "0");
                param.put("pre_area", "0");
                param.put("gh_name", green_house1_name.getText().toString().trim());
                param.put("gh_address", green_house1_address.getText().toString().trim());
                param.put("durdhvani", green_house1_mobile_no.getText().toString().trim());
                param.put("bhraman", green_house1_alternate_no.getText().toString().trim());
                param.put("reg_no", green_house1_reg_no.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
        }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Green House and Shade Net House");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    /*Intent intent = new Intent(GreenHouseActivity.this,GIPipesActivity.class);
                                    startActivity(intent);*/
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
