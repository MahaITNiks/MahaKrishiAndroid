package com.maha.agri.farmer;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerCategoriesActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView farmer_categories_rv;
    private JSONArray farmer_magazine_category_list,farmer_month_list;
    private int[] farmer_dashboard_backy = {R.drawable.dash_attendance,R.drawable.dash_task,R.drawable.dash_task_report,R.drawable.dash_assigned_villages};
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String  category_id,year,id,magazine_category__title;
    private DBHandler dbHandler;
    HashMap<Integer,String> selected_category_id = new HashMap<>();
    View parentLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_categories);
        Intent intent = getIntent();

        magazine_category__title = intent.getStringExtra("magazine_title");
        if (magazine_category__title.equalsIgnoreCase("farmer")){
            getSupportActionBar().setTitle("शेतकरी मासिक");
        } else if(magazine_category__title.equalsIgnoreCase("dept")){ // DOUBT
            getSupportActionBar().setTitle("Farmer Magazine");
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerCategoriesActivity.this);
        sharedPref = new SharedPref(FarmerCategoriesActivity.this);
        dbHandler = new DBHandler(this);
        parentLayout = findViewById(android.R.id.content);

        if(isNetworkAvailable()){
            IdCalling();
            default_Config();
            getTaskManagerListWebservie();
        }else{
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        }

    }

    private void getTaskManagerListWebservie() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.farmer_magazine_categories_url();  // METHOD CALLED
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
//        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall,  this, 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
                                                                                                                                            // ADAPTER HERE
    private void default_Config() {
       /* farmer_categories_rv.addOnItemTouchListener(new FarmerMagazineAdapter.RecyclerTouchListener(this, farmer_categories_rv, new FarmerMagazineAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                id = selected_category_id.get(position);
                getPDFWebservie();
            }
            // NOT SURE ABOUT THIS
            private void getPDFWebservie() {
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));*/
    }

    private void IdCalling() {
        farmer_categories_rv = (RecyclerView)findViewById(R.id.farmer_categories_rv);
        farmer_categories_rv.setLayoutManager(new GridLayoutManager(this, 2));

        Calendar calander = Calendar.getInstance();
        year = String.valueOf(calander.get(Calendar.YEAR));
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_magazine_category_list = jsonObject.getJSONArray("data");
                            for(int j = 0;j < farmer_magazine_category_list.length();j++){
                                JSONObject category_json_obj = farmer_magazine_category_list.getJSONObject(j);
                                category_id = category_json_obj.getString("id");
                                selected_category_id.put(j, category_id);
                            }


                            farmer_categories_rv.setAdapter(new FarmerCategoriesAdapter(preferenceManager, farmer_magazine_category_list,farmer_dashboard_backy, this));

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }


            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
