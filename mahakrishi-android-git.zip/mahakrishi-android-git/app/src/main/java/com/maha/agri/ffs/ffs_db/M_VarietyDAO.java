package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_VarietyDAO {

    @Query("SELECT * FROM M_VarietyEY")
    List<M_VarietyEY> getAll();

    @Query("SELECT * FROM M_VarietyEY WHERE uid IN (:userIds)")
    List<M_VarietyEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_VarietyEY WHERE uid = :id")
    List<M_VarietyEY> checkIdExists(int id);

    @Query("SELECT * FROM M_VarietyEY WHERE crop_id = :crop_id")
    List<M_VarietyEY> getCropVarietyAll(int crop_id);


    @Insert
    void insertAll(M_VarietyEY... m_varietyEYS);

    @Insert
    void insertOnlySingle(M_VarietyEY m_varietyEY);


}
