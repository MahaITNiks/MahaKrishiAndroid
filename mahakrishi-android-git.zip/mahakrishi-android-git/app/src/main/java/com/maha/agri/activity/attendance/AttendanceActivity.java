package com.maha.agri.activity.attendance;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.model.LocationModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.GPSTracker;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListCallbackEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AttendanceActivity extends AppCompatActivity implements ApiCallbackCode, AlertListCallbackEventListener {

    GPSTracker gps;
    public AppLocationManager appLocationManager;
    private DBHandler dbHandler;

    // For Camera
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private ManagePermission managePermissions;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final int APP_PERMISSION_CAMERA_REQUEST_CODE = 222;
    private File photoFile = null;
    private Transformation transformation;
    PreferenceManager preferenceManager;

    private String userId;
    private String currentTime;
    static final Integer CAMERA = 0x5;
    private TextView plzTakeSelfieText,checkinandouttv;

    private CircleImageView attendance_camera_selfie_iv;
    private Button mark_attendance_btn;

    String attendDate, complete_address;

    private String checkIn_lat = "";
    private String checkIn_long = "";
    private String checkOut_lat = "";
    private String checkOut_long = "";
    private String file_lat = "";
    private String file_long = "";
    private String cLat = "";
    private String cLong = "";

    private JSONArray checkInArray;

    private LinearLayout reasonLLayout;
    private RelativeLayout reasonRLayout;
    private TextView reasonDropTextView;
    private JSONArray reasonListArray = null;
    private String reasonId = "";

    private boolean memIsIn = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        getSupportActionBar().setTitle("Attendance");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        dbHandler = new DBHandler(this);
        preferenceManager = new PreferenceManager(AttendanceActivity.this);
        appLocationManager = new AppLocationManager();


        init();
        default_config();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void init() {

        userId = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);

        attendance_camera_selfie_iv = (CircleImageView) findViewById(R.id.attendance_selfie_camera_iv);
        mark_attendance_btn = (Button) findViewById(R.id.mark_attendance_btn);
        plzTakeSelfieText = (TextView) findViewById(R.id.plzTakeSelfieText);
        checkinandouttv = (TextView) findViewById(R.id.checkInandOutv);
        reasonLLayout = (LinearLayout) findViewById(R.id.reasonLLayout);
        reasonRLayout = (RelativeLayout) findViewById(R.id.reasonRLayout);
        reasonDropTextView = (TextView) findViewById(R.id.reasonDropTextView);

        currentTime = ApUtil.getCurrentTimeStamp();
        attendDate = String.valueOf(ApUtil.getDateByTimeStamp(currentTime));

    }


    public void default_config() {

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(40)
                .oval(true)
                .build();


        attendance_camera_selfie_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT < 19) {
                    getLocation("file");
                    takeImageFromCameraUri();
                } else {
                    if (checkUserPermission(APP_PERMISSION_CAMERA_REQUEST_CODE)) {
                        getLocation("file");
                        takeImageFromCameraUri();
                    }
                }
            }
        });

        reasonRLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String reasonData = AppSettings.getInstance().getValue(AttendanceActivity.this, ApConstants.kAB_REASON, ApConstants.kAB_REASON);
                if (!reasonData.equalsIgnoreCase("kAB_REASON")) {
                    try {
                        reasonListArray = new JSONArray(reasonData);
                        ApUtil.showCustomListPicker(reasonDropTextView, reasonListArray, "Select Reason", "name", "id", AttendanceActivity.this, AttendanceActivity.this);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (ApUtil.checkInternetConnection(AttendanceActivity.this)) {
                        getAbsentReasonList();
                    } else {
                        UIToastMessage.show(AttendanceActivity.this, "No internet connection");
                    }

                }
            }
        });


        mark_attendance_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!memIsIn) {
                    if (!reasonId.equalsIgnoreCase("")) {
                        attendanceBtnAction(reasonId);
                    } else{
                        UIToastMessage.show(AttendanceActivity.this, "You are out of your assigned jurisdiction \nplease Select reason");
                    }
                } else {
                    attendanceBtnAction("");
                }
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        isCheckIdIn();
        if (Build.VERSION.SDK_INT < 19) {
            getLocation("");
        } else {
            if (checkUserPermission(APP_PERMISSION_REQUEST_CODE)) {
                getLocation("");
            }
        }

    }

    private void attendanceBtnAction(String reasonId) {

        if (photoFile != null) {

            if (checkInArray.length() > 0) {

                getLocation("out");
                if (!checkOut_lat.equalsIgnoreCase("") && !checkOut_lat.equalsIgnoreCase("")) {
                    boolean result = dbHandler.updateOutAttendanceDetails(userId, attendDate, ApUtil.getCurrentTimeStamp(), complete_address, checkOut_lat, checkOut_long, photoFile.toString(), file_lat, file_long);
                    if (result) {
                        clearAttendanceData();
                        UIToastMessage.show(AttendanceActivity.this, "Success");
                        finish();
                        isCheckIdIn();
                    } else {
                        UIToastMessage.show(AttendanceActivity.this, "Fail");
                    }
                }

            } else {

                getLocation("in");
                if (!checkIn_lat.equalsIgnoreCase("") && !checkIn_long.equalsIgnoreCase("")) {
                    boolean result = dbHandler.insertInAttendanceDetails(userId, attendDate, ApUtil.getCurrentTimeStamp(), complete_address, checkIn_lat, checkIn_long, photoFile.toString(), file_lat, file_long,
                            "", "", "", "", "", "", "", reasonId);
                    if (result) {
                        clearAttendanceData();
                        UIToastMessage.show(AttendanceActivity.this, "Success");
                        finish();
                        isCheckIdIn();
                    } else {
                        UIToastMessage.show(AttendanceActivity.this, "Fail");
                    }
                }
            }

        } else {
            UIToastMessage.show(AttendanceActivity.this, "Please click selfie to mark your attendance");
        }
    }


    private void getAbsentReasonList() {

        JSONObject param = new JSONObject();
        /*try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.absentReasonListReq(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    private void isCheckIdIn() {
        checkInArray = dbHandler.getAttendanceByDateType(userId, attendDate);
        if (checkInArray.length() > 0) {
            mark_attendance_btn.setText("Mark Attendance (Out)");
            //plzTakeSelfieText.setText("Please take selfie to mark your attendance (Out)");
            checkinandouttv.setText("Check Out");
            checkinandouttv.setTextColor(getResources().getColor(R.color.red));
        } else {
            mark_attendance_btn.setText("Mark Attendance (In)");
            //plzTakeSelfieText.setText("Please take selfie to mark your attendance (in)");
            checkinandouttv.setText("Check In");
            checkinandouttv.setTextColor(getResources().getColor(R.color.green));
        }
    }


    private void clearAttendanceData() {
        photoFile = null;
        checkIn_lat = "";
        checkIn_long = "";
        checkOut_lat = "";
        checkOut_long = "";
        file_lat = "";
        file_long = "";
        reasonDropTextView.setText("");
        reasonId = "";
        attendance_camera_selfie_iv.setImageDrawable(getResources().getDrawable(R.drawable.camera));
    }



    // To get Lat & long
    private void getLocation(String type) {
        gps = new GPSTracker(this);
        // Check if GPS enabled

        if (ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(AttendanceActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        } else {

            if (gps.canGetLocation()) {

                final double latitude = gps.getLatitude();
                final double longitude = gps.getLongitude();

                if (type.equalsIgnoreCase("in")) {
                    checkIn_lat = String.valueOf(latitude);
                    checkIn_long = String.valueOf(longitude);
                } else if (type.equalsIgnoreCase("out")) {
                    checkOut_lat = String.valueOf(latitude);
                    checkOut_long = String.valueOf(longitude);
                } else if (type.equalsIgnoreCase("file")) {
                    file_lat = String.valueOf(latitude);
                    file_long = String.valueOf(longitude);
                } else {
                    cLat = String.valueOf(latitude);
                    cLong = String.valueOf(longitude);
                    if (!isUserInRange(cLat,cLong)) {
                        reasonLLayout.setVisibility(View.VISIBLE);
                    } else {
                        reasonLLayout.setVisibility(View.GONE);
                    }
                }
                // Write you code here if permission already given.


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Geocoder geocoder = new Geocoder(AttendanceActivity.this, Locale.getDefault());
                        List<Address> addresses = null;
                        try {
                            addresses = (List<Address>) geocoder.getFromLocation(latitude, longitude, 1);
                            if (addresses != null) {
                                complete_address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


                    }
                }, 2000);


            } else {
                // Can't get location.
                // GPS or network is not enabled.
                // Ask user to enable GPS/network in settings.
                showSettingsAlert();
            }
        }
    }

    // From Single Lat long
    private boolean isInArea() {

        boolean result = false;
        String loginData = AppSettings.getInstance().getValue(this, ApConstants.kLOGIN_DATA, ApConstants.kLOGIN_DATA);

        if (!loginData.equalsIgnoreCase("kLOGIN_DATA")) {
            try {
                JSONObject jsonObject = new JSONObject(loginData);
                JSONArray locationArray = jsonObject.getJSONArray("villages_location");
                if (locationArray.length() > 0) {

                    for (int i = 0; i < locationArray.length(); i++) {
                        JSONObject locJSON = locationArray.getJSONObject(i);
                        String loc_lat = locJSON.getString("lat_loc");
                        String loc_long = locJSON.getString("long_loc");
                        Double dist = ApUtil.distanceByLatLong(Double.valueOf(loc_lat), Double.valueOf(cLat), Double.valueOf(loc_long), Double.valueOf(cLong));
                        if (dist < 2) {
                            result = true;

                        }
                    }

                } else {
                    UIToastMessage.show(this, "Assigned area not found");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        memIsIn = result;
        return result;
    }


    // From min and max latLong
    private boolean isUserInRange(String cLat,String cLong) {

        boolean isRegion = false;

        double lat = Double.parseDouble(cLat);
        double lng = Double.parseDouble(cLong);

       //  DebugLog.getInstance().d("GPS Time=" + appLocationManager.location.getTime());

        Location currentLoc = new Location("Current Location");
        currentLoc.setLatitude(lat);
        currentLoc.setLongitude(lng);

        DebugLog.getInstance().d("Accuracy=" + currentLoc.getAccuracy());

        String loginData = AppSettings.getInstance().getValue(this, ApConstants.kLOGIN_DATA, ApConstants.kLOGIN_DATA);
        if (!loginData.equalsIgnoreCase("kLOGIN_DATA")) {

            try {
                JSONObject loginObject = new JSONObject(loginData);
                JSONArray locationArray = loginObject.getJSONArray("villages_location");

                for (int k = 0; k < locationArray.length(); k++) {

                    JSONObject jsonObject = locationArray.getJSONObject(k);
                    LocationModel model = new LocationModel(jsonObject);

                    double minLat = Double.parseDouble(model.getMin_lat());
                    double minLong = Double.parseDouble(model.getMin_long());

                    double maxLat = Double.parseDouble(model.getMax_lat());
                    double maxLong = Double.parseDouble(model.getMax_long());

                    Location locA = new Location("locationA");
                    locA.setLatitude(minLat);
                    locA.setLongitude(minLong);

                    Location locB = new Location("locationB");
                    locB.setLatitude(minLat);
                    locB.setLongitude(maxLong);

                    Location locC = new Location("locationC");
                    locC.setLatitude(maxLat);
                    locC.setLongitude(maxLong);

                    Location locD = new Location("locationD");
                    locD.setLatitude(maxLat);
                    locD.setLongitude(minLong);


                    float jurisdictionAreaAB = locA.distanceTo(locB);
                    double jurisdictionRadiusAB = Math.floor(jurisdictionAreaAB);

                    float jurisdictionAreaBC = locB.distanceTo(locC);
                    double jurisdictionRadiusBC = Math.floor(jurisdictionAreaBC);

                    float jurisdictionAreaCD = locC.distanceTo(locD);
                    double jurisdictionRadiusCD = Math.floor(jurisdictionAreaCD);

                    float jurisdictionAreaDA = locD.distanceTo(locA);
                    double jurisdictionRadiusDA = Math.floor(jurisdictionAreaDA);

                    float jurisdictionAreaAC = locA.distanceTo(locC);
                    double jurisdictionRadiusAC = Math.floor(jurisdictionAreaAC);


                    DebugLog.getInstance().d("radius=" + jurisdictionRadiusAC / 2);

                    float[] results = new float[1];

                    Location.distanceBetween(currentLoc.getLatitude(), currentLoc.getLongitude(), locA.getLatitude(), locA.getLongitude(), results);
                    float pointA = results[0];

                    Location.distanceBetween(currentLoc.getLatitude(), currentLoc.getLongitude(), locB.getLatitude(), locB.getLongitude(), results);
                    float pointB = results[0];

                    Location.distanceBetween(currentLoc.getLatitude(), currentLoc.getLongitude(), locC.getLatitude(), locC.getLongitude(), results);
                    float pointC = results[0];

                    Location.distanceBetween(currentLoc.getLatitude(), currentLoc.getLongitude(), locD.getLatitude(), locD.getLongitude(), results);
                    float pointD = results[0];

                    int pointAreaABValue = Math.round(jurisdictionAreaAB);
                    int pointAreaBCValue = Math.round(jurisdictionAreaBC);
                    int pointAreaCDValue = Math.round(jurisdictionAreaCD);
                    int pointAreaDAValue = Math.round(jurisdictionAreaDA);
                    int pointAreaACValue = Math.round(jurisdictionAreaAC);

                    int[] arrayOfArea = {pointAreaABValue, pointAreaBCValue, pointAreaCDValue, pointAreaDAValue, pointAreaACValue};
                    Arrays.sort(arrayOfArea);

                    int minArea = arrayOfArea[0];
                    int maxArea = arrayOfArea[arrayOfArea.length - 1];
                    DebugLog.getInstance().d("minArea=" + String.valueOf(minArea));
                    DebugLog.getInstance().d("maxArea=" + String.valueOf(maxArea));


                    int pointAValue = Math.round(pointA);
                    int pointBValue = Math.round(pointB);
                    int pointCValue = Math.round(pointC);
                    int pointDValue = Math.round(pointD);


                    int[] arrayOfPoint = {pointAValue, pointBValue, pointCValue, pointDValue};
                    Arrays.sort(arrayOfPoint);

                    int min = arrayOfPoint[0];
                    int max = arrayOfPoint[arrayOfPoint.length - 1];

                    DebugLog.getInstance().d("min point=" + String.valueOf(min));
                    DebugLog.getInstance().d("max point=" + String.valueOf(max));


                    double jurisdictionArea = maxArea + (minArea / 2);

                    DebugLog.getInstance().d("jurisdictionRadiusAB=" + String.valueOf(jurisdictionRadiusAB));
                    DebugLog.getInstance().d("jurisdictionRadiusBC=" + String.valueOf(jurisdictionRadiusBC));
                    DebugLog.getInstance().d("jurisdictionRadiusCD=" + String.valueOf(jurisdictionRadiusCD));
                    DebugLog.getInstance().d("jurisdictionRadiusDA=" + String.valueOf(jurisdictionRadiusDA));

                    DebugLog.getInstance().d("radius=" + String.valueOf(jurisdictionArea));


                    DebugLog.getInstance().d("pointA=" + String.valueOf(pointA));
                    DebugLog.getInstance().d("pointB=" + String.valueOf(pointB));
                    DebugLog.getInstance().d("pointC=" + String.valueOf(pointC));
                    DebugLog.getInstance().d("pointD=" + String.valueOf(pointD));


                    double far = min - jurisdictionArea;


                    if ((far < 0)) {
                        isRegion = true;
                        reasonLLayout.setVisibility(View.GONE);
                        DebugLog.getInstance().d("User in geofence area");
                        break;
                    } else {
                        reasonLLayout.setVisibility(View.VISIBLE);
                        //distanceTextView.setText("Far from jurisdiction area =" + String.valueOf(far) + "M");
                        isRegion = false;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            UIToastMessage.show(this, "Assigned area not found");
        }
        return isRegion;
    }


    /**
     * Function to show settings alert dialog.
     * On pressing the Settings button it will launch Settings Options.
     */
    public void showSettingsAlert() {
        android.app.AlertDialog.Builder alertDialog = new android.app.AlertDialog.Builder(this);

        // Setting Dialog Title
        alertDialog.setTitle("GPS is settings");

        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");

        // On pressing the Settings button.
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });


        // On pressing the cancel button
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }


    @Override
    public void didSelectAlertViewListItem(TextView textView, String s) {
        if (textView == reasonDropTextView) {
            reasonId = s;
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                // Absent reason Response
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            reasonListArray = responseModel.getData();
                            AppSettings.getInstance().setValue(this, ApConstants.kAB_REASON, reasonListArray.toString());
                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }




    // For CAMERA

    /**** For permission with ManagePermissionClass*****/
    private boolean checkUserPermission(int appPermissionCode) {

        int permissionCamera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionFineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int permissionCoarseLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int permissionStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        ArrayList<String> listPermissionsNeeded = new ArrayList<>();

        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (permissionWrite != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionFineLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionCoarseLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        if (appPermissionCode == APP_PERMISSION_CAMERA_REQUEST_CODE) {
            if (!listPermissionsNeeded.isEmpty()) {
                managePermissions = new ManagePermission(this, listPermissionsNeeded, APP_PERMISSION_CAMERA_REQUEST_CODE);
                ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), APP_PERMISSION_CAMERA_REQUEST_CODE);
                return false;
            }
        } else {
            if (!listPermissionsNeeded.isEmpty()) {
                managePermissions = new ManagePermission(this, listPermissionsNeeded, APP_PERMISSION_REQUEST_CODE);
                ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), APP_PERMISSION_REQUEST_CODE);
                return false;
            }
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case APP_PERMISSION_REQUEST_CODE: {
                boolean isPermissionsGranted = managePermissions.processPermissionsResult(requestCode, permissions, grantResults);
                if (isPermissionsGranted) {
                    getLocation("");
                } else {
                    // toast("Permissions denied.")
                    managePermissions.checkPermission();
                }
            }
            break;

            case APP_PERMISSION_CAMERA_REQUEST_CODE: {
                boolean isPermissionsGranted = managePermissions.processPermissionsResult(requestCode, permissions, grantResults);
                if (isPermissionsGranted) {
                    getLocation("file");
                    takeImageFromCameraUri();
                } else {
                    // toast("Permissions denied.")
                    managePermissions.checkPermission();
                }
            }
            break;
        }
    }


    private void takeImageFromCameraUri() {

        currentTime = ApUtil.getCurrentTimeStamp();
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userId + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                //profileIView.setImageBitmap(bmp);
                //Uri uri = Uri.fromFile(photoFile);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        String imagePath = "file://" + photoFile;

                        Picasso.get()
                                //.load("")
                                // .load(photoFile)
                                .load(imagePath)
                                .transform(transformation)
                                .resize(150, 150)
                                .centerCrop()
                                .into(attendance_camera_selfie_iv);

                        //  uploadImageOnServer(imagePath);

                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(AttendanceActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }

}
