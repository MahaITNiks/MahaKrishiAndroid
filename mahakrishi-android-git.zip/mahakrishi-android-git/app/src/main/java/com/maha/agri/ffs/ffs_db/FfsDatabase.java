/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;

import androidx.room.Database;
import androidx.room.RoomDatabase;



@Database(entities = {
            FacilitatorSchedulesEY.class,
            M_DefenderEY.class,
            M_MethodOfSowingEY.class,
            M_PestEY.class,
            M_Tech_DemoEY.class,
            M_Social_CategoryEY.class,
            M_VarietyEY.class,
            M_SoilConditionEY.class,
            M_WeatherConditionEY.class,
            M_RainfallConditionEY.class,
            M_DiseaseTypeEY.class,
            M_DiseaseSeverityEY.class,
            M_WeedsTypeIntensityEY.class,
            M_IrrigationMethodEY.class,
            M_WindCondEY.class,
            M_RodentDamageEY.class,
            T_PestEY.class,
            T_DefenderEY.class,
            T_DiseaseTypeEY.class,


        }, version = 17 , exportSchema = false)


public abstract class FfsDatabase extends RoomDatabase {

    public abstract FacilitatorSchedulesDAO facilitatorSchedulesDAO();
    public abstract M_DefenderDAO mDefenderDAO();
    public abstract M_MethodOfSowingDAO methodOfSowingDAO();
    public abstract M_PestDAO pestDAO();
    public abstract M_Tech_DemoDAO tech_demoDAO();
    public abstract M_SocialCategoryDAO socialCategoryDAO();
    public abstract M_VarietyDAO varietyDAO();
    public abstract M_SoilConditionDAO soilConditionDAO();
    public abstract M_WeatherConditionDAO weatherConditionDAO();
    public abstract M_RainfallConditionDAO rainfallConditionDAO();
    public abstract M_DiseaseTypeDAO diseaseTypeDAO();
    public abstract M_DiseaseSeverityDAO diseaseSeverityDAO();
    public abstract M_WeedsTypeIntensityDAO weedsTypeIntensityDAO();
    public abstract M_IrrigationMethodDAO irrigationMethodDAO();
    public abstract M_WindCondDAO windCondDAO();
    public abstract M_RodentDamageDAO rodentDamageDAO();
    public abstract T_PestDAO tPestDAO();
    public abstract T_DefenderDAO tDefenderDAO();
    public abstract T_DiseaseTypeDAO tDiseaseTypeDAO();

}



