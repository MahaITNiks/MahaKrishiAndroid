/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface FacilitatorSchedulesDAO {

    @Query("SELECT * FROM FacilitatorSchedulesEY")
    List<FacilitatorSchedulesEY> getAll();

    @Query("SELECT * FROM FacilitatorSchedulesEY WHERE plot_id = :plotId LIMIT 1")
    List<FacilitatorSchedulesEY> getSingleRecord(int plotId);

    @Query("SELECT * FROM FacilitatorSchedulesEY WHERE uid IN (:userIds)")
    List<FacilitatorSchedulesEY> loadAllByIds(int[] userIds);

    @Insert
    void insertAll(FacilitatorSchedulesEY... facilitatorSchedulesEYS);

    @Insert
    void insertOnlySingle(FacilitatorSchedulesEY facilitatorSchedulesEY);

    @Query("UPDATE FacilitatorSchedulesEY SET  is_completed = :is_completed WHERE uid = :schedule_id ")
    void update(int is_completed, int schedule_id);



}
