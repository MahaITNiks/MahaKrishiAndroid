package com.maha.agri.ochard_mapping;

public interface OrchardSurveyInterface {

    void getUpdatedCount(int length);
}
