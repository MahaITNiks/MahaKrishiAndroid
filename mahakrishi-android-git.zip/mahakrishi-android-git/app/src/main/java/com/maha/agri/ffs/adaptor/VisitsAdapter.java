package com.maha.agri.ffs.adaptor;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.util.ApUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.widget.UIToastMessage;

public class VisitsAdapter extends RecyclerView.Adapter<VisitsAdapter.ViewHolder> {

    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;
    private String isCompleted;

    public VisitsAdapter(Context mContext, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
    }


    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.recycler_ffs_visits, parent, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            holder.onBind(mDataArray.getJSONObject(position), listener,position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView titleTextView;
        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener, int position) {


            try {
                int visitNum = position+1;
                String visitDate = jsonObject.getString("visit_date");
                isCompleted = jsonObject.getString("is_completed");

                if (isCompleted.equalsIgnoreCase("0")){
                    titleTextView.setBackgroundColor(mContext.getResources().getColor(R.color.white));
                    titleTextView.setTextColor(mContext.getResources().getColor(R.color.heading));
                    if ( !visitDate.equalsIgnoreCase("null")){
                        // String date = ApUtil.getDateByTimeStamp(visitDate);
                        String date = ApUtil.getDateInDDMMYYYY(visitDate);
                        // String day = ApUtil.getDayByTimeStamp(visitDate);
                        String day = ApUtil.getDayByDate(visitDate);
                        String title = "Visit no. "+visitNum+ "\n"+date+" \n"+day;
                        titleTextView.setText(title);
                    }
                } else {
                    titleTextView.setBackgroundColor(mContext.getResources().getColor(R.color.light_grey));
                    titleTextView.setTextColor(mContext.getResources().getColor(R.color.white));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isCompleted.equalsIgnoreCase("0")){
                        listener.onMultiRecyclerViewItemClick(1, jsonObject);
                    }else {

                        UIToastMessage.show(mContext, "This schedule is completed, \nPlease try other.");
                    }

                }
            });
        }
    }
}
