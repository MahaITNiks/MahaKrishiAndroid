package com.maha.agri.activity.common;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.util.Log;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;

import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONException;
import org.json.JSONObject;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ProfileActivity extends AppCompatActivity implements ApiCallbackCode {


    static final Integer WRITE_EXST = 0x3;
    static final Integer READ_EXST = 0x4;
    static final Integer CAMERA = 0x5;
    static final Integer NOT_GRANTED = 0x6;
    // For Camera
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    PreferenceManager preferenceManager;
    String currentTime;
    SharedPref sharedPref;
    Bitmap photo;
    String imgString;
    private ManagePermission managePermissions;
    private File photoFile = null;
    private Transformation transformation;
    private String userId;
    private ImageView profile_image_view, upload_camera, upload_gallery;
    private EditText surnameedt, middlenameedt, firstnameedt, emailedt, mobile_numberedt;
    private Button updatprofilebtn;
    private String Firstname, Lastname, Mobilenumber, Middlename, Email, profilePic;
    private AlertDialog alertDialog;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.profile_activity);
        getSupportActionBar().setTitle("Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(ProfileActivity.this);
        sharedPref = new SharedPref(ProfileActivity.this);
        currentTime = ApUtil.getCurrentTimeStamp();

        init();
        defaultConfig();

    }

    @Override
    protected void onResume() {
        super.onResume();
        setProfileData();
    }

    private void init() {

        userId = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);

        profile_image_view = (ImageView) findViewById(R.id.profile_image_view);
        firstnameedt = (EditText) findViewById(R.id.firstnameedt);
        surnameedt = (EditText) findViewById(R.id.surnameedt);
        middlenameedt = (EditText) findViewById(R.id.middlenameedt);
        emailedt = (EditText) findViewById(R.id.emailedt);
        updatprofilebtn = (Button) findViewById(R.id.update_profile_btn);
        mobile_numberedt = (EditText) findViewById(R.id.mobileedt);
    }


    private void defaultConfig() {
        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(40)
                .oval(false)
                .build();


        profile_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* if (Build.VERSION.SDK_INT < 19) {
                    takeImageFromCameraUri();
                } else {
                    if (checkUserPermission()) {
                        takeImageFromCameraUri();
                    }
                }*/
                if ((ContextCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }

            }
        });


        updatprofilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateProfileData();
            }
        });
    }


    private void setProfileData() {
        String user_data = AppSettings.getInstance().getValue(this, ApConstants.kLOGIN_DATA, ApConstants.kLOGIN_DATA);
        if (!user_data.equalsIgnoreCase("kLOGIN_DATA")) {

            try {
                JSONObject userJson = new JSONObject(user_data);

                String fName = AppUtility.getInstance().sanitizeJSONObj(userJson, "first_name");
                String lName = AppUtility.getInstance().sanitizeJSONObj(userJson, "last_name");
                String mName = AppUtility.getInstance().sanitizeJSONObj(userJson, "middle_name");
                String email = AppUtility.getInstance().sanitizeJSONObj(userJson, "email");
                String mobile = AppUtility.getInstance().sanitizeJSONObj(userJson, "mobile");
                String profileImage = AppUtility.getInstance().sanitizeJSONObj(userJson, "profile_pic");


                firstnameedt.setText(fName);
                surnameedt.setText(lName);
                middlenameedt.setText(mName);
                emailedt.setText(email);
                mobile_numberedt.setText(mobile);

                if (!profileImage.isEmpty()) {

                    Picasso.get()
                            .load(Uri.parse(profileImage))
                            .transform(transformation)
                            .resize(150, 150)
                            .centerCrop()
                            .placeholder(R.drawable.person)
                            .into(profile_image_view);

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void UpdateProfileData() {
        String surname = surnameedt.getText().toString().trim();
        String middlename = middlenameedt.getText().toString().trim();
        String firstname = firstnameedt.getText().toString().trim();
        String mobile = mobile_numberedt.getText().toString().trim();
        String email = emailedt.getText().toString().trim();

        if (surname.isEmpty()) {
            UIToastMessage.show(this, "Enter surname name");
        } else if (firstname.isEmpty()) {
            UIToastMessage.show(this, "Enter first name");
        } else if (mobile.isEmpty()) {
            UIToastMessage.show(this, "Enter mobile number");
        } else if (middlename.isEmpty()) {
            UIToastMessage.show(this, "Enter middle name");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("first_name", firstname);
                param.put("id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("last_name", surname);
                param.put("middle_name", middlename);
                param.put("email", email);
                param.put("mobile", mobile);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.onupdaterequest(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                // Profile update response
                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);

                    if (responseModel.isStatus()) {
                        //UIToastMessage.show(this, responseModel.getMsg());
                        sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                        sweetAlertDialog.setCancelable(false);
                        sweetAlertDialog.setTitleText("Profile Update");
                        sweetAlertDialog.setContentText("Profile Updated Successfully");
                        sweetAlertDialog.setConfirmText("Ok");
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                try{
                                    JSONObject login_Data = jsonObject.getJSONObject("data");
                                    AppSettings.getInstance().setValue(ProfileActivity.this, ApConstants.kLOGIN_DATA, login_Data.toString());
                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            setProfileData();
                                        }
                                    }, 2000);
                                    finish();
                                }catch (Exception e){

                                }
                            }
                        });
                        sweetAlertDialog.show();
                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }

                // Profile pic update response
                if (i == 2) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);

                    if (responseModel.isStatus()) {
                        UIToastMessage.show(this, responseModel.getMsg());
                        JSONObject login_Data = jsonObject.getJSONObject("data");
                        AppSettings.getInstance().setValue(this, ApConstants.kLOGIN_DATA, login_Data.toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                setProfileData();
                            }
                        }, 2000);

                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == APP_PERMISSION_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                takeImageFromCameraUri();
            } else {
                // Permission Denied
                Toast.makeText(ProfileActivity.this, "This Feature require permission.", Toast.LENGTH_SHORT)
                        .show();
            }

        }
    }


    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userId + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            } /*if(requestCode == NOT_GRANTED){
                managePermissions.requestPermissions();
            }*/
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                //profileIView.setImageBitmap(bmp);
                //Uri uri = Uri.fromFile(photoFile);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                //.load("")
                                // .load(photoFile)
                                .load(imagePath)
                                .transform(transformation)
                                .resize(150, 150)
                                .centerCrop()
                                .into(profile_image_view);

                        uploadImageOnServer(imagePath);
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(ProfileActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {


            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));


            //creating a file
            File file = new File(photoFile.getPath());
            // File file = new File(imagePath);

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.onupdateprofilepic(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}



