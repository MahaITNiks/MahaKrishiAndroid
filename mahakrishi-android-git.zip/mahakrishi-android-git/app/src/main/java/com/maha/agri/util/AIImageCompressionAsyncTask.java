/*
 * Copyright (c) 2019. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/1/19 1:17 PM
 */

package com.maha.agri.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import in.co.appinventor.services_api.listener.AIImgAsyncResponse;


public class AIImageCompressionAsyncTask extends AsyncTask<String, Void, String> {

    private AIImageLoadingUtils mAIImageLoadingUtils;
    public AIImgAsyncResponse delegate = null;//Call back interface
    private File tempFilePath = null;

    public AIImageCompressionAsyncTask(AIImageLoadingUtils mAIImageLoadingUtils, File tempFilePath, AIImgAsyncResponse asyncResponse) {
        this.mAIImageLoadingUtils = mAIImageLoadingUtils;
        this.tempFilePath = tempFilePath;
        this.delegate = asyncResponse;
    }

    @Override
    protected String doInBackground(String... params) {
        String filePath = compressImage(params[0]);
        return filePath;
    }


    private String compressImage(String filePaths) {

//			String filePath = getRealPathFromURI(imageUri);
        String filePath = this.tempFilePath.getAbsolutePath();
        Bitmap scaledBitmap = null;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(filePath , options);

        int actualHeight = options.outHeight;
        int actualWidth = options.outWidth;

        //Capture Resolution-> 1024x768 - <1 Megapixel  Video Display*->Excellent**	Print Size***-> Photo Quality

        //Capture Resolution-> 1280x960 - 1 Megapixel  Video Display*->Excellent**	Print Size***-> Photo Quality
        //Capture Resolution-> 1600x1200 - 2 Megapixel  Video Display*->Excellent**	Print Size***-> Photo Quality

        //Capture Resolution-> 2048x1536 - 3 Megapixel  Video Display*->Excellent**	Print Size***-> Photo Quality
        //Capture Resolution-> 2240x1680 - 4 Megapixel  Video Display*->Excellent**	Print Size***-> Photo Quality

        float maxHeight = 1280.0f;
        float maxWidth = 960.0f;


//---50 KB
//        float maxHeight = 1024.0f;
//        float maxWidth = 768.0f;


//---21 KB
//			float maxWidth = 612.0f;
//			float maxHeight = 816.0f;


/*

			ExifInterface exifs = null;
			try {
				exifs = new ExifInterface(filePath);
			} catch (IOException e) {
				e.printStackTrace();
			}

			float maxWidth = exifs.getAttributeInt( ExifInterface.TAG_IMAGE_WIDTH, 0 );
			float maxHeight = exifs.getAttributeInt( ExifInterface.TAG_IMAGE_LENGTH, 0 );

//			float maxHeight = utils.getFileIMGHeight(Uri.fromFile(new File(filePath)));
//			float maxWidth = utils.getFileIMGWidth(Uri.fromFile(new File(filePath)));;
*/

        float imgRatio = actualWidth / actualHeight;
        float maxRatio = maxWidth / maxHeight;

        if (actualHeight > maxHeight || actualWidth > maxWidth) {
            if (imgRatio < maxRatio) {
                imgRatio = maxHeight / actualHeight;
                actualWidth = (int) (imgRatio * actualWidth);
                actualHeight = (int) maxHeight;
            } else if (imgRatio > maxRatio) {
                imgRatio = maxWidth / actualWidth;
                actualHeight = (int) (imgRatio * actualHeight);
                actualWidth = (int) maxWidth;
            } else {
                actualHeight = (int) maxHeight;
                actualWidth = (int) maxWidth;

            }
        }

        options.inSampleSize = mAIImageLoadingUtils.calculateInSampleSize(options, actualWidth, actualHeight);
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16*1024];

        try{
            bmp = BitmapFactory.decodeFile(filePath,options);
        }
        catch(OutOfMemoryError exception){
            exception.printStackTrace();

        }
        try{
            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
        }
        catch(OutOfMemoryError exception){
            exception.printStackTrace();
        }

        float ratioX = actualWidth / (float) options.outWidth;
        float ratioY = actualHeight / (float)options.outHeight;
        float middleX = actualWidth / 2.0f;
        float middleY = actualHeight / 2.0f;

        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bmp, middleX - bmp.getWidth()/2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));


        //Draw in image canvas
			/*float STROKE_WIDTH = 2f;

			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setColor(Color.BLACK);
			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeJoin(Paint.Join.ROUND);
			paint.setStrokeWidth(STROKE_WIDTH);

			SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault());
			String currentDateAndTime = sdf.format(new Date());
			canvas.drawText(currentDateAndTime , 10, 25, paint);*/


        ExifInterface exif;
        try {
            exif = new ExifInterface(filePath);

            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                Log.d("EXIF", "Exif: " + orientation);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileOutputStream out = null;
//        String filename = getFilename();
//        String filename = filePath;

        try {
            out = new FileOutputStream(filePath);
//            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return filePath;

    }


    public String getFilename() {
//        String path = AppUtility.getInstance().getExternalDirectoryPath(ApConstants.kDIR);

        File file = new File(Environment.getExternalStorageDirectory().getPath(), ApConstants.kDIR+"/"+ ApConstants.kVISITS_DIR);
        if (!file.exists()) {
            file.mkdirs();
        }
        String uriSting = (file.getAbsolutePath() + "/"+ System.currentTimeMillis() + ".jpg");
//        return uriSting;
//        String uriSting = path +"/"+ System.currentTimeMillis() + ".jpg";
        return uriSting;
    }



    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        this.delegate.asyncImgProcessFinish(result);
    }



}
