/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.enums;

public enum ImageTypes {

    ATTENDANCE {
        public String id() {
            return "attendance";
        }
    },
    OBSERVATION {
        public String id() {
            return "observation";
        }
    },

    TECHNOLOGY {
        public String id() {
            return "techdemo";
        }
    },

    SOIL_TEST_REPORT {
        public String id() {
            return "soil";
        }
    };

    public abstract String id();
}
