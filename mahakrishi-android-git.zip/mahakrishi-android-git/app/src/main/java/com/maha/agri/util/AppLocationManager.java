/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 28/12/18 11:58 AM
 */

package com.maha.agri.util;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;

import java.util.List;

import in.co.appinventor.services_api.widget.UIToastMessage;

public class AppLocationManager extends Service {

    private Context mContext = null;
    private AppString appString = null;
    boolean isGPS = false;
    boolean isNetwork = false;
    boolean canGetLocation = false;
    public Location location;
    private double latitude = 0.0;
    private double longitude = 0.0;

    double accuracy; // Longitude
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    //private static final long MIN_TIME_BW_UPDATES =  1;
    private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 2;
    //private static final long MIN_TIME_BW_UPDATES = 10;

    protected LocationManager locationManager;

    public AppLocationManager() {

    }


    public AppLocationManager(Context mContext) {
        this.mContext = mContext;
        appString = new AppString(mContext);
        locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(1);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        criteria.setPowerRequirement(criteria.POWER_HIGH);
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        locationManager.getBestProvider(criteria,true);

        this.location = getLocation();
    }


    public boolean isGPSON() {

        if (locationManager != null) {
            isGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        }
        return isGPS;
    }

    private Location getLocation() {

        try {

            if (locationManager != null) {
                isGPS = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            }

            if (locationManager != null) {
                isNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            }

            //            if (!isGPS && !isNetwork) {
            if (!isGPS && !isNetwork) {
                UIToastMessage.show(mContext, "No Service Provider is available");

            } else {


                // if GPS Enabled get lat/long using GPS Services
                if (isGPS) {

                    if (locationManager != null) {
                      /*  locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES, locationListener);*/
                        locationManager.requestLocationUpdates("network", 0, 0.0f, locationListener);

                    }

                    if (locationManager != null) {

//                      location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        location = getLastKnownLocation();

                        if (location != null && location.getLatitude() > 0) {
                            this.canGetLocation = true;
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                            accuracy =location.getAccuracy();
                            System.out.println("gps"+ latitude+"L" +longitude+ "A "+accuracy);
                           // String accuracyy = "Acuuracy Gps Lat "+latitude  +" Long " + longitude  +   "  Accuracy  "+accuracy;
                          //  Toast.makeText(mContext, accuracyy,Toast.LENGTH_LONG).show();

                        }
                    }

                } else if (isNetwork) {
                    /*locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, locationListener);*/
                    locationManager.requestLocationUpdates("network", 0, 0.0f, locationListener);

                    if (locationManager != null) {
//                        location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        location = getLastKnownLocation();
                    }

                    if (location != null && location.getLatitude() > 0) {
                        this.canGetLocation = true;
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                        accuracy =location.getAccuracy();
                        System.out.println("gps"+ latitude+"L" +longitude+ "A "+accuracy);
                        //String accuracyy = "Acuuracy Gps Lat "+latitude  +" Long " + longitude +  "  Accuracy  "+accuracy;
                        //Toast.makeText(mContext, accuracyy,Toast.LENGTH_LONG).show();
                    }
                }

            }


        } catch (SecurityException e) {
            e.printStackTrace();
        }

        return location;
    }

    private Location getLastKnownLocation() {
        Location bestLocation = null;
        try {

            locationManager = (LocationManager) mContext.getSystemService(LOCATION_SERVICE);

            List<String> providers = null;

            if (locationManager != null) {

                providers = locationManager.getProviders(true);

                for (String provider : providers) {
                    Location l = locationManager.getLastKnownLocation(provider);
                    if (l == null) {
                        continue;
                    }
                    if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                        // Found best last known location: %s", l);
                        bestLocation = l;
                    }
                }
            }

        } catch (SecurityException e) {
            e.printStackTrace();
        }

        return bestLocation;
    }


    public double getLongitude() {
        if (location != null) {
            longitude = location.getLongitude();
        }
        return longitude;
    }

    public double getLatitude() {
        if (location != null) {
            latitude = location.getLatitude();
        }
        return latitude;
    }


    public void setLongitude(Location loc) {
        if (location != null) {
            longitude = loc.getLongitude();
        }
    }

    public void setLatitude(Location loc) {
        if (location != null) {
            latitude = loc.getLatitude();
        }
    }

    public boolean canGetLocation() {
        return this.canGetLocation;
    }

    public void setCanGetLocation(boolean flag) {
        this.canGetLocation = flag;
    }

    public void promptForEnablingGPS() {


        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        alertDialog.setTitle("GPS is not Enabled!");
        alertDialog.setMessage("Do you want to turn on GPS?");
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton(appString.getYES(), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                mContext.startActivity(intent);
            }
        });


        alertDialog.setNegativeButton(appString.getNO(), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });


        alertDialog.show();
    }


    public void stopListener() {

        if (locationManager != null) {

            if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            locationManager.removeUpdates(locationListener);
        }
    }


    // Define a listener that responds to location updates
    LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            // Called when a new location is found by the network location provider.
            makeUseOfNewLocation(location);
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        public void onProviderEnabled(String provider) {
        }

        public void onProviderDisabled(String provider) {
        }
    };


    private void makeUseOfNewLocation(Location location) {
        if (location != null) {
            this.canGetLocation = true;
            this.location = location;
        }
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }




   /* @Override
    public void onLocationChanged(Location location) {
        this.location = location;
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }*/

}

