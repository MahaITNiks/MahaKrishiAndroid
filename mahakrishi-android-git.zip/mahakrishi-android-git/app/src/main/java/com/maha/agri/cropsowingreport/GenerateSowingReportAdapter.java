package com.maha.agri.cropsowingreport;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

public class GenerateSowingReportAdapter extends RecyclerView.Adapter<GenerateSowingReportAdapter.MyViewHolder> {
    private JSONArray generate_report_list;
    private JSONObject jsonObject;
    private Context context;
    private PreferenceManager preferencemanager;
    HashMap<Integer,String> crop_map = new HashMap<Integer, String>();


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView gen_cropname_tv,gen_sown_area_tv,gen_natural_sown_area_tv,gen_last_year_sown_area_tv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.gen_cropname_tv = itemView.findViewById(R.id.gen_cropname_tv);
            this.gen_sown_area_tv = itemView.findViewById(R.id.gen_sown_area_tv);
            this.gen_natural_sown_area_tv = itemView.findViewById(R.id.gen_natural_sown_area_tv);
            //this.gen_last_year_sown_area_tv = itemView.findViewById(R.id.gen_last_year_sown_area_tv);

        }
    }

    public GenerateSowingReportAdapter(PreferenceManager preferenceManager, JSONArray generate_report_list,Context context) {
        this.preferencemanager = preferenceManager;
        this.generate_report_list = generate_report_list;
        this.context = context;

    }

    @Override
    public GenerateSowingReportAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                        int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.gen_sowing_report_single_item, parent, false);

        GenerateSowingReportAdapter.MyViewHolder myViewHolder = new GenerateSowingReportAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final GenerateSowingReportAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = generate_report_list.getJSONObject(listPosition);
            holder.gen_cropname_tv.setText(jsonObject.getString("crop_sown_name"));
            holder.gen_sown_area_tv.setText(jsonObject.getString("area_last_week"));
            holder.gen_natural_sown_area_tv.setText(jsonObject.getString("area_current_week"));
            //holder.gen_last_year_sown_area_tv.setText(jsonObject.getString("last_year_sown_area"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (generate_report_list != null) {
            return generate_report_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private GenerateSowingReportAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final GenerateSowingReportAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
