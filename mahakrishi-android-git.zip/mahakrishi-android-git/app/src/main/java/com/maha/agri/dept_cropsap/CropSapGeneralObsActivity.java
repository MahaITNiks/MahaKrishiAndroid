package com.maha.agri.dept_cropsap;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSapGeneralObsActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView cropsap_new_crop_condition_go,cropsap_new_crop_growth_go,cropsap_new_soil_moisture_go,
            croparea,cropsap_crop_growth_photo_tv,general_obs_doo_tv;
    private EditText cropsap_new_croparea_go;
    private LinearLayout cropsap_crop_growth_photo_ll;
    private ImageView cropsap_crop_growth_photo_iv,general_obs_doo_iv;
    private RadioGroup dept_new_cropsap_pest_rg;
    private RadioButton dept_new_cropsap_pest_yes_radio_btn,dept_new_cropsap_pest_no_radio_btn;
    private Button dept_cropsap_submit_btn_go;
    private String pest_type = "0";
    private int mYear, mMonth, mDay;
    private DatePickerDialog date_of_obs_PickerDialog;
    private String date_of_obs = "";
    private SweetAlertDialog sweetAlertDialog;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    private int crop_id = 0;
    private int crop_growth_id = 0;
    private int crop_condition_id = 0;
    private int soil_moisture_id = 0;
    private int selected_pos = 0;
    private int village_id = 0;
    private int farmer_id = 0;
    private int district_id = 0;
    private int taluka_id = 0;

    private String crop_data_list = "",crop_name = "",crop_id_str = "",type = "",village_id_str="";

    JSONArray crop_growth_list,crop_condition_list,soil_moisture_list,crop_list;
    JSONObject crop_data_json_object;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    static final Integer CAMERA = 0x5;
    private String imagePath;
    public double lat,lang;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private AppLocationManager locationManager;
    private double latitude,longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap_general_obs);

        getSupportActionBar().setTitle("General Observations");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(CropSapGeneralObsActivity.this);
        sharedPref = new SharedPref(CropSapGeneralObsActivity.this);

        Intent intent = getIntent();
        type = intent.getStringExtra("type");
            crop_data_list = intent.getStringExtra("crop_data_list");
            village_id_str = intent.getStringExtra("village_id");
            district_id = intent.getIntExtra("district_id", 0);
            taluka_id = intent.getIntExtra("taluka_id", 0);
            selected_pos = intent.getIntExtra("selected_pos", 0);
            farmer_id = intent.getIntExtra("farmer_id", 0);
            village_id = Integer.parseInt(village_id_str);
            try {
                crop_list = new JSONArray(crop_data_list);
                crop_data_json_object = crop_list.getJSONObject(selected_pos);
                crop_name = crop_data_json_object.getString("crop_english");
                crop_id_str = crop_data_json_object.getString("crop_id");
                crop_id = Integer.valueOf(crop_id_str);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        ids();
        initialization();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void ids(){

        locationManager = new AppLocationManager(this);
        latitude = locationManager.getLatitude();
        longitude = locationManager.getLongitude();

        cropsap_new_croparea_go = (EditText) findViewById(R.id.cropsap_new_croparea_go);
        cropsap_new_crop_condition_go = (TextView) findViewById(R.id.cropsap_new_crop_condn_go);
        cropsap_new_crop_growth_go = (TextView) findViewById(R.id.cropsap_new_crop_growth_go);
        cropsap_new_soil_moisture_go = (TextView) findViewById(R.id.cropsap_new_soil_moisture_go);
        //general_obs_doo_tv = (TextView) findViewById(R.id.general_obs_doo_tv);
        croparea = (TextView)findViewById(R.id.croparea);
        dept_cropsap_submit_btn_go = (Button) findViewById(R.id.dept_cropsap_submit_btn_go);
        croparea.setText(crop_name + " - " + "Area sown in village (ha)");
        dept_new_cropsap_pest_rg = (RadioGroup)findViewById(R.id.dept_new_cropsap_pest_rg);
        dept_new_cropsap_pest_yes_radio_btn = (RadioButton)findViewById(R.id.dept_new_cropsap_pest_yes_radio_btn);
        dept_new_cropsap_pest_no_radio_btn = (RadioButton)findViewById(R.id.dept_new_cropsap_pest_no_radio_btn);
        //cropsap_crop_growth_photo_iv = (ImageView) findViewById(R.id.cropsap_crop_growth_photo_iv);
        //general_obs_doo_iv = (ImageView) findViewById(R.id.general_obs_doo_iv);
        //cropsap_crop_growth_photo_ll = (LinearLayout) findViewById(R.id.cropsap_crop_growth_photo_ll);
        //cropsap_crop_growth_photo_tv = (TextView) findViewById(R.id.cropsap_crop_growth_photo_tv);
        dept_new_cropsap_pest_yes_radio_btn.setChecked(false);
        dept_new_cropsap_pest_no_radio_btn.setChecked(false);
    }

    private void initialization(){

        crop_condition_list = new JSONArray();
        crop_growth_list = new JSONArray();
        soil_moisture_list = new JSONArray();

        crop_condition_service();
        soil_moisture_service();

        /*general_obs_doo_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date_of_obs_Picker();
            }
        });*/

         cropsap_new_crop_condition_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(crop_condition_list, 1, "Select Crop Condition", "crop_condition", "id", CropSapGeneralObsActivity.this, CropSapGeneralObsActivity.this);
            }
        });

        cropsap_new_crop_growth_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(crop_condition_id == 0){
                    Toast.makeText(CropSapGeneralObsActivity.this,"Select crop condition",Toast.LENGTH_SHORT).show();
                }else if (crop_growth_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(crop_growth_list, 2, "Select Crop Growth", "growth_eng_name", "crop_growth_id", CropSapGeneralObsActivity.this, CropSapGeneralObsActivity.this);
                }
            }
        });

        cropsap_new_soil_moisture_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppUtility.getInstance().showListDialogIndex(soil_moisture_list, 3, "Select Soil Moisture ", "soil_moisture", "id", CropSapGeneralObsActivity.this, CropSapGeneralObsActivity.this);
            }
        });

        dept_cropsap_submit_btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cropsap_gen_obs_save();
            }
        });

        dept_new_cropsap_pest_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {
                    case R.id.dept_new_cropsap_pest_yes_radio_btn:
                        dept_new_cropsap_pest_yes_radio_btn.setChecked(true);
                        //cropsap_crop_growth_photo_ll.setVisibility(View.GONE);
                        pest_type = "1";
                        break;

                    case R.id.dept_new_cropsap_pest_no_radio_btn:
                        dept_new_cropsap_pest_no_radio_btn.setChecked(true);
                        //cropsap_crop_growth_photo_ll.setVisibility(View.VISIBLE);
                        pest_type = "2";
                        break;
                }
            }
        });

        /*cropsap_crop_growth_photo_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(CropSapGeneralObsActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CropSapGeneralObsActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(CropSapGeneralObsActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });*/
    }

    private void Date_of_obs_Picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        date_of_obs_PickerDialog = new DatePickerDialog(CropSapGeneralObsActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        date_of_obs = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        general_obs_doo_tv.setText(date_of_obs);
                    }
                }, mYear, mMonth, mDay);

        date_of_obs_PickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        date_of_obs_PickerDialog.show();
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .resize(cropsap_crop_growth_photo_iv.getWidth(), cropsap_crop_growth_photo_iv.getHeight())
                                .centerCrop()
                                .into(cropsap_crop_growth_photo_iv);

                    }
                }, 0);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImage1OnServer(String imagePath1) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("village_id", String.valueOf(village_id));
            /*parmas.put("district_id",String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));*/
            params.put("crop_id", String.valueOf(crop_id));
            params.put("farmer_id", String.valueOf(farmer_id));


            File file = new File(photoFile.getPath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_master_save_image(partBody, params);
            api.postRequest(responseCall, this, 5);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void crop_condition_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_crop_condition_list();
        api.postRequest(responseCall, this, 1);
    }

    private void crop_growth_based_on_crop(int crop_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropGrowth(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void soil_moisture_service(){
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soil_moisture_list();
        api.postRequest(responseCall, this, 3);
    }

    private void cropsap_gen_obs_save(){
       if(crop_condition_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select Crop Condition", Toast.LENGTH_SHORT);
            toast.show();
        }else if(crop_growth_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select Crop Growth Stage", Toast.LENGTH_SHORT);
            toast.show();
        }else if(cropsap_new_croparea_go.getText().toString().trim().equalsIgnoreCase("")){
            Toast toast= Toast.makeText(getApplicationContext(), "Enter Crop Area", Toast.LENGTH_SHORT);
            toast.show();
        }else if(soil_moisture_id==0){
            Toast toast= Toast.makeText(getApplicationContext(), "Select Soil Moisture", Toast.LENGTH_SHORT);
            toast.show();
        }else if(pest_type.equalsIgnoreCase("0")){
           Toast toast= Toast.makeText(getApplicationContext(), "Select Pest Infestation", Toast.LENGTH_SHORT);
           toast.show();
       }else {
           JSONObject param = new JSONObject();
           try {
               param.put("village_id", village_id);
               param.put("farmer_id", farmer_id);
               param.put("crop_id", crop_id);
               param.put("crop_condition_id", crop_condition_id);
               param.put("crop_growth_stage_id", crop_growth_id);
               param.put("area", cropsap_new_croparea_go.getText().toString().trim());
               param.put("soil_moisture_id", soil_moisture_id);

           } catch (JSONException e) {
               e.printStackTrace();
           }
           RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
           AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
           Retrofit retrofit = api.getRetrofitInstance();
           APIRequest apiRequest = retrofit.create(APIRequest.class);

           Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_pre_master_cropsap_form_save(requestBody);
           DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
           DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
           api.postRequest(responseCall, this, 4);
       }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{

                //crop condition
                 if (i == 1) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                crop_condition_list = jsonObject.getJSONArray("data");
                            }
                        }
                    }

                //Crop growth based on crop

                    if (i == 2) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                crop_growth_list = jsonObject.getJSONArray("data");
                            }
                        }else {
                            Toast toast= Toast.makeText(getApplicationContext(), "Crop growth list not found", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }

                    //Soil moisture

                    if (i == 3) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {
                                soil_moisture_list = jsonObject.getJSONArray("data");
                            }

                        }
                    }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(pest_type.equalsIgnoreCase("1")) {
                                selected_crop_layout();
                            }else if(pest_type.equalsIgnoreCase("2")){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("General Observation");
                                sweetAlertDialog.setContentText("Data saved successfully");
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }

                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    private void selected_crop_layout(){
        sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
        sweetAlertDialog.setTitleText("General Observation");
               sweetAlertDialog.setContentText("Submitted Successfully");
                sweetAlertDialog.setConfirmText("Proceed");
                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                            if (crop_name.equals("SOYBEAN")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, SoyabeanCrop.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("SUGARCANE")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, SugarcaneSpot1.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("TUR")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, PigeonpeaSerial1.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("JOWAR")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, SorghumPlant1.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("COTTON")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, CottonPlant1.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("CHICKPEA/GRAM")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, ChickPeaRow.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("MAIZE")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, MaizePlant.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            } else if (crop_name.equals("RICE")) {
                                Intent intent = new Intent(CropSapGeneralObsActivity.this, Rice.class);
                                intent.putExtra("district_id", district_id);
                                intent.putExtra("taluka_id", taluka_id);
                                intent.putExtra("village_id", village_id);
                                intent.putExtra("crop_id",crop_id);
                                intent.putExtra("crop_cond",crop_condition_id);
                                intent.putExtra("crop_growth_id",crop_growth_id);
                                intent.putExtra("soil_moisture_id",soil_moisture_id);
                                startActivity(intent);
                                finish();
                            }
                        }
                });
                sweetAlertDialog.show();
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_condition_id = Integer.parseInt(s1);
            cropsap_new_crop_condition_go.setText(s);
            crop_growth_based_on_crop(crop_id);

        }
        if (i == 2) {
            crop_growth_id = Integer.parseInt(s1);
            cropsap_new_crop_growth_go.setText(s);
        }
        if (i == 3) {
            soil_moisture_id = Integer.parseInt(s1);
            cropsap_new_soil_moisture_go.setText(s);
        }
    }
}
