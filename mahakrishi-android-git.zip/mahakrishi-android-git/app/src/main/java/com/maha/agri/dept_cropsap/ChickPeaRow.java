package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ChickPeaRow extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {

    private TextView dept_cropsap_plant_chickpeatv;
    private Button btn_save_continue_chickpea,btn_add_pest_details_chickpea;
    private String chichpea_crop_name,type;
    private JSONArray chickpea_crop_plant_list;
    private int district_id, taluka_id, village_id, farmer_id,crop_id;
    private int crop_chickpea_plant_id = 0;

    SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private int crop_cond_id = 0;
    private int crop_growth_id = 0;
    private int soil_moisture_id = 0;
    private File photoFile1 = null;
    private String imagePath1="";
    private String image_1_file_name;
    private AppLocationManager locationManager;
    public double lat,lang;
    int count = 1;
    // New
    private TextView chickpea_major_pest,chickpea_minor_pest;
    private JSONArray chickpea_major_pest_list,chickpea_minor_pest_list;
    private int  chickpea_pest_id = 0,generic_int;
    private String pest_name = "",generic_et_str;
    private LinearLayout ll_Generic_Layout_Major_and_Minor__Pest_Chickpea;
    private TextView soybean_defender,Generic_Layout_Major_and_Minor__Pest_tv_Chickpea;
    private EditText et_Generic_Chickpea;

    private ArrayList<String> pest_list_names_Chickpea=new ArrayList<String>();
    private ArrayList<LinearLayout> pest_list_layout_Chickpea=new ArrayList<LinearLayout>();
    private ArrayList<EditText> pest_list_et=new ArrayList<EditText>();
    private TableLayout add_pest_titleTableLayout_chickpea;
    private int selected_pest_id = 0;
    private RecyclerView add_more_pest_rv_chickpea;

    JSONObject pod_borer_json_obj = new JSONObject();
    JSONObject aphids_json_obj = new JSONObject();
    JSONObject cut_worm_json_obj = new JSONObject();
    JSONObject army_worm_json_obj = new JSONObject();

    private JSONArray chickpea_pest_details_json_array = new JSONArray();
    private ImageView photo_et_Generic_Chickpea;
    private Drawable myDrawable ;
    private EditText defender_chickpea;
    private SweetAlertDialog sweetAlertDialog;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_chickprea);
        getSupportActionBar().setTitle("Pest Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(ChickPeaRow.this);
        sharedPref = new SharedPref(ChickPeaRow.this);
        locationManager = new AppLocationManager(this);

        Intent intent = getIntent();
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        village_id = intent.getIntExtra("village_id",0);
        farmer_id = intent.getIntExtra("farmer_id",0);
        crop_id = intent.getIntExtra("crop_id",0);
        crop_cond_id = intent.getIntExtra("crop_cond",0);
        crop_growth_id = intent.getIntExtra("crop_growth_id",0);
        soil_moisture_id = intent.getIntExtra("soil_moisture_id",0);
        myDrawable = getResources().getDrawable(R.drawable.camera);
        ids();
        initialization();

        chickpea_plant_list();
        major_pest_service();
        minor_pest_service();
        zero_pest_input();
    }

    private void ids() {
        //Text view
        dept_cropsap_plant_chickpeatv =(TextView) findViewById(R.id.dept_cropsap_plant_chickpeatv);
        dept_cropsap_plant_chickpeatv.setEnabled(false);

        //Button
        btn_save_continue_chickpea = (Button)findViewById(R.id.btn_save_continue_chickpea);
        btn_add_pest_details_chickpea=(Button)findViewById(R.id.btn_add_pest_details_chickpea);

        // NEW
        chickpea_major_pest=(TextView)findViewById(R.id.chickpea_major_pest);
        chickpea_minor_pest=(TextView)findViewById(R.id.chickpea_minor_pest);

        ll_Generic_Layout_Major_and_Minor__Pest_Chickpea=(LinearLayout)findViewById(R.id.ll_Generic_Layout_Major_and_Minor__Pest_Chickpea);

        add_pest_titleTableLayout_chickpea=(TableLayout)findViewById(R.id.add_pest_titleTableLayout_chickpea);

        add_more_pest_rv_chickpea=(RecyclerView)findViewById(R.id.add_more_pest_rv_chickpea);
        photo_et_Generic_Chickpea=(ImageView)findViewById(R.id.photo_et_Generic_Chickpea);
        defender_chickpea=(EditText)findViewById(R.id.defender_chickpea);
        Generic_Layout_Major_and_Minor__Pest_tv_Chickpea=(TextView)findViewById(R.id.Generic_Layout_Major_and_Minor__Pest_tv_Chickpea);
        et_Generic_Chickpea=(EditText)findViewById(R.id.et_Generic_Chickpea);

        chickpea_crop_plant_list = new JSONArray();
        chickpea_major_pest_list = new JSONArray();
        chickpea_minor_pest_list = new JSONArray();
    }

    private void initialization() {

        dept_cropsap_plant_chickpeatv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chickpea_crop_plant_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(chickpea_crop_plant_list, 1, "Spot List", "spot_name", "spot_id", ChickPeaRow.this, ChickPeaRow.this);
                }
            }
        });

        chickpea_major_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (chickpea_major_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(chickpea_major_pest_list, 11, "Select Major Pest", "pest_eng_name", "id", ChickPeaRow.this, ChickPeaRow.this);
                }else{
                    major_pest_service();
                }
            }
        });

        chickpea_minor_pest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (chickpea_minor_pest_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(chickpea_minor_pest_list, 12, "Select Minor Pest", "pest_eng_name", "id", ChickPeaRow.this, ChickPeaRow.this);
                }else{
                    minor_pest_service();
                }
            }
        });

        //Add button
        btn_add_pest_details_chickpea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String et_Generic_Chickpea_str = et_Generic_Chickpea.getText().toString().trim();

                if(et_Generic_Chickpea_str.isEmpty()){
                    Toast.makeText(ChickPeaRow.this, "Enter number of pest", Toast.LENGTH_SHORT).show();
                }
                else if(imagePath1.equals("")){
                    Toast.makeText(getApplicationContext(), "Click image of the pest", Toast.LENGTH_SHORT).show();
                }
                else{
                    uploadImage1OnServer();
                    add_pest_details(chickpea_pest_id,pest_name);
                }
            }
        });

        photo_et_Generic_Chickpea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(ChickPeaRow.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickPeaRow.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(ChickPeaRow.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(ChickPeaRow.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    type = "1";
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        btn_save_continue_chickpea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String defender_chickpea_str=defender_chickpea.getText().toString().trim();

                if(chickpea_pest_details_json_array.length()>0){
                    if(chickpea_pest_details_json_array.toString().contains("POD BORER")) {
                        if (defender_chickpea_str.isEmpty()) {
                            Toast.makeText(ChickPeaRow.this, "Enter defender", Toast.LENGTH_LONG).show();
                        } else {
                            save_chickpea_data();
                        }
                    }else{
                        sweetAlertDialog = new SweetAlertDialog(ChickPeaRow.this, SweetAlertDialog.WARNING_TYPE);
                        sweetAlertDialog.setContentText("Enter data for all major pests");
                        sweetAlertDialog.setConfirmText("OK");
                        sweetAlertDialog.setCanceledOnTouchOutside(false);
                        sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                            }
                        }).show();
                    }
                } else{
                    final Toast toast = Toast.makeText(ChickPeaRow.this, "Enter data for atleast one pest", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 0);
                }
            }
        });
    }

    private void zero_pest_input(){
        et_Generic_Chickpea.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                generic_et_str = et_Generic_Chickpea.getText().toString().trim();
                if(!generic_et_str.equalsIgnoreCase("")){
                    generic_int = Integer.parseInt(generic_et_str);
                    if(generic_int == 0){
                        photo_et_Generic_Chickpea.setVisibility(View.GONE);
                        add_pest_details(selected_pest_id,pest_name);
                    }else{
                        photo_et_Generic_Chickpea.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void add_pest_details(int chickpea_pest_id, String pest_name) {

        try {
            if (pest_name.equals("POD BORER")) {
                pod_borer_json_obj.put("pest_id", chickpea_pest_id);
                pod_borer_json_obj.put("pest_name", pest_name);
                pod_borer_json_obj.put("spo_gre_lar_no", et_Generic_Chickpea.getText().toString().trim());
                pod_borer_json_obj.put("spo_gre_lar_pic", imagePath1);
                pod_borer_json_obj.put("lat", String.valueOf(lat));
                pod_borer_json_obj.put("long", String.valueOf(lang));
                chickpea_pest_details_json_array.put(pod_borer_json_obj);
            } else if (pest_name.equals("APHIDS")) {
                aphids_json_obj.put("pest_id", chickpea_pest_id);
                aphids_json_obj.put("pest_name", pest_name);
                aphids_json_obj.put("spo_gre_lar_no", et_Generic_Chickpea.getText().toString().trim());
                aphids_json_obj.put("spo_gre_lar_pic", imagePath1);
                aphids_json_obj.put("lat", String.valueOf(lat));
                aphids_json_obj.put("long", String.valueOf(lang));
                chickpea_pest_details_json_array.put(aphids_json_obj);
            }
            else if (pest_name.equals("CUT WORM")) {
                cut_worm_json_obj.put("pest_id", chickpea_pest_id);
                cut_worm_json_obj.put("pest_name", pest_name);
                cut_worm_json_obj.put("spo_gre_lar_no", et_Generic_Chickpea.getText().toString().trim());
                cut_worm_json_obj.put("spo_gre_lar_pic", imagePath1);
                cut_worm_json_obj.put("lat", String.valueOf(lat));
                cut_worm_json_obj.put("long", String.valueOf(lang));
                chickpea_pest_details_json_array.put(cut_worm_json_obj);
            }
            else if (pest_name.equals("ARMY WORM")) {
                army_worm_json_obj.put("pest_id", chickpea_pest_id);
                army_worm_json_obj.put("pest_name", pest_name);
                army_worm_json_obj.put("spo_gre_lar_no", et_Generic_Chickpea.getText().toString().trim());
                army_worm_json_obj.put("spo_gre_lar_pic", imagePath1);
                army_worm_json_obj.put("lat", String.valueOf(lat));
                army_worm_json_obj.put("long", String.valueOf(lang));
                chickpea_pest_details_json_array.put(army_worm_json_obj);
            }

            if(chickpea_pest_details_json_array.length()>0){
                add_pest_titleTableLayout_chickpea.setVisibility(View.VISIBLE);
                add_more_pest_rv_chickpea.setVisibility(View.VISIBLE);
                add_more_pest_rv_chickpea.setLayoutManager(new LinearLayoutManager(ChickPeaRow.this));
                AddPestAdapter addPestAdapter = new AddPestAdapter(chickpea_pest_details_json_array, ChickPeaRow.this);
                add_more_pest_rv_chickpea.setAdapter(addPestAdapter);
                addPestAdapter.notifyDataSetChanged();
                et_Generic_Chickpea.setText("");
                ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.GONE);
                btn_add_pest_details_chickpea.setVisibility(View.GONE);
                chickpea_major_pest.setText("Select");
                chickpea_minor_pest.setText("Select");
                photo_et_Generic_Chickpea.setImageResource(R.drawable.camera);
                photoFile1=null;
            }
            else{
                add_pest_titleTableLayout_chickpea.setVisibility(View.GONE);
                add_more_pest_rv_chickpea.setVisibility(View.GONE);
                final Toast toast = Toast.makeText(ChickPeaRow.this, "Not allowed to add data", Toast.LENGTH_SHORT);
                toast.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toast.cancel();
                    }
                }, 0);
            }

        } catch (Exception e) {

        }
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            if (type.equalsIgnoreCase("1")) {
                photoFile1 = new File(photoDirectory, pest_name + "_" + System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1= null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (type.equalsIgnoreCase("1")) {
            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(photo_et_Generic_Chickpea.getWidth(), photo_et_Generic_Chickpea.getHeight())
                                    .centerCrop()
                                    .into(photo_et_Generic_Chickpea);
                        }
                    }, 0);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void chickpea_plant_list() {
        JSONObject param = new JSONObject();
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.chickpea_spot_list();
        api.postRequest(responseCall, this, 1);
    }

    private void major_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","1");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 11);
    }

    private void minor_pest_service(){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_id",crop_id);
            param.put("pest_id","2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCropPestList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 12);
    }

    private void uploadImage1OnServer() {
        try {
            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath1);

            Map<String, String> params = new HashMap<>();
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("district_id", String.valueOf(district_id));
            params.put("taluka_id", String.valueOf(taluka_id));
            params.put("village_id", String.valueOf(village_id));

            switch (type) {
                case "1":
                    File file1 = new File(photoFile1.getPath());
                    RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file1);
                    partBody = MultipartBody.Part.createFormData("fileToUpload", file1.getName(), reqFile1);
                    break;
            }
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.dept_cropsap_soyabean_spot_saveimage(partBody, params);
            api.postRequest(responseCall, this, 4);


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void save_chickpea_data() {
        JSONObject param = new JSONObject();
        try{
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("village_id", village_id);
            param.put("spot_id", count);
            param.put("crop_id", crop_id);
            param.put("crop_condition_id", crop_cond_id);
            param.put("crop_grow_id", crop_growth_id);
            param.put("soil_mois_id", soil_moisture_id);
            param.put("total_defender", defender_chickpea.getText().toString().trim());
            param.put("pest_details", chickpea_pest_details_json_array.toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_soyabean_spot_save(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.guidelines_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.guidelines:
                Intent intent = new Intent(ChickPeaRow.this,ChickpeaGuidelinesActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            chickpea_crop_plant_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if(i == 4){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data  = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_url");
                        }
                    }
                }

                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            if(count<chickpea_crop_plant_list.length()){
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Chickpea/Gram");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Spot" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        count++;
                                        dept_cropsap_plant_chickpeatv.setText("Spot" + " " + count);
                                        chickpea_major_pest.setText("Select");
                                        chickpea_minor_pest.setText("Select");
                                        sweetAlertDialog.dismissWithAnimation();
                                        chickpea_pest_details_json_array= new JSONArray();
                                        add_more_pest_rv_chickpea.setAdapter(null);
                                        add_pest_titleTableLayout_chickpea.setVisibility(View.VISIBLE);
                                        // All reset

                                        ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.GONE);
                                        et_Generic_Chickpea.setText("");
                                        photo_et_Generic_Chickpea.setImageDrawable(getResources().getDrawable(R.drawable.camera));
                                        image_1_file_name="";
                                        for(int j=0;j<pest_list_names_Chickpea.size();j++){
                                            pest_list_layout_Chickpea.get(j).setVisibility(View.GONE);
                                        }
                                        add_pest_titleTableLayout_chickpea.setVisibility(View.GONE);
                                        btn_add_pest_details_chickpea.setVisibility(View.GONE);
                                        add_more_pest_rv_chickpea.setVisibility(View.GONE);

                                        defender_chickpea.setText("");
                                    }
                                });
                                sweetAlertDialog.show();

                            }else {
                                sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                                sweetAlertDialog.setTitleText("Chickpea/Gram");
                                sweetAlertDialog.setContentText("Data saved successfully for" + " " + "Spot" + " " + count);
                                sweetAlertDialog.setConfirmText("Ok");
                                sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                                        Intent intent = new Intent(ChickPeaRow.this, ChickpeaCropPheromoneActivity.class);
                                        intent.putExtra("district_id",district_id);
                                        intent.putExtra("taluka_id",taluka_id);
                                        intent.putExtra("village_id",village_id);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                sweetAlertDialog.show();
                            }
                        }
                    }
                }

                if (i == 11) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            chickpea_major_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 12) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            chickpea_minor_pest_list = jsonObject.getJSONArray("data");
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

        if (i == 1) {
            crop_chickpea_plant_id = Integer.parseInt(s1);
            chichpea_crop_name = s;
            dept_cropsap_plant_chickpeatv.setText(s);
        }

        if (i == 11) {
            chickpea_pest_id = Integer.parseInt(s1);
            pest_name=s;
            chickpea_major_pest.setText(s);
            chickpea_minor_pest.setText("Select");
            if(chickpea_pest_details_json_array.toString().contains(pest_name) == chickpea_major_pest_list.toString().contains(pest_name)){
                Toast.makeText(ChickPeaRow.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_Generic_Chickpea.setText("");
                photo_et_Generic_Chickpea.setImageResource(R.drawable.camera);
                ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.GONE);
                btn_add_pest_details_chickpea.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_chickpea.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }

        if (i ==12) {
            chickpea_pest_id = Integer.parseInt(s1);
            pest_name=s;
            chickpea_minor_pest.setText(s);
            chickpea_major_pest.setText("Select");
            if(chickpea_pest_details_json_array.toString().contains(pest_name) == chickpea_minor_pest_list.toString().contains(pest_name)){
                Toast.makeText(ChickPeaRow.this,"Cannot add data for same pest again",Toast.LENGTH_SHORT).show();
                et_Generic_Chickpea.setText("");
                photo_et_Generic_Chickpea.setImageResource(R.drawable.camera);
                ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.GONE);
                btn_add_pest_details_chickpea.setVisibility(View.GONE);
            }else{
                btn_add_pest_details_chickpea.setVisibility(View.VISIBLE);
                layout_View_Gone(s);
            }
        }
    }

    private void layout_View_Gone(String s) {
        if(pest_list_names_Chickpea.contains(s)){
            ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.GONE);

            for(int j=0;j<pest_list_names_Chickpea.size();j++){
                if(pest_list_names_Chickpea.get(j).equals(s)){
                    pest_list_layout_Chickpea.get(j).setVisibility(View.VISIBLE);
                }
                else{
                    pest_list_layout_Chickpea.get(j).setVisibility(View.GONE);
                }
            }
        }
        else{
            String localstr=s;
            String localstr2;
            localstr2= capitalizeWord(localstr);
            ll_Generic_Layout_Major_and_Minor__Pest_Chickpea.setVisibility(View.VISIBLE);
            Generic_Layout_Major_and_Minor__Pest_tv_Chickpea.setText(localstr2);
            et_Generic_Chickpea.setText("");
            for(int j=0;j<pest_list_names_Chickpea.size();j++){
                pest_list_layout_Chickpea.get(j).setVisibility(View.GONE);
            }
        }
    }

    private String capitalizeWord(String str) {
        char ch[] = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') {
                if (ch[i] >= 'a' && ch[i] <= 'z') {
                    ch[i] = (char)(ch[i] - 'a' + 'A');
                }
            }
            else if (ch[i] >= 'A' && ch[i] <= 'Z'){
                ch[i] = (char)(ch[i] + 'a' - 'A');
            }
        }
        String st = new String(ch);
        return st;
    }
}
