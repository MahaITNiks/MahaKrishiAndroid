package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class OnionStorageFirstPhysicalActivity1 extends AppCompatActivity implements ApiCallbackCode {

    private TextView onion_str1_p1_datetv,onion_str1_p1_farmer,onion_str1_p1_village,onion_str1_p1_taluka,onion_str1_p1_district,onion_str1_p1_survey,
            onion_str1_p1_vargvari,onion_str1_p1_bab,onion_str1_expected,onion_str1_exp1,onion_str1_exp2,onion_str1_exp3,onion_str1_exp4,onion_str1_exp5,
            onion_str1_exp6;
    private Spinner onion_str1_p1_items_used,onion_str1_p1_roof_items,onion_str1_p1_capacity;
    private EditText onion_str1_exp1_actual,onion_str1_exp2_actual,onion_str1_exp3_actual,onion_str1_exp4_actual, onion_str1_exp5_actual,onion_str1_exp6_actual;
    private RadioGroup onion_str1_p1_rg1,onion_str1_p1_rg,onion_str1_p1_1meter_rg;
    private RadioButton onion_str1_p1_yes1,onion_str1_p1_yes,onion_str1_p1_no1,onion_str1_p1_no,onion_str1_p1_1meter_yes,onion_str1_p1_1meter_no;
    private Button onion_str1_p1_save;
    private String items="",roof_items="",type="0",meter="0",onion_str1_date="0",capacity="",type1="0";
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onion_storage_first_physical1);
        getSupportActionBar().setTitle("Onion Storage Structure First Form 1");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(OnionStorageFirstPhysicalActivity1.this);

        ids();
        functions();
    }

    private void ids(){
        //Textview
        onion_str1_p1_datetv = (TextView) findViewById(R.id.onion_str1_p1_datetv);
        onion_str1_p1_farmer = (TextView) findViewById(R.id.onion_str1_p1_farmer);
        onion_str1_p1_village = (TextView) findViewById(R.id.onion_str1_p1_village);
        onion_str1_p1_taluka = (TextView) findViewById(R.id.onion_str1_p1_taluka);
        onion_str1_p1_district = (TextView) findViewById(R.id.onion_str1_p1_district);
        onion_str1_p1_survey = (TextView) findViewById(R.id.onion_str1_p1_survey);
        onion_str1_p1_vargvari = (TextView) findViewById(R.id.onion_str1_p1_vargvari);
        onion_str1_p1_bab = (TextView) findViewById(R.id.onion_str1_p1_bab);
        onion_str1_expected = (TextView) findViewById(R.id.onion_str1_expected);
        onion_str1_exp1 = (TextView) findViewById(R.id.onion_str1_exp1);
        onion_str1_exp2 = (TextView) findViewById(R.id.onion_str1_exp2);
        onion_str1_exp3 = (TextView) findViewById(R.id.onion_str1_exp3);
        onion_str1_exp4 = (TextView) findViewById(R.id.onion_str1_exp4);
        onion_str1_exp5 = (TextView) findViewById(R.id.onion_str1_exp5);
        onion_str1_exp6 = (TextView) findViewById(R.id.onion_str1_exp6);
        //Spinner
        onion_str1_p1_items_used = (Spinner) findViewById(R.id.onion_str1_p1_items_used);
        onion_str1_p1_roof_items = (Spinner) findViewById(R.id.onion_str1_p1_roof_items);
        onion_str1_p1_capacity = (Spinner) findViewById(R.id.onion_str1_p1_capacity);
        //Radio
        onion_str1_p1_rg = (RadioGroup) findViewById(R.id.onion_str1_p1_rg);
        onion_str1_p1_rg1 = (RadioGroup) findViewById(R.id.onion_str1_p1_rg1);
        onion_str1_p1_1meter_rg = (RadioGroup) findViewById(R.id.onion_str1_p1_1meter_rg);
        onion_str1_p1_yes = (RadioButton) findViewById(R.id.onion_str1_p1_yes);
        onion_str1_p1_yes1 = (RadioButton) findViewById(R.id.onion_str1_p1_yes1);
        onion_str1_p1_no = (RadioButton) findViewById(R.id.onion_str1_p1_no);
        onion_str1_p1_no1 = (RadioButton) findViewById(R.id.onion_str1_p1_no1);
        onion_str1_p1_1meter_yes = (RadioButton) findViewById(R.id.onion_str1_p1_1meter_yes);
        onion_str1_p1_1meter_no = (RadioButton) findViewById(R.id.onion_str1_p1_1meter_no);

        onion_str1_exp1_actual = (EditText) findViewById(R.id.onion_str1_exp1_actual);
        onion_str1_exp2_actual = (EditText) findViewById(R.id.onion_str1_exp2_actual);
        onion_str1_exp3_actual = (EditText) findViewById(R.id.onion_str1_exp3_actual);
        onion_str1_exp4_actual = (EditText) findViewById(R.id.onion_str1_exp4_actual);
        onion_str1_exp5_actual = (EditText) findViewById(R.id.onion_str1_exp5_actual);
        onion_str1_exp6_actual = (EditText) findViewById(R.id.onion_str1_exp6_actual);
        onion_str1_p1_save=(Button)findViewById(R.id.onion_str1_p1_save);

        onion_str1_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        onion_str1_p1_datetv.setText(onion_str1_date);
    }

    private void functions() {

        onion_str1_p1_capacity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                capacity = onion_str1_p1_capacity.getSelectedItem().toString();

                if(capacity.equalsIgnoreCase("5 मे. टन")){
                    onion_str1_expected.setText(capacity);
                    onion_str1_exp1.setText("4.50");
                    onion_str1_exp2.setText("-");
                    onion_str1_exp3.setText("1.50");
                    onion_str1_exp4.setText("-");
                    onion_str1_exp5.setText("-");
                    onion_str1_exp6.setText("3.30");
                }else if(capacity.equalsIgnoreCase("10 मे. टन")){
                    onion_str1_expected.setText(capacity);
                    onion_str1_exp1.setText("4.50");
                    onion_str1_exp2.setText("4.50");
                    onion_str1_exp3.setText("1.50");
                    onion_str1_exp4.setText("1.50");
                    onion_str1_exp5.setText("1.50");
                    onion_str1_exp6.setText("3.30");
                }else if(capacity.equalsIgnoreCase("15 मे. टन")){
                    onion_str1_expected.setText(capacity);
                    onion_str1_exp1.setText("7.25");
                    onion_str1_exp2.setText("7.25");
                    onion_str1_exp3.setText("1.20");
                    onion_str1_exp4.setText("1.20");
                    onion_str1_exp5.setText("1.50");
                    onion_str1_exp6.setText("3.40");
                }else if(capacity.equalsIgnoreCase("20 मे. टन")){
                    onion_str1_expected.setText(capacity);
                    onion_str1_exp1.setText("9.60");
                    onion_str1_exp2.setText("9.60");
                    onion_str1_exp3.setText("1.20");
                    onion_str1_exp4.setText("1.20");
                    onion_str1_exp5.setText("1.50");
                    onion_str1_exp6.setText("3.40");
                }else if(capacity.equalsIgnoreCase("25 मे. टन")){
                    onion_str1_expected.setText(capacity);
                    onion_str1_exp1.setText("12");
                    onion_str1_exp2.setText("12");
                    onion_str1_exp3.setText("1.20");
                    onion_str1_exp4.setText("1.20");
                    onion_str1_exp5.setText("1.50");
                    onion_str1_exp6.setText("3.40");
                }else if (capacity.equalsIgnoreCase("Select")){
                    onion_str1_expected.setText("");
                    onion_str1_exp1.setText("");
                    onion_str1_exp2.setText("");
                    onion_str1_exp3.setText("");
                    onion_str1_exp4.setText("");
                    onion_str1_exp5.setText("");
                    onion_str1_exp6.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        onion_str1_p1_items_used.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                items = onion_str1_p1_items_used.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        onion_str1_p1_roof_items.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                roof_items = onion_str1_p1_roof_items.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        onion_str1_p1_rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.onion_str1_p1_yes1:
                        onion_str1_p1_yes1.setChecked(true);
                        type1 = "1";
                        break;

                    case R.id.onion_str1_p1_no1:
                        onion_str1_p1_no1.setChecked(true);
                        type1 = "2";
                        break;
                }
            }
        });

        onion_str1_p1_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.onion_str1_p1_yes:
                        onion_str1_p1_yes.setChecked(true);
                        type = "1";
                        break;

                    case R.id.onion_str1_p1_no:
                        onion_str1_p1_no.setChecked(true);
                        type = "2";
                        break;
                }
            }
        });

        onion_str1_p1_1meter_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.onion_str1_p1_1meter_yes:
                        onion_str1_p1_1meter_yes.setChecked(true);
                        meter = "1";
                        break;

                    case R.id.onion_str1_p1_1meter_no:
                        onion_str1_p1_1meter_no.setChecked(true);
                        meter = "2";
                        break;
                }
            }
        });

        onion_str1_p1_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(capacity.equalsIgnoreCase("Select")){
                    Toast.makeText(OnionStorageFirstPhysicalActivity1.this,"Select क्षमता",Toast.LENGTH_LONG).show();
                }else{
                    Intent i = new Intent(OnionStorageFirstPhysicalActivity1.this,OnionStorageFirstPhysicalActivity2.class);
                    i.putExtra("capacity",capacity);
                    startActivity(i);
                    //onion_save_part1_service();
                }
            }
        });
    }

    private void onion_save_part1_service(){
        if(capacity.equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Select क्षमता", Toast.LENGTH_SHORT).show();
        }else if(type.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select कांदाचाळीच्या पायाचे बांधकाम मार्गदर्शक सुचनेतील आराखडयाप्रमाणे आहे काय?", Toast.LENGTH_SHORT).show();
        }else if(items.equalsIgnoreCase("Select")){
            Toast.makeText(getApplicationContext(), "Select कांदाचाळीच्या तळाशी व बाजूभिंतीस वापरलेले साहित्य", Toast.LENGTH_SHORT).show();
        }else if(roof_items.equalsIgnoreCase("Select")){
            Toast.makeText(getApplicationContext(), "Select छतासाठी वापरलेले साहित्य", Toast.LENGTH_SHORT).show();
        }else if(meter.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select कांदाचाळीचे छत बाजू बांधकामापेक्षा १ मीटर लांब आहे काय?", Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("onion_date", onion_str1_date);
                param.put("farmer_name", "0");
                param.put("village_id", "0");
                param.put("taluka_id", "0");
                param.put("district_id", "0");
                param.put("survey_no", "0");
                param.put("vargvari", "0");
                param.put("bab", onion_str1_p1_bab.getText().toString().trim());
                param.put("capacity", capacity);
                param.put("onion_rg", type);
                param.put("items_sp", items);
                param.put("roof_items", roof_items);
                param.put("meter_rg", meter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Onion Storage Structure");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    /*Intent intent = new Intent(GreenHouseActivity.this,GIPipesActivity.class);
                                    startActivity(intent);*/
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
