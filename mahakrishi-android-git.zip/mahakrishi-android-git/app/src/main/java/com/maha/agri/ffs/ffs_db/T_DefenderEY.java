package com.maha.agri.ffs.ffs_db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class T_DefenderEY {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int uid;
    private String name;
    private int pest_id;
    private String pest_name;
    private int crop_id;
    private int cropping_system;
    private int plot_obs;
    private int created_by;
    private String created_at;

    public T_DefenderEY() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPest_id() {
        return pest_id;
    }

    public void setPest_id(int pest_id) {
        this.pest_id = pest_id;
    }

    public String getPest_name() {
        return pest_name;
    }

    public void setPest_name(String pest_name) {
        this.pest_name = pest_name;
    }

    public int getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(int crop_id) {
        this.crop_id = crop_id;
    }


    public int getCropping_system() {
        return cropping_system;
    }

    public void setCropping_system(int cropping_system) {
        this.cropping_system = cropping_system;
    }


    public int getPlot_obs() {
        return plot_obs;
    }

    public void setPlot_obs(int plot_obs) {
        this.plot_obs = plot_obs;
    }


    public int getCreated_by() {
        return created_by;
    }

    public void setCreated_by(int created_by) {
        this.created_by = created_by;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
