package com.maha.agri.model;

public class CropSownHeaderPojo {

    public String cropsown;
    public String area_in_current_week;
    public String area_upto_last_week;

    public String getCropsown() {
        return cropsown;
    }

    public void setCropsown(String cropsown) {
        this.cropsown = cropsown;
    }

    public String getArea_in_current_week() {
        return area_in_current_week;
    }

    public void setArea_in_current_week(String area_in_current_week) {
        this.area_in_current_week = area_in_current_week;
    }

    public String getArea_upto_last_week() {
        return area_upto_last_week;
    }

    public void setArea_upto_last_week(String area_upto_last_week) {
        this.area_upto_last_week = area_upto_last_week;
    }

    public CropSownHeaderPojo(int position) {


    }

    public CropSownHeaderPojo(String cropsown, String area_in_current_week, String area_upto_last_week)
    {
        this.cropsown = cropsown;
        this.area_in_current_week = area_in_current_week;
        this.area_upto_last_week = area_upto_last_week;
    }
}
