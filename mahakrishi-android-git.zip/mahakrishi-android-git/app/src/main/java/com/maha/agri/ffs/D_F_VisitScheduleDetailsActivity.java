package com.maha.agri.ffs;

import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.ffs.adaptor.PlotHisVisitsAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.model.VisitDetailModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;

public class D_F_VisitScheduleDetailsActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {

    private String reg_type;

    private TextView titleTextView;
    // private TextView nameTextView;
    private TextView plotTextView;
    private TextView planTextView;
    private TextView interCropTextView;
    private TextView villTextView;
    private TextView dayTextView;
    private TextView dateTextView;
    private TextView emptyTextView;
    private RecyclerView recyclerView;
    private VisitDetailModel model;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_visit_schedule_details);
        getSupportActionBar().setTitle("Visit Details");

        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);

        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        //titleTextView = findViewById(R.id.titleTextView);
        // nameTextView = findViewById(R.id.nameTextView);
        planTextView = findViewById(R.id.planTextView);
        villTextView = findViewById(R.id.villTextView);
        dayTextView = findViewById(R.id.dayTextView);
        dateTextView = findViewById(R.id.dateTextView);

        emptyTextView = findViewById(R.id.emptyTextView);
        recyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setElevation(0);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        try {

            String details = getIntent().getStringExtra("details");

            JSONObject jsonObject = new JSONObject(details);
            model = new VisitDetailModel(jsonObject);

            String title = getResources().getString(R.string.schedule_plot_detail) + " - " + getResources().getString(R.string.visit_number) + " " + model.getVisit_number();
            setTitle(title);

            AppString appString = new AppString(this);
            // String name = appString.getHostFarmerName() + " " + model.getFarmer_name();
            String planName = appString.getPlanName() + " " + model.getCrop_name();
            String village = appString.getVillage() + " " + model.getVillage_name();
            String visitDate = model.getVisit_date();

            //String sDay = ApUtil.getDayByTimeStamp(visitDate);
            String sDay = ApUtil.getDayByDate(visitDate);
            // String sDate = ApUtil.getDateByTimeStamp(visitDate);
            String sDate = ApUtil.getDateInDDMMYYYY(visitDate);
            String day = appString.getDay() + " " + sDay;
            String date = appString.getScheduleDate() + " " + sDate;


            // nameTextView.setText(name);
            planTextView.setText(planName);
            villTextView.setText(village);
            dayTextView.setText(day);
            dateTextView.setText(date);

            int cropId = model.getCrop_id();
            DebugLog.getInstance().d("cropId=" + cropId);
            AppSession session = new AppSession(D_F_VisitScheduleDetailsActivity.this);
            DebugLog.getInstance().d("getCropId=" + session.getCropId());

            //fetchHistoryOfVisits();

            final Context mContext = this;

        } catch (Exception e) {
            e.printStackTrace();
        }

        // final String finalDetails = details;
        findViewById(R.id.nextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageSession();
                String sDetail = getIntent().getStringExtra("details");
                // For DEMO
                if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)) {
                    // Intent intent = new Intent(D_F_VisitScheduleDetailsActivity.this, DemoScheduleVisitDetails.class);  // Commented by santosh
                    Intent intent = new Intent(D_F_VisitScheduleDetailsActivity.this, FFSVisitControllerActivity.class);
                    intent.putExtra("scheduleDetail", sDetail);
                    startActivity(intent);
                } else {
                    // FOR FFS
                    Intent intent = new Intent(D_F_VisitScheduleDetailsActivity.this, FFSVisitControllerActivity.class);
                    intent.putExtra("scheduleDetail", sDetail);
                    startActivity(intent);

                }

            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

    }

    private void manageSession() {
        AppSession session = new AppSession(D_F_VisitScheduleDetailsActivity.this);

        int cropId = model.getCrop_id();
        DebugLog.getInstance().d("cropId=" + cropId);

        AppSettings.getInstance().setIntValue(this, ApConstants.kCROP_UNIQUE_ID, cropId);
        AppSettings.getInstance().setIntValue(this, ApConstants.kVISIT_NUM, model.getVisit_number());
        AppSettings.getInstance().setIntValue(this, ApConstants.kSCHEDULE_ID, model.getSowingvisit_input_id());
        AppSettings.getInstance().setValue(this, ApConstants.kCROP_NAME, model.getCrop_name());
        AppSettings.getInstance().setIntValue(this, ApConstants.kVISIT_COUNT, model.getVisit_count());

    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if (jsonObject != null) {

            DebugLog.getInstance().d("onResponse=" + jsonObject);
            ResponseModel response = new ResponseModel(jsonObject);

            if (response.isStatus()) {
                JSONArray jsonArray = response.getData();
//                if (jsonArray.length() > 0) {
                emptyTextView.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                PlotHisVisitsAdapter hisVisitsAllAdapter = new PlotHisVisitsAdapter(this, this, jsonArray);
                recyclerView.setAdapter(hisVisitsAllAdapter);
//                }
            } else {
                emptyTextView.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
