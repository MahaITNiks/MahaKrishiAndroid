package com.maha.agri.farmer;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerCropSapActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    static final Integer CAMERA = 0x5;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    EditText farmer_cropsap_et_gut_number, et_comment, crop_name_edt;
    ImageView farmers_photo, season_crop_iv;
    Button submit_btn;
    JSONArray District_List;
    JSONArray Taluka_List;
    JSONArray Village_List;
    JSONArray Seasons_List;
    JSONArray Crops_List;
    //spinner
    ArrayList<String> DistrictName;
    ArrayList<String> TalukaName;
    ArrayList<String> VillageName;

    String district_name, district_id = "", taluka_name, taluka_id = "", village_id = "", village_name, currentTime, imagePath, survey_no, comment;
    HashMap<Integer, String> farmer_district_map = new HashMap<Integer, String>();
    HashMap<Integer, String> farmer_taluka_map = new HashMap<Integer, String>();
    HashMap<Integer, String> farmer_village_map = new HashMap<Integer, String>();

    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    View parentLayout;
    private SearchableSpinner sp_farmer_district_fill, sp_farmer_taluka, sp_farmer_village, sp_pikache_gav;
    private TextView  farmer_cropsap_season_tv, farmer_cropsap_crop_name_tv;
    private LinearLayout farmer_cropsap_ll, farmer_cropsap_crop_name_ll, cropsap_pikache_gav_rl;
    private RadioGroup survey_gut_radio_group;
    private RadioButton survey_radio_btn,gut_radio_btn;
    private int season_id = 0;
    private int crop_id = 0;
    private File photoFile = null;
    private int responseID;
    private String activityID = "";
    private String crop_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_crop_sap);
        getSupportActionBar().setTitle("कीड/रोग प्रादुर्भाव झाल्याची माहिती द्या");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerCropSapActivity.this);
        sharedPref = new SharedPref(FarmerCropSapActivity.this);
        parentLayout = findViewById(android.R.id.content);
        //activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);

        if (isNetworkAvailable()) {
            initialization();
            District_Service();
            Seasons_Service();

        } else {
            Snackbar.make(parentLayout, "Please Check Internet Connection", Snackbar.LENGTH_INDEFINITE)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }

    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    private void initialization() {
        farmer_cropsap_ll = (LinearLayout) findViewById(R.id.farmer_cropsap_ll);
        sp_farmer_district_fill = (SearchableSpinner) findViewById(R.id.sp_farmer_district_fill);
        sp_farmer_taluka = (SearchableSpinner) findViewById(R.id.sp_farmer_taluka);
        sp_farmer_village = (SearchableSpinner) findViewById(R.id.sp_farmer_village);
        farmer_cropsap_et_gut_number = (EditText) findViewById(R.id.farmer_cropsap_et_gut_number);
        et_comment = (EditText) findViewById(R.id.et_comment);
        crop_name_edt = (EditText) findViewById(R.id.farmer_cropsap_crop_name_edt);

        farmer_cropsap_season_tv = (TextView) findViewById(R.id.farmer_cropsap_season_tv);
        farmer_cropsap_crop_name_tv = (TextView) findViewById(R.id.farmer_cropsap_crop_name_tv);

        farmers_photo = (ImageView) findViewById(R.id.farmers_photo);
        submit_btn = (Button) findViewById(R.id.submit_btn);

        farmer_cropsap_crop_name_ll = (LinearLayout) findViewById(R.id.farmer_cropsap_crop_name_ll);

        survey_gut_radio_group = (RadioGroup) findViewById(R.id.survey_gut_radio_group);
        survey_radio_btn = (RadioButton) findViewById(R.id.survey_radio_btn);
        gut_radio_btn = (RadioButton) findViewById(R.id.gut_radio_btn);

        currentTime = ApUtil.getCurrentTimeStamp();

        DistrictName = new ArrayList<>();
        TalukaName = new ArrayList<>();
        VillageName = new ArrayList<>();

        Seasons_List = new JSONArray();
        Crops_List = new JSONArray();

        sp_farmer_district_fill.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                district_id = farmer_district_map.get(sp_farmer_district_fill.getSelectedItemPosition());
                Taluka_Service();
                TalukaName.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        sp_farmer_taluka.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                taluka_id = farmer_taluka_map.get(sp_farmer_taluka.getSelectedItemPosition());
                Village_Service();
                VillageName.clear();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_farmer_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = farmer_village_map.get(sp_farmer_village.getSelectedItemPosition());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        farmer_cropsap_season_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Seasons_List.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(Seasons_List, 4, "Select Season", "name_mr", "id", FarmerCropSapActivity.this, FarmerCropSapActivity.this);
                }
            }
        });

        farmer_cropsap_crop_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(season_id==0){
                Toast toast= Toast.makeText(getApplicationContext(), "Select Season", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL| Gravity.CENTER_HORIZONTAL, 0, 0);
                toast.show();
            }else {
                if (Crops_List.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(Crops_List, 5, "Select Crop", "crop_marathi", "id", FarmerCropSapActivity.this, FarmerCropSapActivity.this);
                }
              }
            }
        });

        survey_gut_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                switch(checkedId) {
                    case R.id.survey_radio_btn:
                        survey_radio_btn.setChecked(true);
                        farmer_cropsap_et_gut_number.setKeyListener(DigitsKeyListener.getInstance("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/"));
                        farmer_cropsap_et_gut_number.setRawInputType(InputType.TYPE_CLASS_TEXT);
                        farmer_cropsap_et_gut_number.setText("");
                        break;

                    case R.id.gut_radio_btn:
                        gut_radio_btn.setChecked(true);
                        farmer_cropsap_et_gut_number.setInputType(InputType.TYPE_CLASS_TEXT);
                        farmer_cropsap_et_gut_number.setText("");
                        break;

                }
            }
        });

        survey_no = farmer_cropsap_et_gut_number.getText().toString().trim();
        comment = et_comment.getText().toString().trim();


        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cropsap_Save_Service();

            }
        });

        farmers_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((ContextCompat.checkSelfPermission(FarmerCropSapActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FarmerCropSapActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(FarmerCropSapActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }

                }

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) + "_" + System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile != null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .resize(farmers_photo.getWidth(), farmers_photo.getHeight())
                                .centerCrop()
                                .into(farmers_photo);

                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(FarmerCropSapActivity.this, "Please click cropsap photo", Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {


            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp", currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));

            //creating a file
            File file = new File(photoFile.getPath());
            // File file = new File(imagePath);

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            //creating our api
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.upload_cropsap_image_url(partBody, params);
            api.postRequest(responseCall, this, 7);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void District_Service() {
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_district_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Taluka_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("district_id", district_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_taluka_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void Village_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id", taluka_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void Seasons_Service() {
        JSONObject param = new JSONObject();
        try {
            param.put("activity_id", "31");
        }catch (Exception e){
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterSeasonList(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Crop_Season_Service(int season_id) {
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", "31");
            param.put("crop_season_id", season_id);
            param.put("crop_type", "");
            param.put("horti_crop_type_id", "");
            param.put("primary_report_id", "");
            param.put("fieldsubmenu_id","");
            param.put("panchname_scheme_id", "0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 5);
    }

    private void Cropsap_Save_Service() {

        if (district_id.isEmpty()) {
            Toast.makeText(FarmerCropSapActivity.this, "Select district", Toast.LENGTH_SHORT).show();
        } else if (taluka_id.equalsIgnoreCase("")) {
            Toast.makeText(FarmerCropSapActivity.this, "Select taluka", Toast.LENGTH_SHORT).show();
        } else if (village_id.equalsIgnoreCase("")) {
            Toast.makeText(FarmerCropSapActivity.this, "Select village", Toast.LENGTH_SHORT).show();
        } else if (farmer_cropsap_et_gut_number.getText().toString().trim().isEmpty()) {
            Toast.makeText(FarmerCropSapActivity.this, "Enter survey number or gut number", Toast.LENGTH_SHORT).show();
        } else if (season_id == 0) {
            Toast.makeText(FarmerCropSapActivity.this, "Select season", Toast.LENGTH_SHORT).show();
        } else if (crop_id == 0) {
            Toast.makeText(FarmerCropSapActivity.this, "Select crop", Toast.LENGTH_SHORT).show();
        } else if (photoFile == null) {
            Toast.makeText(FarmerCropSapActivity.this, "Capture Photo", Toast.LENGTH_SHORT).show();
        } else if (et_comment.getText().toString().trim().isEmpty()) {
            Toast.makeText(FarmerCropSapActivity.this, "Enter your comment ", Toast.LENGTH_SHORT).show();
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("survey_no", farmer_cropsap_et_gut_number.getText().toString().trim());
                param.put("season_id", season_id);
                param.put("crop_id", crop_id);
                param.put("crop_name_ed", crop_name_edt.getText().toString().trim());
                param.put("comment", et_comment.getText().toString().trim());
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                //year
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_cropsap_save_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 6);
        }
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //district
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            District_List = jsonObject.getJSONArray("data");
                            AppSettings.getInstance().setValue(FarmerCropSapActivity.this, ApConstants.DISTRICT_LIST, District_List.toString());
                            final int numberOfItemsInResp = District_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject district_json_object = District_List.getJSONObject(j);
                                district_id = district_json_object.getString("id");
                                district_name = district_json_object.getString("district_name");
                                DistrictName.add(district_name);
                                farmer_district_map.put(j, district_id);
                                district_id = "";
                            }
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(FarmerCropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, DistrictName);

                        sp_farmer_district_fill.setAdapter(adapter);
                    } else {
                    }
                } else

                    //taluka
                    if (i == 2) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {

                                Taluka_List = jsonObject.getJSONArray("data");
                                AppSettings.getInstance().setValue(FarmerCropSapActivity.this, ApConstants.TALUKA_LIST, Taluka_List.toString());
                                final int numberOfItemsInResp = Taluka_List.length();
                                for (int j = 0; j < numberOfItemsInResp; j++) {
                                    JSONObject district_json_object = Taluka_List.getJSONObject(j);
                                    taluka_id = district_json_object.getString("id");
                                    taluka_name = district_json_object.getString("taluka_name");
                                    TalukaName.add(taluka_name);
                                    farmer_taluka_map.put(j, taluka_id);
                                    taluka_id = "";
                                }


                            }
                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(FarmerCropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, TalukaName);
                            sp_farmer_taluka.setAdapter(adapter);

                        }
                    } else
                        //Village
                        if (i == 3) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    Village_List = jsonObject.getJSONArray("data");
                                    AppSettings.getInstance().setValue(FarmerCropSapActivity.this, ApConstants.VILLAGE_LIST, Village_List.toString());
                                    final int numberOfItemsInResp = Village_List.length();
                                    for (int j = 0; j < numberOfItemsInResp; j++) {
                                        JSONObject district_json_object = Village_List.getJSONObject(j);
                                        village_id = district_json_object.getString("id");
                                        village_name = district_json_object.getString("village_name");
                                        VillageName.add(village_name);
                                        farmer_village_map.put(j, village_id);
                                        village_id = "";

                                    }

                                }

                                sp_farmer_village.setAdapter(new ArrayAdapter<String>(FarmerCropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName));
                            } else {
                                //Toast.makeText(FarmerCropSapActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                            }
                        } else

                            //seasons
                            if (i == 4) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        Seasons_List = jsonObject.getJSONArray("data");

                                    }
                                }
                            }
                //crop season
                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Crops_List = jsonObject.getJSONArray("data");

                        }

                    }


                } else {
                }

                //Cropsap save
                if (i == 6) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        responseID = jsonObject.getInt("data");

                        uploadImageOnServer(imagePath);
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("CROPSAP")
                                .setContentText("Submitted Successfully")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();

                    } else {

                    }
                }

                //Cropsap save img
                if (i == 7) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        farmers_photo.setImageResource(R.drawable.camera);
                    }
                } else {

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 4) {
            season_id = Integer.parseInt(s1);
            farmer_cropsap_season_tv.setText(s);
            farmer_cropsap_crop_name_tv.setText("Select");
            Crop_Season_Service(season_id);
        }

        if (i == 5) {
            crop_id = Integer.parseInt(s1);
            crop_name = s;
            farmer_cropsap_crop_name_tv.setText(crop_name);
            /*String other = "इतर ";
            if(s.equalsIgnoreCase(other)){
                farmer_cropsap_crop_name_ll.setVisibility(View.VISIBLE);
            }else{
                farmer_cropsap_crop_name_ll.setVisibility(View.GONE);
            }*/
        }
    }
}
