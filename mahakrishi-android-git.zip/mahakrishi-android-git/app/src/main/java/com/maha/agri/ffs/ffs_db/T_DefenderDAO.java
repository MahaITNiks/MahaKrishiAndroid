package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface T_DefenderDAO {

    @Query("SELECT * FROM T_DefenderEY")
    List<T_DefenderEY> getAll();

    @Query("DELETE FROM T_DefenderEY")
    void deleteAll();

//    @Query("DELETE FROM T_DefenderEY WHERE pest_id = :pestId and cropping_system = :cropping_system and plot_obs = :plot_type")
//    void deleteByPestId(int pestId, int cropping_system, int plot_type);

    @Query("DELETE FROM T_DefenderEY WHERE pest_id = :pestId and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteByPestId(int pestId, int cropping_system, int crop_id);

//    @Query("DELETE FROM T_DefenderEY WHERE uid not in(uid = :defenderId)  and cropping_system = :cropping_system and plot_obs = :plot_type")
//    void deleteAllDataExceptNoDefender(int defenderId, int cropping_system, int plot_type);

    @Query("DELETE FROM T_DefenderEY WHERE uid not in(uid = :defenderId)  and cropping_system = :cropping_system and crop_id = :crop_id")
    void deleteAllDataExceptNoDefender(int defenderId, int cropping_system, int crop_id);


    @Query("SELECT * FROM T_DefenderEY WHERE pest_id = :pestId")
    List<T_DefenderEY> getDefenders(int pestId);

//    @Query("SELECT * FROM T_DefenderEY WHERE uid = :id and plot_obs = :plot_type")
//    List<T_DefenderEY> checkIdExists(int id, int plot_type);

    @Query("SELECT * FROM T_DefenderEY WHERE uid = :id and crop_id = :crop_id")
    List<T_DefenderEY> checkIdExists(int id, int crop_id);

//    @Query("SELECT * FROM T_DefenderEY WHERE cropping_system = :cropping_system and plot_obs = :plot_type")
//    List<T_DefenderEY> getDefenderType(int cropping_system, int plot_type);

    @Query("SELECT * FROM T_DefenderEY WHERE cropping_system = :cropping_system and crop_id = :crop_id")
    List<T_DefenderEY> getDefenderType(int cropping_system, int crop_id);


    @Query("SELECT * FROM T_DefenderEY WHERE uid IN (:userIds)")
    List<T_DefenderEY> loadAllByIds(int[] userIds);

    @Insert
    void insertAll(T_DefenderEY... mDefenderEYS);

    @Insert
    void insertOnlySingle(T_DefenderEY mDefenderEY);
}
