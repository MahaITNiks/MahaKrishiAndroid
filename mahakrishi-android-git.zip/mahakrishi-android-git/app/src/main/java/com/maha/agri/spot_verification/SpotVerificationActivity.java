package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class SpotVerificationActivity extends AppCompatActivity implements ApiCallbackCode {

    private RecyclerView phy_veri_item_listing_rv;
    private TextView drip_total_price,drip_fitting_acc,drip_cost_subsidy,drip_total_cost;
    private EditText drip_GSTN_edt;
    private Button drip_listing_save;
    private ImageView drip_system_photo,drip_selfie_farmer;
    private Intent intent;
    private int village_id,district_id,taluka_id,farmer_id;
    private JSONArray phy_veri_item_list,spot_verification_drip_bill_data_against_id;
    private String bill_id = "",drip_bill_id="",button="", form_id = "";
    private String type,batch_no,quantity,unit_rate,total_price,total_price_str,fitting_str,subsidy_str,total_cost_str,gst_str,imageid_1 = "",imageid_2 = "";
    private int total_price_int,fitting_int,subsidy_int,total_cost_int,gst_int;
    HashMap<Integer,String> drip_bill_data_map = new HashMap<Integer, String>();
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    Dialog dialog;
    int actualQtyEt_int;
    int  actualPriceUnitEt_int;
    private View parentLayout;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private File photoFile2 = null;
    static final Integer CAMERA = 0x5;
    String imagePath1,imagePath2,currentTime;
    private Transformation transformation;
    private AppLocationManager locationManager;
    public double lat,lang;
    private String item_code = "";
    private int manuf_code = 0;
    private int scheme_id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spot_verification);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Field Name");
        preferenceManager = new PreferenceManager(SpotVerificationActivity.this);
        sharedPref = new SharedPref(SpotVerificationActivity.this);
        intent=getIntent();
        village_id=intent.getIntExtra("village_id",0);
        taluka_id=intent.getIntExtra("taluka_id",0);
        district_id=intent.getIntExtra("district_id",0);
        farmer_id=intent.getIntExtra("farmer_id",0);
        form_id = intent.getStringExtra("form_id");
        manuf_code = intent.getIntExtra("manuf_code",0);
        scheme_id = intent.getIntExtra("scheme_id",0);
        parentLayout = findViewById(android.R.id.content);
        init();
        default_config();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void init() {
        phy_veri_item_listing_rv = (RecyclerView)findViewById(R.id.phy_veri_item_listing_rv);
        drip_total_price = (TextView) findViewById(R.id.drip_total_price);
        drip_total_cost = (TextView) findViewById(R.id.drip_total_cost);
        drip_cost_subsidy = (TextView) findViewById(R.id.drip_cost_subsidy);
        drip_fitting_acc = (TextView) findViewById(R.id.drip_fitting_acc);
        drip_GSTN_edt = (EditText)  findViewById(R.id.drip_GSTN_edt);
        drip_selfie_farmer = (ImageView)  findViewById(R.id.drip_selfie_farmer);
        drip_system_photo = (ImageView)  findViewById(R.id.drip_system_photo);
        drip_listing_save = (Button) findViewById(R.id.drip_listing_save);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        phy_veri_item_listing_rv.setLayoutManager(gridLayoutManager);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
        locationManager = new AppLocationManager(this);
    }

    private void default_config() {

        phy_veri_item_list = new JSONArray();
        get_item_list();

        phy_veri_item_listing_rv.addOnItemTouchListener(new SpotVerificationAdapter.RecyclerTouchListener(this, phy_veri_item_listing_rv, new SpotVerificationAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                    JSONObject jsonObject1 = null;
                    try {
                        jsonObject1 = phy_veri_item_list.getJSONObject(position);
                        item_code = jsonObject1.getString("item_code");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                Intent drip_form_details = new Intent(SpotVerificationActivity.this, DripFormDetailActivity.class);
                drip_form_details.putExtra("village_id",village_id);
                drip_form_details.putExtra("district_id",district_id);
                drip_form_details.putExtra("takula_id",taluka_id);
                drip_form_details.putExtra("farmer_id",farmer_id);
                drip_form_details.putExtra("item_code",item_code);
                drip_form_details.putExtra("form_position",position);
                drip_form_details.putExtra("manuf_code", manuf_code);
                drip_form_details.putExtra("scheme_id", scheme_id);
                startActivity(drip_form_details);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        drip_system_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(SpotVerificationActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&
                        (ContextCompat.checkSelfPermission(SpotVerificationActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&
                        (ContextCompat.checkSelfPermission(SpotVerificationActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    type ="1";
                    takeImage1FromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        drip_selfie_farmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(SpotVerificationActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(SpotVerificationActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(SpotVerificationActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    type="2";
                    takeImage2FromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        drip_listing_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //drip_listing_save_service();
            }
        });
    }


    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    private void takeImage2FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile2 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile2);
            } else {
                photoURI = Uri.fromFile(photoFile2);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
            photoFile2 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (type.equalsIgnoreCase("1")) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .transform(transformation)
                                    .resize(drip_system_photo.getWidth(), drip_system_photo.getHeight())
                                    .centerCrop()
                                    .into(drip_system_photo);
                            //uploadImage1OnServer(imagePath1);

                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {

        }

        if(photoFile2 != null){

            if (type.equalsIgnoreCase("2")){

                if (photoFile2.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile2, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath2 = "file://" + photoFile2;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath2)
                                    .transform(transformation)
                                    .resize(drip_selfie_farmer.getWidth(), drip_selfie_farmer.getHeight())
                                    .centerCrop()
                                    .into(drip_selfie_farmer);
                            //uploadImage2OnServer(imagePath2);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile2);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else{
            //Toast.makeText(D_F_AttendanceSheetForm.this, "Please click photo", Toast.LENGTH_SHORT).show();
        }
    }

    private void get_item_list() {

        JSONObject param = new JSONObject();
        try {
            param.put("product_type",form_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.spot_veri_item_list(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

    private void uploadImage1OnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("farmer_id", String.valueOf(farmer_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("image_id","1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mechanism_save_image(partBody, params);
            api.postRequest(responseCall, this, 2);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadImage2OnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("farmer_id", String.valueOf(farmer_id));
            params.put("village_id", String.valueOf(village_id));
            params.put("image_id","2");

            File file = new File(photoFile2.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mechanism_save_image(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void drip_listing_save_service(){
        if(drip_GSTN_edt.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(SpotVerificationActivity.this,"Enter GST (Rs.)",Toast.LENGTH_SHORT).show();
        }else if(photoFile1 == null){
            Toast.makeText(SpotVerificationActivity.this,"Capture photo of drip system",Toast.LENGTH_SHORT).show();
        }else if(photoFile2 == null){
            Toast.makeText(SpotVerificationActivity.this,"Capture a selfie with farmer and drip system",Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("village_id", village_id);
                param.put("farmer_id", farmer_id);
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("gst",drip_GSTN_edt.getText().toString().trim());
                param.put("drip_photo", imageid_1);
                param.put("selfie_photo", imageid_2);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.spot_verification_drip_bill_against_id_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 4);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            phy_veri_item_list = jsonObject.getJSONArray("data");
                            SpotVerificationAdapter spotVerificationAdapter = new SpotVerificationAdapter(this,phy_veri_item_list);
                            phy_veri_item_listing_rv.setAdapter(spotVerificationAdapter);
                            spotVerificationAdapter.notifyDataSetChanged();
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        JSONObject datajsonobject = jsonObject.getJSONObject("data");
                        imageid_1 = datajsonobject.getString("file_url");
                        //farmer_mech1ImageView.setImageResource(R.drawable.camera);
                    }
                }
                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        JSONObject datajsonobject = jsonObject.getJSONObject("data");
                        imageid_2 = datajsonobject.getString("file_url");
                        //farmer_mech2ImageView.setImageResource(R.drawable.camera);
                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("Submitted successfully")
                                .setContentText(jsonObject.getString("response"))
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
