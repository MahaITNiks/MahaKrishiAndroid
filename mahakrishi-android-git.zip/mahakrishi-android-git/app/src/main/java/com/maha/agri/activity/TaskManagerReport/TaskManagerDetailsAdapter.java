package com.maha.agri.activity.TaskManagerReport;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TaskManagerDetailsAdapter extends RecyclerView.Adapter<TaskManagerDetailsAdapter.CustomViewHolder> {

    private Context context;
    private JSONArray task_manager_details_array_list,offline_scheme_work_list,offline_Work_task_list;
    private JSONObject jsonObject;
    private PreferenceManager preferenceManager;
    private DBHandler dbHandler;
    private String farmer_name,crop_name,area_name,site_location,no_of_participants,work_details,activity_name;


    public TaskManagerDetailsAdapter(Context context, JSONArray task_manager_details_array_list, PreferenceManager preferenceManager) {
        this.context = context;
        this.task_manager_details_array_list = task_manager_details_array_list;
        this.preferenceManager = preferenceManager;
        dbHandler = new DBHandler(context);

    }


    class CustomViewHolder extends RecyclerView.ViewHolder {

        private View mView;
        private TextView farmerNametxt,cropNametxt,siteLocationtxt,areaNametxt,workDetailstxt,scheme_nametxt,activity_nametxt,no_of_participantstxt;
        private RelativeLayout relativeLayout;
        private LinearLayout farmerNameLL,areaNameLL,cropNameLL,siteLocationNameLL,no_of_participantsLL,activityNameLL,workDetailsLL;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            farmerNametxt = mView.findViewById(R.id.farmernameDetails_txt);
            cropNametxt = mView.findViewById(R.id.cropnameDetails_txt);
            siteLocationtxt = mView.findViewById(R.id.sitelocationDetails_txt);
            areaNametxt = mView.findViewById(R.id.areanameDetails_txt);
            workDetailstxt = mView.findViewById(R.id.work_doneDetails_txt);
            //scheme_nametxt = mView.findViewById(R.id.scheme_nameDetails_txt);
            activity_nametxt = mView.findViewById(R.id.activity_nameDetails_txt);
            no_of_participantstxt = mView.findViewById(R.id.no_of_participants_Details_txt);
            farmerNameLL = mView.findViewById(R.id.farmernameDetails_ll);
            cropNameLL = mView.findViewById(R.id.cropnameDetails_ll);
            areaNameLL = mView.findViewById(R.id.areanameDetails_ll);
            siteLocationNameLL = mView.findViewById(R.id.sitelocationDetails_ll);
            no_of_participantsLL = mView.findViewById(R.id.no_of_participants_Details_ll);
            workDetailsLL =  mView.findViewById(R.id.workDetails_ll);
            activityNameLL = mView.findViewById(R.id.activity_nameDetails_ll);

        }
    }

    @Override
    public TaskManagerDetailsAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.tm_report_list, parent, false);
        return new TaskManagerDetailsAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TaskManagerDetailsAdapter.CustomViewHolder holder, int position) {

        try {
            JSONObject Data = task_manager_details_array_list.getJSONObject(position);

            //String firstName = Data.getString("first_name");
            //String middleName = Data.getString("middle_name");
            //String lastName = Data.getString("last_name");
            //String FullName = firstName + " " + middleName + " " + lastName;
            String  activity_Id = Data.getString("activity_id");
            offline_scheme_work_list = dbHandler.getOfflineSchemeWork(activity_Id);
            JSONObject jsonObject_offline_work = offline_scheme_work_list.getJSONObject(0);
            farmer_name = jsonObject_offline_work.getString("farmer_name");
            crop_name = jsonObject_offline_work.getString("crop_name");
            area_name = jsonObject_offline_work.getString("area");
            site_location = jsonObject_offline_work.getString("site_location");
            no_of_participants = jsonObject_offline_work.getString("no_of_participants");
            work_details = jsonObject_offline_work.getString("details");

            if(farmer_name.equalsIgnoreCase("1")){
                holder.farmerNameLL.setVisibility(View.VISIBLE);
            }  else{
                holder.farmerNameLL.setVisibility(View.GONE);
            }

            if(crop_name.equalsIgnoreCase("1")){
                holder.cropNameLL.setVisibility(View.VISIBLE);
            } else {
                holder.cropNameLL.setVisibility(View.GONE);
            }

            if(area_name.equalsIgnoreCase("1")){
                holder.areaNameLL.setVisibility(View.VISIBLE);
            }  else{
                holder.areaNameLL.setVisibility(View.GONE);
            }

            if(work_details.equalsIgnoreCase("1")){
                holder.workDetailsLL.setVisibility(View.VISIBLE);
            } else {
                holder.cropNameLL.setVisibility(View.GONE);
            }

            if(site_location.equalsIgnoreCase("1")){
                holder.siteLocationNameLL.setVisibility(View.VISIBLE);
            } else {
                holder.siteLocationNameLL.setVisibility(View.GONE);
            }

            if(no_of_participants.equalsIgnoreCase("1")){
                holder.no_of_participantsLL.setVisibility(View.VISIBLE);
            } else {
                holder.no_of_participantsLL.setVisibility(View.GONE);
            }

            holder.farmerNametxt.setText(Data.getString("farmer_name"));
            holder.cropNametxt.setText(Data.getString("crop_name"));
            holder. siteLocationtxt.setText(Data.getString("site_location"));
            holder.areaNametxt.setText(Data.getString("area"));
            holder.workDetailstxt.setText(Data.getString("details"));
            holder.no_of_participantstxt.setText(Data.getString("no_of_participants"));
            holder.activity_nametxt.setText(Data.getString("activity_name"));
            //holder.scheme_nametxt.setText(Data.getString("scheme_name"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return task_manager_details_array_list.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);
        void onLongClick(View view, int position);
    }


    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private TaskManagerDetailsAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final TaskManagerDetailsAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
