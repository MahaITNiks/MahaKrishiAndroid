package com.maha.agri.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class VisitDetailModel {

    private int sowingvisit_input_id;
    private int sowing_date;
    private String sowing_method;
    private int farmer_id;
    private String farmer_name;
    private int crop_id;
    private String crop_name;
    private int village_id;
    private String village_name;
    private String reg_type;
    private String visit_date;
    private int cropping_system_id;
    private int crop_variety_id;
    private String variety_name;
    private String irrigation_source;
    private int visit_number;
    private int is_completed;
    private int inter_crop_id;
    private String inter_crop_name;
    private int inter_crop_visit_count;
    private int visit_count;
    private int status;
    private String host_farmer_mobile;

    private JSONObject jsonObject;

    public VisitDetailModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public int getSowingvisit_input_id() {
        sowingvisit_input_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "sowingvisit_input_id");
        return sowingvisit_input_id;
    }


    public int getSowing_date() {
        sowing_date = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "sowing_date");
        return sowing_date;
    }


    public int getFarmer_id() {
        farmer_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "farmer_id");
        return farmer_id;
    }


    public int getVisit_number() {
        visit_number = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "visit_number");
        return visit_number;
    }

    public String getVillage_name() {
        village_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "village_name");
        return village_name;
    }


    public int getCrop_id() {
        crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "crop_id");
        return crop_id;
    }

    public String getCrop_name() {
        crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "crop_name");
        return crop_name;
    }

    public String getFarmer_name() {
        farmer_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "farmer_name");
        return farmer_name;
    }


    public int getCropping_system_id() {
        cropping_system_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "cropping_system_id");
        return cropping_system_id;
    }

    public int getStatus() {
        status = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "status");
        return status;
    }

    public String getHost_farmer_mobile() {
        host_farmer_mobile = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "host_farmer_mobile");
        return host_farmer_mobile;
    }

    public int getVisit_count() {
        visit_count = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "visit_count");
        return visit_count;
    }


    public int getInter_crop_id() {
        inter_crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "inter_crop_id");
        return inter_crop_id;
    }

    public String getInter_crop_name() {
        inter_crop_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "inter_crop_name");
        return inter_crop_name;
    }

    public int getInter_crop_visit_count() {
        inter_crop_visit_count = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "inter_crop_visit_count");
        return inter_crop_visit_count;
    }

    public int getIs_completed() {
        is_completed = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "is_completed");
        return is_completed;
    }

    public String getSowing_method() {
        sowing_method = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "sowing_method");
        return sowing_method;
    }

    public int getCrop_variety_id() {
        crop_variety_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "crop_variety_id");
        return crop_variety_id;
    }

    public String getVariety_name() {
        variety_name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "variety_name");
        return variety_name;
    }

    public int getVillage_id() {
        village_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "village_id");
        return village_id;
    }

    public String getReg_type() {
        reg_type = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "reg_type");
        return reg_type;
    }

    public String getVisit_date() {
        visit_date = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "visit_date");
        return visit_date;
    }

    public String getIrrigation_source() {
        irrigation_source = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "irrigation_source");
        return irrigation_source;
    }
}
