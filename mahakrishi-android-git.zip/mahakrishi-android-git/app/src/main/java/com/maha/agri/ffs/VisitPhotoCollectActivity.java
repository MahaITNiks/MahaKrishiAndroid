package com.maha.agri.ffs;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.maha.agri.R;

public class VisitPhotoCollectActivity extends AppCompatActivity /*implements ApiCallbackCode, AsyncResponse*/ {


    /*private static final int PERMISSION_REQUEST_CODE = 1;
    private static final int CAMERA_CODE = 22;

    private TextView headerTextView;

    //    private ImageView addAttendanceImageView;
    private ImageView attendanceImageView;
    private ImageView attendanceListImageView;

    //    private ImageView addTechImageView;
    private ImageView tech1ImageView;
    private ImageView tech2ImageView;


    //    private CardView obsCardView;
//    private ImageView addObservationImageView;
    private ImageView obs1ImageView;
    private ImageView obs2ImageView;
    private ImageView obs3ImageView;
    private ImageView obs4ImageView;

    //    private CardView controlObsCardView;
//    private ImageView addControlObservationImageView;
    private ImageView controlObs1ImageView;
    private ImageView controlObs2ImageView;
//    private ImageView controlObs3ImageView;
//    private ImageView controlObs4ImageView;

    //    private EditText decisionEditText;
    private String plot_name;
    private String village_name;
    private int host_farmer_id;
    private int plot_id;
    private int crop_id;
    private int inter_crop_id;
    private int cropping_system_id = 0;
    private int visit_number;
    private int schedule_id;
    private AppString appString;
    private AppSession session;
    private OnlineOfflineMode onlineOfflineMode;
    private int imgNumber = 0;
    private File photoFile;
    private File imgFile1 = null;
    private File imgFile2 = null;
    private File imgFile3 = null;
    private File imgFile4 = null;
    private File imgFile5 = null;
    private File imgFile6 = null;
    private File imgFile7 = null;
    private File imgFile8 = null;
    private File imgFile9 = null;
    private File imgFile10 = null;
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_photo_collect);
        //initComponents();
        //setConfiguration();

    }

//    private void initComponents() {
//
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        if (getSupportActionBar() != null) {
//            getSupportActionBar().setElevation(0);
//            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        }
//
//        headerTextView = findViewById(R.id.headerTextView);
//
////        addAttendanceImageView = findViewById(R.id.addAttendanceImageView);
//        attendanceImageView = findViewById(R.id.attendanceImageView);
//        attendanceListImageView = findViewById(R.id.attendanceListImageView);
//
//
////        addTechImageView = findViewById(R.id.addTechImageView);
//        tech1ImageView = findViewById(R.id.tech1ImageView);
//        tech2ImageView = findViewById(R.id.tech2ImageView);
//
//
////        obsCardView = findViewById(R.id.obsCardView);
////        addObservationImageView = findViewById(R.id.addObservationImageView);
//        obs1ImageView = findViewById(R.id.obs1ImageView);
//        obs2ImageView = findViewById(R.id.obs2ImageView);
//        obs3ImageView = findViewById(R.id.obs3ImageView);
//        obs4ImageView = findViewById(R.id.obs4ImageView);
//
//
////        controlObsCardView = findViewById(R.id.controlObsCardView);
////        addControlObservationImageView = findViewById(R.id.addControlObservationImageView);
//        controlObs1ImageView = findViewById(R.id.controlObs1ImageView);
//        controlObs2ImageView = findViewById(R.id.controlObs2ImageView);
////        controlObs3ImageView = findViewById(R.id.controlObs3ImageView);
////        controlObs4ImageView = findViewById(R.id.controlObs4ImageView);
//
////        decisionEditText = findViewById(R.id.decisionEditText);
//
//    }
//
//
//    private void setConfiguration() {
//
//        session = new AppSession(this);
//        appString = new AppString(this);
//
//        visit_number = getIntent().getIntExtra("visit", 0);
//        schedule_id = getIntent().getIntExtra("schedule_id", 0);
//        String visit = appString.getVisit() + " " + visit_number;
//        plot_name = getIntent().getStringExtra("plot_name");
//        village_name = getIntent().getStringExtra("village_name");
//
//        plot_id = getIntent().getIntExtra("plot_id", -1);
//        crop_id = getIntent().getIntExtra("crop_id", -1);
//        inter_crop_id = getIntent().getIntExtra("inter_crop_id", -1);
//
//        cropping_system_id = getIntent().getIntExtra("cropping_system_id", 0);
//
//
//        if (getIntent() != null) {
//            onlineOfflineMode = (OnlineOfflineMode) getIntent().getSerializableExtra("OnlineOfflineMode");
//        }
//
//        host_farmer_id = getIntent().getIntExtra("host_farmer_id", -1);
//
//
//        headerTextView.setText(visit);
//
//
//        attendanceImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 1; // Group photo attendance
//                onImageAction();
//            }
//        });
//
//        attendanceListImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 2; // Attendance list photo
//                onImageAction();
//            }
//        });
//
//        tech1ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 3;
//                onImageAction();
//            }
//        });
//
//        tech2ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 4;
//                onImageAction();
//            }
//        });
//
//
//        obs1ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 5;
//                onImageAction();
//            }
//        });
//
//        obs2ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 6;
//                onImageAction();
//            }
//        });
//
//        obs3ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 7;
//                onImageAction();
//            }
//        });
//
//        obs4ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 8;
//                onImageAction();
//            }
//        });
//
//
//
//        controlObs1ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 9;
//                onImageAction();
//            }
//        });
//
//        controlObs2ImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                imgNumber = 10;
//                onImageAction();
//            }
//        });
//
//
//        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                submitRequest();
//            }
//        });
//
//        dataBind();
//
////        DebugLog.getInstance().d("lat " + String.valueOf(appLocationManager.location.getLatitude()));
////        DebugLog.getInstance().d("lang " + String.valueOf(appLocationManager.location.getLongitude()));
//
//
//    }
//
//    @Override
//    public void onBackPressed() {
////        super.onBackPressed();
//    }
//
//    private void dataBind() {
//        try {
//
//            AppSession session = new AppSession(this);
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
//
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//
//        if (item.getItemId() == android.R.id.home) {
//            if (this.imgFile1 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile2 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile3 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile4 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile5 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile6 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile9 != null) {
//                showDiscardAlertMessage();
//
//            } else if (this.imgFile10 != null) {
//                showDiscardAlertMessage();
//
//            } else {
//                finish();
//            }
//
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//    }
//
//
//    private void submitRequest() {
//        validateDeltaPost();
//    }
//
//
//    private void validateDeltaPost() {
//        try {
//
//            if (imgFile1 == null) {
//                UIToastMessage.show(this, "Please capture group photo of farmers!");
//
//            } else if (imgFile2 == null) {
//                UIToastMessage.show(this, "Please capture attendance list photo!");
//
//            } else if (imgFile3 == null) {
//                UIToastMessage.show(this, "Please take photo of technology demonstrated/discussed");
//
//            } else if (imgFile5 == null) {
//                UIToastMessage.show(this, "Take the photo of farmers taking observations");
//
//            } else if (imgFile6 == null) {
//                UIToastMessage.show(this, "Take the photo of observations chart");
//
//            } else if (imgFile9 == null) {
//                UIToastMessage.show(this, "Take the photo of farmers taking control observations");
//
//            } else if (imgFile10 == null) {
//                UIToastMessage.show(this, "Take the photo of control observations chart");
//
//            } else {
//                showConfirmationAlertMessage(getResources().getString(R.string.visit_post));
//            }
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    private void postData() {
//        try {
//
//            final JSONObject jsonObject = new JSONObject();
//
//            jsonObject.put("schedule_id", schedule_id);
//            jsonObject.put("facilitator_id", session.getUserId());
//            jsonObject.put("plot_id", plot_id);
//            jsonObject.put("crop_id", crop_id);
//            jsonObject.put("cropping_system_id", cropping_system_id);
//            jsonObject.put("visit_number", visit_number);
//            jsonObject.put("host_farmer_id", host_farmer_id);
//
//
///*
//                if (onlineOfflineMode == OnlineOfflineMode.ONLINE) {
//                    jsonObject.put("guest_farmers", attendance);
//
//                } else { //Offline Guest Farmer Registered
//                    jsonObject.put("guest_farmers", session.getAttendance().toString());
//                    jsonObject.put("offline_guest_farmers", session.getAttendance().toString());
//                }
//
//                jsonObject.put("tech_demonstrations", tech);
//
//                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("observations", session.getPostObservationsIntercrop().toString());
//                } else {
//                    jsonObject.put("observations", session.getPostServerObservations(CroppingSystem.SOLE.id()));
//                }*/
//
//            jsonObject.put("lat", String.valueOf(appLocationManager.getLatitude()));
//            jsonObject.put("lon", String.valueOf(appLocationManager.getLongitude()));
////                jsonObject.put("decision_taken", decision);
//
//            jsonObject.put("file_attendance", session.getAttendanceFileName());
//            jsonObject.put("file_attendance_list", session.getAttendanceListFileName());
//            jsonObject.put("file_attendance_snacks", session.getAttendanceSnacksFileName());
//
//            jsonObject.put("file_tech_demo_1", session.getTechDemoFileName1());
//            jsonObject.put("file_tech_demo_2", session.getTechDemoFileName2());
//
//            jsonObject.put("file_observation_1", session.getObsFileName1());
//            jsonObject.put("file_observation_2", session.getObsFileName2());
//            jsonObject.put("file_observation_3", session.getObsFileName3());
//            jsonObject.put("file_observation_4", session.getObsFileName4());
//
//            jsonObject.put("control_file_obs1", session.getObsFileName1Control());
//            jsonObject.put("control_file_obs2", session.getObsFileName2Control());
//            jsonObject.put("control_file_obs3", session.getObsFileName3Control());
//            jsonObject.put("control_file_obs4", session.getObsFileName4Control());
//
//
//            jsonObject.put("latlong_attendance", session.getAttendanceFileLatLon());
//            jsonObject.put("latlong_attendance_list", session.getAttendanceListFileLatLon());
//            jsonObject.put("latlong_attendance_snacks", session.getAttendanceSnacksFileLatLon());
//
//            jsonObject.put("latlong_tech_demo_1", session.getTechDemo1FileLatLon());
//            jsonObject.put("latlong_tech_demo_2", session.getTechDemo2FileLatLon());
//
//            jsonObject.put("latlong_observation_1", session.getObs1FileLatLon());
//            jsonObject.put("latlong_observation_2", session.getObs2FileLatLon());
//
//            if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                jsonObject.put("latlong_observation_3", session.getObs3FileLatLon());
//                jsonObject.put("latlong_observation_4", session.getObs4FileLatLon());
//
//            } else {
//                jsonObject.put("latlong_observation_3", "0");
//                jsonObject.put("latlong_observation_4", "0");
//
//            }
//
///*
//                jsonObject.put("date_of_sowing", session.getDateSowing());
//                jsonObject.put("method_of_sowing", session.getMethodSowing());
//                jsonObject.put("crop_variety", session.getCropVariety());
//                jsonObject.put("irrigation_method", session.getIrrigationMethod());
//
//
//                jsonObject.put("control_date_of_sowing", session.getControlDateSowing());
//                jsonObject.put("control_method_of_sowing", session.getControlMethodSowing());
//                jsonObject.put("control_crop_variety", session.getControlCropVariety());
//                jsonObject.put("control_irrigation_method", session.getControlIrrigationMethod());
//*/
//
//
//            jsonObject.put("control_latlong_obs1", session.getObs1FileLatLonControl());
//            jsonObject.put("control_latlong_obs2", session.getObs2FileLatLonControl());
//
//            if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                jsonObject.put("control_latlong_obs3", session.getObs3FileLatLonControl());
//                jsonObject.put("control_latlong_obs4", session.getObs4FileLatLonControl());
//            } else {
//                jsonObject.put("control_latlong_obs3", "0");
//                jsonObject.put("control_latlong_obs4", "0");
//            }
//
//                /*if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
//                    jsonObject.put("control_observations", session.getPostObservationsIntercropControl().toString());
//                } else {
//                    jsonObject.put("control_observations", session.getPostServerObservationsControl(CroppingSystem.SOLE.id()));
//                }*/
//            jsonObject.put("created_at_app", session.getTimeStamp());
//
//            DebugLog.getInstance().d("param=" + jsonObject.toString());
//
//
//            final Context mContext = this;
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    FfsDatabase db = AppDelegate.getInstance(mContext).getAppDatabase();
//
//                    OffVisitDataModel model = new OffVisitDataModel(jsonObject);
//
//                    T_OfflineVisitEY offlineVisitsEY = new T_OfflineVisitEY();
//                    offlineVisitsEY.setFacilitator_id(model.getFacilitator_id());
//                    offlineVisitsEY.setPlot_id(model.getPlot_id());
//                    offlineVisitsEY.setVisit_number(model.getVisit_number());
//                    offlineVisitsEY.setHost_farmer_id(model.getFarmer_id());
////                            offlineVisitsEY.setGuest_farmers(model.getGuest_farmers());
////                            offlineVisitsEY.setTech_demonstrations(model.getTech_demonstrations());
////                            offlineVisitsEY.setObservations(model.getObservations());
////                            offlineVisitsEY.setDecision_taken(model.getDecision_taken());
//                    offlineVisitsEY.setCrop_id(model.getCrop_id());
//                    offlineVisitsEY.setSchedule_id(model.getSchedule_id());
////                        offlineVisitsEY.setCropping_system_id(model.getCropping_system_id());
//                    offlineVisitsEY.setFile_attendance(session.getAttendanceFilePath());
//                    offlineVisitsEY.setFile_attendance_list(session.getAttendanceListFilePath());
//                    // offlineVisitsEY.setFile_attendance_snacks(session.getAttendanceSnacksFilePath());
//                    offlineVisitsEY.setFile_tech_demo_1(session.getTechDemoFilePATH1());
//                    offlineVisitsEY.setFile_tech_demo_2(session.getTechDemoFilePATH2());
//                    offlineVisitsEY.setFile_observation_1(session.getObsFilePATH1());
//                    offlineVisitsEY.setFile_observation_2(session.getObsFilePATH2());
//                    offlineVisitsEY.setFile_observation_3(session.getObsFilePATH3());
//                    offlineVisitsEY.setFile_observation_4(session.getObsFilePATH4());
//                    offlineVisitsEY.setLatlong_attendance(model.getLatlong_attendance());
//                    offlineVisitsEY.setLatlong_attendance_list(model.getLatlong_attendance_list());
//                    offlineVisitsEY.setLatlong_tech_demo_1(model.getLatlong_tech_demo_1());
//                    offlineVisitsEY.setLatlong_tech_demo_2(model.getLatlong_tech_demo_2());
//                    offlineVisitsEY.setLatlong_observation_1(model.getLatlong_observation_1());
//                    offlineVisitsEY.setLatlong_observation_2(model.getLatlong_observation_2());
//                    offlineVisitsEY.setLatlong_observation_3(model.getLatlong_observation_3());
//                    offlineVisitsEY.setLatlong_observation_4(model.getLatlong_observation_4());
//                    offlineVisitsEY.setCreated_at(model.getCreated_at());
//                    offlineVisitsEY.setCreated_at_app(model.getCreated_at_app());
//                    offlineVisitsEY.setLat(model.getLat());
//                    offlineVisitsEY.setLon(model.getLon());
//                    offlineVisitsEY.setVillage_name(village_name);
//                    offlineVisitsEY.setPlot_name(plot_name);
//
//                    offlineVisitsEY.setControl_file_obs1(session.getObsFilePATH1Control());
//                    offlineVisitsEY.setControl_file_obs2(session.getObsFilePATH2Control());
//                    offlineVisitsEY.setControl_file_obs3(session.getObsFilePATH3Control());
//                    offlineVisitsEY.setControl_file_obs4(session.getObsFilePATH4Control());
//
///*
//                            offlineVisitsEY.setDate_of_sowing(model.getDate_of_sowing());
//                            offlineVisitsEY.setMethod_of_sowing(model.getMethod_of_sowing());
//                            offlineVisitsEY.setCrop_variety(model.getCrop_variety());
//
//                            offlineVisitsEY.setControl_date_of_sowing(model.getControl_date_of_sowing());
//                            offlineVisitsEY.setControl_method_of_sowing(model.getControl_method_of_sowing());
//                            offlineVisitsEY.setControl_crop_variety(model.getControl_crop_variety());
//*/
//
//                    offlineVisitsEY.setControl_latlong_obs1(model.getControl_latlong_obs1());
//                    offlineVisitsEY.setControl_latlong_obs2(model.getControl_latlong_obs2());
//                    offlineVisitsEY.setControl_latlong_obs3(model.getControl_latlong_obs3());
//                    offlineVisitsEY.setControl_latlong_obs4(model.getControl_latlong_obs4());
//
////                            offlineVisitsEY.setControl_observations(model.getControl_observations());
//
//                    offlineVisitsEY.setIs_online(0); //O means offline mode
//
//                    db.tOfflineVisitDAO().insertOnlySingle(offlineVisitsEY);
//
//                    db.facilitatorSchedulesDAO().update(1, model.getSchedule_id());
//
//                    db.close();
//
//                    VisitPhotoCollectActivity.this.runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            showAlertMessage("Your visit completed successfully.\nData saved on offline mode.\n Please sync it once you have internet");
//                        }
//                    });
//
//                }
//            }).start();
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    private void showDiscardAlertMessage() {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage("Are you sure you want to discard the captured data?");
//
//        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                    }
//                });
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                        session.clearDataForScheduleVisits();
//                        dataBind();
//                        finish();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    private void showConfirmationAlertMessage(String msg) {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(msg);
//
//
//        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.cancel();
//                    }
//                });
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        postData();
//                        dialog.cancel();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    @Override
//    public void onResponse(JSONObject jsonObject, int i) {
//        try {
//            if (jsonObject != null) {
//                ResponseModel response = new ResponseModel(jsonObject);
//
//                if (response.getStatus()) {
//                    showAlertMessage(response.getResponse());
//                    AppUtility.getInstance().deleteAllFileFromDirectory(session.getOnlineStorageDir());
//
//                } else {
//                    UIToastMessage.show(this, response.getResponse());
//                }
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    @Override
//    public void onFailure(Object o, Throwable throwable, int i) {
//
//    }
//
//
//    private void showAlertMessage(String msg) {
//
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(msg);
//
//        alertDialogBuilder.setNegativeButton(appString.getOK(),
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        showDashboard();
//                        dialog.cancel();
//                    }
//                });
//
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//    }
//
//
//    private void showDashboard() {
//        Intent intent = new Intent(this, DashboardActivity.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
//
//
//    private void onImageAction() {
//
//        if (Build.VERSION.SDK_INT < 23) {
//            //Do not need to check the permission
//            DebugLog.getInstance().d("No need to check the permission");
//            captureCamera();
//        } else {
//
//            if (checkPermissionsIsEnabledOrNot()) {
//                //If you have already permitted the permission
//                captureCamera();
//            } else {
//                requestMultiplePermission();
//            }
//
//        }
//
//    }
//
//
//    private boolean checkPermissionsIsEnabledOrNot() {
//
//
//        int permissionCamera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
//        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
//
//        return permissionCamera == PackageManager.PERMISSION_GRANTED &&
//                permissionWrite == PackageManager.PERMISSION_GRANTED;
//    }
//
//    private void requestMultiplePermission() {
//
//        int permissionCamera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
//        int permissionWrite = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
//
//        List<String> listPermissionsNeeded = new ArrayList<>();
//
//        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
//            listPermissionsNeeded.add(Manifest.permission.CAMERA);
//        }
//
//        if (permissionWrite != PackageManager.PERMISSION_GRANTED) {
//            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
//        }
//
//        ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), PERMISSION_REQUEST_CODE);
//    }
//
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        switch (requestCode) {
//
//            case PERMISSION_REQUEST_CODE:
//                try {
//                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                        captureCamera();
//                    } else {
//                        captureCamera();
//                    }
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//                break;
//
//        }
//    }
//
//
//    private void dispatchTakePictureIntent() {
//
//        AIImageLoadingUtil aiImageLoadingUtil = new AIImageLoadingUtil(this);
//
//        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//
//        // Ensure that there's a camera activity to handle the intent
//        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
//            // Create the File where the photo should go
//
//            try {
//                photoFile = aiImageLoadingUtil.createImageFile(ImageTypes.OBSERVATION.id());
//
//            } catch (Exception ex) {
//                // Error occurred while creating the File
//                ex.printStackTrace();
//            }
//
//            // Continue only if the File was successfully created
//
//            if (photoFile != null) {
//                Uri mImgURI;
//
//                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
//                    mImgURI = Uri.fromFile(photoFile);
//                } else {
//                    mImgURI = FileProvider.getUriForFile(this,
//                            "in.gov.krishi.maharashtra.pocra.ffs.android.fileprovider",
//                            photoFile);
//                }
//
//                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mImgURI);
//                takePictureIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
//
//                PackageManager packageManager = getPackageManager();
//
//                List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);
//
//                ResolveInfo res = listCam.get(0);
//                String packageName = res.activityInfo.packageName;
//
//                Intent intent = new Intent(takePictureIntent);
//                intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
//                intent.setPackage(packageName);
//
//                startActivityForResult(intent, CAMERA_CODE);
//
//                DebugLog.getInstance().d("mImgURI=" + mImgURI);
//
//            }
//
//        }
//    }
//
//
//    private void captureCamera() {
//        dispatchTakePictureIntent();
//    }
//
//
//    @Override
//    protected void onActivityResult(final int requestCode, int resultCode, Intent data) {
//
//        if (requestCode == CAMERA_CODE && resultCode == Activity.RESULT_OK) {
//
//            AIImageLoadingUtils aiImageLoadingUtil = new AIImageLoadingUtils(this);
//
//            AIImageCompressionAsyncTask asyncTask = new AIImageCompressionAsyncTask(aiImageLoadingUtil, photoFile, this);
//            asyncTask.execute("");
//        }
//
//    }
//
//
//    @Override
//    public void asyncProcessFinish(Object output) {
//
//        String result = (String) output;
//
//        DebugLog.getInstance().d("asyncProcessFinish=" + result);
//
//        String latLong = appLocationManager.getLatitude()+ "_" + appLocationManager.getLongitude();
//
//
//        if (imgNumber == 1) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kATTENDANCE_PATH, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kATTENDANCE_FILE_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile1 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(attendanceImageView);
//
//        } else if (imgNumber == 2) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kATTENDANCE_LIST_PATH, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kATTENDANCE_LIST_FILE_LOC, latLong);
//
//
//            File imgFile = new File(result);
//            this.imgFile2 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(attendanceListImageView);
//
//        } else if (imgNumber == 3) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kTECH_DEMO_PATH1, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kTECH_DEMO_FILE1_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile3 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(tech1ImageView);
//
//        } else if (imgNumber == 4) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kTECH_DEMO_PATH2, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kTECH_DEMO_FILE2_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile4 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(tech2ImageView);
//
//        } else if (imgNumber == 5) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_PATH1, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_FILE1_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile5 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(obs1ImageView);
//
//        } else if (imgNumber == 6) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_PATH2, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_FILE2_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile6 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(obs2ImageView);
//
//        } else if (imgNumber == 7) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_PATH3, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_FILE3_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile7 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(obs3ImageView);
//
//        } else if (imgNumber == 8) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_PATH4, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kOBS_FILE4_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile8 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(obs4ImageView);
//
//        } else if (imgNumber == 9) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kCONTROL_OBS_PATH1, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kCONTROL_OBS_FILE1_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile9 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(controlObs1ImageView);
//
//        } else if (imgNumber == 10) {
//
//            AppSettings.getInstance().setValue(this, AppConstants.kCONTROL_OBS_PATH2, result);
//            AppSettings.getInstance().setValue(this, AppConstants.kCONTROL_OBS_FILE2_LOC, latLong);
//
//            File imgFile = new File(result);
//            this.imgFile10 = imgFile;
//            Picasso.get()
//                    .load(imgFile)
//                    .fit()
//                    .into(controlObs2ImageView);
//
//        }
//
//
//    }
}
