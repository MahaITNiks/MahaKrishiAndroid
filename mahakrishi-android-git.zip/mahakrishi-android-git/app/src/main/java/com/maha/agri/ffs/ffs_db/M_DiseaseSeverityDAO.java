package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_DiseaseSeverityDAO {

    @Query("SELECT * FROM M_DiseaseSeverityEY")
    List<M_DiseaseSeverityEY> getAll();

    @Query("SELECT * FROM M_DiseaseSeverityEY WHERE uid IN (:userIds)")
    List<M_DiseaseSeverityEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_DiseaseSeverityEY WHERE uid = :id")
    List<M_DiseaseSeverityEY> checkIdExists(int id);


    @Insert
    void insertAll(M_DiseaseSeverityEY... m_diseaseTypeEYS);

    @Insert
    void insertOnlySingle(M_DiseaseSeverityEY m_diseaseTypeEY);

}
