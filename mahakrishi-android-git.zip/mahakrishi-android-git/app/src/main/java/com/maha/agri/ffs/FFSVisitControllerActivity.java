package com.maha.agri.ffs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.enums.CroppingSystem;
import com.maha.agri.ffs.adaptor.AttendanceVisitAdapter;
import com.maha.agri.ffs.adaptor.ObservationsAdapter;
import com.maha.agri.ffs.adaptor.TechDemonstratedAdapter;
import com.maha.agri.model.EventModel;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.AppSession;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FFSVisitControllerActivity extends AppCompatActivity implements OnMultiRecyclerItemClickListener, ApiCallbackCode {

    private PreferenceManager preferenceManager;
    private AppLocationManager appLocationManager;
    private String userID;
    private String reg_type;
    private String activityID;
    private String demoSchemeId;
    private String planId;
    private ImageView addAttendanceImageView;
    private RecyclerView attendanceRecyclerView;
    private ImageView attendanceImageView;
    private ImageView attendanceListImageView;
    private TextView attendanceBlankTextView;

    private ImageView addTechImageView;
    private RecyclerView techRecyclerView;
    private ImageView tech1ImageView;
    private ImageView tech2ImageView;
    private TextView techBlankTextView;

    private CardView obsCardView;
    private ImageView addObservationImageView;
    private RecyclerView obsRecyclerView;
    private ImageView obs1ImageView;
    private ImageView obs2ImageView;
    private ImageView obs3ImageView;
    private ImageView obs4ImageView;
    private TextView obsBlankTextView;

    private EditText decisionEditText;
    private String plot_name;
    private String village_name;
    private int villageID;
    // private int host_farmer_id;
    // private String hostFarmerName;
    private int crop_id;
    private int season_id;
    private int crop_name;
    private int inter_crop_id;
    private int cropping_system_id = 0;
    private int visit_number;
    private int schedule_id;
    private AppString appString;
    private AppSession session;

    private Boolean isObsAllowed = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_visit_controller);
        getSupportActionBar().setTitle("Visit");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        userID = AppSettings.getInstance().getValue(this,ApConstants.kUSER_ID,ApConstants.kUSER_ID);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);

        initComponents();
        setConfiguration();
    }


    private void initComponents() {

        appLocationManager = new AppLocationManager(this);
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/

        if (getSupportActionBar() != null) {
            getSupportActionBar().setElevation(0);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // headerTextView = findViewById(R.id.headerTextView);

        addAttendanceImageView = findViewById(R.id.addAttendanceImageView);
        attendanceRecyclerView = findViewById(R.id.attendanceRecyclerView);
        attendanceImageView = findViewById(R.id.attendanceImageView);
        attendanceListImageView = findViewById(R.id.attendanceListImageView);
        attendanceBlankTextView = findViewById(R.id.attendanceBlankTextView);

        addTechImageView = findViewById(R.id.addtrchnologyImageView);
        techRecyclerView = findViewById(R.id.techRecyclerView);
        tech1ImageView = findViewById(R.id.tech1ImageView);
        tech2ImageView = findViewById(R.id.tech2ImageView);
        techBlankTextView = findViewById(R.id.techBlankTextView);

        obsCardView = findViewById(R.id.obsCardView);
        addObservationImageView = findViewById(R.id.addObservationImageView);
        obsRecyclerView = findViewById(R.id.obsRecyclerView);
        obs1ImageView = findViewById(R.id.obs1ImageView);
        obs2ImageView = findViewById(R.id.obs2ImageView);
        obs3ImageView = findViewById(R.id.obs3ImageView);
        obs4ImageView = findViewById(R.id.obs4ImageView);
        obsBlankTextView = findViewById(R.id.obsBlankTextView);

        decisionEditText = findViewById(R.id.decisionEditText);
    }


    private void setConfiguration() {

        session = new AppSession(this);
        appString = new AppString(this);

        EventBus.getDefault().register(this);

        String sDetail = getIntent().getStringExtra("scheduleDetail");
        try {
            JSONObject sJSON = new JSONObject(sDetail);
            visit_number = sJSON.getInt("visit_number");
            schedule_id = sJSON.getInt("schedule_id");
            demoSchemeId = sJSON.getString("demo_scheme_id") == null ? "0" : sJSON.getString("demo_scheme_id");

            village_name = sJSON.getString("village_name");
            villageID = sJSON.getInt("village_id");

            String cropData = sJSON.getString("crop_data") == null ? "": sJSON.getString("crop_data");
            if (!cropData.equalsIgnoreCase("")){
                JSONArray cropDataArray = new JSONArray(cropData);
                JSONObject crop_data = cropDataArray.getJSONObject(0);
                crop_id = crop_data.getInt("crop_id");
                season_id = crop_data.getInt("season_id");
            }else{
                crop_id = sJSON.getInt("crop_id");
            }
            cropping_system_id = sJSON.getString("cropping_system_id") == null ? 0: Integer.parseInt(sJSON.getString("cropping_system_id"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Added on 15 June 2019
        if (visit_number == 1) {
            isObsAllowed = false;
            obsCardView.setVisibility(View.GONE);
        } else {
            isObsAllowed = true;
            obsCardView.setVisibility(View.VISIBLE);
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        attendanceRecyclerView.setLayoutManager(layoutManager);
        attendanceRecyclerView.setHasFixedSize(true);
        attendanceRecyclerView.setItemAnimator(new DefaultItemAnimator());

        LinearLayoutManager layoutManagerTech = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        techRecyclerView.setLayoutManager(layoutManagerTech);
        techRecyclerView.setHasFixedSize(true);
        techRecyclerView.setItemAnimator(new DefaultItemAnimator());

        LinearLayoutManager layoutManagerObs = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        obsRecyclerView.setLayoutManager(layoutManagerObs);
        obsRecyclerView.setHasFixedSize(true);
        obsRecyclerView.setItemAnimator(new DefaultItemAnimator());

        addTechImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG)){
                    Intent intent = new Intent(FFSVisitControllerActivity.this, DemoTechnologyForm.class);
                    intent.putExtra("villageID", String.valueOf(villageID));
                    intent.putExtra("demoSchemeId", String.valueOf(demoSchemeId));
                    intent.putExtra("cropingSysId", String.valueOf(cropping_system_id));
                    intent.putExtra("crop_id", String.valueOf(crop_id));
                    intent.putExtra("season_id",String.valueOf(season_id));
                    intent.putExtra("visit_num",String.valueOf(visit_number));
                    startActivity(intent);
                }else {
                    Intent intent = new Intent(FFSVisitControllerActivity.this, FFSTechActivity.class);
                    intent.putExtra("villageID", String.valueOf(villageID));
                    intent.putExtra("crop_id", crop_id);
                    intent.putExtra("visit_num",String.valueOf(visit_number));
                    startActivity(intent);
                }
            }
        });


        addObservationImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String schedule_details = getIntent().getStringExtra("scheduleDetail");

                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
                    Intent intent = new Intent(FFSVisitControllerActivity.this, FFSObservationIntercropActivity.class);
                    intent.putExtra("crop_id", crop_id);
                    intent.putExtra("inter_crop_id", inter_crop_id);
                    intent.putExtra("schedule_details", schedule_details);
                    intent.putExtra("cropping_system_id", cropping_system_id);
                    startActivity(intent);
                } else if (cropping_system_id == CroppingSystem.CROP_SYS_BASED.id()) {
                    Intent intent = new Intent(FFSVisitControllerActivity.this, FFSObservationIntercropActivity.class);
                    intent.putExtra("crop_id", crop_id);
                    intent.putExtra("inter_crop_id", inter_crop_id);
                    intent.putExtra("schedule_details", schedule_details);
                    intent.putExtra("cropping_system_id", cropping_system_id);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(FFSVisitControllerActivity.this, FFSObservationActivity.class);
                    intent.putExtra("crop_id", crop_id);
                    intent.putExtra("schedule_details", schedule_details);
                    startActivity(intent);
                }
            }
        });


        addAttendanceImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FFSVisitControllerActivity.this, FFSAttendanceActivity.class);
                intent.putExtra("visit_number", visit_number);
                intent.putExtra("villageID", String.valueOf(villageID));
                // intent.putExtra("farmerId", String.valueOf(host_farmer_id));
                // intent.putExtra("farmerName", hostFarmerName);
                startActivity(intent);
            }
        });


        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitRequest();
            }
        });

        dataBind();

    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

    private void dataBind() {
        try {

            AppSession session = new AppSession(this);
            JSONArray jsonArray = session.getAttendance();

            if (jsonArray.length() > 0) {
                attendanceRecyclerView.setVisibility(View.VISIBLE);
                attendanceBlankTextView.setVisibility(View.GONE);
            } else {
                attendanceRecyclerView.setVisibility(View.GONE);
                attendanceBlankTextView.setVisibility(View.VISIBLE);
            }

            AttendanceVisitAdapter attendanceVisitAdapter = new AttendanceVisitAdapter(this, village_name, this, jsonArray);
            attendanceRecyclerView.setAdapter(attendanceVisitAdapter);

            /*** For Tech Demo */
            JSONArray jsonArray1 = session.getTechDemo();

            if (jsonArray1.length() > 0) {
                techRecyclerView.setVisibility(View.VISIBLE);
                techBlankTextView.setVisibility(View.GONE);
            } else {
                techRecyclerView.setVisibility(View.GONE);
                techBlankTextView.setVisibility(View.VISIBLE);
            }

            TechDemonstratedAdapter techDemonstratedAdapter = new TechDemonstratedAdapter(this, this, jsonArray1);
            techRecyclerView.setAdapter(techDemonstratedAdapter);

            /*** For Observation*/
            JSONArray jsonArray2;

            if (cropping_system_id == CroppingSystem.SOLE.id()) {
                jsonArray2 = session.getObservations();
            } else {
                jsonArray2 = session.getObservationsIntercrop();
            }

            if (jsonArray2.length() > 0) {
                obsRecyclerView.setVisibility(View.VISIBLE);
                obsBlankTextView.setVisibility(View.GONE);
            } else {
                obsRecyclerView.setVisibility(View.GONE);
                obsBlankTextView.setVisibility(View.VISIBLE);
            }

            ObservationsAdapter observationsAdapter = new ObservationsAdapter(this, this, jsonArray2);
            obsRecyclerView.setAdapter(observationsAdapter);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                JSONArray jsonArray = session.getAttendance();
                JSONArray techjsonArray = session.getTechDemo();
                JSONArray inputJsonArray = session.getInputDemo();
                JSONArray obsjsonArray = session.getObservations();

                if (jsonArray != null && jsonArray.length() > 0) {
                    showDiscardAlertMessage();
                } else if (techjsonArray != null && techjsonArray.length() > 0) {
                    showDiscardAlertMessage();
                } else if (inputJsonArray != null && inputJsonArray.length() > 0) {
                    showDiscardAlertMessage();
                } else if (obsjsonArray != null && obsjsonArray.length() > 0) {
                    showDiscardAlertMessage();
                } else {
                    finish();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFire(EventModel event) {

        if (event != null) {

            DebugLog.getInstance().d("onEventFire=" + event.getEvent());

            //TODO Attendance
            if (event.getEvent().equalsIgnoreCase("update_1")) {

                if (session.getAttendanceFileURL() != null) {
                    Picasso.get().load(session.getAttendanceFileURL()).fit().into(attendanceImageView);
                }

                if (session.getAttendanceListFileURL() != null) {
                    Picasso.get().load(session.getAttendanceListFileURL()).fit().into(attendanceListImageView);
                }
                dataBind();
            }


            //TODO TECH Demo
            if (event.getEvent().equalsIgnoreCase("update_2")) {

                if (session.getTechDemoFileURL1() != null) {
                    Picasso.get().load(session.getTechDemoFileURL1()).fit().into(tech1ImageView);
                }

                if (session.getTechDemoFileURL2() != null) {
                    Picasso.get().load(session.getTechDemoFileURL2()).fit().into(tech2ImageView);
                }
                dataBind();
            }


            //TODO Observations
            if (event.getEvent().equalsIgnoreCase("update_3")) {

                if (!session.getObsFileURL1().equalsIgnoreCase("")) {
                    Picasso.get().load(session.getObsFileURL1()).fit().into(obs1ImageView);
                }

                if (!session.getObsFileURL2().equalsIgnoreCase("")) {
                    Picasso.get().load(session.getObsFileURL2()).fit().into(obs2ImageView);
                }

                if (!session.getObsFileURL3().equalsIgnoreCase("")) {
                    obs3ImageView.setVisibility(View.VISIBLE);
                    Picasso.get().load(session.getObsFileURL3()).fit().into(obs3ImageView);
                }

                if (!session.getObsFileURL4().equalsIgnoreCase("")) {
                    obs4ImageView.setVisibility(View.VISIBLE);
                    Picasso.get().load(session.getObsFileURL4()).fit().into(obs4ImageView);
                }
                dataBind();
            }
        }
    }


    private void submitRequest() {
        validateDeltaPost();
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {

    }

    private void validateDeltaPost() {
        try {

            JSONArray attendanceArray = session.getAttendance();
            JSONArray techArray = session.getTechDemo();

            String attendance = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getAttendance(), "id");
            String tech = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getTechDemo(), "id");
            JSONArray inputJsonArray = session.getInputDemo();
            String decision = decisionEditText.getText().toString();

            if (isObsAllowed) {
                if (attendance.isEmpty()) {
                    UIToastMessage.show(this, "Please mark attendance");
                } /*else if (!reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && tech.isEmpty()) {
                    UIToastMessage.show(this, "Please mark technology demonstrated");
                }*/else if ((reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && inputJsonArray.length() == 0)) {
                    UIToastMessage.show(this, "Please mark input used");
                } else if (session.getPostObservations(cropping_system_id).length() == 0) {
                    UIToastMessage.show(this, "Please take observations");
                } else if (decision.isEmpty()) {
                    UIToastMessage.show(this, "Please enter decision taken by group farmers");
                } else {
                    showConfirmationAlertMessage(getResources().getString(R.string.visit_post));
                }
            } else {

                if (attendance.isEmpty()) {
                    UIToastMessage.show(this, "Please mark attendance");
                } /*else if (tech.isEmpty()) {
                    UIToastMessage.show(this, "Please mark technology demonstrated");
                }*/ else if (decision.isEmpty()) {
                    UIToastMessage.show(this, "Please enter decision taken by group farmers");
                } else {
                    showConfirmationAlertMessage(getResources().getString(R.string.visit_post));
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void postData() {
        try {

            String attendance = getPresentFarmer(session.getAttendance(),  "id");
            // String attendance = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getAttendance(), "id");

            String tech = AppUtility.getInstance().componentSeparatedByCommaJSONArray(session.getTechDemo(), "id");
            JSONArray inputJsonArray = session.getInputDemo();
            String decision = decisionEditText.getText().toString();

            if (attendance.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.visit_attendance_err));
            } /*else if (!reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && tech.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.visit_tech_err));
            }*/else if ((reg_type.equalsIgnoreCase(ApConstants.kFARMER_DEMO_REG) && inputJsonArray.length() == 0)) {
                UIToastMessage.show(this, getResources().getString(R.string.visit_input_err));
            } else if (decision.isEmpty()) {
                UIToastMessage.show(this, getResources().getString(R.string.visit_decision_err));
            } else {

                DebugLog.getInstance().d("attendance=" + attendance);
                DebugLog.getInstance().d("tech=" + tech);

                final JSONObject jsonObject = new JSONObject();

                jsonObject.put("plan_id", planId);
                jsonObject.put("schedule_id", schedule_id);
                jsonObject.put("user_id", userID);
                jsonObject.put("reg_type", reg_type);
                jsonObject.put("crop_id", crop_id);
                jsonObject.put("cropping_system_id", cropping_system_id);
                jsonObject.put("visit_number", visit_number);
                jsonObject.put("guest_farmers", attendance);
                jsonObject.put("tech_demonstrations", tech);
                jsonObject.put("input_demonstrations", inputJsonArray);
                if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
                    jsonObject.put("observations", session.getPostObservationsIntercrop().toString());
                } else {
                    jsonObject.put("observations", session.getPostServerObservations(CroppingSystem.SOLE.id()));
                }
                 jsonObject.put("lat", "0.0");
                 jsonObject.put("lon", "0.0");

                // jsonObject.put("lat", String.valueOf(appLocationManager.getLatitude()));
                // jsonObject.put("lon", String.valueOf(appLocationManager.getLongitude()));
                jsonObject.put("decision_taken", decision);
                jsonObject.put("file_attendance", session.getAttendanceFileURL());
                jsonObject.put("file_attendance_list", session.getAttendanceListFileURL());
                jsonObject.put("file_tech_demo_1", session.getTechDemoFileURL1());
                jsonObject.put("file_tech_demo_2", session.getTechDemoFileURL2());
                jsonObject.put("file_observation_1", session.getObsFileURL1());
                jsonObject.put("file_observation_2", session.getObsFileURL2());
                //jsonObject.put("file_observation_3", session.getObsFileURL3());
                //jsonObject.put("file_observation_4", session.getObsFileURL4());
                jsonObject.put("latlong_attendance", session.getAttendanceFileLatLon());
                jsonObject.put("latlong_attendance_list", session.getAttendanceListFileLatLon());
                jsonObject.put("latlong_tech_demo_1", session.getTechDemo1FileLatLon());
                jsonObject.put("latlong_tech_demo_2", session.getTechDemo2FileLatLon());
                jsonObject.put("latlong_observation_1", session.getObs1FileLatLon());
                jsonObject.put("latlong_observation_2", session.getObs2FileLatLon());

                //jsonObject.put("latlong_observation_3", "0");
                //jsonObject.put("latlong_observation_4", "0");

               /* if (cropping_system_id == CroppingSystem.INTER_CROP.id()) {
                    jsonObject.put("latlong_observation_3", session.getObs3FileLatLon());
                    jsonObject.put("latlong_observation_4", session.getObs4FileLatLon());
                } else {
                    jsonObject.put("latlong_observation_3", "0");
                    jsonObject.put("latlong_observation_4", "0");
                }*/

                jsonObject.put("date_of_sowing", session.getDateSowing());
                jsonObject.put("method_of_sowing", session.getMethodSowing());
                jsonObject.put("crop_variety", session.getCropVariety());
                jsonObject.put("irrigation_method", session.getIrrigationMethod());
                jsonObject.put("created_at_app", session.getTimeStamp());

                DebugLog.getInstance().d("param=" + jsonObject.toString());
                RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

                AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);
                Call<JsonObject> responseCall = apiRequest.postD_F_VisitsRequest(requestBody);

                DebugLog.getInstance().d("param=" + responseCall.request().toString());
                DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

                api.postRequest(responseCall, this, 1);

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private String getPresentFarmer(JSONArray array, String key) {

        StringBuilder sb = new StringBuilder();

        try {
            for(int i = 0; i < array.length(); ++i) {
                JSONObject jsonObject = array.getJSONObject(i);
                String type = jsonObject.getString("designation");
                String data = jsonObject.getString(key);
                if (sb.length() > 0 && !data.isEmpty()) {
                    sb.append(',');
                }

                if (!data.isEmpty()) {
                    if (type.equalsIgnoreCase("Host Farmer")){
                        sb.append("H-").append(data);
                    }else if (type.equalsIgnoreCase("Guest Farmer")){
                        sb.append("G-").append(data);
                    }
                }
            }
        } catch (JSONException var7) {
            var7.printStackTrace();
        }
        return sb.toString();
    }


    private void showDiscardAlertMessage() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to discard the captured data?");

        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setNegativeButton(appString.getOK(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        session.clearDataForScheduleVisits();
                        dataBind();
                        finish();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    private void showConfirmationAlertMessage(String msg) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage(msg);

        alertDialogBuilder.setPositiveButton(appString.getCANCEL(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        alertDialogBuilder.setNegativeButton(appString.getOK(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        postData();
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        try {
            if (jsonObject != null) {
                ResponseModel response = new ResponseModel(jsonObject);

                fetchSchedules();
                fetchHistoryOfVisits();

                if (response.isStatus()) {
                    showAlertMessage(response.getMsg());
                    AppUtility.getInstance().deleteAllFileFromDirectory(session.getOnlineStorageDir());
                } else {
                    UIToastMessage.show(this, response.getMsg());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    private void showAlertMessage(String msg) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage(msg);

        alertDialogBuilder.setNegativeButton(appString.getOK(),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        showDashboard();
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    private void showDashboard() {
        Intent intent = new Intent(this, D_F_VisitScheduleActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }


    private void fetchSchedules() {

        try {

            AppSession session = new AppSession(this);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("user_id", session.getUserId());
                jsonObject.put("season_id", session.getSeasonType());
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchSchedules(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, new ApiCallbackCode() {
                @Override
                public void onResponse(JSONObject jsonObject, int i) {
                    if (i == 1) {
                        if (jsonObject != null) {

                            DebugLog.getInstance().d("onResponse=" + jsonObject);
                            ResponseModel response = new ResponseModel(jsonObject);

                            if (response.isStatus()) {
                                JSONArray jsonArray = response.getData();
                                if (jsonArray.length() > 0) {
                                    AppSettings.getInstance().setValue(FFSVisitControllerActivity.this, ApConstants.kSCHEDULES, jsonArray.toString());
                                }
                            } else {
                                AppSettings.getInstance().setValue(FFSVisitControllerActivity.this, ApConstants.kSCHEDULES, ApConstants.kSCHEDULES);
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Object o, Throwable throwable, int i) {

                }
            }, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void fetchHistoryOfVisits() {

        /*try {
            AppSession session = new AppSession(this);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("user_id", session.getUserId());

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, session.getToken(), new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchHistoryOfVisits(requestBody);

            DebugLog.getInstance().d("param=" + responseCall.request().toString());
            DebugLog.getInstance().d("param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, new ApiCallbackCode() {
                @Override
                public void onResponse(JSONObject jsonObject, int i) {
                    if (jsonObject != null) {

                        DebugLog.getInstance().d("onResponse=" + jsonObject);
                        ResponseModel response = new ResponseModel(jsonObject);

                        if (response.isStatus()) {
                            JSONArray jsonArray = response.getData();
                            if (jsonArray.length() > 0) {
                               // AppSettings.getInstance().setValue(FFSVisitControllerActivity.this, AppConstants.kHISTORY_OF_VISITS, jsonArray.toString());
                            }
                        } else {
                            //AppSettings.getInstance().setValue(FFSVisitControllerActivity.this, AppConstants.kHISTORY_OF_VISITS, AppConstants.kHISTORY_OF_VISITS);
                        }
                    }
                }

                @Override
                public void onFailure(Object o, Throwable throwable, int i) {

                }
            }, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }
}
