package com.maha.agri.ffs;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.ffs.adaptor.VisitsAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_VisitScheduleActivity extends AppCompatActivity implements OnMultiRecyclerItemClickListener {

    private RecyclerView recyclerView;
    private TextView scheduleEmptyTextView;
    private VisitsAdapter visitsAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_visits_schedule);
        getSupportActionBar().setTitle("Visits scheduled");

        initComponents();
        setConfiguration();
    }

    private void initComponents() {

        recyclerView = findViewById(R.id.recyclerView);
        scheduleEmptyTextView = (TextView) findViewById(R.id.scheduleEmptyTextView);
    }

    private void setConfiguration() {

        if (getSupportActionBar() != null) {
            getSupportActionBar().setElevation(0);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        GridLayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        fetchSchedules();
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject) o;
        Intent intent = new Intent(this, D_F_VisitScheduleDetailsActivity.class);
        intent.putExtra("details", jsonObject.toString());
        startActivity(intent);
    }

    // TO get Schedule
    private void fetchSchedules() {
        try {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("crop_id", AppSettings.getInstance().getValue(this, ApConstants.kCROP_ID_DEMO_FFS, ApConstants.kCROP_ID_DEMO_FFS));
                jsonObject.put("vareity_id", AppSettings.getInstance().getValue(this, ApConstants.kCROP_VERITY_ID_DEMO_FFS, ApConstants.kCROP_VERITY_ID_DEMO_FFS));
                jsonObject.put("reg_type", AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE));
                jsonObject.put("village_id", AppSettings.getInstance().getValue(this, ApConstants.kVILLAGE_ID_DEMO_FFS, ApConstants.kVILLAGE_ID_DEMO_FFS));
                jsonObject.put("plan_id", AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS));

            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.fetchSchedules(requestBody);

            DebugLog.getInstance().d("get_schedule_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("get_schedule_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, new ApiCallbackCode() {

                @Override
                public void onResponse(JSONObject jsonObject, int i) {
                    if (jsonObject != null) {

                        DebugLog.getInstance().d("onResponse=" + jsonObject);
                        ResponseModel response = new ResponseModel(jsonObject);

                        if (response.isStatus()) {

                            JSONArray scheduleJSONArr = response.getData(); // Commented for testing purpose

                            if (scheduleJSONArr.length() > 0) {
                                scheduleEmptyTextView.setVisibility(View.GONE);
                                recyclerView.setVisibility(View.VISIBLE);
                                visitsAdapter = new VisitsAdapter(D_F_VisitScheduleActivity.this, D_F_VisitScheduleActivity.this, scheduleJSONArr);
                                recyclerView.setAdapter(visitsAdapter);
                                visitsAdapter.notifyDataSetChanged();
                            } else {
                                scheduleEmptyTextView.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                                visitsAdapter = new VisitsAdapter(D_F_VisitScheduleActivity.this, D_F_VisitScheduleActivity.this, null);
                                recyclerView.setAdapter(visitsAdapter);
                                visitsAdapter.notifyDataSetChanged();
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Object o, Throwable throwable, int i) {

                }

            }, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
