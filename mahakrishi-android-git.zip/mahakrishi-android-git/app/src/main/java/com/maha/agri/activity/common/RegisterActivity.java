package com.maha.agri.activity.common;

import android.content.Intent;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class RegisterActivity extends AppCompatActivity implements ApiCallbackCode {

    private TextInputLayout first_name_txtinputlayout,middle_name_txtinputlayout,last_name_txtinputlayout,mobile_txtinputlayout,aadhar_txtinputlayout;
    private SearchableSpinner sp_farmer_reg_district,sp_farmer_reg_taluka,sp_farmer_reg_village;
    private EditText first_name_edt,middle_name_edt,last_name_edt,mobile_edt,aadhar_edt,password_edt,confirm_password_edt;
    private Button registernowBtn;
    private JSONObject registerJsonObject;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;
    private String districtID="0",talukaID="0",villageID;
    private String district_name,taluka_name,village_name;
    HashMap<Integer,String> district_map = new HashMap<Integer, String>();
    HashMap<Integer,String> taluka_map = new HashMap<Integer, String>();
    HashMap<Integer,String> village_map = new HashMap<>();
    ArrayList<String> DistrictName;
    ArrayList<String> TalukaName;
    ArrayList<String> VillageName;
    private JSONArray district_list,taluka_list,village_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);
        sharedPref = new SharedPref(RegisterActivity.this);
        preferenceManager = new PreferenceManager(RegisterActivity.this);
        init();
        default_confiq();
    }

    private void init(){

        first_name_txtinputlayout = (TextInputLayout) findViewById(R.id.first_name_txtinputlayout);
        middle_name_txtinputlayout = (TextInputLayout) findViewById(R.id.middle_name_txtinputlayout);
        last_name_txtinputlayout = (TextInputLayout) findViewById(R.id.last_name_txtinputlayout);
        mobile_txtinputlayout = (TextInputLayout) findViewById(R.id.mobile_txtinputlayout);
        aadhar_txtinputlayout = (TextInputLayout) findViewById(R.id.aadhar_txtinputlayout);

        first_name_edt = (EditText) findViewById(R.id.first_name_edt);
        middle_name_edt = (EditText) findViewById(R.id.middle_name_edt);
        last_name_edt = (EditText) findViewById(R.id.last_name_edt);
        mobile_edt = (EditText) findViewById(R.id.mobile_edt);

        sp_farmer_reg_district = (SearchableSpinner)findViewById(R.id.sp_farmer_reg_district);
        sp_farmer_reg_taluka = (SearchableSpinner)findViewById(R.id.sp_farmer_reg_taluka);
        sp_farmer_reg_village = (SearchableSpinner)findViewById(R.id.sp_farmer_reg_village);

        mobile_edt.setText(preferenceManager.getPreferenceValues(Preference_Constant.FARMER_MOBILE_NUMBER));
        aadhar_edt = (EditText) findViewById(R.id.aadhar_edt);
        password_edt = (EditText) findViewById(R.id.password_edt);
        confirm_password_edt = (EditText) findViewById(R.id.confirm_password_edt);

        registernowBtn = (Button) findViewById(R.id.registernowBtn);

        DistrictName = new ArrayList<>();
        TalukaName = new ArrayList<>();
        VillageName = new ArrayList<>();
        District_Service();
    }

    private void default_confiq(){

        sp_farmer_reg_district.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                districtID = district_map.get(sp_farmer_reg_district.getSelectedItemPosition());
                district_name = sp_farmer_reg_district.getSelectedItem().toString();
                Taluka_Service();
                TalukaName.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_farmer_reg_taluka.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                talukaID = taluka_map.get(sp_farmer_reg_taluka.getSelectedItemPosition());
                taluka_name = sp_farmer_reg_taluka.getSelectedItem().toString();
                Village_Service();
                VillageName.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_farmer_reg_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                villageID = village_map.get(sp_farmer_reg_village.getSelectedItemPosition());
                village_name = sp_farmer_reg_village.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        registernowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerApiCalling();
            }
        });

    }

    private void District_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_district_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Taluka_Service(){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",districtID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_taluka_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);

    }

    private void Village_Service(){
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id",talukaID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }


    private void registerApiCalling(){

        if(districtID.equalsIgnoreCase("")){
            UIToastMessage.show(RegisterActivity.this,"जिल्हा निवडा");
        }

        if(talukaID.equalsIgnoreCase("")){
            UIToastMessage.show(RegisterActivity.this, "तालुका निवडा");
        }

        if(villageID.equalsIgnoreCase("")){
            UIToastMessage.show(RegisterActivity.this, "गाव निवडा");
        }

        if(first_name_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"आपले नाव प्रविष्ट करा");

        } else if(middle_name_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"आपले मधले नाव प्रविष्ट करा");

        }else if(last_name_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"आपले आडनाव प्रविष्ट करा");

        }else if(aadhar_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"आपला वैध आधार क्रमांक प्रविष्ट करा");

        }else if(password_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"आपला संकेतशब्द प्रविष्ट करा");

        }else if(confirm_password_edt.getText().toString().equalsIgnoreCase("")){

            UIToastMessage.show(RegisterActivity.this,"कृपया आपल्या संकेतशब्दाची पुष्टी करा");

        } else {
            JSONObject param = new JSONObject();
            try {
                param.put("district_id",districtID);
                param.put("taluka_id",talukaID);
                param.put("village_id",villageID);
                param.put("first_name", first_name_edt.getText().toString().trim());
                param.put("middle_name", middle_name_edt.getText().toString().trim());
                param.put("last_name", last_name_edt.getText().toString().trim());
                param.put("email","");
                param.put("salutation_name","");
                param.put("mobile", preferenceManager.getPreferenceValues(Preference_Constant.FARMER_MOBILE_NUMBER));
                param.put("aadhar_no", aadhar_edt.getText().toString().trim());
                param.put("password", password_edt.getText().toString().trim());
                param.put("confirm_password", confirm_password_edt.getText().toString().trim());
                param.put("usertype","");
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmer_registration_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 4);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            district_list = jsonObject.getJSONArray("data");
                            final int numberOfItemsInResp = district_list.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject district_json_object = district_list.getJSONObject(j);
                                districtID = district_json_object.getString("id");
                                district_name = district_json_object.getString("district_name");
                                DistrictName.add(district_name);
                                district_map.put(j, districtID);
                                districtID = "";


                            }


                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(RegisterActivity.this, android.R.layout.simple_spinner_dropdown_item, DistrictName);
                        sp_farmer_reg_district.setAdapter(adapter);
                    } else {
                        //UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                } else

                    //taluka
                    if (i == 2) {

                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {

                                taluka_list = jsonObject.getJSONArray("data");
                                final int numberOfItemsInResp = taluka_list.length();
                                for (int j = 0; j < numberOfItemsInResp; j++) {
                                    JSONObject taluka_json_object = taluka_list.getJSONObject(j);
                                    talukaID = taluka_json_object.getString("id");
                                    taluka_name = taluka_json_object.getString("taluka_name");
                                    TalukaName.add(taluka_name);
                                    taluka_map.put(j, talukaID);
                                    talukaID = "";

                                }

                            }

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(RegisterActivity.this, android.R.layout.simple_spinner_dropdown_item, TalukaName);
                            sp_farmer_reg_taluka.setAdapter(adapter);

                        } else {
                            //UIToastMessage.show(this, jsonObject.getString("response"));
                        }
                    }else
                        //Village
                        if (i == 3) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    village_list = jsonObject.getJSONArray("data");
                                    final int numberOfItemsInResp = village_list.length();
                                    for (int j = 0; j < numberOfItemsInResp; j++) {
                                        JSONObject village_json_object = village_list.getJSONObject(j);
                                        villageID = village_json_object.getString("id");
                                        village_name = village_json_object.getString("village_name");
                                        VillageName.add(village_name);
                                        village_map.put(j, villageID);
                                        villageID = "";
                                    }

                                }
                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(RegisterActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName);
                                sp_farmer_reg_village.setAdapter(adapter);
                            } else {
                                Toast.makeText(RegisterActivity.this,jsonObject.getString("response"),Toast.LENGTH_SHORT).show();
                            }

                        }

                        if (i == 4) {

                            if (jsonObject.getString("status").equals("200")) {
                                UIToastMessage.show(RegisterActivity.this,jsonObject.getString("response"));
                                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                intent.putExtra("type","farmer");
                                startActivity(intent);
                                finish();

                            } else {
                                UIToastMessage.show(this, jsonObject.getString("response"));
                            }


                        }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


   /* private boolean validateName() {
        if (first_name_edt.getText().toString().trim().isEmpty()) {
            first_name_txtinputlayout.setError("आपले नाव प्रविष्ट करा");
            requestFocus(first_name_edt);
            return true;
        } else if(middle_name_edt.getText().toString().trim().isEmpty()){
            middle_name_txtinputlayout.setError("आपले मधले नाव प्रविष्ट करा");
            requestFocus(middle_name_edt);
            return true;
        } else if(last_name_edt.getText().toString().trim().isEmpty()){
            last_name_txtinputlayout.setError("आपले आडनाव प्रविष्ट करा");
            requestFocus(last_name_edt);
            return true;
        } else {
            first_name_txtinputlayout.setErrorEnabled(false);
            middle_name_txtinputlayout.setErrorEnabled(false);
            last_name_txtinputlayout.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateMobile() {
        String mobile = mobile_edt.getText().toString().trim();

        if (mobile.isEmpty()) {
            mobile_txtinputlayout.setError(getString(R.string.error_mobile));
            requestFocus(mobile_edt);
            return false;
        } else {
            mobile_txtinputlayout.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateAadhar() {
        if (aadhar_edt.getText().toString().trim().isEmpty()) {
            aadhar_txtinputlayout.setError(getString(R.string.error_aadhar));
            requestFocus(aadhar_edt);
            return false;
        } else {
            aadhar_txtinputlayout.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validatePassword() {
        if (password_edt.getText().toString().trim().isEmpty()) {
            password_txtinputlayout.setError(getString(R.string.error_password));
            requestFocus(password_edt);
            return false;
        } else {
            password_txtinputlayout.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateConfirmPassword() {
        if (confirm_password_edt.getText().toString().trim().isEmpty()) {
            reenter_password_txtinputlayout.setError(getString(R.string.error_confirm_password));
            requestFocus(confirm_password_edt);
            return false;
        } else {
            reenter_password_txtinputlayout.setErrorEnabled(false);
        }

        return true;
    }






    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }

    }*/

   /* private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.first_name_edt:
                    validateName();
                    break;

                case R.id.middle_name_edt:
                    validateName();
                    break;

                case R.id.last_name_edt:
                    validateName();
                    break;

                case R.id.mobile_edt:
                    validateMobile();
                    break;
                case R.id.aadhar_edt:
                    validateAadhar();
                    break;

                case R.id.password_edt:
                    validatePassword();
                    break;
                case R.id.confirm_password_edt:
                    validateConfirmPassword();
                    break;
            }
        }
    }*/
}
