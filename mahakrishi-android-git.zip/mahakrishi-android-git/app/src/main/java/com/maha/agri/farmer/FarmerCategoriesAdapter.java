package com.maha.agri.farmer;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerCategoriesAdapter extends RecyclerView.Adapter<FarmerCategoriesAdapter.MyViewHolderFarmer> {
    private JSONArray farmer_category_array_list;
    private Context context;
    private int[] farmer_dashboard_background;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;

    public FarmerCategoriesAdapter(PreferenceManager preferenceManager, JSONArray farmer_category_array_list,int[] farmer_dashboard_background, Context context) {
        this.preferencemanager = preferenceManager;
        this.farmer_dashboard_background=farmer_dashboard_background;
        this.farmer_category_array_list = farmer_category_array_list;
        this.context = context;
    }

    public static class MyViewHolderFarmer extends RecyclerView.ViewHolder {
        private ImageView farmer_dashboard_single_background;
        private TextView farmer_category_single_title;
        private RelativeLayout farmer_category_single_item_rl;


        public MyViewHolderFarmer(View itemView) {
            super(itemView);
            this.farmer_dashboard_single_background = itemView.findViewById(R.id.farmer_category_back_single_image_view);
            this.farmer_category_single_title = itemView.findViewById(R.id.farmer_category_single_text_view);
            this.farmer_category_single_item_rl = itemView.findViewById(R.id.farmer_category_single_item_rl);

        }
    }

    @NonNull
    @Override
    public FarmerCategoriesAdapter.MyViewHolderFarmer onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_category_single_item, parent, false);

        FarmerCategoriesAdapter.MyViewHolderFarmer myViewHolderFarmer = new FarmerCategoriesAdapter.MyViewHolderFarmer(view);
        return myViewHolderFarmer;
    }

    @Override
    public void onBindViewHolder(@NonNull FarmerCategoriesAdapter.MyViewHolderFarmer myViewHolder, int listPosition) {
        try {
            jsonObject = farmer_category_array_list.getJSONObject(listPosition);

           /* holder.farmer_magazine_single_item_rl.setTag(listPosition);

            holder.farmer_magazine_single_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = farmer_magazine_array_list.getJSONObject(index).getString("id");
                        preferencemanager.putPreferenceValues(Preference_Constant.FARMER_MAGAZINE_MONTH_ID,id);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });*/
            {
                myViewHolder.farmer_category_single_title.setText(jsonObject.getString("name_mr"));
                myViewHolder.farmer_dashboard_single_background.setImageResource(farmer_dashboard_background[listPosition]);

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (farmer_category_array_list != null) {
            return farmer_category_array_list.length();
        } else {
            return 0;
        }
    }



}
