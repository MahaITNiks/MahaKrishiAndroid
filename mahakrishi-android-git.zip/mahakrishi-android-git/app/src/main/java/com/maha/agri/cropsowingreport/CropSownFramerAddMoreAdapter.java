package com.maha.agri.cropsowingreport;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;


public class CropSownFramerAddMoreAdapter extends RecyclerView.Adapter<CropSownFramerAddMoreAdapter.MyViewHolder>  {
    private JSONArray add_more_list;
    private JSONObject jsonObject;
    private Context context;
    private PreferenceManager preferencemanager;
    HashMap<Integer,String> crop_map = new HashMap<Integer, String>();

    public CropSownFramerAddMoreAdapter(PreferenceManager preferenceManager, JSONArray add_more_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.add_more_list = add_more_list;
        this.context = context;

    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView fcropname_tv,fsown_area_tv,flast_year_sown_area_tv,fnatural_sown_area_tv,ffamertotal;
        private ImageView fsowing_report_row_delete_iv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.fcropname_tv = itemView.findViewById(R.id.fcropname_tv);
            this.fsown_area_tv = itemView.findViewById(R.id.fsown_area_tv);
            this.fnatural_sown_area_tv = itemView.findViewById(R.id.fnatural_sown_area_tv);
            this.flast_year_sown_area_tv = itemView.findViewById(R.id.flast_year_sown_area_tv);
            this.ffamertotal = itemView.findViewById(R.id.ffamertotal);
            this.fsowing_report_row_delete_iv = itemView.findViewById(R.id.fsowing_report_row_delete_iv);

        }
    }



    @Override
    public CropSownFramerAddMoreAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sowingfarmer_report_single_item, parent, false);

        CropSownFramerAddMoreAdapter.MyViewHolder myViewHolder = new CropSownFramerAddMoreAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int listPosition) {

        try {
            jsonObject = add_more_list.getJSONObject(listPosition);
            myViewHolder.fcropname_tv.setText(jsonObject.getString("crop_name"));
            myViewHolder.fsown_area_tv.setText(jsonObject.getString("area_zero_one_year"));
            myViewHolder.fnatural_sown_area_tv.setText(jsonObject.getString("area_one_three_year"));
            myViewHolder.flast_year_sown_area_tv.setText(jsonObject.getString("area_above_three_year"));
            myViewHolder.ffamertotal.setText(jsonObject.getString("total_area"));
            myViewHolder.fsowing_report_row_delete_iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    add_more_list.remove(listPosition);
                    notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private CropSownAddMoreAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CropSownAddMoreAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }


}
