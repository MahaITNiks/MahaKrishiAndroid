

package com.maha.agri.mb_recording;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.util.ApUtil;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;

public class MbSoilListAdapter extends RecyclerView.Adapter<MbSoilListAdapter.ViewHolder> {

    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;


    public MbSoilListAdapter(Context mContext,  OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
    }


    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.list_mb_soil_report, parent, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            holder.onBind(mDataArray.getJSONObject(position), listener);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView mbStageImageView;
        private final TextView stageNameTextView;
        private final TextView stageLaveTextView;
        private final TextView liftFromTextView;
        private final TextView liftToTextView;
        private final TextView dateTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            stageNameTextView = (TextView)itemView.findViewById(R.id.stageNameTextView);
            stageLaveTextView = (TextView)itemView.findViewById(R.id.stageLaveTextView);
            mbStageImageView = (ImageView)itemView.findViewById(R.id.mbStageImageView);
            liftFromTextView = (TextView)itemView.findViewById(R.id.liftFromTextView);
            liftToTextView = (TextView)itemView.findViewById(R.id.liftToTextView);
            dateTextView = (TextView)itemView.findViewById(R.id.dateTextView);
        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            try {

                Transformation transformation = new RoundedTransformationBuilder()
                        .borderColor(mContext.getResources().getColor(R.color.colorPrimaryDark))
                        .borderWidthDp(1)
                        .cornerRadiusDp(10)
                        .oval(false)
                        .build();

                JSONObject mbData = jsonObject.getJSONObject("form_data");
                String soilId =  mbData.getString("soil_id");
                String SoilName = mbData.getString("soil_name");
                String img1Url = "";
                stageNameTextView.setText(SoilName);
                String stageLaval = mbData.getString("stepID");
                String laval =  "Level : "+stageLaval;
                stageLaveTextView.setText(laval);
                String createdDate = jsonObject.getString("created_at");
                dateTextView.setText("Date :"+ ApUtil.getDateByTimeStamp(createdDate));
                img1Url = mbData.getString("img1Url");

                if (soilId.equalsIgnoreCase("9")){
                    String total = "PCC Total : "+mbData.getString("total_pcc");
                    liftFromTextView.setText(total);
                }else if (soilId.equalsIgnoreCase("10")){
                    String volume = mbData.getString("str_volume_reinforced");
                    String material = mbData.getString("str_material_required_reinforced");
                    String qtyInKg = mbData.getString("str_qty_kg_reinforced");
                    liftFromTextView.setText("Total qyt of M-15");
                    liftToTextView.setText(qtyInKg +" Qty(Kg)");
                }else if (soilId.equalsIgnoreCase("11")){
                    String qty = mbData.getString("str_qty_dewatering");
                    liftFromTextView.setText("De-watering by 5 HP Engine :");
                    liftToTextView.setText(qty +" Qrt(cum)");
                }else if (soilId.equalsIgnoreCase("12")){
                    String refillingQty = mbData.getString("str_total_qty_refilling");
                    String wellPortionQty = mbData.getString("str_total_qty_dwpt");
                    liftFromTextView.setText("Total Qty of well : "+refillingQty);
                    liftToTextView.setText("Deduct well portion : "+wellPortionQty);
                }else if (soilId.equalsIgnoreCase("13")){
                    String nos = mbData.getString("str_nos_name_plate");
                    String Qty = mbData.getString("str_qty_name_plate");
                    liftFromTextView.setText("Nos: "+nos);
                    liftToTextView.setText("Qty(cum): "+Qty);
                }else{
                    String liftFrom = "Lift From : "+mbData.getString("str_list_from");
                    liftFromTextView.setText(liftFrom);
                    String liftTo = "Lift To : "+mbData.getString("str_lift_to");
                    liftToTextView.setText(liftTo);
                }

                if (!img1Url.equalsIgnoreCase("")){
                    Picasso.get()
                            .load(img1Url)
                            .transform(transformation)
                            .resize(100, 100)
                            .centerCrop()
                            .into(mbStageImageView);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onMultiRecyclerViewItemClick(1, jsonObject);
                }
            });
        }
    }
}