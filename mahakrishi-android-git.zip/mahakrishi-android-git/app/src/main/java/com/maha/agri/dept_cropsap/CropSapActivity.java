package com.maha.agri.dept_cropsap;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.AppCompatRadioButton;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.history.DeptCropSapHistoryActivity;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.searchspinner.SearchableSpinner;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class CropSapActivity extends AppCompatActivity implements ApiCallbackCode {

    private SearchableSpinner sp_dept_cropsap_village,sp_dept_crop_pikache_gav;
    private TextView district_tv,taluka_tv;
    EditText et_gut_number,dept_cropsap_comment_edt,pikache_naav_edt;
    RadioButton dept_cropsap_kharif_rb,dept_cropsap_rabi_rb;
    ImageView dept_cropsap_photo;
    Button dept_cropsap_submit_btn,farmer_case_report_btn;
    JSONArray District_List;
    JSONArray Taluka_List;
    JSONArray Village_List;
    JSONArray Seasons_List;
    JSONArray Crops_Season_List;

    //spinner
    ArrayList<String> DistrictName;
    ArrayList<String> TalukaName;
    ArrayList<String> VillageName;
    ArrayList<String> SeasonCropName;
    ArrayList<String> DistricId;
    ArrayList<String> TalukaId;
    ArrayList<String> VillageId;
    String district_name,district_id,taluka_name,taluka_id,village_id="",village_name,season_name,crop_id="",crop_name,currentTime,imagePath,crop_condition="";
    String season_id="";
    HashMap<Integer,String> farmer_village_map = new HashMap<Integer, String>();
    HashMap<Integer,String> farmer_season_id_map = new HashMap<>();
    HashMap<Integer,String> farmer_crop_id_map = new HashMap<>();
    RadioGroup dept_cropsap_radio_group,crop_condition_rg;
    //Defining 5 buttons.
    int buttons = 2;
    AppCompatRadioButton[] rb = new AppCompatRadioButton[buttons];
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private Transformation transformation;
    private int responseID;

    private LinearLayout cropsap_pikache_gav_rl,dept_cropsap_crop_name_ll;

    private JSONArray village_list;
    private String data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_sap);
        getSupportActionBar().setTitle("CROPSAP");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(CropSapActivity.this);
        sharedPref = new SharedPref(CropSapActivity.this);

        initialization();
        get_district_taluka();
        data = AppSettings.getInstance().getValue(CropSapActivity.this, ApConstants.kLOGIN_DATA,"");
        try {
            JSONObject getVillageLocation = new JSONObject(data);
            village_list = getVillageLocation.getJSONArray("villages_location");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        VillageName = new ArrayList<>();
        final int numberOfItemsInResp = village_list.length();
        for (int j = 0; j < numberOfItemsInResp; j++) {
            JSONObject village_json_object = null;
            try {
                village_json_object = village_list.getJSONObject(j);
                village_id = village_json_object.getString("village_id");
                village_name = village_json_object.getString("village_name");
                VillageName.add(village_name);
                farmer_village_map.put(j, village_id);
                village_id = "";
                sp_dept_cropsap_village.setAdapter(new ArrayAdapter<String>(CropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName));
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }


        Seasons_Service();
        Crop_Season_Service();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.csr_history_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.history:
                Intent cropsap_history  = new Intent(CropSapActivity.this, DeptCropSapHistoryActivity.class);
                startActivity(cropsap_history);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void initialization() {
        district_tv = (TextView) findViewById(R.id.dept_cropsap_district_tv);
        taluka_tv = (TextView) findViewById(R.id.dept_cropsap_taluka_tv);
        sp_dept_cropsap_village = (SearchableSpinner) findViewById(R.id.sp_dept_cropsap_village);
        sp_dept_crop_pikache_gav = (SearchableSpinner) findViewById(R.id.sp_dept_cropsap_crop);

        et_gut_number = (EditText) findViewById(R.id.et_gut_number);
        dept_cropsap_comment_edt = (EditText)findViewById(R.id.dept_cropsap_comment_edt);
        pikache_naav_edt = (EditText)findViewById(R.id.pikache_naav_edt);

        dept_cropsap_kharif_rb = (RadioButton)findViewById(R.id.dept_cropsap_kharif_rb);
        dept_cropsap_rabi_rb = (RadioButton)findViewById(R.id.dept_cropsap_rabi_rb);
        dept_cropsap_kharif_rb.setChecked(false);
        dept_cropsap_rabi_rb.setChecked(false);

        dept_cropsap_photo = (ImageView)findViewById(R.id.dept_cropsap_photo);
        dept_cropsap_submit_btn = (Button)findViewById(R.id.dept_cropsap_submit_btn);
        //farmer_case_report_btn = (Button)findViewById(R.id.farmer_case_report_btn);

        cropsap_pikache_gav_rl = (LinearLayout)findViewById(R.id.sp_dept_cropsap_crop_ll);
        dept_cropsap_crop_name_ll = (LinearLayout)findViewById(R.id.dept_cropsap_crop_name_ll);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();


        dept_cropsap_radio_group = (RadioGroup)findViewById(R.id.dept_cropsap_radio_group);
        crop_condition_rg = (RadioGroup)findViewById(R.id.dept_cropsap_crop_condition_radio_group);

        SeasonCropName = new ArrayList<>();
        VillageId= new ArrayList<>();

        /*farmer_case_report_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent scheme_5 = new Intent(CropSapActivity.this, DepartmentCropSapVillageList.class);
                startActivity(scheme_5);
            }
        });
*/

        sp_dept_cropsap_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = farmer_village_map.get(sp_dept_cropsap_village.getSelectedItemPosition());

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_dept_crop_pikache_gav.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                crop_id = farmer_crop_id_map.get(sp_dept_crop_pikache_gav.getSelectedItemPosition());
                crop_name = sp_dept_crop_pikache_gav.getSelectedItem().toString();
                if(crop_name.startsWith("Other")){
                    dept_cropsap_crop_name_ll.setVisibility(View.VISIBLE);
                }else{
                    dept_cropsap_crop_name_ll.setVisibility(View.GONE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        dept_cropsap_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId) {

                    case R.id.dept_cropsap_kharif_rb:
                        dept_cropsap_kharif_rb.setChecked(true);
                        season_id = farmer_season_id_map.get(0);
                        cropsap_pikache_gav_rl.setVisibility(View.VISIBLE);
                        Crop_Season_Service();
                        SeasonCropName.clear();
                        break;

                    case R.id.dept_cropsap_rabi_rb:
                        dept_cropsap_rabi_rb.setChecked(true);
                        season_id = farmer_season_id_map.get(1);
                        cropsap_pikache_gav_rl.setVisibility(View.VISIBLE);
                        Crop_Season_Service();
                        SeasonCropName.clear();
                        break;


                }
            }
        });

        crop_condition_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch(checkedId)
                {


                    case R.id.dept_cropsap_crop_condition_very_good_rb:
                        int very_good = group.getCheckedRadioButtonId();
                        RadioButton dept_cropsap_crop_condition_very_good_rb =(RadioButton) findViewById(very_good);
                        crop_condition = dept_cropsap_crop_condition_very_good_rb.getText().toString();

                        break;

                    case R.id.dept_cropsap_crop_condition_normal_rb:
                        int normal = group.getCheckedRadioButtonId();
                        RadioButton dept_cropsap_crop_condition_normal_rb =(RadioButton) findViewById(normal);
                        crop_condition = dept_cropsap_crop_condition_normal_rb.getText().toString();
                        break;

                    case R.id.dept_cropsap_crop_condition_poor_rb:
                        int poor = group.getCheckedRadioButtonId();
                        RadioButton dept_cropsap_crop_condition_poor_rb =(RadioButton) findViewById(poor);
                        crop_condition = dept_cropsap_crop_condition_poor_rb.getText().toString();
                        break;

                }
            }
        });

        dept_cropsap_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cropsap_Save_Service();
            }
        });

        dept_cropsap_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(CropSapActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(CropSapActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(CropSapActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
                    takeImageFromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }

                }

            }
        });

    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile!=null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(dept_cropsap_photo.getWidth(), dept_cropsap_photo.getHeight())
                                .centerCrop()
                                .into(dept_cropsap_photo);

                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        else{
            Toast.makeText(CropSapActivity.this,"Please click cropsap photo",Toast.LENGTH_SHORT).show();
        }
    }


    private void uploadImageOnServer(String imagePath) {
        try {


            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id", String.valueOf(responseID));


            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);


            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.department_save_cropsap_image_url(partBody, params);
            api.postRequest(responseCall, this, 6);


            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void get_district_taluka(){
        JSONObject param = new JSONObject();
        try {
            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.department_login_get_district_taluka(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


   /* private void Village_Service(){
        JSONObject param = new JSONObject();
        try {
            param.put("taluka_id",taluka_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_village_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }*/

    private void Seasons_Service(){
        JSONObject param = new JSONObject();
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_seasons_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }

    private void Crop_Season_Service(){
        JSONObject param = new JSONObject();
        try {
            param.put("season_id",season_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.farmer_crop_season_url(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void Cropsap_Save_Service(){

        if(village_id.isEmpty()){
            Toast.makeText(CropSapActivity.this,"Village",Toast.LENGTH_SHORT).show();
        }else if(et_gut_number.getText().toString().trim().isEmpty()){
            Toast.makeText(CropSapActivity.this,"Enter survey number or gut number",Toast.LENGTH_SHORT).show();
        }else if(season_id.isEmpty()){
            Toast.makeText(CropSapActivity.this,"Select season",Toast.LENGTH_SHORT).show();
        }else if(crop_id.isEmpty()){
            Toast.makeText(CropSapActivity.this,"Select crop",Toast.LENGTH_SHORT).show();
        }else if(photoFile==null){
            Toast.makeText(CropSapActivity.this,"Capture Photo",Toast.LENGTH_SHORT).show();
        }else if(crop_condition.isEmpty()){
            Toast.makeText(CropSapActivity.this,"Select crop condition",Toast.LENGTH_SHORT).show();
        }else if(dept_cropsap_comment_edt.getText().toString().trim().isEmpty()){
            Toast.makeText(CropSapActivity.this,"Enter your comment ",Toast.LENGTH_SHORT).show();
        }else {


            JSONObject param = new JSONObject();
            try {
                param.put("district_id", district_id);
                param.put("taluka_id", taluka_id);
                param.put("village_id", village_id);
                param.put("survey_no", et_gut_number.getText().toString().trim());
                param.put("season_id", season_id);
                param.put("crop_id", crop_id);
                param.put("crop_name_ed", pikache_naav_edt.getText().toString().trim());
                param.put("crop_cond", crop_condition);
                param.put("comment", dept_cropsap_comment_edt.getText().toString().trim());
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.department_save_cropsap_details_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 5);

        }

    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                //district
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            District_List = jsonObject.getJSONArray("data");
                            for (int j = 0; j <= District_List.length(); j++) {
                                JSONObject district_json_object = District_List.getJSONObject(j);
                                district_name = district_json_object.getString("district_name");
                                taluka_name = district_json_object.getString("taluka_name");
                                district_id = district_json_object.getString("district_id");
                                taluka_id = district_json_object.getString("taluka_id");
                                district_tv.setText(district_name);
                                taluka_tv.setText(taluka_name);

                            }
                        }

                    }
                }
                else{

                }/*
                        //Village
                        if (i == 2) {

                            if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                ResponseModel responseModel = new ResponseModel(jsonObject);
                                if (responseModel.isStatus()) {
                                    Village_List = jsonObject.getJSONArray("data");
                                    AppSettings.getInstance().setValue(CropSapActivity.this, ApConstants.VILLAGE_LIST,Village_List.toString());
                                    final int numberOfItemsInResp = Village_List.length();
                                    for (int j = 0; j < numberOfItemsInResp; j++) {
                                        JSONObject district_json_object = Village_List.getJSONObject(j);
                                        village_id = district_json_object.getString("id");
                                        village_name = district_json_object.getString("village_name");
                                        VillageName.add(village_name);
                                        farmer_village_map.put(j, village_id);
                                    }

                                }

                                sp_dept_cropsap_village.setAdapter(new ArrayAdapter<String>(CropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, VillageName));
                            } else {
                                //UIToastMessage.show(this, jsonObject.getString("response"));
                            }
                        }else{

                        }*/

                            //seasons
                            if (i == 3) {

                                if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                                    ResponseModel responseModel = new ResponseModel(jsonObject);
                                    if (responseModel.isStatus()) {
                                        final Toast toast = Toast.makeText(CropSapActivity.this,responseModel.getMsg(),Toast.LENGTH_SHORT);

                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                toast.cancel();
                                            }
                                        }, 1000);
                                        Seasons_List = jsonObject.getJSONArray("data");
                                        //final int numberOfItemsInResp = Seasons_List.length();
                                        for (int j = 0; j < Seasons_List.length(); j++) {
                                            JSONObject season_json_object = Seasons_List.getJSONObject(j);
                                            season_id = season_json_object.getString("id");
                                            season_name = season_json_object.getString("name_mr");
                                            if(season_id.equalsIgnoreCase("1")){
                                                dept_cropsap_kharif_rb.setText(season_name);
                                            } else if(season_id.equalsIgnoreCase("2")){
                                                dept_cropsap_rabi_rb.setText(season_name);
                                            }
                                            farmer_season_id_map.put(j, season_id);
                                            season_id = "";

                                        }

                                    }
                                }
                            } else {
                            }

                //crop season
                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Crops_Season_List = jsonObject.getJSONArray("data");
                            final int numberOfItemsInResp = Crops_Season_List.length();
                            for (int j = 0; j < numberOfItemsInResp; j++) {
                                JSONObject crop_json_object = Crops_Season_List.getJSONObject(j);
                                crop_id = crop_json_object.getString("id");
                                crop_name = crop_json_object.getString("name");
                                SeasonCropName.add(crop_name);
                                farmer_crop_id_map.put(j, crop_id);
                                crop_id = "";

                            }

                        }

                        sp_dept_crop_pikache_gav.setAdapter(new ArrayAdapter<String>(CropSapActivity.this, android.R.layout.simple_spinner_dropdown_item, SeasonCropName));

                    }

                } else {
                }

                //Cropsap save
                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        responseID = jsonObject.getInt("data");
                        uploadImageOnServer(imagePath);
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("CROPSAP")
                                .setContentText("CropSap For Department Added Successfully")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();

                    } else {

                    }
                }

                //Cropsap save img
                if (i == 6) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {

                        dept_cropsap_photo.setImageResource(R.drawable.camera);
                    }
                } else {

                }

            }
            catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
