package com.maha.agri.model;

public class MBRecordingModel {
    private String name;
    private String level;
    private int img;

    public MBRecordingModel(String name, String level, int img) {
        this.name = name;
        this.level = level;
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
