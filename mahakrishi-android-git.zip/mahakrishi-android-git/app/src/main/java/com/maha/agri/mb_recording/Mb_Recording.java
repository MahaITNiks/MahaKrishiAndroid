package com.maha.agri.mb_recording;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppHelper;
import com.maha.agri.util.AppString;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class Mb_Recording extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener, OnMultiRecyclerItemClickListener {

    private PreferenceManager preferenceManager;
    private String farmerRegId;

    private LinearLayout stagesLayout;
    private RelativeLayout wellStageRLayout;
    private JSONArray stageListArray = new JSONArray();
    private RecyclerView mbSoilListDetailRView;
    private JSONArray mb_soil_list = new JSONArray();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mb_recording);

        init();
        defaultConfig();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void init() {
        preferenceManager = new PreferenceManager(Mb_Recording.this);
        farmerRegId = preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID);
        stagesLayout = (LinearLayout)findViewById(R.id.stagesLayout);
        wellStageRLayout = (RelativeLayout) findViewById(R.id.wellStageRLayout);
        mbSoilListDetailRView = (RecyclerView) findViewById(R.id.mbSoilListDetailRView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mbSoilListDetailRView.setLayoutManager(layoutManager);

        stageListArray = AppHelper.getInstance().getMbSoilStageList();

    }


    private void defaultConfig() {

        wellStageRLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stageListArray.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(stageListArray, 1, "Select Stage", "name", "id", Mb_Recording.this, Mb_Recording.this);
                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getSoilReportList();
    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        int id = Integer.valueOf(s1);
        switch (id) {
            case 1:
                Intent intent_1 = new Intent(Mb_Recording.this, SoilActivity.class);
                intent_1.putExtra("soilId", s1);
                intent_1.putExtra("soilName", s);
                intent_1.putExtra("soilData","");
                startActivity(intent_1);
                break;

            case 2:
                Intent intent_2 = new Intent(Mb_Recording.this, Soft_Murum_Activity.class);
                intent_2.putExtra("soilId", s1);
                intent_2.putExtra("soilName", s);
                intent_2.putExtra("soilData","");
                startActivity(intent_2);
                break;

            case 3:
                Intent intent_3 = new Intent(Mb_Recording.this, Hard_Murum_Activity.class);
                intent_3.putExtra("soilId", s1);
                intent_3.putExtra("soilName", s);
                intent_3.putExtra("soilData","");
                startActivity(intent_3);
                break;

            case 4:
                Intent intent_4 = new Intent(Mb_Recording.this, Hard_Man_Activity.class);
                intent_4.putExtra("soilId", s1);
                intent_4.putExtra("soilName", s);
                intent_4.putExtra("soilData","");
                startActivity(intent_4);
                break;

            case 5:
                Intent intent_5 = new Intent(Mb_Recording.this, Hard_Man_Boulder_Activity.class);
                intent_5.putExtra("soilId", s1);
                intent_5.putExtra("soilName", s);
                intent_5.putExtra("soilData","");
                startActivity(intent_5);
                break;

            case 6:
                Intent intent_6 = new Intent(Mb_Recording.this, Soft_Rock_Activity.class);
                intent_6.putExtra("soilId", s1);
                intent_6.putExtra("soilName", s);
                intent_6.putExtra("soilData","");
                startActivity(intent_6);
                break;

            case 7:
                Intent intent_7 = new Intent(Mb_Recording.this, Jamba_Activity.class);
                intent_7.putExtra("soilId", s1);
                intent_7.putExtra("soilName", s);
                intent_7.putExtra("soilData","");
                startActivity(intent_7);
                break;

            case 8:
                Intent intent_8 = new Intent(Mb_Recording.this, Hard_Rock_Activity.class);
                intent_8.putExtra("soilId", s1);
                intent_8.putExtra("soilName", s);
                intent_8.putExtra("soilData","");
                startActivity(intent_8);
                break;

            case 9:
                Intent intent_9 = new Intent(Mb_Recording.this, Plain_Cement_Concrete.class);
                intent_9.putExtra("soilId", s1);
                intent_9.putExtra("soilName", s);
                intent_9.putExtra("soilData","");
                startActivity(intent_9);
                break;

            case 10:
                Intent intent_10 = new Intent(Mb_Recording.this, Reinforced_Cement_Concrete_Activity.class);
                intent_10.putExtra("soilId", s1);
                intent_10.putExtra("soilName", s);
                intent_10.putExtra("soilData","");
                startActivity(intent_10);
                break;

            case 11:
                Intent intent_11 = new Intent(Mb_Recording.this, Dewatering_Activity.class);
                intent_11.putExtra("soilId", s1);
                intent_11.putExtra("soilName", s);
                intent_11.putExtra("soilData","");
                startActivity(intent_11);
                break;

            case 12:
                Intent intent_12 = new Intent(Mb_Recording.this, Refilling_Activity.class);
                intent_12.putExtra("soilId", s1);
                intent_12.putExtra("soilName", s);
                intent_12.putExtra("soilData","");
                startActivity(intent_12);
                break;

            case 13:
                Intent intent_13 = new Intent(Mb_Recording.this, Providing_Name_plate_Activity.class);
                intent_13.putExtra("soilId", s1);
                intent_13.putExtra("soilName", s);
                intent_13.putExtra("soilData","");
                startActivity(intent_13);
                break;
        }
    }

    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject soilJSON = (JSONObject)o;
        JSONObject mbData = null;
        try {
            mbData = soilJSON.getJSONObject("form_data");
            String soilId =  mbData.getString("soil_id");
            String soilName = mbData.getString("soil_name");

            int id = Integer.valueOf(soilId);
            switch (id) {
                case 1:
                    Intent intent_1 = new Intent(Mb_Recording.this, SoilActivity.class);
                    intent_1.putExtra("soilId", soilId);
                    intent_1.putExtra("soilName", soilName);
                    intent_1.putExtra("soilData",mbData.toString());
                    startActivity(intent_1);
                    break;

                case 2:
                    Intent intent_2 = new Intent(Mb_Recording.this, Soft_Murum_Activity.class);
                    intent_2.putExtra("soilId", soilId);
                    intent_2.putExtra("soilName", soilName);
                    intent_2.putExtra("soilData",mbData.toString());
                    startActivity(intent_2);
                    break;

                case 3:
                    Intent intent_3 = new Intent(Mb_Recording.this, Hard_Murum_Activity.class);
                    intent_3.putExtra("soilId", soilId);
                    intent_3.putExtra("soilName", soilName);
                    intent_3.putExtra("soilData",mbData.toString());
                    startActivity(intent_3);
                    break;

                case 4:
                    Intent intent_4 = new Intent(Mb_Recording.this, Hard_Man_Activity.class);
                    intent_4.putExtra("soilId", soilId);
                    intent_4.putExtra("soilName", soilName);
                    intent_4.putExtra("soilData",mbData.toString());
                    startActivity(intent_4);
                    break;

                case 5:
                    Intent intent_5 = new Intent(Mb_Recording.this, Hard_Man_Boulder_Activity.class);
                    intent_5.putExtra("soilId", soilId);
                    intent_5.putExtra("soilName", soilName);
                    intent_5.putExtra("soilData",mbData.toString());
                    startActivity(intent_5);
                    break;

                case 6:
                    Intent intent_6 = new Intent(Mb_Recording.this, Soft_Rock_Activity.class);
                    intent_6.putExtra("soilId", soilId);
                    intent_6.putExtra("soilName", soilName);
                    intent_6.putExtra("soilData",mbData.toString());
                    startActivity(intent_6);
                    break;

                case 7:
                    Intent intent_7 = new Intent(Mb_Recording.this, Jamba_Activity.class);
                    intent_7.putExtra("soilId", soilId);
                    intent_7.putExtra("soilName", soilName);
                    intent_7.putExtra("soilData",mbData.toString());
                    startActivity(intent_7);
                    break;

                case 8:
                    Intent intent_8 = new Intent(Mb_Recording.this, Hard_Rock_Activity.class);
                    intent_8.putExtra("soilId", soilId);
                    intent_8.putExtra("soilName", soilName);
                    intent_8.putExtra("soilData",mbData.toString());
                    startActivity(intent_8);
                    break;

                case 9:
                    Intent intent_9 = new Intent(Mb_Recording.this, Plain_Cement_Concrete.class);
                    intent_9.putExtra("soilId", soilId);
                    intent_9.putExtra("soilName", soilName);
                    intent_9.putExtra("soilData",mbData.toString());
                    startActivity(intent_9);
                    break;

                case 10:
                    Intent intent_10 = new Intent(Mb_Recording.this, Reinforced_Cement_Concrete_Activity.class);
                    intent_10.putExtra("soilId", soilId);
                    intent_10.putExtra("soilName", soilName);
                    intent_10.putExtra("soilData",mbData.toString());
                    startActivity(intent_10);
                    break;

                case 11:
                    Intent intent_11 = new Intent(Mb_Recording.this, Dewatering_Activity.class);
                    intent_11.putExtra("soilId", soilId);
                    intent_11.putExtra("soilName", soilName);
                    intent_11.putExtra("soilData",mbData.toString());
                    startActivity(intent_11);
                    break;

                case 12:
                    Intent intent_12 = new Intent(Mb_Recording.this, Refilling_Activity.class);
                    intent_12.putExtra("soilId", soilId);
                    intent_12.putExtra("soilName", soilName);
                    intent_12.putExtra("soilData",mbData.toString());
                    startActivity(intent_12);
                    break;

                case 13:
                    Intent intent_13 = new Intent(Mb_Recording.this, Providing_Name_plate_Activity.class);
                    intent_13.putExtra("soilId", soilId);
                    intent_13.putExtra("soilName", soilName);
                    intent_13.putExtra("soilData",mbData.toString());
                    startActivity(intent_13);
                    break;
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    private void getSoilReportList() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("farmer_reg_id", preferenceManager.getPreferenceValues(Preference_Constant.MB_RECORDING_FARMER_REG_ID));

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(jsonObject.toString());
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", new AppString(this).getkMSG_WAIT(), true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.mbSoilReportList(requestBody);

            DebugLog.getInstance().d("mb_soil_list=" + responseCall.request().toString());
            DebugLog.getInstance().d("mb_soil_list=" + AppUtility.getInstance().bodyToString(responseCall.request()));

            api.postRequest(responseCall, this, 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        AppSettings.getInstance().setValue(Mb_Recording.this, ApConstants.LIFT_TO_SOIL_ID, ApConstants.LIFT_TO_SOIL_ID);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {
                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        mb_soil_list = responseModel.getData();
                        MbSoilListAdapter mbSoilListAdapter = new MbSoilListAdapter(this, this, mb_soil_list);
                        mbSoilListDetailRView.setAdapter(mbSoilListAdapter);

                        JSONObject lastItemJSon = mb_soil_list.getJSONObject(mb_soil_list.length() - 1);
                        JSONObject dataJSON = lastItemJSon.getJSONObject("form_data");
                        String soilId = dataJSON.getString("soil_id");
                        int laval = dataJSON.getInt("stepID");
                        AppSettings.getInstance().setIntValue(this, ApConstants.MB_STAGE_LAVAL, laval);
                        if (!soilId.equalsIgnoreCase("9") && !soilId.equalsIgnoreCase("10")
                                && !soilId.equalsIgnoreCase("11") && !soilId.equalsIgnoreCase("12")
                                && !soilId.equalsIgnoreCase("13")) {
                            String str_lift_to_soil = dataJSON.getString("str_lift_to");
                            AppSettings.getInstance().setValue(this, ApConstants.LIFT_TO_SOIL_ID, str_lift_to_soil);
                            String str_qty_soil = dataJSON.getString("str_qty");
                            AppSettings.getInstance().setValue(this, ApConstants.QTY_SOIL_ID, str_qty_soil);
                        }

                        if (soilId.equalsIgnoreCase("13")){
                            stagesLayout.setVisibility(View.GONE);
                        }else {
                            stagesLayout.setVisibility(View.VISIBLE);
                        }
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


}
