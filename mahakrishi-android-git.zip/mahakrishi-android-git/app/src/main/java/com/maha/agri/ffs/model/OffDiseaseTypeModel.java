package com.maha.agri.ffs.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class OffDiseaseTypeModel {


    private int id;
    private String  name;
    private int crop_id;
    private String value;
    private int cropping_system;
    private int plot_obs;
    private int is_severity;

    private JSONObject jsonObject;

    public OffDiseaseTypeModel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    public int getId() {
        id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "id");
        return id;
    }

    public String getName() {
        name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject , "name");
        return name;
    }

    public int getCrop_id() {
        crop_id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "crop_id");
        return crop_id;
    }


    public String getValue() {
        value = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject , "value");
        return value;
    }

    public int getCropping_system() {
        cropping_system = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "cropping_system");
        return cropping_system;
    }

    public int getPlot_obs() {
        plot_obs = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "plot_obs");
        return plot_obs;
    }

    public int getIs_severity() {
        is_severity = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "is_severity");
        return is_severity;
    }
}
