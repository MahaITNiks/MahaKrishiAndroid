/*
 * Copyright (c) 2019. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 25/2/19 2:34 PM
 */

package com.maha.agri.activity.approve_attendance;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;


public class AdapterAprovUserList extends RecyclerView.Adapter<AdapterAprovUserList.ViewHolder> {


    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    private JSONArray mDataArray;
    String id;
    PreferenceManager preferenceManager;



    public AdapterAprovUserList(Context mContext, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray,PreferenceManager preferenceManager) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
        this.preferenceManager = preferenceManager;
    }


    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.recycler_aprov_user_list, parent, false);
        return new ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            holder.onBind(mDataArray.getJSONObject(position), listener);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView statusImageView;
        private TextView nameTextView;
        private TextView codeTextView;

        public ViewHolder(View itemView) {
            super(itemView);

            statusImageView = itemView.findViewById(R.id.statusImageView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            //codeTextView = itemView.findViewById(R.id.codeTextView);

        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            String fName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "first_name");
            String mName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "middle_name");
            String lName = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "last_name");
            String  isCompleted = AppUtility.getInstance().sanitizeJSONObj(jsonObject, "is_completed");
            //id = AppUtility.getInstance().sanitizeJSONObj(jsonObject,"id");
            final String name = fName + " " + mName + " " + lName;
            nameTextView.setText(name);
            codeTextView.setText(id);
            if(isCompleted.equalsIgnoreCase("1")){
                statusImageView.setImageResource(R.drawable.ic_done_green);
            }else {
                statusImageView.setImageResource(R.drawable.ic_close_red);
            }


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   Intent intent = new Intent(mContext,ApproveAttendActivity.class);
                   intent.putExtra("junior_id",id);
                   intent.putExtra("name",name);
                   mContext.startActivity(intent);
                }
            });


        }

    }

}
