/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_SocialCategoryDAO {

    @Query("SELECT * FROM M_Social_CategoryEY")
    List<M_Social_CategoryEY> getAll();

    @Query("SELECT * FROM M_Social_CategoryEY WHERE uid IN (:ids)")
    List<M_Social_CategoryEY> loadAllByIds(int[] ids);

    @Insert
    void insertAll(M_Social_CategoryEY... m_social_categoryEYS);

    @Insert
    void insertOnlySingle(M_Social_CategoryEY m_social_categoryEY);


}
