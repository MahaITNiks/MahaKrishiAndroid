package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class PipesActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private TextView pipes_obsdate, pipes_farmer_name, pipes_villagetv, pipes_talukatv, pipes_districttv, pipes_vargvari, pipes_pravarg, pipes_mobileno,
            pipes_gutno, pipes_8a, pipes_scheme, pipes_acceptletter, pipes_accepted_money, pipes_bab, pipes_length_app, pipes_purchase_date,
            pipes_delivery_date, pipes_billno_app,pipes_purchasedbab,pipes_payment_method;

    private EditText pipes_length_actual, pipes_seller_name, pipes_bis_letter, pipes_billno_actual, pipes_bill_amount, pipes_actual_bill_amount, pipes_subsidy_amount;

    private ImageView pipes_purchase_date_iv, pipes_delivery_date_iv, pipes_photo;

    private RadioGroup pipes_rg1, pipes_rg2, pipes_rg3;

    private RadioButton pipes_rg1_yes, pipes_rg1_no, pipes_rg2_yes, pipes_rg2_no, pipes_rg3_yes, pipes_rg3_no;

    private LinearLayout pipes_ll;
    private Button pipes_save;
    private CheckBox pipes_accept_terms;

    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String rg1 = "0", rg2 = "0", rg3 = "0", purchase_date, delivery_date, pipes_obs_date, pipes_length_str, seller_name_str, bis_letter_str, bill_no_actual_str,
            bill_amount_actual_str, bill_amount_str, subsidy_str,imageid_1,purchased_bab_str="",payment_str="";
    private JSONArray purchased_bab_list,pipes_payment_list;
    private DatePickerDialog purchasedatePickerDialog;
    private int mYear, mMonth, mDay,purchased_bab_id,payment_id;
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    static final Integer CAMERA = 0x5;
    String imagePath, currentTime;
    private Transformation transformation;

    private AppLocationManager locationManager;
    public double lat, lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pipes);
        getSupportActionBar().setTitle("Pipes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(PipesActivity.this);
        sharedPref = new SharedPref(PipesActivity.this);

        ids();
        functionality();
        //Purchased_bab_service();
        //Payment_method_service();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void ids() {
        //Textview
        pipes_obsdate = (TextView) findViewById(R.id.pipes_obsdate);
        pipes_farmer_name = (TextView) findViewById(R.id.pipes_farmer_name);
        pipes_villagetv = (TextView) findViewById(R.id.pipes_villagetv);
        pipes_talukatv = (TextView) findViewById(R.id.pipes_talukatv);
        pipes_districttv = (TextView) findViewById(R.id.pipes_districttv);
        pipes_vargvari = (TextView) findViewById(R.id.pipes_vargvari);
        pipes_pravarg = (TextView) findViewById(R.id.pipes_pravarg);
        pipes_mobileno = (TextView) findViewById(R.id.pipes_mobileno);
        pipes_8a = (TextView) findViewById(R.id.pipes_8a);
        pipes_scheme = (TextView) findViewById(R.id.pipes_scheme);
        pipes_acceptletter = (TextView) findViewById(R.id.pipes_acceptletter);
        pipes_accepted_money = (TextView) findViewById(R.id.pipes_accepted_money);
        pipes_bab = (TextView) findViewById(R.id.pipes_bab);
        pipes_purchasedbab = (TextView) findViewById(R.id.pipes_purchasedbab);
        pipes_length_app = (TextView) findViewById(R.id.pipes_length_app);
        pipes_purchase_date = (TextView) findViewById(R.id.pipes_purchase_date);
        pipes_delivery_date = (TextView) findViewById(R.id.pipes_delivery_date);
        pipes_billno_app = (TextView) findViewById(R.id.pipes_billno_app);
        pipes_payment_method = (TextView) findViewById(R.id.pipes_payment_method);
        //Edtittext
        pipes_length_actual = (EditText) findViewById(R.id.pipes_length_actual);
        pipes_seller_name = (EditText) findViewById(R.id.pipes_seller_name);
        pipes_bis_letter = (EditText) findViewById(R.id.pipes_bis_letter);
        pipes_billno_actual = (EditText) findViewById(R.id.pipes_billno_actual);
        pipes_bill_amount = (EditText) findViewById(R.id.pipes_bill_amount);
        pipes_actual_bill_amount = (EditText) findViewById(R.id.pipes_actual_bill_amount);
        pipes_subsidy_amount = (EditText) findViewById(R.id.pipes_subsidy_amount);
        //Imageview
        pipes_purchase_date_iv = (ImageView) findViewById(R.id.pipes_purchase_date_iv);
        pipes_delivery_date_iv = (ImageView) findViewById(R.id.pipes_delivery_date_iv);
        pipes_photo = (ImageView) findViewById(R.id.pipes_photo);
        //Radiogroup
        pipes_rg1 = (RadioGroup) findViewById(R.id.pipes_rg1);
        pipes_rg2 = (RadioGroup) findViewById(R.id.pipes_rg2);
        pipes_rg3 = (RadioGroup) findViewById(R.id.pipes_rg3);
        //Radiobutton
        pipes_rg1_yes = (RadioButton) findViewById(R.id.pipes_rg1_yes);
        pipes_rg1_no = (RadioButton) findViewById(R.id.pipes_rg1_no);
        pipes_rg2_yes = (RadioButton) findViewById(R.id.pipes_rg2_yes);
        pipes_rg2_no = (RadioButton) findViewById(R.id.pipes_rg2_no);
        pipes_rg3_yes = (RadioButton) findViewById(R.id.pipes_rg3_yes);
        pipes_rg3_no = (RadioButton) findViewById(R.id.pipes_rg3_no);
        pipes_ll = (LinearLayout) findViewById(R.id.pipes_hidden_ll);
        pipes_accept_terms = (CheckBox) findViewById(R.id.pipes_accept_terms);
        pipes_save = (Button) findViewById(R.id.pipes_save);

        pipes_obs_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        pipes_obsdate.setText(pipes_obs_date);

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();
        locationManager = new AppLocationManager(this);

        pipes_payment_list = new JSONArray();
        purchased_bab_list = new JSONArray();
    }

    private void functionality() {

        pipes_purchasedbab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (purchased_bab_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(purchased_bab_list, 1, "Select Scheme", "scheme_name", "id", PipesActivity.this, PipesActivity.this);
                }
            }
        });

        pipes_payment_method.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pipes_payment_list.length() > 0) {
                    AppUtility.getInstance().showListDialogIndex(pipes_payment_list, 2, "Select Scheme", "scheme_name", "id", PipesActivity.this, PipesActivity.this);
                }
            }
        });

        pipes_rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.pipes_rg1_yes:
                        pipes_rg1_yes.setChecked(true);
                        pipes_ll.setVisibility(View.VISIBLE);
                        rg1 = "1";
                        break;

                    case R.id.pipes_rg1_no:
                        pipes_rg1_no.setChecked(true);
                        pipes_ll.setVisibility(View.GONE);
                        rg1 = "2";
                        break;
                }
            }
        });

        pipes_rg2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.pipes_rg2_yes:
                        pipes_rg2_yes.setChecked(true);
                        rg2 = "1";
                        break;

                    case R.id.pipes_rg2_no:
                        pipes_rg2_no.setChecked(true);
                        rg2 = "2";
                        break;
                }
            }
        });

        pipes_rg3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch (i) {
                    case R.id.pipes_rg3_yes:
                        pipes_rg3_yes.setChecked(true);
                        rg3 = "1";
                        break;

                    case R.id.pipes_rg3_no:
                        pipes_rg3_no.setChecked(true);
                        rg3 = "2";
                        break;
                }
            }
        });

        pipes_purchase_date_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prucahse_date_picker();
            }
        });

        pipes_delivery_date_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delivery_date_picker();
            }
        });

        pipes_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((ContextCompat.checkSelfPermission(PipesActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(PipesActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(PipesActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(PipesActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    takeImage1FromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        pipes_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //pipes_save_service();
            }
        });
    }

    private void prucahse_date_picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        purchasedatePickerDialog = new DatePickerDialog(PipesActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        purchase_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        pipes_purchase_date.setText(purchase_date);
                    }
                }, mYear, mMonth, mDay);

        purchasedatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        purchasedatePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        purchasedatePickerDialog.show();
    }

    private void delivery_date_picker() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(c.getTime());
        //Disable 3 month before
        c.add(Calendar.DAY_OF_YEAR, -90);
        Date newDate = c.getTime();

        purchasedatePickerDialog = new DatePickerDialog(PipesActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        delivery_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        pipes_delivery_date.setText(delivery_date);
                    }
                }, mYear, mMonth, mDay);

        purchasedatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        purchasedatePickerDialog.getDatePicker().setMinDate(newDate.getTime());
        purchasedatePickerDialog.show();
    }

    private void Purchased_bab_service(){
        JSONObject param = new JSONObject();
        /*try {
            param.put("scheme_title_id",component_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_scheme_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void Payment_method_service(){
        JSONObject param = new JSONObject();
        /*try {
            param.put("scheme_title_id",component_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.phy_verf_scheme_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    private void takeImage1FromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
            } else {
                photoURI = Uri.fromFile(photoFile1);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1 = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if (photoFile1 != null) {

            if (photoFile1.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile1;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(pipes_photo.getWidth(), pipes_photo.getHeight())
                                .centerCrop()
                                .into(pipes_photo);
                        uploadImage1OnServer(imagePath);
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile1);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImage1OnServer(String imagePath) {
        try {

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("farmer_id", "1");
            params.put("village_id", "1");
            params.put("image_id", "1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mechanism_save_image(partBody, params);
            api.postRequest(responseCall, this, 3);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void pipes_save_service() {
        pipes_length_str = pipes_length_actual.getText().toString().trim();
        seller_name_str = pipes_seller_name.getText().toString().trim();
        bis_letter_str = pipes_bis_letter.getText().toString().trim();
        bill_no_actual_str = pipes_billno_actual.getText().toString().trim();
        bill_amount_str = pipes_bill_amount.getText().toString().trim();
        bill_amount_actual_str = pipes_actual_bill_amount.getText().toString().trim();
        subsidy_str = pipes_subsidy_amount.getText().toString().trim();
        if (pipes_length_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter पाइपची लांबी (मी.) - प्रत्यक्षात", Toast.LENGTH_LONG).show();
        } else if (seller_name_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter पुरवठादाराचे/ विक्रेत्याचे नाव", Toast.LENGTH_LONG).show();
        } else if (bis_letter_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter तपासणी अहवाल क्र./BIS प्रमाणपत्र", Toast.LENGTH_LONG).show();
        } else if (purchase_date.equalsIgnoreCase("0")) {
            Toast.makeText(PipesActivity.this, "Enter खरेदी दिनांक", Toast.LENGTH_LONG).show();
        } else if (delivery_date.equalsIgnoreCase("0")) {
            Toast.makeText(PipesActivity.this, "Enter प्रत्यक्ष प्राप्त (डिलिव्हरी)दिनांक", Toast.LENGTH_LONG).show();
        } else if (bill_no_actual_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter बील क्र. - प्रत्यक्षात", Toast.LENGTH_LONG).show();
        } else if (bill_amount_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter बीलानुसार खरेदीची रक्कम (₹)", Toast.LENGTH_LONG).show();
        } else if (bill_amount_actual_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter प्रत्यक्षात खरेदीची रक्कम (₹)", Toast.LENGTH_LONG).show();
        } else if (subsidy_str.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "Enter अनुदानासाठी शिफ़ारस केलेली रक्कम (₹)", Toast.LENGTH_LONG).show();
        } else if (rg1.equalsIgnoreCase("0")) {
            Toast.makeText(PipesActivity.this, "शेतकऱ्यांने खरेदी केलेल्या पाइपची रक्कम स्वतःच्या बँक खात्यातुन दिली आहे काय?", Toast.LENGTH_LONG).show();
        } else if (rg2.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "उत्पादक कंपनीने यंत्र/औजारावर परिक्षण अहवाल क्रमांक व मॉडेल क्रमांक कोरला आहे काय?", Toast.LENGTH_LONG).show();
        } else if (rg3.equalsIgnoreCase("")) {
            Toast.makeText(PipesActivity.this, "शेतकऱ्यांने खरेदी केलेली बाब पुर्वसंमती पत्रात नमुद केल्यानुसार आहे काय?", Toast.LENGTH_LONG).show();
        } else if (photoFile1 == null) {
            Toast.makeText(PipesActivity.this, "Click the photo", Toast.LENGTH_LONG).show();
        } else if (!pipes_accept_terms.isChecked()) {
            Toast.makeText(PipesActivity.this, "Accept the term", Toast.LENGTH_LONG).show();
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("pipe_obsdate", pipes_obs_date);
                param.put("farmer_id", "1");
                param.put("village_id", "1");
                param.put("taluka_id", "1");
                param.put("district_id", "1");
                param.put("vargvari", "1");
                param.put("parvarg", "1");
                param.put("mobile_no", "1");
                param.put("gut_no", "1");
                param.put("eight_a_form", "1");
                param.put("yojna", "1");
                param.put("accepted_letter", "1");
                param.put("accepted_amount", "1");
                param.put("bab", "1");
                param.put("purchased_bab", "1");
                param.put("pipe_length_app", "1");
                param.put("pipe_length_actual", pipes_length_str);
                param.put("seller_name", seller_name_str);
                param.put("bis_letter", bis_letter_str);
                param.put("purchase_date", purchase_date);
                param.put("delivery_date", delivery_date);
                param.put("bill_no_app", "1");
                param.put("bill_no_actual", bill_no_actual_str);
                param.put("bill_amt", bill_amount_str);
                param.put("bill_amt_actual", bill_amount_actual_str);
                param.put("subsidy_amt", subsidy_str);
                param.put("payment_method", "1");
                param.put("rg1", rg1);
                param.put("rg2", rg2);
                param.put("rg3", rg3);
                param.put("photo", imagePath);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SV_MECHANIZATION_BASE_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.spot_verification_drip_bill_against_id_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 4);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{

                if (i == 1) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            purchased_bab_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            pipes_payment_list = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 4) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("Submitted Successfully")
                                .setConfirmText("Ok")
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        finish();
                                    }
                                })
                                .show();
                    }
                }

                if (i == 3) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        JSONObject datajsonobject = jsonObject.getJSONObject("data");
                        imageid_1 = datajsonobject.getString("file_url");
                        //farmer_mech1ImageView.setImageResource(R.drawable.camera);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            purchased_bab_id = Integer.parseInt(s1);
            purchased_bab_str = s;
            pipes_purchasedbab.setText(purchased_bab_str);
        }

        if (i == 2) {
            payment_id = Integer.parseInt(s1);
            payment_str = s;
            pipes_payment_method.setText(payment_str);

        }
    }
}