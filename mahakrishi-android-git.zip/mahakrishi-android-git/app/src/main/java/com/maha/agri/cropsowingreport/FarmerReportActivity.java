package com.maha.agri.cropsowingreport;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.settings.AppSettings;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerReportActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    private PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private String horti_crop_id="",crop_type = "",crop_name = "",year_of_plantationstr,data,village_name="";
    private JSONArray CropNameList,farmer_list,village_list,Year_Of_Plantation,SchemeNamesJsonArray,district_list;
    ArrayList<String> VillageName;
    HashMap<Integer,String> village_map = new HashMap<Integer, String>();
    private TextView farmer_report_year_of_plantation_tv,farmer_wise_report_crop_list_tv,farmer_report_farmer_tv,sp_farmer_report_village_selection;
   // private SearchableSpinner sp_farmer_report_village_selection;
    private int crop_id=0;
    private int farmer_id=0;
    private int season_id=0;
    private int district_id_int = 0 ;
    private int taluka_id_int = 0;
    private int divison_id = 0,district_id = 0,taluka_id = 0,sajja_id = 0,village_id = 0;
    private int year_of_plantationsid=0;
    private String activityID = "";

    /*NEW */
    private JSONArray multiple_crop_area_year = new JSONArray();
    private RecyclerView fr_add_more_rv;
    private Button farmer_report_add_more_btn;
    private TextView farmer_report_zero_to_one_year_edt,farmer_report_one_to_three_year_edt,farmer_report_above_three_year_edt,farmer_report_total_edt,farmer_report_scheme_name_tv;
    private String zero_one_str = "", one_three_str = "", above_three_str = "", current_week="",last_week="",first_image_url="",image_name="";
    private int zero_one_int = 0,one_three_int = 0,above_three_int = 0,total_int = 0;
    private int scheme_id;
    private EditText farmer_report_survey_no_edt,farmer_report_mobile_no_edt,farmer_report_crop_variety,csr_far_other_crop_edt,farmerwise_farmer1,farmerwise_farmer2,
            farmerwise_farmer3;
    private ImageView farmer_crop_image;
    private Button dept_farmer_wise_report_submit_btn;
    private String scheme,imagePath,currentTime;
    private int crop_type_id,horti_type_id;
    private SweetAlertDialog sweetAlertDialog;

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;

    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile = null;
    private Transformation transformation;
    private LinearLayout csr_far_other_crop_ll;
    private AppLocationManager appLocationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_report);
        getSupportActionBar().setTitle("Farmer Wise Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerReportActivity.this);
        sharedPref = new SharedPref(FarmerReportActivity.this);
        activityID = AppSettings.getInstance().getValue(this, ApConstants.kSLED_ACTIVITY, ApConstants.kSLED_ACTIVITY);
        crop_type = preferenceManager.getPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_CROP_TYPE_ID);
        horti_crop_id = preferenceManager.getPreferenceValues(Preference_Constant.CROP_SOWING_REPORT_HORTI_ID);
        appLocationManager = new AppLocationManager(this);
        lat = appLocationManager.getLatitude();
        lang = appLocationManager.getLongitude();

        Intent intent = getIntent();
        divison_id = intent.getIntExtra("divison_id",0);
        district_id = intent.getIntExtra("district_id",0);
        taluka_id = intent.getIntExtra("taluka_id",0);
        sajja_id = intent.getIntExtra("sajja_id", 0);
        village_id = intent.getIntExtra("village_id",0);
        village_name = intent.getStringExtra("village_name");
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        current_week = intent.getStringExtra("current_week");
        last_week = intent.getStringExtra("last_week");
        district_id_int = Integer.valueOf(district_id);
        taluka_id_int = Integer.valueOf(taluka_id);
        init();
        default_confiq();
    }
    private void init(){
        CropNameList = new JSONArray();
        farmer_list = new JSONArray();
        Year_Of_Plantation= new JSONArray();
        SchemeNamesJsonArray = new JSONArray();

        farmer_wise_report_crop_list_tv = (TextView)findViewById(R.id.farmer_wise_report_crop_list_tv);
        sp_farmer_report_village_selection = (TextView) findViewById(R.id.sp_farmer_report_village_selection);
        sp_farmer_report_village_selection.setText(village_name);
        //farmer_report_farmer_tv = (TextView)findViewById(R.id.farmer_report_farmer_tv);
        data = AppSettings.getInstance().getValue(FarmerReportActivity.this, ApConstants.kLOGIN_DATA,"");

        farmer_report_year_of_plantation_tv=(TextView)findViewById(R.id.farmer_report_year_of_plantation_tv);
        farmer_report_zero_to_one_year_edt=(TextView)findViewById(R.id.farmer_report_zero_to_one_year_edt);
        farmer_report_one_to_three_year_edt=(TextView)findViewById(R.id.farmer_report_one_to_three_year_edt);
        farmer_report_above_three_year_edt=(TextView)findViewById(R.id.farmer_report_above_three_year_edt);
        farmer_report_total_edt=(TextView)findViewById(R.id.farmer_report_total_edt);
        farmer_report_total_edt.setEnabled(false);
        fr_add_more_rv = (RecyclerView) findViewById(R.id.fr_add_more_rv);
        farmer_report_add_more_btn = (Button) findViewById(R.id.farmer_report_add_more_btn);
        farmer_report_scheme_name_tv=(TextView)findViewById(R.id.farmer_report_scheme_name_tv);
        farmer_report_survey_no_edt=(EditText)findViewById(R.id.farmer_report_survey_no_edt);
        farmer_report_crop_variety=(EditText)findViewById(R.id.farmer_report_crop_variety);
        farmer_report_mobile_no_edt=(EditText)findViewById(R.id.farmer_report_mobile_no_edt);
        csr_far_other_crop_edt=(EditText)findViewById(R.id.csr_far_other_crop_edt);
        farmerwise_farmer1=(EditText)findViewById(R.id.farmerwise_farmer1);
        farmerwise_farmer2=(EditText)findViewById(R.id.farmerwise_farmer2);
        farmerwise_farmer3=(EditText)findViewById(R.id.farmerwise_farmer3);
        farmer_crop_image=(ImageView) findViewById(R.id.farmer_crop_image);
        csr_far_other_crop_ll = (LinearLayout)findViewById(R.id.csr_far_other_crop_ll);

        dept_farmer_wise_report_submit_btn=(Button)findViewById(R.id.dept_farmer_wise_report_submit_btn);

        crop_list(season_id,crop_type_id,horti_type_id);
        year_of_plantation();
        farmer_scheme_name();

        currentTime = ApUtil.getCurrentTimeStamp();

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(10)
                .oval(false)
                .build();

    }

    private void default_confiq(){

        farmer_report_year_of_plantation_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Year_Of_Plantation.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(Year_Of_Plantation, 1, "Select Year", "year", "id", FarmerReportActivity.this, FarmerReportActivity.this);
                }
                else{
                    year_of_plantation();
                }
            }
        });


        farmer_report_scheme_name_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SchemeNamesJsonArray.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(SchemeNamesJsonArray, 2, "Select Scheme", "scheme_name", "id", FarmerReportActivity.this, FarmerReportActivity.this);
                }
                else{
                    farmer_scheme_name();
                }
            }
        });


        /*sp_farmer_report_village_selection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                village_id = Integer.parseInt(village_map.get(sp_farmer_report_village_selection.getSelectedItemPosition()));
                village_name = sp_farmer_report_village_selection.getSelectedItem().toString();

                farmer_list_based_on_dtv(district_id_int, taluka_id_int, village_id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/


        /*farmer_report_farmer_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(village_id == 0){
                    Toast.makeText(FarmerReportActivity.this,"Select Village",Toast.LENGTH_SHORT).show();
                }else if (farmer_list.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(farmer_list, 3, "Select Farmer", "farmer_name", "id", FarmerReportActivity.this, FarmerReportActivity.this);
                }else {
                    farmer_list_based_on_dtv(district_id_int,taluka_id_int,village_id);
                }
            }
        });*/

        farmer_wise_report_crop_list_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* if(farmer_id == 0){
                    Toast.makeText(FarmerReportActivity.this,"Select Farmer",Toast.LENGTH_SHORT).show();
                }*/ if(farmerwise_farmer1.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's first name", Toast.LENGTH_SHORT).show();
                }else if(farmerwise_farmer2.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's middle name", Toast.LENGTH_SHORT).show();
                }else if(farmerwise_farmer3.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's last name", Toast.LENGTH_SHORT).show();
                } else if (CropNameList.length()>0) {
                    AppUtility.getInstance().showListDialogIndex(CropNameList, 4, "Select Crop", "crop_english", "id", FarmerReportActivity.this, FarmerReportActivity.this);
                }else{
                    crop_list(season_id,crop_type_id,horti_type_id);
                }
            }
        });

        /* ZERO TO ONE  */
        farmer_report_zero_to_one_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        /* ONE TWO THREE */
        farmer_report_one_to_three_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        /* ABOVE THREE */
        farmer_report_above_three_year_edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calculations();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        farmer_report_add_more_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(crop_id != 0 && !farmer_report_crop_variety.getText().toString().equalsIgnoreCase("") &&
                        !farmer_report_above_three_year_edt.getText().toString().equalsIgnoreCase("")
                        && !farmer_report_one_to_three_year_edt.getText().toString().equalsIgnoreCase("")
                        && !farmer_report_above_three_year_edt.getText().toString().equalsIgnoreCase("") && !(photoFile==null)){

                    if(crop_name.equalsIgnoreCase("OTHER")){
                        if(!csr_far_other_crop_edt.getText().toString().trim().equalsIgnoreCase("")){
                            crop_name = csr_far_other_crop_edt.getText().toString().trim();
                            uploadImageOnServer(imagePath);
                        }else {
                            final Toast toast = Toast.makeText(FarmerReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
                            toast.show();
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    toast.cancel();
                                }
                            }, 1000);
                        }

                    }else {
                        uploadImageOnServer(imagePath);
                    }
                }else{
                    final Toast toast = Toast.makeText(FarmerReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
                    toast.show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 1000);
                }
            }
        });

        farmer_crop_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((ContextCompat.checkSelfPermission(FarmerReportActivity.this, Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerReportActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerReportActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)&&(ContextCompat.checkSelfPermission(FarmerReportActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)){
                    takeImageFromCameraUri();
                } else{
                    String[] permissionRequest = {Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest,APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });

        dept_farmer_wise_report_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (year_of_plantationsid == 0) {
                    Toast.makeText(FarmerReportActivity.this, "Select Year of Plantation", Toast.LENGTH_SHORT).show();
                } else if (scheme_id == 0) {
                    Toast.makeText(FarmerReportActivity.this, "Select Scheme", Toast.LENGTH_SHORT).show();
                }/* else if (village_id == 0) {
                    Toast.makeText(FarmerReportActivity.this, "Select Village", Toast.LENGTH_SHORT).show();
                } else if (farmer_id == 0) {
                    Toast.makeText(FarmerReportActivity.this, "Select Farmer", Toast.LENGTH_SHORT).show();
                }*/ else if(farmerwise_farmer1.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's first name", Toast.LENGTH_SHORT).show();
                }else if(farmerwise_farmer2.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's middle name", Toast.LENGTH_SHORT).show();
                }else if(farmerwise_farmer3.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(FarmerReportActivity.this, "Enter farmer's last name", Toast.LENGTH_SHORT).show();
                }
                else if (farmer_report_survey_no_edt.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(FarmerReportActivity.this, "Enter Survey number", Toast.LENGTH_SHORT).show();
                } else if (farmer_report_mobile_no_edt.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(FarmerReportActivity.this, "Enter Mobile number", Toast.LENGTH_SHORT).show();
                } else if (multiple_crop_area_year.length() == 0) {
                    Toast.makeText(FarmerReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(FarmerReportActivity.this, GenerateFarmerWiseReportActivity.class);
                    intent.putExtra("divison_id",divison_id);
                    intent.putExtra("district_id", district_id);
                    intent.putExtra("taluka_id", taluka_id);
                    intent.putExtra("sajja_id", sajja_id);
                    intent.putExtra("village_id", village_id);
                    intent.putExtra("crop_type_id", crop_type_id);
                    intent.putExtra("horti_type_id", horti_type_id);
                    intent.putExtra("year_plt_id", year_of_plantationsid);
                    intent.putExtra("scheme_id", scheme_id);
                    //intent.putExtra("farmer_id", farmer_id);
                    intent.putExtra("farmer_first",farmerwise_farmer1.getText().toString().trim());
                    intent.putExtra("farmer_middle",farmerwise_farmer2.getText().toString().trim());
                    intent.putExtra("farmer_last",farmerwise_farmer3.getText().toString().trim());
                    intent.putExtra("survey_no", farmer_report_survey_no_edt.getText().toString());
                    intent.putExtra("mobile_number", farmer_report_mobile_no_edt.getText().toString());
                    intent.putExtra("multi_consolreport_data", multiple_crop_area_year.toString());
                    intent.putExtra("current_week",current_week);
                    intent.putExtra("last_week",last_week);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void calculations(){

        zero_one_str = farmer_report_zero_to_one_year_edt.getText().toString();
        if(zero_one_str.equals("")){
            zero_one_str="0";
        }
        one_three_str = farmer_report_one_to_three_year_edt.getText().toString();
        if(one_three_str.equals("")){
            one_three_str="0";
        }
        above_three_str=farmer_report_above_three_year_edt.getText().toString();
        if(above_three_str.equals("")){
            above_three_str="0";
        }
        if((zero_one_str.equals("")) && (one_three_str.equals("")) && (above_three_str.equals("")) ){
            zero_one_int=0;
            one_three_int=0;
            above_three_int=0;
            total_int=zero_one_int + one_three_int + above_three_int ;
            farmer_report_total_edt.setText(String.valueOf(total_int));
        }
        else if((!zero_one_str.equals("")) &&(one_three_str.equals("")) && (above_three_str.equals("")) ){
            zero_one_int=Integer.parseInt(zero_one_str);
            one_three_int=0;
            above_three_int=0;
            total_int=zero_one_int + one_three_int + above_three_int ;
            farmer_report_total_edt.setText(String.valueOf(total_int));
        }
        else if((zero_one_str.equals("")) &&(!one_three_str.equals("")) && (above_three_str.equals("")) ){
            zero_one_int=0;
            one_three_int=Integer.parseInt(one_three_str);
            above_three_int=0;
            total_int=zero_one_int + one_three_int + above_three_int ;
            farmer_report_total_edt.setText(String.valueOf(total_int));
        }
        else if((!zero_one_str.equals("")) &&(!one_three_str.equals("")) && (!above_three_str.equals("")) ){
            zero_one_int=Integer.parseInt(zero_one_str);
            one_three_int=Integer.parseInt(one_three_str);
            above_three_int=Integer.parseInt(above_three_str);
            total_int=zero_one_int + one_three_int + above_three_int ;
            farmer_report_total_edt.setText(String.valueOf(total_int));
        }
        else {
            zero_one_int=Integer.parseInt(zero_one_str);
            one_three_int=0;
            above_three_int=0;
            total_int=zero_one_int + one_three_int + above_three_int ;
            farmer_report_total_edt.setText(String.valueOf(total_int));
        }
    }

    private void add_multiple_area(int crop_id, String crop_name, String zero_one_year, String ont_three_year, String above_three_years, String total_area) {
        JSONObject add_multiple_area = new JSONObject();
        try{
            add_multiple_area.put("crop_sown_id", crop_id);
            add_multiple_area.put("crop_name", crop_name);
            add_multiple_area.put("area_zero_one_year", zero_one_year);
            add_multiple_area.put("area_one_three_year", ont_three_year);
            add_multiple_area.put("area_above_three_year", above_three_years);
            add_multiple_area.put("total_area",total_area);
            add_multiple_area.put("image_url",first_image_url);
            add_multiple_area.put("image_name",image_name);
            multiple_crop_area_year.put(add_multiple_area);

        }catch (Exception e){
            e.printStackTrace();
        }

        if(multiple_crop_area_year.length()>0){
            fr_add_more_rv.setLayoutManager(new LinearLayoutManager(FarmerReportActivity.this));
            CropSownFramerAddMoreAdapter cropSownFramerAddMoreAdapter = new CropSownFramerAddMoreAdapter(preferenceManager, multiple_crop_area_year, FarmerReportActivity.this);
            fr_add_more_rv.setAdapter(cropSownFramerAddMoreAdapter);
            cropSownFramerAddMoreAdapter.notifyDataSetChanged();
            farmer_wise_report_crop_list_tv.setText("Select");
            farmer_report_crop_variety.setText("");
            farmer_report_zero_to_one_year_edt.setText("");
            farmer_report_one_to_three_year_edt.setText("");
            farmer_report_above_three_year_edt.setText("");
            farmer_report_total_edt.setText("");
            csr_far_other_crop_ll.setVisibility(View.GONE);
            csr_far_other_crop_edt.setText("");
            photoFile = null;
            farmer_crop_image.setImageResource(R.drawable.camera);

        }else{
            final Toast toast = Toast.makeText(FarmerReportActivity.this, "Add data for atleast one crop", Toast.LENGTH_SHORT);
            toast.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            }, 1000);
        }

    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, preferenceManager.getPreferenceValues(Preference_Constant.USER_ID) +"_"+ System.currentTimeMillis() + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            onCameraActivityResult();
        }else{
            photoFile = null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

        if(photoFile!=null) {

            if (photoFile.exists()) {

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Picasso.get()
                                .load(imagePath)
                                .transform(transformation)
                                .resize(farmer_crop_image.getWidth(), farmer_crop_image.getHeight())
                                .centerCrop()
                                .into(farmer_crop_image);
                    }
                }, 0);

                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void uploadImageOnServer(String imagePath) {
        try {
            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("timestamp",currentTime);
            params.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("id",String.valueOf(crop_id));
            params.put("lat", String.valueOf(lat));
            params.put("long", String.valueOf(lang));
            params.put("district_id",String.valueOf(district_id));
            params.put("taluka_id",String.valueOf(taluka_id));
            params.put("village_id",String.valueOf(village_id));
            params.put("saja_id",String.valueOf(sajja_id));

            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();

            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.farmerwise_report_img_save(partBody, params);
            api.postRequest(responseCall, this, 5);

            DebugLog.getInstance().d("Profile_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("Profile_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void farmer_scheme_name() {
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_farmer_scheme_name();
        api.postRequest(responseCall, this, 2);
    }


    private void crop_list(int season_id,int crop_type_id, int horti_type_id){
        JSONObject param = new JSONObject();
        try {
            param.put("crop_activity_id", activityID);
            param.put("crop_season_id",season_id);
            param.put("crop_type",crop_type_id);
            param.put("horti_crop_type_id",horti_type_id);
            param.put("fieldsubmenu_id","");
            param.put("primary_report_id","");
            param.put("panchname_scheme_id","0");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.BASE_API, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.fetchMasterCrop(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 4);
    }

    private void year_of_plantation() {

        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.crop_sowing_report_farmer_year_of_plantation();
        api.postRequest(responseCall, this, 1);

    }

    private void farmer_list_based_on_dtv(int district_id,int taluka_id,int village_id){
        JSONObject param = new JSONObject();
        try {
            param.put("district_id",district_id);
            param.put("taluka_id",taluka_id);
            param.put("village_id",village_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.CROPSAP_NEW_BASE_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.dept_crop_sap_new_farmer_list(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 3);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if (jsonObject != null) {

            try {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            Year_Of_Plantation = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            SchemeNamesJsonArray = jsonObject.getJSONArray("data");
                        }
                    }
                }

                if(i == 3){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_list = jsonObject.getJSONArray("data");
                        }else {
                            Toast toast = Toast.makeText(getApplicationContext(), "Farmer list not found", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL, 0, 0);
                            toast.show();
                        }
                    }
                }

                if(i == 4){
                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            CropNameList = jsonObject.getJSONArray("data");
                        }
                    }else {
                        final Toast toast = Toast.makeText(FarmerReportActivity.this, "Crops not available", Toast.LENGTH_SHORT);
                        toast.show();
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                toast.cancel();
                            }
                        }, 1000);
                    }
                }

                if (i == 5) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            first_image_url = data.getString("file_url");
                            image_name = data.getString("file_name");
                            add_multiple_area(crop_id,crop_name,farmer_report_zero_to_one_year_edt.getText().toString().trim(),
                                    farmer_report_one_to_three_year_edt.getText().toString().trim(),farmer_report_above_three_year_edt.getText().toString().trim(),
                                    farmer_report_total_edt.getText().toString().trim());
                            crop_id = 0;
                        }
                    }
                }

        }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {
        if (i == 1) {
            year_of_plantationsid=Integer.parseInt(s1);
            year_of_plantationstr=s;
            farmer_report_year_of_plantation_tv.setText(year_of_plantationstr);
        }

        if (i == 2) {
            scheme_id=Integer.parseInt(s1);
            scheme=s;
            farmer_report_scheme_name_tv.setText(scheme);
        }

        if(i == 3){
            farmer_id = Integer.parseInt(s1);
            farmer_report_farmer_tv.setText(s);
        }

        if(i == 4){
            crop_id = Integer.parseInt(s1);
            crop_name=s;
            farmer_wise_report_crop_list_tv.setText(crop_name);
            /*if(multiple_crop_area_year.toString().contains(crop_name) == CropNameList.toString().contains(crop_name)){
                if(crop_name.contains("OTHER")){

                }else{
                    sweetAlertDialog = new SweetAlertDialog(FarmerReportActivity.this, SweetAlertDialog.WARNING_TYPE);
                    sweetAlertDialog.setContentText("Cannot add data for same crop again");
                    sweetAlertDialog.setConfirmText("OK");
                    sweetAlertDialog.setCanceledOnTouchOutside(false);
                    sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                            farmer_wise_report_crop_list_tv.setText("Select");
                        }
                    }).show();
                }
            }else{

            }*/

            if(crop_name.equalsIgnoreCase("OTHER")){
                csr_far_other_crop_ll.setVisibility(View.VISIBLE);
            }else {
                csr_far_other_crop_ll.setVisibility(View.GONE);
                csr_far_other_crop_edt.setText("");
            }

            farmer_report_zero_to_one_year_edt.setText("");
            farmer_report_one_to_three_year_edt.setText("");
            farmer_report_above_three_year_edt.setText("");
            farmer_report_total_edt.setText("");
            csr_far_other_crop_edt.setText("");
            farmer_report_crop_variety.setText("");
            photoFile = null;
            farmer_crop_image.setImageResource(R.drawable.camera);
        }

    }
}
