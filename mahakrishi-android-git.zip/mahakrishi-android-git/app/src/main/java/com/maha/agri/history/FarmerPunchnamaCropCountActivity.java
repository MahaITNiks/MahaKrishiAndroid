package com.maha.agri.history;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerPunchnamaCropCountActivity extends AppCompatActivity implements ApiCallbackCode{
        private RecyclerView farmer_punchnama_crop_list_count_rv;
        private JSONArray farmer_punchnama_crop_count_list;
        private PreferenceManager preferenceManager;
        SharedPref sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_punchnama_crop_count);

        getSupportActionBar().setTitle("नैसर्गिक आपत्तीमुळे झालेल्या पीक नुकसानीची माहिती द्या इतिहास");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(FarmerPunchnamaCropCountActivity.this);
        sharedPref = new SharedPref(FarmerPunchnamaCropCountActivity.this);

        IdCalling();

        if (isNetworkAvailable()){
            getFarmer_punchnama_crop_list_count();

        }else {

        }

    }

        private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

        private void IdCalling(){
        farmer_punchnama_crop_list_count_rv = (RecyclerView)findViewById(R.id.farmer_punchnama_crop_list_count_rv);
        farmer_punchnama_crop_list_count_rv.setLayoutManager(new GridLayoutManager(this,2));

    }

        private void getFarmer_punchnama_crop_list_count() {

        JSONObject param = new JSONObject();
        try{

            param.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));

        }catch (Exception e){

        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.farmer_panchnama_crop_list_with_count(requestBody);
        DebugLog.getInstance().d("absent_list_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("absent_list_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);

    }

        @Override
        public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            farmer_punchnama_crop_count_list = jsonObject.getJSONArray("data");
                            farmer_punchnama_crop_list_count_rv.setAdapter(new FarmerPunchnamaCountAdapter(preferenceManager,farmer_punchnama_crop_count_list,this));

                        }
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


        @Override
        public void onFailure(Object o, Throwable throwable, int i) {

    }

    }
