package com.maha.agri.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

public class SchemeListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> expandableListTitle;
    private JSONArray scheme_types_array_list;
    private HashMap<String, List<String>> expandableListDetail;

    public SchemeListAdapter(Context context, /*List<String> expandableListTitle*/JSONArray scheme_types_array_list,
                                       HashMap<String, List<String>> expandableListDetail) {
        this.context = context;
        this.scheme_types_array_list = scheme_types_array_list;
        this.expandableListDetail = expandableListDetail;
    }

    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        return listPosition;
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }


    @Override
    public int getChildrenCount(int listPosition) {
        return expandableListDetail.size();
    }

    @Override
    public Object getGroup(int listPosition) {
        return scheme_types_array_list.length();
    }

    @Override
    public int getGroupCount() {
        return scheme_types_array_list.length();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
       /* String listTitle = (String) getGroup(listPosition);*/
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.schemelist_group_single_item, null);
        }
        TextView listTitleTextView = (TextView) convertView
                .findViewById(R.id.listTitle);
        listTitleTextView.setTypeface(null, Typeface.BOLD);
        try {
            JSONObject jsonObject = scheme_types_array_list.getJSONObject(listPosition);
            listTitleTextView.setText(jsonObject.getString("name"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        return null;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }
}
