package com.maha.agri.cropsowingreport;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

public class CropSownAddMoreAdapter extends RecyclerView.Adapter<CropSownAddMoreAdapter.MyViewHolder> {
private JSONArray add_more_list;
//private JSONArray add_more_list_replica;
private JSONObject jsonObject;
//private JSONObject add_more_list_replica_json_object;
private Context context;
private PreferenceManager preferencemanager;
HashMap<Integer,String> crop_map = new HashMap<Integer, String>();


public static class MyViewHolder extends RecyclerView.ViewHolder {
    private TextView cropname_tv,sown_area_tv,last_year_sown_area_tv,natural_sown_area_tv;
    private ImageView sowing_report_row_delete_iv;

    public MyViewHolder(View itemView) {
        super(itemView);
        this.cropname_tv = itemView.findViewById(R.id.cropname_tv);
        this.sown_area_tv = itemView.findViewById(R.id.sown_area_tv);
        this.natural_sown_area_tv = itemView.findViewById(R.id.natural_sown_area_tv);
        //this.last_year_sown_area_tv = itemView.findViewById(R.id.last_year_sown_area_tv);
        this.sowing_report_row_delete_iv = itemView.findViewById(R.id.sowing_report_row_delete_iv);

    }
}

    public CropSownAddMoreAdapter(PreferenceManager preferenceManager, JSONArray add_more_list/*,JSONArray add_more_list_replica*/, Context context) {
        this.preferencemanager = preferenceManager;
        this.add_more_list = add_more_list;
        //this.add_more_list_replica = add_more_list_replica;
        this.context = context;

    }

    @Override
    public CropSownAddMoreAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sowing_report_single_item, parent, false);

        CropSownAddMoreAdapter.MyViewHolder myViewHolder = new CropSownAddMoreAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final CropSownAddMoreAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = add_more_list.getJSONObject(listPosition);
            holder.cropname_tv.setText(jsonObject.getString("crop_sown_name"));
            holder.sown_area_tv.setText(jsonObject.getString("area_last_week"));
            holder.natural_sown_area_tv.setText(jsonObject.getString("area_current_week"));
            holder.sowing_report_row_delete_iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    add_more_list.remove(listPosition);
                    notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

public interface ClickListener {
    void onClick(View view, int position);

    void onLongClick(View view, int position);
}

public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

    private GestureDetector gestureDetector;
    private CropSownAddMoreAdapter.ClickListener clickListener;

    public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final CropSownAddMoreAdapter.ClickListener clickListener) {
        this.clickListener = clickListener;
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                if (child != null && clickListener != null) {
                    clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                }
            }
        });
    }

    @Override
    public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

        View child = rv.findChildViewUnder(e.getX(), e.getY());
        if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
            clickListener.onClick(child, rv.getChildPosition(child));
        }
        return false;
    }

    @Override
    public void onTouchEvent(RecyclerView rv, MotionEvent e) {
    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }
}
}
