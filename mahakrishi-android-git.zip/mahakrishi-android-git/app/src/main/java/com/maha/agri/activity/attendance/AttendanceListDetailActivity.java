package com.maha.agri.activity.attendance;

import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.model.AttendDetailModel;
import com.maha.agri.model.LoginDetailModel;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import in.co.appinventor.services_api.settings.AppSettings;

public class AttendanceListDetailActivity extends AppCompatActivity {

    private Transformation transformation;

    private TextView fNameTView;
    private TextView mNameTView;
    private TextView lNameTView;
    private TextView mobileTView;
    private TextView genderTView;
    private TextView inTimeTView;
    private TextView outTimeTView;
    private TextView totHourTView;
    private TextView inAddressTView;
    private TextView outAddressTView;
    private TextView juriAreaTView;
    private TextView reasonTView;
    private ImageView in_image_view;
    private ImageView out_image_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_list_detail);
        getSupportActionBar().setTitle("Attendance Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();
        defaultConfig();
    }


    private void init() {

        fNameTView = (TextView)findViewById(R.id.fNameTView);
        mNameTView = (TextView)findViewById(R.id.mNameTView);
        lNameTView = (TextView)findViewById(R.id.lNameTView);
        mobileTView = (TextView)findViewById(R.id.mobileTView);
        genderTView = (TextView)findViewById(R.id.genderTView);
        inTimeTView = (TextView)findViewById(R.id.inTimeTView);
        outTimeTView = (TextView)findViewById(R.id.outTimeTView);
        totHourTView = (TextView)findViewById(R.id.totHourTView);
        inAddressTView = (TextView)findViewById(R.id.inAddressTView);
        outAddressTView = (TextView)findViewById(R.id.outAddressTView);
        juriAreaTView = (TextView)findViewById(R.id.juriAreaTView);
        reasonTView = (TextView)findViewById(R.id.reasonTView);
        in_image_view = (ImageView)findViewById(R.id.in_image_view);
        out_image_view = (ImageView)findViewById(R.id.out_image_view);
    }




    private void defaultConfig() {

        transformation = new RoundedTransformationBuilder()
                .borderColor(getResources().getColor(R.color.colorPrimaryDark))
                .borderWidthDp(1)
                .cornerRadiusDp(40)
                .oval(false)
                .build();
    }

    @Override
    protected void onResume() {
        super.onResume();

        String attendDetail = getIntent().getStringExtra("data");
        String userData = AppSettings.getInstance().getValue(this, ApConstants.kLOGIN_DATA,ApConstants.kLOGIN_DATA);
        try {
            JSONObject userJSON = null;
            if (!userData.equalsIgnoreCase("kLOGIN_DATA")){
                userJSON = new JSONObject(userData);
            }
            JSONObject attendJSON = new JSONObject(attendDetail);
            setAttendDetail(attendJSON, userJSON);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    private void setAttendDetail(JSONObject attendJSON, JSONObject userJSON) {
        if (attendJSON != null && userJSON != null){

            Geocoder geocoder = new Geocoder(AttendanceListDetailActivity.this, Locale.getDefault());
            LoginDetailModel lDModel = new LoginDetailModel(userJSON);

            fNameTView.setText(lDModel.getFirst_name());
            mNameTView.setText(lDModel.getMiddle_name());
            lNameTView.setText(lDModel.getLast_name());
            mobileTView.setText(lDModel.getMobile());


            JSONArray juriArea = lDModel.getWork_location();
            if (juriArea != null  && juriArea.length()> 0){
                try {
                    String area = juriArea.getJSONObject(0).getString("work_location_name");
                    juriAreaTView.setText(area);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                /*JSONArray aArea = new JSONArray();
                for (int i = 0; i<juriArea.length(); i++){
                    try {
                        JSONObject object = juriArea.getJSONObject(i);
                        double latitude = Double.valueOf( object.getString("lat_loc"));
                        double longitude =  Double.valueOf(object.getString("long_loc"));

                        List<Address> addresses = null;
                        try {
                            addresses = (List<Address>) geocoder.getFromLocation(latitude, longitude, 1);
                            if (addresses != null){
                                String area = addresses.get(0).getLocality();
                                // String complete_address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                                aArea.put(new JSONObject().put("area",area));
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

                if (aArea.length()>0){
                    juriAreaTView.setText(ApUtil.componentSeparatedByCommaJSONArray(aArea,"area"));
                }*/

            }


            // genderTView.setText(lDModel.ge);   // TODO

            AttendDetailModel aDModel = new AttendDetailModel(attendJSON);
            inTimeTView.setText(ApUtil.getTimeByTimeStamp(aDModel.getIn_report_time()));
            outTimeTView.setText(ApUtil.getTimeByTimeStamp(aDModel.getOut_time()));
            totHourTView.setText(aDModel.getHours());

            // For in Address
            double inLat = Double.valueOf(aDModel.getIn_lat());
            double inlong = Double.valueOf(aDModel.getIn_long());
            List<Address> inAddresses = null;
            try {
                inAddresses = (List<Address>) geocoder.getFromLocation(inLat, inlong, 1);
                if (inAddresses != null){
                    String in_address = inAddresses.get(0).getAddressLine(0);
                    inAddressTView.setText(in_address);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // For out Address
            double outLat = Double.valueOf(aDModel.getOut_lat());
            double outLong = Double.valueOf(aDModel.getOut_long());
            List<Address> outAddresses = null;
            try {
                outAddresses = (List<Address>) geocoder.getFromLocation(outLat, outLong, 1);
                if (outAddresses != null){
                    String out_address = outAddresses.get(0).getAddressLine(0);
                    outAddressTView.setText(out_address);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }


           reasonTView.setText(aDModel.getAbsent_reason_name());

            // For in image
            String inImageUrl = aDModel.getIn_file_name();
            if (!inImageUrl.isEmpty()) {
                Picasso.get()
                        .load(Uri.parse(inImageUrl))
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .placeholder(R.drawable.person)
                        .into(in_image_view);

            }

            // For out image
            String outImageUrl = aDModel.getOut_file_name();

            if (!outImageUrl.isEmpty()) {
                Picasso.get()
                        .load(Uri.parse(outImageUrl))
                        .transform(transformation)
                        .resize(150, 150)
                        .centerCrop()
                        .placeholder(R.drawable.person)
                        .into(out_image_view);

            }

        }
    }
}
