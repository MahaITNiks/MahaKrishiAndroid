package com.maha.agri.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerDashboardAdapter extends RecyclerView.Adapter<FarmerDashboardAdapter.MyViewHolder> {
    private JSONArray farmer_dashboard_array_list;
    private int[] farmer_dashboard_background;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView farmer_dashboard_single_background;
        private TextView farmer_dashboard_single_title;
        private RelativeLayout farmer_dashboard_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.farmer_dashboard_single_background = itemView.findViewById(R.id.farmer_dashboard_back_single_image_view);
            this.farmer_dashboard_single_title = itemView.findViewById(R.id.farmer_dashboard_single_text_view);
            this.farmer_dashboard_single_item_rl = itemView.findViewById(R.id.farmer_dashboard_single_item_rl);

        }
    }

    public FarmerDashboardAdapter(PreferenceManager preferenceManager, JSONArray farmer_dashboard_array_list, int[] farmer_dashboard_background, Context context) {
        this.preferencemanager = preferenceManager;
        this.farmer_dashboard_array_list = farmer_dashboard_array_list;
        this.farmer_dashboard_background = farmer_dashboard_background;
        this.context = context;

    }

    @Override
    public FarmerDashboardAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.farmer_dashboard_single_item, parent, false);

        FarmerDashboardAdapter.MyViewHolder myViewHolder = new FarmerDashboardAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final FarmerDashboardAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = farmer_dashboard_array_list.getJSONObject(listPosition);

           //holder.farmer_dashboard_single_item_rl.setTag(listPosition);

           /* holder.farmer_dashboard_single_item_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        String id = farmer_dashboard_array_list.getJSONObject(index).getString("id");

                        if (id.equalsIgnoreCase("1")) {
                            Intent scheme = new Intent(context, FarmerCropSapActivity.class);
                            context.startActivity(scheme);
                        }
                        if (id.equalsIgnoreCase("2")) {
                            Intent scheme = new Intent(context, FarmerPunchnamaActivity.class);
                            context.startActivity(scheme);
                        }


                        if (id.equalsIgnoreCase("4")) {

                        }
                        preferencemanager.putPreferenceValues(Preference_Constant.FARMER_DASHBOARD_ID, id);
                       *//* *//*
                    } catch (JSONException e) {
                        e.printStackTrace();

                    }

                }
            });*/

                holder.farmer_dashboard_single_title.setText(jsonObject.getString("name_mr"));
                holder.farmer_dashboard_single_background.setImageResource(farmer_dashboard_background[listPosition]);


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (farmer_dashboard_array_list != null) {
            return farmer_dashboard_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private FarmerDashboardAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final FarmerDashboardAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
