package com.maha.agri.spot_verification;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class OnionStorageFirstPhysicalActivity2 extends AppCompatActivity implements ApiCallbackCode {

    private EditText onion_str1_p2_money_used,onion_str1_p2_cal1,onion_str_p2_bill1,onion_str_p2_bill2,onion_str_p2_bill3,onion_str_p2_bill4,onion_str_p2_bill5,
            onion_str_p2_bill6,onion_str_p2_bill7,onion_str_p2_bill8,onion_str_p2_bill9,onion_str_p2_bill10,onion_str_p2_dar1,onion_str_p2_dar2,onion_str_p2_dar3,
            onion_str_p2_dar4,onion_str_p2_dar5,onion_str_p2_dar6,onion_str_p2_dar7,onion_str_p2_dar8,onion_str_p2_dar9,onion_str_p2_dar10,onion_str_p2_amt1,
            onion_str_p2_amt2,onion_str_p2_amt3,onion_str_p2_amt4,onion_str_p2_amt5,onion_str_p2_amt6,onion_str_p2_amt7,onion_str_p2_amt8,onion_str_p2_amt9,
            onion_str_p2_amt10;
    private TextView onion_str1_p2_cal2,onion_str1_p2_cal3,onion_str1_p2_capacity,onion_str_p2_exp1,onion_str_p2_exp2,onion_str_p2_exp3,onion_str_p2_exp4,
            onion_str_p2_exp5,onion_str_p2_exp6,onion_str_p2_exp7,onion_str_p2_exp8,onion_str_p2_exp9,onion_str_p2_exp10;
    private CheckBox onion_str1_p2_checkbox;
    private Button onion_str1_p2_save;
    private String capacity="";
    private PreferenceManager preferenceManager;
    private SweetAlertDialog sweetAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onion_storage_first_physical2);
        getSupportActionBar().setTitle("Onion Storage Structure First Form 2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(OnionStorageFirstPhysicalActivity2.this);
        Intent intent = getIntent();
        capacity = intent.getStringExtra("capacity");

        ids();
        functions();
        pre_setdata();
    }

    private void ids(){
        onion_str1_p2_money_used = (EditText) findViewById(R.id.onion_str1_p2_money_used);
        onion_str1_p2_cal1 = (EditText) findViewById(R.id.onion_str1_p2_cal1);

        onion_str1_p2_cal2 = (TextView) findViewById(R.id.onion_str1_p2_cal2);
        onion_str1_p2_cal3 = (TextView) findViewById(R.id.onion_str1_p2_cal3);
        onion_str1_p2_capacity = (TextView) findViewById(R.id.onion_str1_p2_capacity);
        onion_str_p2_exp1 = (TextView) findViewById(R.id.onion_str_p2_exp1);
        onion_str_p2_exp2 = (TextView) findViewById(R.id.onion_str_p2_exp2);
        onion_str_p2_exp3 = (TextView) findViewById(R.id.onion_str_p2_exp3);
        onion_str_p2_exp4 = (TextView) findViewById(R.id.onion_str_p2_exp4);
        onion_str_p2_exp5 = (TextView) findViewById(R.id.onion_str_p2_exp5);
        onion_str_p2_exp6 = (TextView) findViewById(R.id.onion_str_p2_exp6);
        onion_str_p2_exp7 = (TextView) findViewById(R.id.onion_str_p2_exp7);
        onion_str_p2_exp8 = (TextView) findViewById(R.id.onion_str_p2_exp8);
        onion_str_p2_exp9 = (TextView) findViewById(R.id.onion_str_p2_exp9);
        onion_str_p2_exp10 = (TextView) findViewById(R.id.onion_str_p2_exp10);

        onion_str1_p2_checkbox = (CheckBox) findViewById(R.id.onion_str1_p2_checkbox);
        onion_str1_p2_save = (Button) findViewById(R.id.onion_str1_p2_save);
    }

    private void functions(){
        onion_str1_p2_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //onion_str1_part2_save_service();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void pre_setdata(){
        if(capacity.equalsIgnoreCase("5 मे. टन")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("6.48");
            onion_str_p2_exp2.setText("0.972");
            onion_str_p2_exp3.setText("0.864");
            onion_str_p2_exp4.setText("0.423");
            onion_str_p2_exp5.setText("60");
            onion_str_p2_exp6.setText("160");
            onion_str_p2_exp7.setText("16");
            onion_str_p2_exp8.setText("04");
            onion_str_p2_exp9.setText("300");
        }else if(capacity.equalsIgnoreCase("10 मे. टन")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("12.96");
            onion_str_p2_exp2.setText("1.944");
            onion_str_p2_exp3.setText("1.728");
            onion_str_p2_exp4.setText("0.846");
            onion_str_p2_exp5.setText("120");
            onion_str_p2_exp6.setText("320");
            onion_str_p2_exp7.setText("32");
            onion_str_p2_exp8.setText("08");
            onion_str_p2_exp9.setText("600");
        }else if(capacity.equalsIgnoreCase("15 मे. टन")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("19.44");
            onion_str_p2_exp2.setText("2.916");
            onion_str_p2_exp3.setText("2.592");
            onion_str_p2_exp4.setText("1.270");
            onion_str_p2_exp5.setText("180");
            onion_str_p2_exp6.setText("480");
            onion_str_p2_exp7.setText("48");
            onion_str_p2_exp8.setText("12");
            onion_str_p2_exp9.setText("900");
        }else if(capacity.equalsIgnoreCase("20 मे. टन")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("22.68");
            onion_str_p2_exp2.setText("3.402");
            onion_str_p2_exp3.setText("3.024");
            onion_str_p2_exp4.setText("1.481");
            onion_str_p2_exp5.setText("240");
            onion_str_p2_exp6.setText("640");
            onion_str_p2_exp7.setText("64");
            onion_str_p2_exp8.setText("16");
            onion_str_p2_exp9.setText("1200");
        }else if(capacity.equalsIgnoreCase("25 मे. टन")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("29.16");
            onion_str_p2_exp2.setText("4.374");
            onion_str_p2_exp3.setText("3.888");
            onion_str_p2_exp4.setText("1.904");
            onion_str_p2_exp5.setText("300");
            onion_str_p2_exp6.setText("800");
            onion_str_p2_exp7.setText("80");
            onion_str_p2_exp8.setText("20");
            onion_str_p2_exp9.setText("1500");
        }else if (capacity.equalsIgnoreCase("Select")){
            onion_str1_p2_capacity.setText(capacity);
            onion_str_p2_exp1.setText("");
            onion_str_p2_exp2.setText("");
            onion_str_p2_exp3.setText("");
            onion_str_p2_exp4.setText("");
            onion_str_p2_exp5.setText("");
            onion_str_p2_exp6.setText("");
            onion_str_p2_exp7.setText("");
            onion_str_p2_exp8.setText("");
            onion_str_p2_exp9.setText("");
        }
    }

    private void onion_str1_part2_save_service(){
        if(onion_str1_p2_money_used.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter उपरोक्त तक्त्याप्रमाणे वापरण्यात आलेल्या साहित्य ब मजुरीची एकुण किंमत (प्रत्यक्ष खर्च)", Toast.LENGTH_SHORT).show();
        }else if(onion_str1_p2_cal1.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter मार्गदर्शक सुचनेनुसार प्रति मे.टन रु.७७०००/- प्रमाणे ग्राहय खर्च मर्यादा", Toast.LENGTH_SHORT).show();
        }else if(!onion_str1_p2_checkbox.isChecked()){
            Toast.makeText(getApplicationContext(), "Accept the terms", Toast.LENGTH_SHORT).show();
        }else{
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("money_used", onion_str1_p2_money_used.getText().toString().trim());
                param.put("cal1", onion_str1_p2_cal1.getText().toString().trim());
                param.put("cal2", onion_str1_p2_cal2);
                param.put("cal3", onion_str1_p2_cal3);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mb_community_pond_9_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Onion Storage Structure");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    /*Intent intent = new Intent(GreenHouseActivity.this,GIPipesActivity.class);
                                    startActivity(intent);*/
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
