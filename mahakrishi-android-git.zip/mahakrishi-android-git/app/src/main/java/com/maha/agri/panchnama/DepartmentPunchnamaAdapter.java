package com.maha.agri.panchnama;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;

import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DepartmentPunchnamaAdapter extends RecyclerView.Adapter<DepartmentPunchnamaAdapter.MyViewHolder> {
    private JSONArray farmer_claim_array_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView dept_punchnama_farmer_name_tv;
        private RelativeLayout dept_punchnama_farmer_single_item_rl;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.dept_punchnama_farmer_name_tv = itemView.findViewById(R.id.dept_punchnama_farmer_name_tv);
            this.dept_punchnama_farmer_single_item_rl = itemView.findViewById(R.id.dept_punchnama_farmer_single_item_rl);

        }
    }

    public DepartmentPunchnamaAdapter(JSONArray farmer_claim_array_list, Context context) {
        this.farmer_claim_array_list = farmer_claim_array_list;
        this.context = context;

    }

    @Override
    public DepartmentPunchnamaAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dept_punchanam_farmer_list_single_item, parent, false);

        DepartmentPunchnamaAdapter.MyViewHolder myViewHolder = new DepartmentPunchnamaAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final DepartmentPunchnamaAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = farmer_claim_array_list.getJSONObject(listPosition);

                holder.dept_punchnama_farmer_name_tv.setText(jsonObject.getString("farmer_name"));


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (farmer_claim_array_list != null) {
            return farmer_claim_array_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private DepartmentPunchnamaAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final DepartmentPunchnamaAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
