package com.maha.agri.spot_verification;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class MechanizationMIDHActivity extends AppCompatActivity implements ApiCallbackCode, AlertListEventListener {
    
    private TextView mech_midh_obsdatetv,mech_midh_farmer_nametv,mech_midh_villagetv,mech_midh_talukatv,mech_midh_districttv,mech_midh_proposed_toolname,
            mech_midh_proposed_trachp;
    
    private EditText mech_midh_actual_toolname,mech_midh_actual_trachp,mech_midh_total_rupees_et;
    private ImageView mech_midh_obsdateiv,mech_midh_license_photo;
    private LinearLayout mech_midh_license_ll;
    private CheckBox mech_midh_checkbox;
    private RadioGroup mech_midh_toolworking_rg,mech_midh_rto_license_rg;
    private RadioButton mech_midh_automatic,mech_midh_manpower,mech_midh_rto_license_yes,mech_midh_rto_license_no;
    private Button mech_midh_save;
    
    private String toolworking="0",license="0";
    private SweetAlertDialog sweetAlertDialog;
    private PreferenceManager preferenceManager;

    private int mYear, mMonth, mDay,dummy=1;
    private DatePickerDialog mech_midh_datepicker;
    private String mech_midh_date="0";

    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private File photoFile1 = null;
    private String imagePath1="";
    private String image_1_file_name="";
    private AppLocationManager locationManager;
    public double lat,lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanization_m_i_d_h);
        getSupportActionBar().setTitle("Mechanization by MIDH Scheme");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        locationManager = new AppLocationManager(this);
        preferenceManager = new PreferenceManager(MechanizationMIDHActivity.this);

        ids();
        functions();
    }
    
    private void ids(){
        //Textview
        mech_midh_obsdatetv = (TextView) findViewById(R.id.mech_midh_obsdatetv);
        mech_midh_farmer_nametv = (TextView) findViewById(R.id.mech_midh_farmer_nametv);
        mech_midh_villagetv = (TextView) findViewById(R.id.mech_midh_villagetv);
        mech_midh_talukatv = (TextView) findViewById(R.id.mech_midh_talukatv);
        mech_midh_districttv = (TextView) findViewById(R.id.mech_midh_districttv);
        mech_midh_proposed_toolname = (TextView) findViewById(R.id.mech_midh_proposed_toolname);
        mech_midh_proposed_trachp = (TextView) findViewById(R.id.mech_midh_proposed_trachp);
        //Edittext
        mech_midh_actual_toolname = (EditText) findViewById(R.id.mech_midh_actual_toolname);
        mech_midh_actual_trachp = (EditText) findViewById(R.id.mech_midh_actual_trachp);
        mech_midh_total_rupees_et = (EditText) findViewById(R.id.mech_midh_total_rupees_et);
        //Imageview
        //mech_midh_obsdateiv = (ImageView) findViewById(R.id.mech_midh_obsdateiv);
        mech_midh_license_photo = (ImageView) findViewById(R.id.mech_midh_license_photo);

        mech_midh_license_ll = (LinearLayout) findViewById(R.id.mech_midh_license_ll);
        mech_midh_checkbox = (CheckBox) findViewById(R.id.mech_midh_checkbox);
        //Radiogroup
        mech_midh_toolworking_rg = (RadioGroup) findViewById(R.id.mech_midh_toolworking_rg);
        mech_midh_rto_license_rg = (RadioGroup) findViewById(R.id.mech_midh_rto_license_rg);
        //Radiobutton
        mech_midh_automatic = (RadioButton) findViewById(R.id.mech_midh_automatic);
        mech_midh_manpower = (RadioButton) findViewById(R.id.mech_midh_manpower);
        mech_midh_rto_license_yes = (RadioButton) findViewById(R.id.mech_midh_rto_license_yes);
        mech_midh_rto_license_no = (RadioButton) findViewById(R.id.mech_midh_rto_license_no);
        
        mech_midh_save = (Button) findViewById(R.id.mech_midh_save);
        mech_midh_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        mech_midh_obsdatetv.setText(mech_midh_date);
    }
    
    private void functions(){

       /* mech_midh_obsdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mech_midh_date_service();
            }
        });*/

        mech_midh_toolworking_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mech_midh_automatic:
                        mech_midh_automatic.setChecked(true);
                        toolworking = "1";
                        break;

                    case R.id.mech_midh_manpower:
                        mech_midh_manpower.setChecked(true);
                        toolworking = "2";
                        break;
                }
            }
        });

        mech_midh_rto_license_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch(checkedId) {
                    case R.id.mech_midh_rto_license_yes:
                        mech_midh_rto_license_yes.setChecked(true);
                        mech_midh_license_ll.setVisibility(View.VISIBLE);
                        license = "1";
                        break;

                    case R.id.mech_midh_rto_license_no:
                        mech_midh_rto_license_no.setChecked(true);
                        mech_midh_license_ll.setVisibility(View.GONE);
                        license = "2";
                        break;
                }
            }
        });

        mech_midh_license_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((ContextCompat.checkSelfPermission(MechanizationMIDHActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MechanizationMIDHActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(MechanizationMIDHActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED  && (ContextCompat.checkSelfPermission(MechanizationMIDHActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))) {
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_FINE_LOCATION};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }
        });
        
        mech_midh_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mech_midh_save_service();
            }
        });
    }

    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
                photoFile1 = new File(photoDirectory, System.currentTimeMillis() + ".jpg");

                Uri photoURI = null;

                if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                    photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile1);
                } else {
                    photoURI = Uri.fromFile(photoFile1);
                }

                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setClipData(ClipData.newRawUri("", photoURI));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                startActivityForResult(intent, CAMERA);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }else{
            photoFile1= null;
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;

            if (photoFile1 != null) {

                if (photoFile1.exists()) {

                    bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile1, 1050, true); // BitmapFactory.decodeFile(photopath);
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    imagePath1 = "file://" + photoFile1;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Picasso.get()
                                    .load(imagePath1)
                                    .resize(mech_midh_license_photo.getWidth(), mech_midh_license_photo.getHeight())
                                    .centerCrop()
                                    .into(mech_midh_license_photo);

                            uploadImageOnServer(imagePath1);
                        }
                    }, 2000);


                    FileOutputStream fOut;
                    try {
                        fOut = new FileOutputStream(photoFile1);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                        fOut.flush();
                        fOut.close();

                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
    }

    private void uploadImageOnServer(String imagePath) {
        try {

            lat = locationManager.getLatitude();
            lang = locationManager.getLongitude();

            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();
            params.put("district_id","1");
            params.put("taluka_id","1");
            params.put("village_id","1");
            params.put("farmer_id","1");
            params.put("lat","1");
            params.put("long","1");

            File file = new File(photoFile1.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("fileToUpload", file.getName(), reqFile);

            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.mech_midh_img_save(partBody, params);
            api.postRequest(responseCall, this, 1);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void mech_midh_date_service(){

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        mech_midh_datepicker = new DatePickerDialog(MechanizationMIDHActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        mech_midh_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        mech_midh_obsdatetv.setText(mech_midh_date);


                    }
                }, mYear, mMonth, mDay);

        mech_midh_datepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        mech_midh_datepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        mech_midh_datepicker.show();
    }

    private void mech_midh_save_service(){
        if(mech_midh_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "Select दिनांक", Toast.LENGTH_SHORT).show();
        }else if(mech_midh_actual_toolname.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्येक्ष अवजाराचे नाव", Toast.LENGTH_SHORT).show();
        }else if(mech_midh_actual_trachp.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्येक्ष ट्रॅक्टरची क्षमता (एचपी)", Toast.LENGTH_SHORT).show();
        }else if(toolworking.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(), "अवजार स्वंयमचलीत आहे की मानवचलीत?", Toast.LENGTH_SHORT).show();
        }else if(license.equalsIgnoreCase("0")) {
            Toast.makeText(getApplicationContext(), "ट्रॅक्टरची नोंदणी प्रादेशिक परीवहन खात्याकडे (7०) केली आहे का ?",Toast.LENGTH_SHORT).show();
        }else if(mech_midh_total_rupees_et.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter अंतिम देय रक्कम रु.", Toast.LENGTH_SHORT).show();
        }else if(!mech_midh_checkbox.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept the terms",Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("date_midh", mech_midh_date);
                param.put("farmer_name", "0");
                param.put("village_id", "0");
                param.put("taluka_id", "0");
                param.put("district_id", "0");
                param.put("proposed_tool", "0");
                param.put("actual_tool", mech_midh_actual_toolname.getText().toString().trim());
                param.put("proposed_trac_hp", "0");
                param.put("actual_trac_hp", mech_midh_actual_trachp.getText().toString().trim());
                param.put("toolworking", toolworking);
                param.put("license",license);
                param.put("photo",image_1_file_name);
                param.put("total", mech_midh_total_rupees_et.getText().toString().trim());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.mech_midh_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        if(jsonObject != null){

            try{
                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            image_1_file_name = data.getString("file_name");
                        }
                    }
                }

                if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Mechanization by MIDH Scheme");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

    }
}
