package com.maha.agri.activity.common;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class FarmerOTPLoginActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button generateOTP_btn,verify_otp_btn;
    private EditText mobileNumEText,otp_edit_text;
    private TextView resend_otp_text_view;
    private CardView mobile_card_view,otp_card_view;
    private String mobile_number;
    private JSONObject generateotpJsonObject,verifyotpJsonObject;
    private SharedPref sharedPref;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_otplogin);

        sharedPref = new SharedPref(FarmerOTPLoginActivity.this);
        preferenceManager = new PreferenceManager(FarmerOTPLoginActivity.this);
        init();
        default_confiq();


    }

    private void init(){
        mobileNumEText = (EditText) findViewById(R.id.mobileNumEText);
        otp_edit_text = (EditText) findViewById(R.id.otpEText);
        generateOTP_btn = (Button) findViewById(R.id.generateOTPbtn);
        verify_otp_btn = (Button) findViewById(R.id.OTP_verifybtn);
        resend_otp_text_view = (TextView) findViewById(R.id.resend_otp_textview);
        mobile_card_view = (CardView) findViewById(R.id.mobileCardView);
        otp_card_view = (CardView) findViewById(R.id.otpCardView);

    }

    private void default_confiq(){
        generateOTP_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferenceManager.putPreferenceValues(Preference_Constant.FARMER_MOBILE_NUMBER,mobileNumEText.getText().toString().trim());

                generateotpWebservice();
            }
        });

        verify_otp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                verifyotpWebservice();

            }
        });

    }

    private void generateotpWebservice(){

        if(mobileNumEText.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter mobile number");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("mobile", mobileNumEText.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.farmer_verify_mobile_number_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    private void resendotpWebservice(){

            JSONObject param = new JSONObject();
            try {
                param.put("mobile", preferenceManager.getPreferenceValues(Preference_Constant.FARMER_MOBILE_NUMBER));
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.farmer_verify_mobile_number_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 3);
        }


    private void verifyotpWebservice(){

        if(mobileNumEText.getText().toString().trim().isEmpty()){
            UIToastMessage.show(this, "Please enter valid otp");
        } else {

            JSONObject param = new JSONObject();
            try {
                param.put("mobile", preferenceManager.getPreferenceValues(Preference_Constant.FARMER_MOBILE_NUMBER));
                param.put("otp", otp_edit_text.getText().toString().trim());
            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.farmer_verify_otp_url(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }



    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

                if (i == 1) {

                    if (jsonObject.getString("status").equals("200")) {
                        generateotpJsonObject = jsonObject.getJSONObject("data");
                        mobile_card_view.setVisibility(View.GONE);
                        otp_card_view.setVisibility(View.VISIBLE);
                        generateOTP_btn.setVisibility(View.GONE);
                        verify_otp_btn.setVisibility(View.VISIBLE);
                        resend_otp_text_view.setVisibility(View.VISIBLE);
                        resend_otp_text_view.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                resendotpWebservice();
                            }
                        });
                        UIToastMessage.show(this, jsonObject.getString("response"));

                    } else {
                        Intent intent = new Intent(FarmerOTPLoginActivity.this, LoginActivity.class);
                        intent.putExtra("type","farmer");
                        startActivity(intent);
                        finish();

                    }


                }

                if (i == 2) {

                    if (jsonObject.getString("status").equals("200")) {

                        Intent intent = new Intent(FarmerOTPLoginActivity.this, RegisterActivity.class);
                        startActivity(intent);


                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));

                    }


                }

            if (i == 3) {

                if (jsonObject.getString("status").equals("200")) {
                    UIToastMessage.show(this, jsonObject.getString("response"));

                } else {
                    UIToastMessage.show(this, jsonObject.getString("response"));

                }


            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {


    }
}
