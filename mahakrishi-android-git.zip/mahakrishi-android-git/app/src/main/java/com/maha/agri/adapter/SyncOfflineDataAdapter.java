package com.maha.agri.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.click_listener.sync_task_Click_Listener;
import com.maha.agri.database.DBHandler;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SyncOfflineDataAdapter extends RecyclerView.Adapter<SyncOfflineDataAdapter.MyViewHolder> {

    private final DBHandler dbHandler;
    private JSONArray task_manager_array_list,offline_Work_task_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    private sync_task_Click_Listener sync_task_click_listener;
    private String id,farmer_name,crop_name,area_name,site_location,no_of_participants,work_details,activity_name,activity_id;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView activity_name_tv,farmer_name_tv,crop_name_tv,area_name_tv,site_locations_tv,no_of_participants_tv,work_details_tv;
        private LinearLayout schemeLL,non_scheme_LL,farmer_name_ll,crop_name_ll,area_name_ll,site_location_ll,no_of_participants_ll,work_details_ll,activity_name_ll,add_task_group_details_ll,add_task_subtype_ll,non_scheme_ll;
        private ImageView sync_task_iv;

        public MyViewHolder(View itemView) {
            super(itemView);
            schemeLL = (LinearLayout)itemView.findViewById(R.id.schemeLL);
            non_scheme_LL = (LinearLayout) itemView.findViewById(R.id.non_schemeLL);
            farmer_name_ll = (LinearLayout)itemView.findViewById(R.id.farmer_name_ll);
            crop_name_ll = (LinearLayout) itemView.findViewById(R.id.crop_name_ll);
            area_name_ll = (LinearLayout)itemView.findViewById(R.id.area_name_ll);
            site_location_ll = (LinearLayout) itemView.findViewById(R.id.site_locations_ll);
            no_of_participants_ll = (LinearLayout)itemView.findViewById(R.id.number_of_participants_ll);
            work_details_ll = (LinearLayout) itemView.findViewById(R.id.work_details_ll);
            activity_name_ll = (LinearLayout) itemView.findViewById(R.id.activity_name_ll);
            add_task_group_details_ll = (LinearLayout)itemView.findViewById(R.id.add_task_group_details_ll);
            add_task_subtype_ll = (LinearLayout) itemView.findViewById(R.id.add_task_subtype_ll);
            activity_name_tv = (TextView) itemView.findViewById(R.id.actNameTView);
            farmer_name_tv = (TextView) itemView.findViewById(R.id.actFarmerTView);
            crop_name_tv = (TextView) itemView.findViewById(R.id.actCropTView);
            area_name_tv = (TextView) itemView.findViewById(R.id.actAreaTView);
            site_locations_tv = (TextView) itemView.findViewById(R.id.actNonSchemeLocationTView);
            no_of_participants_tv = (TextView) itemView.findViewById(R.id.actNumOfParticipantTView);
            work_details_tv = (TextView) itemView.findViewById(R.id.actWorkDetailTView);
            sync_task_iv = (ImageView) itemView.findViewById(R.id.sync_task_image_view);

        }
    }

    public SyncOfflineDataAdapter(PreferenceManager preferenceManager, JSONArray task_manager_array_list,Context context) {
        this.preferencemanager = preferenceManager;
        this.task_manager_array_list = task_manager_array_list;
        this.sync_task_click_listener = (sync_task_Click_Listener) context;;
        this.context = context;

        dbHandler = new DBHandler(context);
    }

    @Override
    public SyncOfflineDataAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_offline_task, parent, false);

        SyncOfflineDataAdapter.MyViewHolder myViewHolder = new SyncOfflineDataAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final SyncOfflineDataAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = task_manager_array_list.getJSONObject(listPosition);
            activity_id = jsonObject.getString("activity_id");

            offline_Work_task_list = dbHandler.getOfflineSchemeWork(activity_id);
            JSONObject jsonObject_offline_work = offline_Work_task_list.getJSONObject(0);
            farmer_name = jsonObject_offline_work.getString("farmer_name");
            crop_name = jsonObject_offline_work.getString("crop_name");
            area_name = jsonObject_offline_work.getString("area");
            site_location = jsonObject_offline_work.getString("site_location");
            no_of_participants = jsonObject_offline_work.getString("no_of_participants");
            work_details = jsonObject_offline_work.getString("details");


            if(farmer_name.equalsIgnoreCase("1") && crop_name.equalsIgnoreCase("1") && area_name.equalsIgnoreCase("1")){
                holder.add_task_subtype_ll.setVisibility(View.VISIBLE);
            } else{
                holder.add_task_subtype_ll.setVisibility(View.GONE);
            }

            if(no_of_participants.equalsIgnoreCase("1")){
                holder.no_of_participants_ll.setVisibility(View.VISIBLE);
            } else{
                holder.no_of_participants_ll.setVisibility(View.GONE);
            }

            if(site_location.equalsIgnoreCase("1")){
                holder.site_location_ll.setVisibility(View.VISIBLE);
            } else {
                holder.site_location_ll.setVisibility(View.GONE);
            }

            if(work_details.equalsIgnoreCase("1")){
                holder.add_task_group_details_ll.setVisibility(View.VISIBLE);
            } else{
                holder.add_task_group_details_ll.setVisibility(View.GONE);
            }


            holder.activity_name_tv.setText(jsonObject.getString("activity_name"));
            holder.farmer_name_tv.setText(jsonObject.getString("farmer_name"));
            holder.crop_name_tv.setText(jsonObject.getString("crop_name"));
            holder.area_name_tv.setText(jsonObject.getString("area"));
            holder.site_locations_tv.setText(jsonObject.getString("site_location"));
            holder.no_of_participants_tv.setText(jsonObject.getString("no_of_participants"));
            holder.work_details_tv.setText(jsonObject.getString("details"));


            holder.sync_task_iv.setTag(listPosition);

            holder.sync_task_iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int index = (Integer) view.getTag();

                    try {
                        id = task_manager_array_list.getJSONObject(index).getString("id");
                        if(sync_task_click_listener!=null) {
                            sync_task_click_listener.onSyncClick(id);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

        }
        catch (JSONException e) {
            e.printStackTrace();
        }

    }



    @Override
    public int getItemCount() {
        if (task_manager_array_list != null) {
            return task_manager_array_list.length();
        } else {
            return 0;
        }
    }


    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SyncOfflineDataAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SyncOfflineDataAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
