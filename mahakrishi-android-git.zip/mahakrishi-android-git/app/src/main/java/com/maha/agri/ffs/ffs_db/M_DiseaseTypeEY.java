package com.maha.agri.ffs.ffs_db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class M_DiseaseTypeEY {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int uid;
    private int crop_id;
    private String name;

    public M_DiseaseTypeEY() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }


    public int getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(int crop_id) {
        this.crop_id = crop_id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
