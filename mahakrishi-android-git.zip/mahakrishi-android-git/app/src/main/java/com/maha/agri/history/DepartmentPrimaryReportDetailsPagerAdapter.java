package com.maha.agri.history;

import android.content.Context;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DepartmentPrimaryReportDetailsPagerAdapter extends PagerAdapter {

    private LayoutInflater layoutInflater;
    private JSONArray dept_primary_report_details_list;
    private Context context;
    private PreferenceManager preferencemanager;
    private JSONObject jsonObject;
    private String id,name,districtname,talukaname,cropname,villagename,seasonname,total_affected_area,sajja_name;

    private TextView primary_report_district_tv,primary_report_taluka_tv,primary_report_sajja_tv,primary_report_affected_village_tv,primary_report_season_tv,primary_report_crop_name_tv,primary_report_total_affected_tv;

    public DepartmentPrimaryReportDetailsPagerAdapter(PreferenceManager preferenceManager, JSONArray dept_primary_report_details_list, Context context) {
        this.preferencemanager = preferenceManager;
        this.dept_primary_report_details_list = dept_primary_report_details_list;
        this.context = context;

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.dept_primary_report_details_single_item, container, false);
        try {
            jsonObject = dept_primary_report_details_list.getJSONObject(position);
            districtname = jsonObject.getString("district_name");
            talukaname = jsonObject.getString("taluka_name");
            villagename = jsonObject.getString("village_name");
            seasonname = jsonObject.getString("season_name");
            cropname = jsonObject.getString("crop_name");
            sajja_name = jsonObject.getString("sajja_name");
            total_affected_area = jsonObject.getString("total_affected_area_ha");

            primary_report_district_tv = (TextView) view.findViewById(R.id.primary_report_district_tv);
            primary_report_taluka_tv = (TextView)view. findViewById(R.id.primary_report_taluka_tv);
            primary_report_sajja_tv = (TextView) view.findViewById(R.id.primary_report_sajja_tv);
            primary_report_affected_village_tv = (TextView)view. findViewById(R.id.primary_report_affected_village_tv);
            primary_report_season_tv = (TextView) view.findViewById(R.id.primary_report_season_tv);
            primary_report_crop_name_tv = (TextView) view.findViewById(R.id.primary_report_crop_name_tv);
            primary_report_total_affected_tv = (TextView)view. findViewById(R.id.primary_report_total_affected_tv);

            primary_report_district_tv.setText(districtname);
            primary_report_taluka_tv.setText(talukaname);
            primary_report_affected_village_tv.setText(villagename);
            primary_report_sajja_tv.setText(sajja_name);
            primary_report_season_tv.setText(seasonname);
            primary_report_crop_name_tv.setText(cropname);
            primary_report_total_affected_tv.setText(total_affected_area);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        container.addView(view);

        return view;
    }

    @Override
    public int getCount() {
        return dept_primary_report_details_list.length();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view == ((View) obj);
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
