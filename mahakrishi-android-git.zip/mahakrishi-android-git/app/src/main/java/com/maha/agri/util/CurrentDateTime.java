package com.maha.agri.util;

import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class CurrentDateTime {
    private static final String TAG = "CurrentDateTime";

    public static String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static String getDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }


    public static String getIndian() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "dd-MM-yyyy", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static String getTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public static String ConvertToDateTime(String dateString) {

        String outputdate = "";
        if ((dateString != null) && (dateString.length() > 8) && (!dateString.trim().equals("0000-00-00"))) {
            DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            DateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

            Date date = null;
            try {
                date = inputFormat.parse(dateString);
                if (date != null)
                {
                    outputdate = outputFormat.format(date);
                }
            } catch (ParseException e) {
                Log.e(TAG, e.toString());
            }
        }
        return outputdate;
    }


    public static String convertToTime(String dateString) {

        String outputdate = "";
        if ((dateString != null) && (dateString.length() > 0) && (!dateString.trim().equals("00:00:00"))) {
            DateFormat inputFormat = new SimpleDateFormat("kk:mm:ss", Locale.getDefault());
            DateFormat outputFormat = new SimpleDateFormat("hh:mm a");

            Date date = null;
            try {
                date = inputFormat.parse(dateString);
                if (date != null) {
                    outputdate = outputFormat.format(date);
                }
            } catch (ParseException e) {
                Log.e(TAG, e.toString());
            }
        }
        return outputdate;
    }

    public static String convertToTimeFormate(String dateString) {

        String outputdate = "";
        if ((dateString != null) && (dateString.length() > 0) && (!dateString.trim().equals("00:00:00"))) {
            DateFormat inputFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            DateFormat outputFormat = new SimpleDateFormat("kk:mm:ss");

            Date date = null;
            try {
                date = inputFormat.parse(dateString);
                if (date != null) {
                    outputdate = outputFormat.format(date);
                }
            } catch (ParseException e) {
                Log.e(TAG, e.toString());
            }
        }
        return outputdate;
    }

    public static String ConvertToDate(String dateString) {

        String outputdate = "";
        if ((dateString != null) && (dateString.length() > 8) && (!dateString.trim().equals("0000-00-00"))) {
            DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

            Date date = null;
            try {
                date = inputFormat.parse(dateString);
                if (date != null) {
                    outputdate = outputFormat.format(date);
                }
            } catch (ParseException e) {
                Log.e(TAG, e.toString());
            }
        }
        return outputdate;
    }

    public static String ConvertToDateUS(String dateString) {

        String outputdate = "";
        if ((dateString != null) && (dateString.length() > 8)) {
            DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");


            Date date = null;
            try {
                date = inputFormat.parse(dateString);
                if (date != null) {
                    outputdate = outputFormat.format(date);
                }
            } catch (ParseException e) {
                Log.e(TAG, e.toString());
            }

        }
        return outputdate;
    }

    public static int calculateDifference(Date a, Date b) {
        int tempDifference = 0;
        int difference = 1;
        Calendar earlier = Calendar.getInstance();
        Calendar later = Calendar.getInstance();

        if (a.compareTo(b) < 0) {
            earlier.setTime(a);
            later.setTime(b);
        } else {
            earlier.setTime(b);
            later.setTime(a);
        }

        while (earlier.get(Calendar.YEAR) != later.get(Calendar.YEAR)) {
            tempDifference = 365 * (later.get(Calendar.YEAR) - earlier.get(Calendar.YEAR));
            difference += tempDifference;

            earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
        }

        if (earlier.get(Calendar.DAY_OF_YEAR) != later.get(Calendar.DAY_OF_YEAR)) {
            tempDifference = later.get(Calendar.DAY_OF_YEAR) - earlier.get(Calendar.DAY_OF_YEAR);
            difference += tempDifference;

            earlier.add(Calendar.DAY_OF_YEAR, tempDifference);
        }

        return difference;
    }

    public static boolean checkDate(String date) {

        boolean isdate = false;
        try {

            if (date != null && date.trim().length() > 0 && !date.trim().equals("0000-00-00")) {

                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                Date date1 = sdf2.parse(date);
                Date date2 = sdf2.parse("1970-01-01");

                if ((date1.after(date2))) {
                    isdate = true;
                } else {
                    isdate = false;
                }
            }
        } catch (ParseException e) {
            Log.e(TAG, e.toString());
        }
        return isdate;
    }

}
