package com.maha.agri.activity.approve_attendance;

import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.activity.attendance.AttedanceCalenderActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class ApproveAttendActivity extends AppCompatActivity implements ApiCallbackCode {

    private TextView name,doj,present_day_in_juri,present_day_for_meeting,full_attendance,short_atteandance,days_absent,govt_holiday,sanctioned_leave,total_number_days_approve;
    private EditText number_of_approved_days,remark;
    private RadioGroup ca_status_radio_group;
    private RadioButton resigned_rb,abscoding_rb;
    private Button approve_btn,cancel_btn;
    private String month,year,user_status,fullname,junior_id,responseID;
    private PreferenceManager preferenceManager;
    private SharedPref sharedPref;
    private JSONObject login_Data;
    private JSONArray approve_attendance_List;
    private int user_status_id;
    private String isCompleted,no_of_approved_Days;
    private DatePickerDialog datePickerDialog;
    int days_approved,total_Days_in_month,num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approve_attend);
        getSupportActionBar().setTitle("Approve Attendance");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(ApproveAttendActivity.this);
        sharedPref = new SharedPref(ApproveAttendActivity.this);
        init();
        default_Confiq();
        approve_attendance_Webservice();

    }

    private void init(){
        name = (TextView)findViewById(R.id.nameTextView);
        present_day_in_juri = (TextView)findViewById(R.id.pjurisTextView);
        present_day_for_meeting = (TextView)findViewById(R.id.mtTextView);
        full_attendance = (TextView)findViewById(R.id.fullAttendanceTextView);
        short_atteandance = (TextView)findViewById(R.id.shortAttendanceTextView);
        days_absent = (TextView)findViewById(R.id.absentTextView);
        govt_holiday = (TextView)findViewById(R.id.ghTextView);
        sanctioned_leave = (TextView)findViewById(R.id.leaveTextView);
        total_number_days_approve = (TextView)findViewById(R.id.totalDaysTextView);
        number_of_approved_days = (EditText) findViewById(R.id.approvedDaysEditText);
        ca_status_radio_group = (RadioGroup) findViewById(R.id.radioGroup);
        resigned_rb = (RadioButton)findViewById(R.id.resignedRadioButton);
        abscoding_rb = (RadioButton) findViewById(R.id.abscondingRadioButton);
        remark = (EditText) findViewById(R.id.remarkEditText);
        approve_btn = (Button) findViewById(R.id.approveButton);
        cancel_btn = (Button) findViewById(R.id.cancel_btn);
        Calendar calander = Calendar.getInstance();
        SimpleDateFormat month_date = new SimpleDateFormat("MMMM");
        month = String.valueOf(calander.get(Calendar.MONTH));
        year = String.valueOf(calander.get(Calendar.YEAR));
        Intent intent = getIntent();
        junior_id = intent.getStringExtra("junior_id");
        fullname = intent.getStringExtra("name");
        name.setText(fullname);

    }

    private void default_Confiq(){
        approve_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                approve_attendance_save_Webservice();
            }
        });

        ca_status_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                checkedId = ca_status_radio_group.getCheckedRadioButtonId();
                user_status_id = Integer.parseInt(findViewById(checkedId).getTag().toString());



            }
        });



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.calendar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.calendar_menu:
                Intent intent = new Intent(ApproveAttendActivity.this, AttedanceCalenderActivity.class);
                startActivity(intent);


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void approve_attendance_Webservice () {

        JSONObject param = new JSONObject();
        try {
            param.put("user_id",junior_id);
            param.put("month", month);
            param.put("year", year);
            param.put("senior_user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.approve_attendance(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void approve_attendance_save_Webservice () {

        if (user_status_id == 0) {
            UIToastMessage.show(ApproveAttendActivity.this, "Please select the status");
        } else if (number_of_approved_days.getText().toString().isEmpty()) {
            UIToastMessage.show(ApproveAttendActivity.this, "Please approve the number of days");

        } else if(Integer.parseInt(number_of_approved_days.getText().toString())>=total_Days_in_month){
             UIToastMessage.show(ApproveAttendActivity.this, "Please approve the number of days within the month");
         }
        else {


            JSONObject param = new JSONObject();
            try {
                param.put("id", responseID);
                param.put("total_no_of_days_approved_by_senior", number_of_approved_days.getText().toString().trim());
                param.put("user_status", user_status_id);
                param.put("remark", remark.getText().toString().trim());
                param.put("senior_user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.approve_attendance_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 2);
        }
    }



    @Override
    public void onResponse (JSONObject jsonObject,int i){

        try {

            if (jsonObject != null) {
                if (i == 1) {

                    if (jsonObject.getString("status").equals("200")) {
                        total_Days_in_month = Integer.parseInt(jsonObject.getString("total_days_in_month"));
                        approve_attendance_List = jsonObject.getJSONArray("data");
                        for(int j = 0; j < approve_attendance_List .length(); j++)
                        {
                            JSONObject login_Data = approve_attendance_List.getJSONObject(j);
                            present_day_in_juri.setText(login_Data.getString("present_days_in_jurisdiction"));
                            present_day_for_meeting.setText(login_Data.getString("present_days_for_meeting_training"));
                            full_attendance.setText(login_Data.getString("full_attendance"));
                            short_atteandance.setText(login_Data.getString("short_attendance"));
                            days_absent.setText(login_Data.getString("absent_days"));
                            govt_holiday.setText(login_Data.getString("government_holidays"));
                            sanctioned_leave.setText(login_Data.getString("leave_sanctioned"));
                            total_number_days_approve.setText(login_Data.getString("total_no_of_days_approved_by_senior"));
                            responseID = login_Data.getString("id");
                            isCompleted = login_Data.getString("is_completed");
                            preferenceManager.putPreferenceValues(Preference_Constant.IS_COMPLETED,isCompleted);

                            if(isCompleted.equalsIgnoreCase("1")){
                                number_of_approved_days.setEnabled(false);
                                remark.setEnabled(false);
                                number_of_approved_days.setText(login_Data.getString("total_no_of_days_approved_by_senior"));

                                String user_server_status_ID = login_Data.getString("user_status");
                                if(user_server_status_ID.equalsIgnoreCase("1")){
                                    resigned_rb.setChecked(true);
                                    abscoding_rb.setChecked(false);
                                    resigned_rb.setEnabled(false);
                                    abscoding_rb.setEnabled(false);

                                } else {
                                    resigned_rb.setChecked(false);
                                    abscoding_rb.setChecked(true);
                                    resigned_rb.setEnabled(false);
                                    abscoding_rb.setEnabled(false);
                                }

                                remark.setText(login_Data.getString("remark"));
                                approve_btn.setVisibility(View.INVISIBLE);
                                //approve_btn.setEnabled(false);
                            }
                            else{
                                number_of_approved_days.setEnabled(true);
                                remark.setEnabled(true);
                                approve_btn.setVisibility(View.VISIBLE);
                                //approve_btn.setEnabled(true);
                            }


                        }

                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }


                }

                if (i == 2) {

                    if (jsonObject.getString("status").equals("200")) {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    } else {
                        UIToastMessage.show(this, jsonObject.getString("response"));
                    }


                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFailure (Object o, Throwable throwable,int i){

    }



}
