package com.maha.agri.spot_verification;

import android.app.DatePickerDialog;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.DecimalDigitsInputFilter;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.AlertListEventListener;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class RejuvenationOldFruitPlantationActivity extends AppCompatActivity implements AlertListEventListener, ApiCallbackCode {

    private TextView rejuv_farmer_nametv,rejuv_villagetv,rejuv_talukatv,rejuv_districttv,rejuv_beneficiarytv,rejuv_pravargtv,rejuv_bhumapantv,rejuv_gutnotv,rejuv_8Atv,
            rejuv_proposed_area_tv,rejuv_obsdatetv;

    private EditText rejuv_landtype_et,rejuv_fruitname_et,rejuv_type_et,rejuv_age_et,rejuv_actual_area_et,rejuv_ekun_schemearea_et,farming_tools_et,old_farm_rejuv_et,
            rejuv_total_rupees_et,rejuv_row1col4,rejuv_row1col5,rejuv_row2col4,rejuv_row2col5,rejuv_row3col4,rejuv_row3col5,rejuv_row4col4,rejuv_row4col5,
            rejuv_row5col4,rejuv_row5col5,rejuv_row6col4,rejuv_row6col5,rejuv_row7col4,rejuv_row7col5,rejuv_row8col4,rejuv_row8col5,rejuv_row9col4,rejuv_row9col5;

    private ImageView rejuv_obsdateiv,rejuv_table1_dd1,rejuv_table1_dd2,rejuv_table1_dd3,rejuv_table1_dd4,rejuv_table1_dd5,rejuv_table1_dd6,rejuv_table1_dd7,
            rejuv_table1_dd8;
    private TableLayout rejuv_tablerow1,rejuv_tablerow2,rejuv_tablerow3,rejuv_tablerow4,rejuv_tablerow5,rejuv_tablerow6,rejuv_tablerow7,rejuv_tablerow8,rejuv_tablerow9;
    private CheckBox rejuv_checkbox1,rejuv_checkbox2,rejuv_checkbox3;
    private Button rejuv_save;

    private SweetAlertDialog sweetAlertDialog;

    private int mYear, mMonth, mDay;
    private DatePickerDialog rejuvdatepicker;
    private String rejuv_date="0";
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rejuvenation_old_fruit_plantation);
        getSupportActionBar().setTitle("Rejuvenation of Old Fruit Plantation");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(RejuvenationOldFruitPlantationActivity.this);

        ids();
        functions();
    }

    private void ids(){
        //Textview
        rejuv_farmer_nametv = (TextView) findViewById(R.id.rejuv_farmer_nametv);
        rejuv_villagetv = (TextView) findViewById(R.id.rejuv_villagetv);
        rejuv_talukatv = (TextView) findViewById(R.id.rejuv_talukatv);
        rejuv_districttv = (TextView) findViewById(R.id.rejuv_districttv);
        rejuv_beneficiarytv = (TextView) findViewById(R.id.rejuv_beneficiarytv);
        rejuv_pravargtv = (TextView) findViewById(R.id.rejuv_pravargtv);
        rejuv_bhumapantv = (TextView) findViewById(R.id.rejuv_bhumapantv);
        rejuv_gutnotv = (TextView) findViewById(R.id.rejuv_gutnotv);
        rejuv_8Atv = (TextView) findViewById(R.id.rejuv_8Atv);
        rejuv_proposed_area_tv = (TextView) findViewById(R.id.rejuv_proposed_area_tv);
        rejuv_obsdatetv = (TextView) findViewById(R.id.rejuv_obsdatetv);

        //Edittext
        rejuv_landtype_et = (EditText) findViewById(R.id.rejuv_landtype_et);
        rejuv_fruitname_et = (EditText) findViewById(R.id.rejuv_fruitname_et);
        rejuv_type_et = (EditText) findViewById(R.id.rejuv_type_et);
        rejuv_age_et = (EditText) findViewById(R.id.rejuv_age_et);
        rejuv_actual_area_et = (EditText) findViewById(R.id.rejuv_actual_area_et);
        rejuv_ekun_schemearea_et = (EditText) findViewById(R.id.rejuv_ekun_schemearea_et);
        farming_tools_et = (EditText) findViewById(R.id.farming_tools_et);
        old_farm_rejuv_et = (EditText) findViewById(R.id.old_farm_rejuv_et);
        rejuv_total_rupees_et = (EditText) findViewById(R.id.rejuv_total_rupees_et);
        rejuv_row1col4 = (EditText) findViewById(R.id.rejuv_row1col4);
        rejuv_row2col4 = (EditText) findViewById(R.id.rejuv_row2col4);
        rejuv_row3col4 = (EditText) findViewById(R.id.rejuv_row3col4);
        rejuv_row4col4 = (EditText) findViewById(R.id.rejuv_row4col4);
        rejuv_row5col4 = (EditText) findViewById(R.id.rejuv_row5col4);
        rejuv_row6col4 = (EditText) findViewById(R.id.rejuv_row6col4);
        rejuv_row7col4 = (EditText) findViewById(R.id.rejuv_row7col4);
        rejuv_row8col4 = (EditText) findViewById(R.id.rejuv_row8col4);
        rejuv_row9col4 = (EditText) findViewById(R.id.rejuv_row9col4);
        rejuv_row1col5 = (EditText) findViewById(R.id.rejuv_row1col5);
        rejuv_row2col5 = (EditText) findViewById(R.id.rejuv_row2col5);
        rejuv_row3col5 = (EditText) findViewById(R.id.rejuv_row3col5);
        rejuv_row4col5 = (EditText) findViewById(R.id.rejuv_row4col5);
        rejuv_row5col5 = (EditText) findViewById(R.id.rejuv_row5col5);
        rejuv_row6col5 = (EditText) findViewById(R.id.rejuv_row6col5);
        rejuv_row7col5 = (EditText) findViewById(R.id.rejuv_row7col5);
        rejuv_row8col5 = (EditText) findViewById(R.id.rejuv_row8col5);
        rejuv_row9col5 = (EditText) findViewById(R.id.rejuv_row9col5);

        rejuv_table1_dd1 = (ImageView) findViewById(R.id.rejuv_table1_dd1);
        rejuv_table1_dd2 = (ImageView) findViewById(R.id.rejuv_table1_dd2);
        rejuv_table1_dd3 = (ImageView) findViewById(R.id.rejuv_table1_dd3);
        rejuv_table1_dd4 = (ImageView) findViewById(R.id.rejuv_table1_dd4);
        rejuv_table1_dd5 = (ImageView) findViewById(R.id.rejuv_table1_dd5);
        rejuv_table1_dd6 = (ImageView) findViewById(R.id.rejuv_table1_dd6);
        rejuv_table1_dd7 = (ImageView) findViewById(R.id.rejuv_table1_dd7);
        rejuv_table1_dd8 = (ImageView) findViewById(R.id.rejuv_table1_dd8);

        rejuv_checkbox1 = (CheckBox)findViewById(R.id.rejuv_checkbox1);
        rejuv_checkbox2 = (CheckBox)findViewById(R.id.rejuv_checkbox2);
        rejuv_checkbox3 = (CheckBox)findViewById(R.id.rejuv_checkbox3);

        rejuv_tablerow1 = (TableLayout) findViewById(R.id.rejuv_tablerow1);
        rejuv_tablerow2 = (TableLayout) findViewById(R.id.rejuv_tablerow2);
        rejuv_tablerow3 = (TableLayout) findViewById(R.id.rejuv_tablerow3);
        rejuv_tablerow4 = (TableLayout) findViewById(R.id.rejuv_tablerow4);
        rejuv_tablerow5 = (TableLayout) findViewById(R.id.rejuv_tablerow5);
        rejuv_tablerow6 = (TableLayout) findViewById(R.id.rejuv_tablerow6);
        rejuv_tablerow7 = (TableLayout) findViewById(R.id.rejuv_tablerow7);
        rejuv_tablerow8 = (TableLayout) findViewById(R.id.rejuv_tablerow8);
        rejuv_tablerow9 = (TableLayout) findViewById(R.id.rejuv_tablerow9);
        rejuv_save = (Button) findViewById(R.id.rejuv_save);
        rejuv_date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        rejuv_obsdatetv.setText(rejuv_date);

        rejuv_row1col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row1col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row2col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row2col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row3col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row3col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row4col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row4col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row5col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row5col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row6col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row6col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row7col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row7col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row8col4.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
        rejuv_row8col5.setFilters(new InputFilter[] {new DecimalDigitsInputFilter(6,2)});
    }

    private void functions(){

        /*rejuv_obsdateiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rejuv_date();
            }
        });*/

        rejuv_table1_dd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow1.getVisibility() == View.GONE){
                    rejuv_tablerow1.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow1.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow2.getVisibility() == View.GONE){
                    rejuv_tablerow2.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow2.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow3.getVisibility() == View.GONE){
                    rejuv_tablerow3.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow3.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow4.getVisibility() == View.GONE){
                    rejuv_tablerow4.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow4.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow5.getVisibility() == View.GONE){
                    rejuv_tablerow5.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow5.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow6.getVisibility() == View.GONE){
                    rejuv_tablerow6.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow6.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow7.getVisibility() == View.GONE){
                    rejuv_tablerow7.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow7.setVisibility(View.GONE);
                }
            }
        });

        rejuv_table1_dd8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rejuv_tablerow8.getVisibility() == View.GONE){
                    rejuv_tablerow8.setVisibility(View.VISIBLE);
                }else{
                    rejuv_tablerow8.setVisibility(View.GONE);
                }
            }
        });

        rejuv_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rejuv_save_service();
            }
        });
    }

    private void rejuv_date(){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        rejuvdatepicker = new DatePickerDialog(RejuvenationOldFruitPlantationActivity.this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        rejuv_date = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year;
                        rejuv_obsdatetv.setText(rejuv_date);

                    }
                }, mYear, mMonth, mDay);

        rejuvdatepicker.getDatePicker().setMinDate(System.currentTimeMillis());
        rejuvdatepicker.getDatePicker().setMaxDate(System.currentTimeMillis());

        rejuvdatepicker.show();
    }

    private void rejuv_save_service(){
        if(rejuv_landtype_et.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter जमिनीचा प्रकार", Toast.LENGTH_SHORT).show();
        }else if(rejuv_fruitname_et.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter फळपिकाचे नाव", Toast.LENGTH_SHORT).show();
        }else if(rejuv_type_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter जात", Toast.LENGTH_SHORT).show();
        }else if(rejuv_age_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter वय (वर्ष)", Toast.LENGTH_SHORT).show();
        }else if(rejuv_actual_area_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter प्रत्येक्ष क्षेत्र (हेक्टर)", Toast.LENGTH_SHORT).show();
        }else if(rejuv_ekun_schemearea_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter एकूण योजनेकरिता क्षेत्र", Toast.LENGTH_SHORT).show();
        }else if(farming_tools_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter फळबागेसाठी उपलब्ध ओलीताचे साधन", Toast.LENGTH_SHORT).show();
        }else if(old_farm_rejuv_et.getText().toString().trim().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter जुन्या फळबागेचे पुनरूज्जीवन या घटकांतर्गत बाबनिहाय दिलेल्या कार्यक्रमाप्रमाणे उत्पादन व उत्पादकता का कमी झाली याची कारणमिमांसा, त्यासाठी लागणा-या निविष्ठा इ. तपशील", Toast.LENGTH_SHORT).show();
        }else if(rejuv_total_rupees_et.getText().toString().equalsIgnoreCase("")){
            Toast.makeText(getApplicationContext(), "Enter अंतिम देय रक्कम रु.", Toast.LENGTH_SHORT).show();
        }else if(!rejuv_checkbox1.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept all the terms",Toast.LENGTH_SHORT).show();
        }else if(!rejuv_checkbox2.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept all the terms",Toast.LENGTH_SHORT).show();
        }else if(!rejuv_checkbox3.isChecked()){
            Toast.makeText(getApplicationContext(),"Accept all the terms",Toast.LENGTH_SHORT).show();
        }else if(rejuv_date.equalsIgnoreCase("0")){
            Toast.makeText(getApplicationContext(),"Select दिनांक",Toast.LENGTH_SHORT).show();
        }else {
            JSONObject param = new JSONObject();
            try {
                param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
                param.put("farmer_name_dbt", "0");
                param.put("village_id_dbt", 0);
                param.put("taluka_id_dbt", 0);
                param.put("district_id_dbt", 0);
                param.put("benificiary_varg_dbt", "0");
                param.put("pravarg_dbt", "0");
                param.put("bhumapan_no_dbt", "0");
                param.put("gut_no_dbt", 0);
                param.put("eight_a", 0);
                param.put("land_type", rejuv_landtype_et.getText().toString().trim());
                param.put("fruit_name", rejuv_fruitname_et.getText().toString().trim());
                param.put("fruit_type", rejuv_type_et.getText().toString().trim());
                param.put("age", rejuv_age_et.getText().toString().trim());
                param.put("proposed_area_dbt", "0");
                param.put("actual_area", rejuv_actual_area_et.getText().toString().trim());
                param.put("ekun_yojna_area", rejuv_ekun_schemearea_et.getText().toString().trim());
                param.put("farm_tools", farming_tools_et.getText().toString().trim());
                param.put("old_farm", old_farm_rejuv_et.getText().toString().trim());
                param.put("total", rejuv_total_rupees_et.getText().toString().trim());
                param.put("date_rejuvenation",rejuv_date);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.SPOT_VERIFICATION_URL, "", ApConstants.kMSG, true);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            Call<JsonObject> responseCall = apiRequest.rejuvenation_save(requestBody);
            DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {
        if(jsonObject != null){

            try{

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE);
                            sweetAlertDialog.setTitleText("Rejuvenation of Old Fruit Plantation");
                            sweetAlertDialog.setContentText("Data saved successfully");
                            sweetAlertDialog.setConfirmText("Ok");
                            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sweetAlertDialog) {
                                    finish();
                                }
                            });
                            sweetAlertDialog.show();
                        }
                    }
                }

            }catch (Exception e){

            }
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

    @Override
    public void didSelectListItem(int i, String s, String s1) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
