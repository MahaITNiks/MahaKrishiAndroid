package com.maha.agri.ffs.adaptor;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;

public class D_F_PreShowingActivityAdapter extends RecyclerView.Adapter<D_F_PreShowingActivityAdapter.ViewHolder> {

    private PreferenceManager preferenceManager;
    private String reg_type;
    private String villageId;
    private String planId;
    private DBHandler dbHandler;
    private OnMultiRecyclerItemClickListener listener;
    private Context mContext;
    public JSONArray mDataArray;
    private String userID;
    private String cropID;

    public D_F_PreShowingActivityAdapter(Context mContext, OnMultiRecyclerItemClickListener listener, JSONArray jsonArray) {
        this.mContext = mContext;
        this.listener = listener;
        this.mDataArray = jsonArray;
        dbHandler = new DBHandler(mContext);

        preferenceManager = new PreferenceManager(mContext);
        userID = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
        reg_type = AppSettings.getInstance().getValue(mContext, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        villageId = AppSettings.getInstance().getValue(mContext, ApConstants.kVILLAGE_ID_DEMO_FFS, ApConstants.kVILLAGE_ID_DEMO_FFS);
        planId = AppSettings.getInstance().getValue(mContext, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);
        cropID = AppSettings.getInstance().getValue(mContext, ApConstants.kCROP_ID_DEMO_FFS, ApConstants.kCROP_ID_DEMO_FFS);
    }

    @Override
    public int getItemCount() {
        if (mDataArray != null) {
            return mDataArray.length();
        } else {
            return 0;
        }
    }


    @NonNull
    @Override
    public D_F_PreShowingActivityAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View base = LayoutInflater.from(mContext).inflate(R.layout.list_pre_showing_activities, viewGroup, false);
        return new D_F_PreShowingActivityAdapter.ViewHolder(base);
    }

    @Override
    public void onBindViewHolder(@NonNull final D_F_PreShowingActivityAdapter.ViewHolder viewHolder, int i) {
        try {
            viewHolder.onBind(mDataArray.getJSONObject(i), listener);

            viewHolder.saveTV.setTag(i);
            viewHolder.saveTV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // SaveButtonAction(jsonObject);
                    boolean result = false;
                    String visitName = null;

                    try {

                        int index = (Integer) viewHolder.saveTV.getTag();
                        JSONObject dataJSON = mDataArray.getJSONObject(index);

                        visitName = dataJSON.getString("visit_day");
                        String activity = dataJSON.getString("activity");
                        String activityID = dataJSON.getString("activity_id");
                        String unit = dataJSON.getString("unit");
                        String img1 = dataJSON.getString("img1");
                        String img1LatLang = dataJSON.getString("lat_lang1");
                        String img2 = dataJSON.getString("img2");
                        String img2LatLang = dataJSON.getString("lat_lang2");;
                        String comment = viewHolder.commentText.getText().toString().trim();

                        if (img1.equalsIgnoreCase("")){
                            UIToastMessage.show(mContext,"Capture image 1 of "+activity);
                        }else if (img2.equalsIgnoreCase("")){
                            UIToastMessage.show(mContext,"Capture image 2 of "+activity);
                        }else if (comment.equalsIgnoreCase("")){
                            UIToastMessage.show(mContext,"insert "+activity + " comment");
                        }else {

                            if (dbHandler.isActivityDetailExist(activityID)) {
                                result = dbHandler.updatePreShowingVisitDetail(userID,villageId,visitName,activity,activityID,cropID,planId,unit,comment,img1,img1LatLang,img2,img2LatLang,"1");
                            }else {
                                result = dbHandler.insertPreShowingVisitDetail(userID,villageId,visitName,activity,activityID,cropID,planId,unit,comment,img1,img1LatLang,img2,img2LatLang,"1");
                            }

                            if (result){
                                UIToastMessage.show(mContext,"Data Added successfully");
                                mDataArray = dbHandler.getPreShowingActivityList(visitName);
                                notifyDataSetChanged();
                            }else {
                                UIToastMessage.show(mContext,"Try Again");
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView commentText;
        private final TextView activityNameTV;
        private final TextView saveTV;
        private final ImageView actImage1IV;
        private final ImageView actImage2IV;

        public ViewHolder(View itemView) {
            super(itemView);

            saveTV = itemView.findViewById(R.id.saveTV);
            activityNameTV = itemView.findViewById(R.id.activityNameTV);
            actImage1IV = itemView.findViewById(R.id.actImage1IV);
            actImage2IV = itemView.findViewById(R.id.actImage2IV);
            commentText = itemView.findViewById(R.id.commentText);
        }

        private void onBind(final JSONObject jsonObject, final OnMultiRecyclerItemClickListener listener) {

            try {
                activityNameTV.setText(jsonObject.getString("activity"));
                String isCompleted = jsonObject.getString("is_submitted");
                String comment = jsonObject.getString("comment");
                commentText.setText(comment);
                // For image
                String img1Url = jsonObject.getString("img1");
                String img2Url = jsonObject.getString("img2");

                if (!img1Url.equalsIgnoreCase("")){
                    Picasso.get()
                            //.load("")
                            // .load(photoFile)
                            .load(img1Url)
                            .resize(150, 150)
                            .centerCrop()
                            .into(actImage1IV);
                }

                if (!img2Url.equalsIgnoreCase("")){
                    Picasso.get()
                            //.load("")
                            // .load(photoFile)
                            .load(img2Url)
                            .resize(150, 150)
                            .centerCrop()
                            .into(actImage2IV);
                }


                if (isCompleted.equalsIgnoreCase("1")){
                    saveTV.setText("Saved");
                    saveTV.setBackgroundColor(mContext.getResources().getColor(R.color.green));
                }else {
                    saveTV.setText("Save");
                    saveTV.setBackgroundColor(mContext.getResources().getColor(R.color.red));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            actImage1IV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onMultiRecyclerViewItemClick(1, jsonObject);
                }
            });

            actImage2IV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onMultiRecyclerViewItemClick(2, jsonObject);
                }
            });

        }

        private void SaveButtonAction(JSONObject actDetailJSON) {
            boolean result = false;
            String img1URL = "";
            String img1 = AppSettings.getInstance().getValue(mContext, ApConstants.kPRE_SHOWING_IMG1_URL,ApConstants.kPRE_SHOWING_IMG1_URL);
            if (!img1.equalsIgnoreCase("kPRE_SHOWING_IMG1_URL")){
                img1URL = img1;
            }
            String img2URL = "";
            String img2 = AppSettings.getInstance().getValue(mContext, ApConstants.kPRE_SHOWING_IMG2_URL,ApConstants.kPRE_SHOWING_IMG2_URL);
            if (!img2.equalsIgnoreCase("kPRE_SHOWING_IMG2_URL")){
                img2URL = img2;
            }

            String comment = commentText.getText().toString().trim();

            try {
                String cropId = actDetailJSON.getString("crop_id");
                String visitName = actDetailJSON.getString("pre_visit_days");
                String activity = actDetailJSON.getString("activities");
                String activityID = actDetailJSON.getString("id");
                String unit = actDetailJSON.getString("unit");

                if (img1URL.equalsIgnoreCase("")){
                    UIToastMessage.show(mContext,"Capture image 1 of "+activity);
                }else if (img2URL.equalsIgnoreCase("")){
                    UIToastMessage.show(mContext,"Capture image 2 of "+activity);
                }else if (comment.equalsIgnoreCase("")){
                    UIToastMessage.show(mContext,"insert "+activity + " comment");
                }else {
                    String userId = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);

                    if (dbHandler.isActivityDetailExist(activityID)) {
                        result = dbHandler.updatePreShowingVisitDetail(userId,villageId,visitName,activity,activityID,cropId,planId,unit,comment,img1URL,"",img2URL,"","1");
                    }else {
                        result = dbHandler.insertPreShowingVisitDetail(userId,villageId,visitName,activity,activityID,cropId,planId,unit,comment,img1URL,"",img2URL,"","1");
                    }

                    if (result){
                        UIToastMessage.show(mContext,"Data Added successfully");
                        saveTV.setText("Saved");
                        saveTV.setBackgroundColor(mContext.getResources().getColor(R.color.green));
                    }else {
                        saveTV.setText("Save");
                        saveTV.setBackgroundColor(mContext.getResources().getColor(R.color.red));
                        UIToastMessage.show(mContext,"Try Again");
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}


