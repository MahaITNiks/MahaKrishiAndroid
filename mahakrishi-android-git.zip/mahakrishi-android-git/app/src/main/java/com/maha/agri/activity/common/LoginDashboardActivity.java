package com.maha.agri.activity.common;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class LoginDashboardActivity extends AppCompatActivity implements ApiCallbackCode {

    private Button farmer_login_btn,department_login_btn;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    private TextView login_dashboard_version;
    String version_name="",package_name="";
    int version_code = 0;
    Context context;
    PackageManager packageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login_dashboard);
        preferenceManager = new PreferenceManager(LoginDashboardActivity.this);
        sharedPref = new SharedPref(LoginDashboardActivity.this);

        context = getApplicationContext();
        packageManager = context.getPackageManager();
        package_name = context.getPackageName();
        version_code = BuildConfig.VERSION_CODE;
        //version_name = BuildConfig.VERSION_NAME;

        try {
            version_name = packageManager.getPackageInfo(package_name, 0).versionName;
            //version_code = packageManager.getPackageInfo(package_name, 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        login_dashboard_version = (TextView) findViewById(R.id.login_dashboard_version);
        login_dashboard_version.setText("V - " + version_name);
        //update_service();

        if(!preferenceManager.getPreferenceValues(Preference_Constant.ROLE_ID).equalsIgnoreCase("")){
            Intent intent = new Intent(LoginDashboardActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }else{
            init();
            default_confiq();
        }
    }

    private void update_service() {

                JSONObject param = new JSONObject();
                try {
                    param.put("version_code", version_code);
                    param.put("version_name", version_name);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
                AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
                Retrofit retrofit = api.getRetrofitInstance();
                APIRequest apiRequest = retrofit.create(APIRequest.class);

                Call<JsonObject> responseCall = apiRequest.oauthRequest(requestBody);
                DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
                DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
                api.postRequest(responseCall, this, 1);

            }

    private void init(){
        farmer_login_btn = (Button) findViewById(R.id.farmer_login_btn);
        department_login_btn = (Button) findViewById(R.id.department_login_btn);
    }

    private void default_confiq(){

        farmer_login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new FancyAlertDialog.Builder(LoginDashboardActivity.this)
                        .setTitle("माहिती")
                        .setBackgroundColor(Color.parseColor("#d32e18"))
                        .setMessage("आपण नवीन वापरकर्ता असल्यास कृपया नोंदणी बटणावर क्लिक करा")
                        .setNegativeBtnText("लॉगिन करा")
                        .setIcon(R.drawable.ic_error_outline_black_24dp, Icon.Visible)
                        .setPositiveBtnBackground(Color.parseColor("#FFA9A7A8"))
                        .setPositiveBtnText("नोंदणी करा")
                        .setNegativeBtnBackground(Color.parseColor("#d32e18"))
                        .setAnimation(Animation.POP)
                        .isCancellable(true)
                        .OnPositiveClicked(new FancyAlertDialogListener() {
                            @Override
                            public void OnClick() {
                                Intent intent = new Intent(LoginDashboardActivity.this, FarmerOTPLoginActivity.class);
                                startActivity(intent);
                            }
                        })
                        .OnNegativeClicked(new FancyAlertDialogListener() {
                            @Override
                            public void OnClick() {

                                Intent intent = new Intent(LoginDashboardActivity.this, LoginActivity.class);
                                intent.putExtra("type","farmer");
                                intent.putExtra("islogin","true");
                                startActivity(intent);
                            }
                        })
                        .build();
            }
        });

        department_login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginDashboardActivity.this, LoginActivity.class);
                intent.putExtra("type","department");
                intent.putExtra("islogin","true");
                startActivity(intent);
            }
        });
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try{

            if(jsonObject != null){

                if(i == 1){
                        if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                            ResponseModel responseModel = new ResponseModel(jsonObject);
                            if (responseModel.isStatus()) {

                            }
                        }else{
                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Alert")
                                    .setContentText("Kindly update the application")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            final String appPackageName = getPackageName(); // package name of the app
                                            try {
                                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                                            } catch (android.content.ActivityNotFoundException anfe) {
                                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                                            }
                                        }
                                    })
                                    .show();
                        }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }
}
