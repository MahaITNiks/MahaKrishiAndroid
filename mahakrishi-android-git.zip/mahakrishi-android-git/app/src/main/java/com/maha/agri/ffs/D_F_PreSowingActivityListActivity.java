package com.maha.agri.ffs;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.maha.agri.BuildConfig;
import com.maha.agri.R;
import com.maha.agri.database.DBHandler;
import com.maha.agri.ffs.adaptor.D_F_PreShowingActivityAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.util.ApConstants;
import com.maha.agri.util.ApUtil;
import com.maha.agri.util.AppLocationManager;
import com.maha.agri.util.BitmapUtil;
import com.maha.agri.util.ManagePermission;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.api.AppinventorIncAPI;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class D_F_PreSowingActivityListActivity extends AppCompatActivity implements ApiCallbackCode, OnMultiRecyclerItemClickListener {


    private PreferenceManager preferenceManager;
    private DBHandler dbHandler;
    private String schemeID;
    private String userID;
    private String reg_type;
    private String villageId;
    private String cropID;
    private String planId;
    private AppLocationManager locationManager;

    // For Image upload
    static final Integer CAMERA = 0x5;
    private static final String IMAGE_DIRECTORY = "/Krisi_SMA";
    private static final int APP_PERMISSION_REQUEST_CODE = 111;
    String currentTime;
    private ManagePermission managePermissions;
    private File photoFile = null;
    private Transformation transformation;
    private String selectedImage = "0";

    private TextView visitTitle;
    private RecyclerView activityRecyclerView;

    private Button submitBtn;
    private D_F_PreShowingActivityAdapter activityAdapter;
    private String preShowingVisit;
    private JSONArray preVisitArray;
    private JSONArray activitiesWithUrlArray;
    private String preShowingVisitActId;
    private boolean isDetailAdded = false;
    private double lat1 = 0.0;
    private double lang1 = 0.0;
    private double lat2 = 0.0;
    private double lang2 = 0.0;
    private ProgressDialog progress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_f_pre_sowing_activities_list);

        getSupportActionBar().setTitle("Pre Sowing Visits");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferenceManager = new PreferenceManager(D_F_PreSowingActivityListActivity.this);
        currentTime = ApUtil.getCurrentTimeStamp();
        dbHandler = new DBHandler(D_F_PreSowingActivityListActivity.this);

        init();
        defaultConfig();
    }

    private void init() {
        visitTitle = (TextView) findViewById(R.id.visitTitle);
        activityRecyclerView = (RecyclerView) findViewById(R.id.activityRecyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        activityRecyclerView.setLayoutManager(linearLayoutManager);
        submitBtn = (Button) findViewById(R.id.submitBtn);
        userID = preferenceManager.getPreferenceValues(Preference_Constant.USER_ID);
    }


    private void defaultConfig() {

        String table_name = DBHandler.TABLE_PRE_SHOWING_DETAILS;
        dbHandler.deleteTableData(table_name);

        String activities = getIntent().getStringExtra("ShowingActivities");
        if (!activities.equalsIgnoreCase("")) {
            try {
                JSONArray activitiesArray = new JSONArray(activities);

                for (int i = 0; activitiesArray.length() > i; i++) {
                    JSONObject jsonObject = activitiesArray.getJSONObject(i);
                    preShowingVisit = jsonObject.getString("pre_visit_days");
                    String activity = jsonObject.getString("activities");
                    String activityID = jsonObject.getString("id");
                    String unit = jsonObject.getString("unit");

                    dbHandler.insertPreShowingVisitDetail(userID, villageId, preShowingVisit, activity, activityID, cropID, planId, unit, "", "", "", "","","0");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            JSONArray preShowingVisitDetail = dbHandler.getPreShowingActivityList(preShowingVisit);
            if (preShowingVisitDetail.length() > 0) {
                activityAdapter = new D_F_PreShowingActivityAdapter(this, this, preShowingVisitDetail);
                activityRecyclerView.setAdapter(activityAdapter);
            }
        }

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitBtnAction();
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();

        schemeID = preferenceManager.getPreferenceValues(Preference_Constant.SCHEME_ID);
        reg_type = AppSettings.getInstance().getValue(this, ApConstants.kFARMER_REG_TYPE, ApConstants.kFARMER_REG_TYPE);
        villageId = AppSettings.getInstance().getValue(this, ApConstants.kVILLAGE_ID_DEMO_FFS, ApConstants.kVILLAGE_ID_DEMO_FFS);
        cropID = AppSettings.getInstance().getValue(this, ApConstants.kCROP_ID_DEMO_FFS, ApConstants.kCROP_ID_DEMO_FFS);
        planId = AppSettings.getInstance().getValue(this, ApConstants.kPLAN_ID_DEMO_FFS, ApConstants.kPLAN_ID_DEMO_FFS);

        preShowingVisit = getIntent().getStringExtra("visitName");
        preVisitArray = dbHandler.getPreShowingActivityList(preShowingVisit);
        visitTitle.setText(preShowingVisit);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (preVisitArray.length() > 0 && isDetailAdded) {
                    backPressPermission();
                } else {
                    finish();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (preVisitArray.length() > 0 && isDetailAdded) {
            backPressPermission();
        } else {
            super.onBackPressed();
        }
    }

    private void backPressPermission() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage("On BackPress you loss your saved data. You want to continue")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbHandler.deleteTableData(DBHandler.TABLE_PRE_SHOWING_DETAILS);
                        dialog.dismiss();
                        finish();
                    }
                })

                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();

        alertDialog.show();
    }

    private void progressDialog() {
        progress = new ProgressDialog(this);
        progress.setTitle("Please Wait...");
        progress.setMessage("loading data...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.show();
    }


    @Override
    public void onMultiRecyclerViewItemClick(int i, Object o) {
        JSONObject jsonObject = (JSONObject) o;

        try {
            preShowingVisitActId = jsonObject.getString("activity_id");
            if (i == 1) {
                selectedImage = "1";
                if ((ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    // && (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ){
                    locationManager = new AppLocationManager(this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }

            if (i == 2) {
                selectedImage = "2";
                if ((ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                        // && (ContextCompat.checkSelfPermission(D_F_PreSowingActivityListActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
                ){
                    locationManager = new AppLocationManager(this);
                    takeImageFromCameraUri();
                } else {
                    String[] permissionRequest = {
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            // Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    };
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionRequest, APP_PERMISSION_REQUEST_CODE);
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void updateAdaptorArray(String imgUrl, String imageNum) {
        JSONArray preShowingArray = dbHandler.getPreShowingActivityList(preShowingVisit);
        for (int i = 0; preShowingArray.length() > i; i++) {
            try {
                JSONObject jsonObject = preShowingArray.getJSONObject(i);
                String actId = jsonObject.getString("activity_id");
                String visitName = jsonObject.getString("visit_day");
                String activity = jsonObject.getString("activity");
                String unit = jsonObject.getString("unit");
                String img1 = jsonObject.getString("img1");
                String lat1_lang1 = jsonObject.getString("lat_lang1");
                String img2 = jsonObject.getString("img2");
                String lat2_lang2 = jsonObject.getString("lat_lang2");

                if (actId.equalsIgnoreCase(preShowingVisitActId)) {
                    if (imageNum.equalsIgnoreCase("1")) {
                        dbHandler.updatePreShowingVisitDetail(userID, villageId, visitName, activity, actId, cropID, planId, unit, "", imgUrl,lat1+"_"+lang1, img2, lat2_lang2,"0");
                    } else if (imageNum.equalsIgnoreCase("2")) {
                        dbHandler.updatePreShowingVisitDetail(userID, villageId, visitName, activity, actId, cropID, planId, unit, "", img1, lat1_lang1,imgUrl, lat2+"_"+lang2,"0");
                    }
                    preShowingVisitActId = "";
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        activityAdapter.mDataArray = dbHandler.getPreShowingActivityList(preShowingVisit);
        activityAdapter.notifyDataSetChanged();

        progress.dismiss();
    }


    private void submitBtnAction() {

        JSONArray preShowingVisitDetail = dbHandler.getPreShowingActivityList(preShowingVisit);
        boolean visitDetailAdded = false;
        for (int i = 0; preShowingVisitDetail.length() > i; i++) {
            try {
                JSONObject jsonObject = preShowingVisitDetail.getJSONObject(i);
                String is_submitted = jsonObject.getString("is_submitted");
                if (is_submitted.equalsIgnoreCase("0")) {
                    visitDetailAdded = false;
                    break;
                } else {
                    visitDetailAdded = true;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (!visitDetailAdded) {
            UIToastMessage.show(this, "Please fill all activity detail");
        } else {
            JSONObject param = new JSONObject();
            try {
                param.put("reg_type", reg_type);
                param.put("plan_id", planId);
                param.put("pre_sowingvisit_details", preShowingVisitDetail);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
            AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);
            Call<JsonObject> responseCall = apiRequest.insertPreShowingDetail(requestBody);

            DebugLog.getInstance().d("inset_PreShowing Detail=" + responseCall.request().toString());
            DebugLog.getInstance().d("inset_PreShowing=" + AppUtility.getInstance().bodyToString(responseCall.request()));
            api.postRequest(responseCall, this, 1);
        }
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                // activity image upload response
                if (i == 1) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        UIToastMessage.show(this, responseModel.getMsg());
                        finish();
                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                    }
                }


                if (i == 2) {
                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        UIToastMessage.show(this, responseModel.getMsg());

                        JSONObject imgJSon = jsonObject.getJSONObject("data");
                        String imgUrl = imgJSon.getString("file_url");
                        isDetailAdded = true;
                        if (selectedImage.equalsIgnoreCase("1")) {
                            AppSettings.getInstance().setValue(this, ApConstants.kPRE_SHOWING_IMG1_URL, imgUrl);
                            updateAdaptorArray(imgUrl, selectedImage);
                        } else if (selectedImage.equalsIgnoreCase("2")) {
                            AppSettings.getInstance().setValue(this, ApConstants.kPRE_SHOWING_IMG2_URL, imgUrl);
                            updateAdaptorArray(imgUrl, selectedImage);
                        }

                    } else {
                        UIToastMessage.show(this, responseModel.getMsg());
                        progress.dismiss();
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    // For Image upload
    private void takeImageFromCameraUri() {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(takePictureIntent, 0);

        ResolveInfo res = listCam.get(0);
        final String packageName = res.activityInfo.packageName;
        final Intent intent = new Intent(takePictureIntent);
        intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
        Log.d("Camera Package Name", packageName);
        intent.setPackage(packageName);

        if (intent.resolveActivity(getPackageManager()) != null) {

            File photoDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
            if (!photoDirectory.exists()) {
                photoDirectory.mkdirs();
            }
            photoFile = new File(photoDirectory, userID + "_" + currentTime + ".jpg");

            Uri photoURI = null;
            if ((Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT)) {
                photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".android.fileprovider", photoFile);
            } else {
                photoURI = Uri.fromFile(photoFile);
            }

            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                intent.setClipData(ClipData.newRawUri("", photoURI));
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                    m.invoke(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            startActivityForResult(intent, CAMERA);
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CAMERA) {
                onCameraActivityResult();
            }
        }
    }

    public void onCameraActivityResult() {

        int rotate = 0;
        Bitmap bmp = null;


        if (photoFile != null) {

            if (photoFile.exists()) {
                progressDialog();

                bmp = BitmapUtil.decodeSampledBitmapFromPath(this, photoFile, 1050, true); // BitmapFactory.decodeFile(photopath);
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);

                final String imagePath = "file://" + photoFile;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        uploadImageOnServer(imagePath);
                    }
                }, 2000);


                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(photoFile);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(D_F_PreSowingActivityListActivity.this, "Please select the image for update", Toast.LENGTH_SHORT).show();
        }
    }




    private void uploadImageOnServer(String imagePath) {
        try {

            if (selectedImage.equalsIgnoreCase("1")){
                 lat1 = locationManager.getLatitude();
                 lang1 = locationManager.getLongitude();
            }else if (selectedImage.equalsIgnoreCase("2")){
                 lat2 = locationManager.getLatitude();
                 lang2 = locationManager.getLongitude();
            }


            MultipartBody.Part partBody = null;
            DebugLog.getInstance().d("imgName=" + imagePath);

            Map<String, String> params = new HashMap<>();

            params.put("user_id",preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            params.put("crop_id", cropID);
            params.put("ima_sr_no", selectedImage);

            //creating a file
            File file = new File(photoFile.getPath());

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            partBody = MultipartBody.Part.createFormData("image_name", file.getName(), reqFile);
            AppinventorIncAPI api = new AppinventorIncAPI(this, APIServices.API_URL, "", ApConstants.kMSG, false);
            Retrofit retrofit = api.getRetrofitInstance();
            APIRequest apiRequest = retrofit.create(APIRequest.class);

            //creating a call and calling the upload image method
            Call<JsonObject> responseCall = apiRequest.visit_image_upload(partBody, params);
            api.postRequest(responseCall, this, 2);

            DebugLog.getInstance().d("activity_photo_param=" + responseCall.request().toString());
            DebugLog.getInstance().d("activity_photo_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
