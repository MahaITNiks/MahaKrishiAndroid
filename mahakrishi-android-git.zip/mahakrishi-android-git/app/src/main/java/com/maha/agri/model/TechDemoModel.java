/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.model;

import org.json.JSONObject;

import in.co.appinventor.services_api.app_util.AppUtility;

public class TechDemoModel {

     private int id;
     private String name;
     private int is_selected;
     private JSONObject jsonObject;

     public TechDemoModel(JSONObject jsonObject) {
         this.jsonObject = jsonObject;
     }


    public int getId() {
        id = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "id");
        return id;
    }

    public String getName() {
        name = AppUtility.getInstance().sanitizeJSONObj(this.jsonObject, "name");
        return name;
    }

    public int getIs_selected() {
        is_selected = AppUtility.getInstance().sanitizeIntJSONObj(this.jsonObject, "is_selected");
        return is_selected;
    }


}
