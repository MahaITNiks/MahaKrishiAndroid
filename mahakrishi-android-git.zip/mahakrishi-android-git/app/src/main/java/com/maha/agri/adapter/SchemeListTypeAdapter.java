package com.maha.agri.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.dept_cropsap.CropSapAddFarmerSurveyActivity;
import com.maha.agri.mb_recording.EstimatedSubsidyActivity;
import com.maha.agri.database.DBHandler;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.spot_verification.ComponentTilesActivity;
import com.maha.agri.util.ApConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.listener.OnMultiRecyclerItemClickListener;
import in.co.appinventor.services_api.settings.AppSettings;
import in.co.appinventor.services_api.widget.UIToastMessage;

public class SchemeListTypeAdapter extends RecyclerView.Adapter<SchemeListTypeAdapter.CustomViewHolder> {

    private Context context;
    private OnMultiRecyclerItemClickListener listener;
    private JSONArray scheme_types_array_list;
    private PreferenceManager preferenceManager;
    private JSONObject jsonObject;
    private DBHandler dbHandler;

    public SchemeListTypeAdapter(Context context, JSONArray scheme_types_array_list, PreferenceManager preferenceManager, OnMultiRecyclerItemClickListener listener) {
        this.context = context;
        this.listener = listener;
        this.scheme_types_array_list = scheme_types_array_list;
        this.preferenceManager = preferenceManager;

    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private TextView listTitleTextView;
        private ImageView scheme_act_number_tv;
        private LinearLayout scheme_list_type_ll;


        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            listTitleTextView = (TextView) mView.findViewById(R.id.listTitle);
            scheme_act_number_tv = (ImageView) mView.findViewById(R.id.scheme_act_number_tv);
            scheme_list_type_ll = (LinearLayout) mView.findViewById(R.id.scheme_list_type_ll);
            listTitleTextView.setTypeface(null, Typeface.BOLD);

        }
    }

    @Override
    public SchemeListTypeAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.schemelist_group_single_item, parent, false);
        return new SchemeListTypeAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SchemeListTypeAdapter.CustomViewHolder holder, int position) {
        dbHandler = new DBHandler(context);

        try {

            jsonObject = scheme_types_array_list.getJSONObject(position);
            holder.scheme_list_type_ll.setTag(position);
            holder.listTitleTextView.setText(jsonObject.getString("name"));
            //holder.scheme_act_number_tv.setText(jsonObject.getString("sr_no"));
            holder.scheme_act_number_tv.setImageResource(R.drawable.ic_arrow_right_black_24dp);


            holder.scheme_list_type_ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    JSONObject sledJSON = new JSONObject();
                    String actName = "";
                    try {
                        sledJSON = scheme_types_array_list.getJSONObject(index);
                        String activityId = sledJSON.getString("id");
                        actName = scheme_types_array_list.getJSONObject(index).getString("name");
                        preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_NAME, actName);
                        preferenceManager.putPreferenceValues(Preference_Constant.ACTIVITY_ID, activityId);
                        AppSettings.getInstance().setValue(context, ApConstants.kSLED_ACTIVITY,activityId);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        String has_subactivity = scheme_types_array_list.getJSONObject(index).getString("has_subactivity");

                        if (has_subactivity.equalsIgnoreCase("0")) {
                            if (isNetworkAvailable()) {
                                if (dbHandler.getAllOfflineSchemeWorkDetails().length() > 0) {
                                    UIToastMessage.show(context, "Please sync offline task details");
                                } else if (actName.equalsIgnoreCase("FFS")) {
                                    listener.onMultiRecyclerViewItemClick(1, sledJSON);

                                } else if (actName.equalsIgnoreCase("Demonstration")) {
                                    listener.onMultiRecyclerViewItemClick(2, sledJSON);

                                } else if (actName.equalsIgnoreCase("CROPSAP")) {
                                    Intent intent = new Intent(context, CropSapAddFarmerSurveyActivity.class);
                                    context.startActivity(intent);
                                } else if (actName.equalsIgnoreCase("Physical Verification")) {
                                    Intent intent = new Intent(context, ComponentTilesActivity.class);
                                    context.startActivity(intent);
                                }

                            }
                        } else if (has_subactivity.equalsIgnoreCase("1")) {
                            if (isNetworkAvailable()) {
                                if (dbHandler.getAllOfflineSchemeWorkDetails().length() > 0) {
                                    UIToastMessage.show(context, "Please sync offline task details");
                                } else if (actName.equalsIgnoreCase("MB Recording")) {
                                    Intent intent = new Intent(context, EstimatedSubsidyActivity.class);
                                    intent.putExtra("schemeList", scheme_types_array_list.toString());
                                    intent.putExtra("position", position);
                                    context.startActivity(intent);
                                }

                            }
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return scheme_types_array_list.length();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SchemeListTypeAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SchemeListTypeAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
