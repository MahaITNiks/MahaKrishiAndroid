package com.maha.agri.cropsowingreport;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class ConsolidatedExpandableAdapter extends BaseExpandableListAdapter {

    private Context context;
    private JSONArray village_wise_crop_data;
    private JSONArray crop_data;
    private JSONObject village_jsonObject;
    String cropname = "", area_current_week = "", area_last_week = "";
    TextView listTitleTextView,total_affected_area_expandedListItem;

    public ConsolidatedExpandableAdapter(Context context, JSONArray village_wise_crop_data) {
        this.context = context;
        this.village_wise_crop_data = village_wise_crop_data;
    }

    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        String childCropName = "";
        try {
            JSONArray childData =  village_wise_crop_data.getJSONObject(listPosition).getJSONArray("crop_data");
            childCropName = childData.getJSONObject(expandedListPosition).getString("crop_name");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return childCropName;
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(int listPosition, int expandedListPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        ConsolidatedExpandableAdapter.ChildViewHolder cholder = new ConsolidatedExpandableAdapter.ChildViewHolder();

        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.crop_sown_report_crop_single_item, null);
        }
        TextView crop_expandedListTextView = (TextView) convertView.findViewById(R.id.crop_expandedListItem);
        TextView area_upto_last_week_expandedListItem = (TextView)convertView.findViewById(R.id.area_upto_last_week_expandedListItem);
        TextView area_in_current_week_expandedListItem = (TextView)convertView.findViewById(R.id.area_in_current_week_expandedListItem);

        cholder.addView(crop_expandedListTextView);
        cholder.addView(area_upto_last_week_expandedListItem);
        convertView.setTag(cholder);

        ConsolidatedExpandableAdapter.ChildViewHolder childholder = (ConsolidatedExpandableAdapter.ChildViewHolder) convertView.getTag();
        TextView crop_holder_expandedListTextView = (TextView) childholder.getView(R.id.crop_expandedListItem);
        TextView area_upto_last_week_holder_expandedListItem = (TextView) childholder.getView(R.id.affected_area_expandedListItem);
        TextView area_in_current_week_holder_expandedListItem = (TextView) childholder.getView(R.id.area_in_current_week_expandedListItem);

        try {
            JSONObject crop_data_json_object = crop_data.getJSONObject(expandedListPosition);
            cropname = crop_data_json_object.getString("crop_sown_name");
            area_last_week = crop_data_json_object.getString("area_last_week");
            area_current_week = crop_data_json_object.getString("area_current_week");
            crop_holder_expandedListTextView.setText(cropname);
            area_upto_last_week_holder_expandedListItem.setText(area_last_week);
            area_in_current_week_holder_expandedListItem.setText(area_current_week);

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return convertView;
    }

    static class ChildViewHolder {
        private HashMap<Integer, View> storedViews = new HashMap<Integer, View>();
        public ConsolidatedExpandableAdapter.ChildViewHolder addView(View view)
        {
            int id = view.getId();
            storedViews.put(id, view);
            return this;
        }

        public View getView(int id)
        {
            return storedViews.get(id);
        }
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        JSONArray childData = new JSONArray();
        try {
            childData =  village_wise_crop_data.getJSONObject(groupPosition).getJSONArray("crop_data");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return childData.length();

    }

    @Override
    public Object getGroup(int listPosition) {
        return null;
    }

    @Override
    public int getGroupCount() {
        return this.village_wise_crop_data.length();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }


    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        try {
            village_jsonObject = village_wise_crop_data.getJSONObject(listPosition);
            crop_data = village_jsonObject.getJSONArray("crop_data");

            if (convertView == null) {
                LayoutInflater layoutInflater = (LayoutInflater) this.context.
                        getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = layoutInflater.inflate(R.layout.village_group_single_item, null);
            }
            listTitleTextView = (TextView) convertView.findViewById(R.id.village_expandedListItem);
            total_affected_area_expandedListItem = (TextView)convertView.findViewById(R.id.total_affected_area_expandedListItem);
            listTitleTextView.setText(village_jsonObject.getString("village_name"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        return convertView;
    }


    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }
}
