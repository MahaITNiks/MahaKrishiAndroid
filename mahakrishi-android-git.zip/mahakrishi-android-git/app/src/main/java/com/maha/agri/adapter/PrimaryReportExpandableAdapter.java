package com.maha.agri.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PrimaryReportExpandableAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> expandableListVillage;
    private HashMap<String, String> expandableListcCrop;
    private JSONArray village_wise_crop_data;
    private JSONArray crop_data;
    private JSONObject village_jsonObject;
    String cropname = "", total_affected_area = "";
    int total_affected_area_int = 0;
    TextView listTitleTextView,total_affected_area_expandedListItem;
    ArrayList<HashMap<String, String>> lstAns = new ArrayList<HashMap<String,String>>();;

    public PrimaryReportExpandableAdapter(Context context, JSONArray village_wise_crop_data) {
        this.context = context;
        this.village_wise_crop_data = village_wise_crop_data;
    }

    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        String childCropName = "";
        try {
            JSONArray childData =  village_wise_crop_data.getJSONObject(listPosition).getJSONArray("crop_data");
            childCropName = childData.getJSONObject(expandedListPosition).getString("crop_name");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return childCropName;
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(int listPosition, int expandedListPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        ChildViewHolder cholder = new ChildViewHolder();

        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.crop_group_single_item, null);
        }
        TextView crop_expandedListTextView = (TextView) convertView.findViewById(R.id.crop_expandedListItem);
        TextView affected_area_expandedListItem = (TextView)convertView.findViewById(R.id.affected_area_expandedListItem);

        cholder.addView(crop_expandedListTextView);
        cholder.addView(affected_area_expandedListItem);
        convertView.setTag(cholder);

        ChildViewHolder childholder = (ChildViewHolder) convertView.getTag();
        TextView crop_holder_expandedListTextView = (TextView) childholder.getView(R.id.crop_expandedListItem);
        TextView affected_area_holder_expandedListItem = (TextView) childholder.getView(R.id.affected_area_expandedListItem);

        try {
            JSONObject crop_data_json_object = crop_data.getJSONObject(expandedListPosition);
            cropname = crop_data_json_object.getString("crop_name");
            total_affected_area = crop_data_json_object.getString("affectedArea");
            crop_holder_expandedListTextView.setText(cropname);
            affected_area_holder_expandedListItem.setText(total_affected_area);

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return convertView;
    }

    static class ChildViewHolder {
        private HashMap<Integer, View> storedViews = new HashMap<Integer, View>();
        public ChildViewHolder addView(View view)
        {
            int id = view.getId();
            storedViews.put(id, view);
            return this;
        }

        public View getView(int id)
        {
            return storedViews.get(id);
        }
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        JSONArray childData = new JSONArray();
        try {
             childData =  village_wise_crop_data.getJSONObject(groupPosition).getJSONArray("crop_data");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return childData.length();

    }

    @Override
    public Object getGroup(int listPosition) {
        return null;
    }

    @Override
    public int getGroupCount() {
        return this.village_wise_crop_data.length();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }


    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        //String listTitle = (String) getGroup(listPosition);
        try {
            village_jsonObject = village_wise_crop_data.getJSONObject(listPosition);
            crop_data = village_jsonObject.getJSONArray("crop_data");

            if (convertView == null) {
                LayoutInflater layoutInflater = (LayoutInflater) this.context.
                        getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = layoutInflater.inflate(R.layout.village_group_single_item, null);
            }
            listTitleTextView = (TextView) convertView.findViewById(R.id.village_expandedListItem);
            total_affected_area_expandedListItem = (TextView)convertView.findViewById(R.id.total_affected_area_expandedListItem);
            listTitleTextView.setText(village_jsonObject.getString("village_name"));
            total_affected_area = village_jsonObject.getString("totalAffected");
            total_affected_area_expandedListItem.setText(total_affected_area);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return convertView;
    }


    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }
}
