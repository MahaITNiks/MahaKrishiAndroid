package com.maha.agri.panchnama;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.adapter.PrimaryReportExpandableAdapter;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class GeneratePrimaryReportActivity extends AppCompatActivity implements ApiCallbackCode {

    private TextView total_affected_crop_count, total_affected_area_count;
    private Button primary_report_submit_btn, primary_report_cancel_btn;
    private String district_name, taluka_name, sajja_name, season_name, genrate_primary_report_data;
    private String  affectedArea;
    private int affectedArea_int = 0,division_id = 0, district_id = 0, taluka_id = 0, circle_id = 0, sajja_id = 0,season_id=0,crop_type_id = 0,horti_type_id = 0;
    private RecyclerView generate_report_add_more_rv;
    PreferenceManager preferenceManager;
    SharedPref sharedPref;
    JSONArray affectedJsonArray = new JSONArray();
    JSONArray village_wise_crop_data = new JSONArray();
    JSONArray crop_data = new JSONArray();
    private JSONObject affected_area_json_object;

    private ExpandableListView report_expandableListView;
    private List<String> expandableListVillage;
    private HashMap<String, List<String>> expandableListcCrop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_primary_report);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Generate Primary Report");
        preferenceManager = new PreferenceManager(GeneratePrimaryReportActivity.this);
        sharedPref = new SharedPref(GeneratePrimaryReportActivity.this);
        init();
        default_config();

    }

    private void init() {
        primary_report_submit_btn = (Button) findViewById(R.id.primary_report_submit_btn);
        primary_report_cancel_btn = (Button) findViewById(R.id.primary_report_cancel_btn);
        report_expandableListView = (ExpandableListView)findViewById(R.id.report_expandableListView);

        primary_report_submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PrimaryReportSave();
            }
        });

        primary_report_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });

    }

    private void default_config() {

        Intent intent = getIntent();
        district_name = intent.getStringExtra("district_name");
        district_id = intent.getIntExtra("district_id",0);
        division_id = intent.getIntExtra("division_id",0);
        taluka_name = intent.getStringExtra("taluka_name");
        taluka_id = intent.getIntExtra("taluka_id",0);
        circle_id = intent.getIntExtra("circle_id",0);
        sajja_name = intent.getStringExtra("sajja_name");
        sajja_id = intent.getIntExtra("sajja_id",0);
        season_name = intent.getStringExtra("season_name");
        season_id = intent.getIntExtra("season_id",0);
        crop_type_id = intent.getIntExtra("crop_type_id",0);
        horti_type_id = intent.getIntExtra("horti_type_id",0);
        genrate_primary_report_data = intent.getStringExtra("affected_crop");


        try {
            affectedJsonArray = new JSONArray(genrate_primary_report_data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Village_wise_crop_data();

    }

    private void Village_wise_crop_data() {
        JSONObject param = new JSONObject();
        try {
            param.put("village_wise_c_data", affectedJsonArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.MASTER_API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.primary_report_village_wise_crop_data(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }

    private void PrimaryReportSave() {
        JSONObject param = new JSONObject();
        try {
            param.put("id", "");
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
            param.put("division_id", division_id);
            param.put("district_id", district_id);
            param.put("taluka_id", taluka_id);
            param.put("circle_id", circle_id);
            param.put("sajja_id", sajja_id);
            param.put("season_id", season_id);
            param.put("crop_type_id", crop_type_id);
            param.put("horti_type_id", horti_type_id);
            param.put("priAffetedArea", affectedJsonArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);

        Call<JsonObject> responseCall = apiRequest.primary_report_save(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 2);
    }

    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {

                if (i == 1) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {
                            village_wise_crop_data = jsonObject.getJSONArray("data");
                            PrimaryReportExpandableAdapter primaryreportexpandableadapter = new PrimaryReportExpandableAdapter(GeneratePrimaryReportActivity.this,village_wise_crop_data);
                            report_expandableListView.destroyDrawingCache();
                            report_expandableListView.setAdapter(primaryreportexpandableadapter);
                            primaryreportexpandableadapter.notifyDataSetChanged();
                        }
                     }
                }

                else

                    if (i == 2) {

                    if (jsonObject.getString("status").equalsIgnoreCase("200")) {
                        ResponseModel responseModel = new ResponseModel(jsonObject);
                        if (responseModel.isStatus()) {

                            new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                    .setTitleText("Primary Report")
                                    .setContentText("Submitted Successfully")
                                    .setConfirmText("Ok")
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Intent intent = new Intent(GeneratePrimaryReportActivity.this,DepartmentCategoryPanchnamaActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    })
                                    .show();


                        }
                    }
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
