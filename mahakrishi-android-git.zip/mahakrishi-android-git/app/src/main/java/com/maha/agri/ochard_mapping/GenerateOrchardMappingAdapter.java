package com.maha.agri.ochard_mapping;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.preferenceconstant.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class GenerateOrchardMappingAdapter extends RecyclerView.Adapter<GenerateOrchardMappingAdapter.MyViewHolder> {
    private JSONArray add_more_list;
    private JSONObject jsonObject;
    private Context context;
    private PreferenceManager preferencemanager;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView gen_orchard_mapping_survey_gat_tv,gen_orchard_mapping_crop_tv,gen_orchard_mapping_area_tv;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.gen_orchard_mapping_survey_gat_tv = itemView.findViewById(R.id.gen_orchard_mapping_survey_gat_tv);
            this.gen_orchard_mapping_crop_tv = itemView.findViewById(R.id.gen_orchard_mapping_crop_tv);
            this.gen_orchard_mapping_area_tv = itemView.findViewById(R.id.gen_orchard_mapping_area_tv);

        }
    }

    public GenerateOrchardMappingAdapter(JSONArray add_more_list,Context context) {
        this.add_more_list = add_more_list;
        this.context = context;

    }

    @Override
    public GenerateOrchardMappingAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                        int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.generate_orchard_single_item, parent, false);

        GenerateOrchardMappingAdapter.MyViewHolder myViewHolder = new GenerateOrchardMappingAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final GenerateOrchardMappingAdapter.MyViewHolder holder, final int listPosition) {

        try {
            jsonObject = add_more_list.getJSONObject(listPosition);
            holder.gen_orchard_mapping_survey_gat_tv.setText(jsonObject.getString("surveyorgutvalue"));
            holder.gen_orchard_mapping_crop_tv.setText(jsonObject.getString("crop_name"));
            holder.gen_orchard_mapping_area_tv.setText(jsonObject.getString("area"));
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (add_more_list != null) {
            return add_more_list.length();
        } else {
            return 0;
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private GenerateOrchardMappingAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final GenerateOrchardMappingAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
