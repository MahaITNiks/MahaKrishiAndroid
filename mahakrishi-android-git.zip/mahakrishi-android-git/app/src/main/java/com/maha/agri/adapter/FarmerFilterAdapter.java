/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FarmerFilterAdapter extends BaseAdapter {


    private final Context mContext;
    private final JSONArray mDataArray;

    public FarmerFilterAdapter(Context mContext, JSONArray mDataArray) {
        this.mContext = mContext;
        this.mDataArray = mDataArray;

    }

    @Override
    public int getCount() {
        return mDataArray.length();
    }

    @Override
    public Object getItem(int position) {
        try {
            return mDataArray.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;

        if (convertView == null) {

            viewHolder = new ViewHolder();

            LayoutInflater mLayoutInflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            if (mLayoutInflater != null) {
                convertView = mLayoutInflater.inflate(R.layout.list_filter, null);

                viewHolder.checkImageView =  convertView.findViewById(R.id.checkImageView);
                viewHolder.nameTextView =  convertView.findViewById(R.id.nameTextView);
                convertView.setTag(viewHolder);
            }

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        try {
            JSONObject jsonObject = mDataArray.getJSONObject(position);

            viewHolder.nameTextView.setText(jsonObject.getString("name"));
//            if (jsonObject.getString("icon") == null) {
//                viewHolder.checkImageView.setImageDrawable(null);
//            } else {
                viewHolder.checkImageView.setVisibility(View.VISIBLE);
//            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }


    private static class ViewHolder {
        private TextView nameTextView;
        private ImageView checkImageView;
    }
}
