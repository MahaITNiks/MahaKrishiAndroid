package com.maha.agri.activity.approve_attendance;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.maha.agri.R;
import com.maha.agri.model.ResponseModel;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;
import com.maha.agri.preferenceconstant.SharedPref;
import com.maha.agri.util.ApConstants;
import com.maha.agri.web_services.APIRequest;
import com.maha.agri.web_services.APIServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import in.co.appinventor.services_api.api.AppinventorApi;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.debug.DebugLog;
import in.co.appinventor.services_api.listener.ApiCallbackCode;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;

public class AttendanceReportActivity extends AppCompatActivity implements ApiCallbackCode {
    private TextView approve_month_yearTv, total_no_of_approved_daysTv, approveRemarkTv;
    private PreferenceManager preferenceManager;
    private SharedPref sharedPref;
    private JSONArray approved_attendance_yearwise_list;
    private ImageView approved_image;
    private String is_Completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_report);
        getSupportActionBar().setTitle("Attendance Report");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferenceManager = new PreferenceManager(AttendanceReportActivity.this);
        sharedPref = new SharedPref(AttendanceReportActivity.this);
        init();
        approved_attendance_year_wise_Webservice();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void init() {
        approve_month_yearTv = (TextView) findViewById(R.id.approve_month_year);
        total_no_of_approved_daysTv = (TextView) findViewById(R.id.no_days_approved_Tv);
        approveRemarkTv = (TextView) findViewById(R.id.remarkTv);
        approved_image = (ImageView) findViewById(R.id.approved_image_view);
    }

    private void approved_attendance_year_wise_Webservice() {
        JSONObject param = new JSONObject();
        try {
            param.put("user_id", preferenceManager.getPreferenceValues(Preference_Constant.USER_ID));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody requestBody = AppUtility.getInstance().getRequestBody(param.toString());
        AppinventorApi api = new AppinventorApi(this, APIServices.API_URL, "", ApConstants.kMSG, true);
        Retrofit retrofit = api.getRetrofitInstance();
        APIRequest apiRequest = retrofit.create(APIRequest.class);
        Call<JsonObject> responseCall = apiRequest.approve_attendance_days_yearwise(requestBody);
        DebugLog.getInstance().d("facilitator_auth_param=" + responseCall.request().toString());
        DebugLog.getInstance().d("facilitator_auth_param=" + AppUtility.getInstance().bodyToString(responseCall.request()));
        api.postRequest(responseCall, this, 1);
    }


    @Override
    public void onResponse(JSONObject jsonObject, int i) {

        try {

            if (jsonObject != null) {
                if (i == 1) {

                    ResponseModel responseModel = new ResponseModel(jsonObject);
                    if (responseModel.isStatus()) {
                        approved_attendance_yearwise_list = responseModel.getData();
                        JSONObject data = approved_attendance_yearwise_list.getJSONObject(0);
                        total_no_of_approved_daysTv.setText(data.getString("total_no_of_days_approved_by_senior"));
                        approveRemarkTv.setText(data.getString("remark"));
                        approve_month_yearTv.setText(data.getString("month_name") + " " + " / " + " " + data.getString("year"));
                        approved_image.setVisibility(View.VISIBLE);
                    } else {
                        total_no_of_approved_daysTv.setText("");
                        approveRemarkTv.setText("");
                        approve_month_yearTv.setText(responseModel.getMsg());
                        approved_image.setVisibility(View.GONE);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Object o, Throwable throwable, int i) {

    }

}
