package com.maha.agri.adapter;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.maha.agri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PhyVeriCatAdapter extends RecyclerView.Adapter<PhyVeriCatAdapter.CustomViewHolder> {

    private Context context;
    private JSONArray phy_veri_form_list;
    private JSONObject phy_veri_form_json_object;
    private String form_id = "";

    public PhyVeriCatAdapter(Context context,JSONArray phy_veri_form_list) {
        this.context = context;
        this.phy_veri_form_list = phy_veri_form_list;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private RelativeLayout tile_form_rl;
        private TextView tile_form_tv;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            tile_form_tv = mView.findViewById(R.id.tile_form_tv);
            tile_form_rl = mView.findViewById(R.id.tile_form_rl);
        }
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.tile_form_single_item, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        try {
            phy_veri_form_json_object = phy_veri_form_list.getJSONObject(position);

            /*holder.tile_form_rl.setTag(position);

            holder.tile_form_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = (Integer) v.getTag();
                    try {
                        form_id = phy_veri_form_list.getJSONObject(index).getString("id");
                        switch (form_id) {

                            case "1":
                                Intent int_1 = new Intent(context, FarmerMechanizationActivity.class);
                                context.startActivity(int_1);
                                break;

                            case "2":
                                Intent int_2 = new Intent(context, CustomerHiringCenterActivity.class);
                                context.startActivity(int_2);
                                break;

                            case "3":
                                Intent int_3 = new Intent(context, DripFormActivity.class);
                                context.startActivity(int_3);
                                break;

                            case "4":
                                Intent int_4 = new Intent(context, SprinklerActivity.class);
                                context.startActivity(int_4);
                                break;

                            case "5":
                                Intent int_5 = new Intent(context, MBCommunityFarmPondActivity.class);
                                context.startActivity(int_5);
                                break;

                            case "6":
                                Intent int_6 = new Intent(context, PipesActivity.class);
                                context.startActivity(int_6);
                                break;

                            case "7":
                                Intent int_7 = new Intent(context, PumpsetActivity.class);
                                context.startActivity(int_7);
                                break;

                            case "8":
                                Intent int_8 = new Intent(context, GreenHouseActivity.class);
                                context.startActivity(int_8);
                                break;

                            case "9":
                                Intent int_9 = new Intent(context, ProtectiveCultivationActivity.class);
                                context.startActivity(int_9);
                                break;

                            case "10":
                                Intent int_10 = new Intent(context, OnionStorageFirstPhysicalActivity1.class);
                                context.startActivity(int_10);
                                break;

                            case "11":
                                Intent int_11 = new Intent(context,PipesActivity.class);
                                context.startActivity(int_11);
                                break;

                            case "12":
                                Intent int_12 = new Intent(context,PumpsetActivity.class);
                                context.startActivity(int_12);
                                break;

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });*/

            holder.tile_form_tv.setText(phy_veri_form_json_object.getString("scheme_tile_form_name"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return phy_veri_form_list.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
