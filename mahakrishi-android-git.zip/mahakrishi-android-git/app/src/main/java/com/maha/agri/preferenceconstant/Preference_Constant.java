package com.maha.agri.preferenceconstant;

public class Preference_Constant {

    public static final String USER_STATUS="userstatuskey";
    public static final String FIRST_NAME = "firstname";
    public static final String MIDDLE_NAME = "middlename";
    public static final String LAST_NAME = "lastname";
    public static final String PRIMARY_JOB_CATEGORY = "primary_job_category";
    public static final String JOB_CATEGORY = "job_category";
    public static final String MOBILE_NUMBER="mobilenumber";
    public static final String ROLE_OFFICER_ID="role_officer_id";
    public static final String ROLE_CHARGE_ID="role_charge_id";
    public static final String CIRCLE_ID="circle_id";
    public static final String CIRCLE_NAME="circle_name";
    public static final String SAJJA_NAME="sajja_name";
    public static final String SAJJA_ID="sajja_id";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String EMAIL = "email";
    public static final String LOGIN_ID = "login_id";
    public static final String ROLE_DESIGNATION = "rol  e_desg";
    public static final String CIRCLE_ASSIGN = "circle_assign";
    public static final String JUNIER_ROLE_ID = "JUNIER_ROLE_ID";
    public static final String PROFILE_PIC = "profile_pic";
    public static final String DISTRICT_CODE="district_code";
    public static final String TALUKA_CODE = "taluka_code";
    public static final String VILLAGE_CODE = "village_code";
    public static final String USER_ID = "userId";
    public static final String ROLE_ID = "roleId";
    public static final String SCHEME_TYPE_ID = "schemeTypeId";
    public static final String SCHEME_ID = "schemeId";
    public static final String SCHEME_NAME = "schemeName";
    public static final String TYPE_ID = "typeId";
    public static final String ACTIVITY_ID = "activityID";
    public static final String NON_SCHEME_ACTIVITY_ID = "activityID";
    public static final String MONTH_FILTER = "month_filter";
    public static final String IS_COMPLETED = "is_completed";
    public static final String ACTIVITY_NAME = "activity_name";
    public static final String SCHEME_lIST_ID = "schemeListId";
    public static final String MONTH_FILTER_POS = "month_filter_pos";

    public static final String FARMER_MOBILE_NUMBER = "farmer_mobile_number";
    public static final String FARMER_MAGAZINE_MONTH_ID = "farmer_magazine_month_id";

    public static final String FARMER_SEASON_ID = "farmer_season_id";

    public static final String FARMER_VILLAGE_LIST_WITH_CROPSAP_COUNT = "farmer_village_list_with_cropsap_count";

    public static final String ADD_MORE_CROP_ID = "add_more_crop_id";

    public static final String District_name_ID = "district_name";
    public static final String taluka_name_ID = "taluka_name";

    public static final String DEMO_TECH_IMAGE1 = "demo_tech_image1";
    public static final String DEMO_TECH_IMAGE2 = "demo_tech_image2";

    public static final String DEMO_ATTENDANCE_IMAGE1 = "demo_attendance_image1";
    public static final String DEMO_ATTENDANCE_IMAGE2 = "demo_attendance_image2";

    public static final String DEMO_AESAOBS_IMAGE1 = "demo_aesaobs_image1";
    public static final String DEMO_AESAOBS_IMAGE2 = "demo_aesaobs_image2";
    public static final String DEMO_AESA_SOWING_DATE = "demo_aesa_sowing_date";

    //mb recording
    public static final String MB_RECORDING_FARMER_REG_ID = "mb_recording_farmer_reg_id";
    public static final String MB_RECORDING_STEP_SOIL_ID = "step_id_soil_id";
    public static final String MB_RECORDING_STEP_SOFT_MURUM_ID = "soft_murum_id";
    public static final String CROPSAP_COTTON_CROP_PLANT_ID = "cotton_crop_plant_id";
    public static final String CROPSAP_COTTON_CROP_LAST_INSERTED_ID = "cotton_crop_last_inserted_id";
    public static final String MB_RECORDING_IMAGE1 = "mb_recording_image1";

    public static final String CROP_SOWING_REPORT_HORTI_ID = "crop_sowing_report_horti_id";
    public static final String CROP_SOWING_REPORT_CROP_TYPE_ID = "crop_sowing_report_crop_type_id";

    //Village Mapping Area
    public static final String VILLAGE_MAPPING_AREA_DIVISON_ID = "village_mapping_area_divison_id";
    public static final String VILLAGE_MAPPING_AREA_DISTRICT_ID = "village_mapping_area_district_id";
    public static final String VILLAGE_MAPPING_AREA_TALUKA_ID = "village_mapping_area_taluka_id";
    public static final String VILLAGE_MAPPING_AREA_CIRCLE_ID = "village_mapping_area_circle_id";
    public static final String VILLAGE_MAPPING_AREA_SAJJA_ID = "village_mapping_area_sajja_id";
    public static final String VILLAGE_MAPPING_AREA_VILLAGE_ID = "village_mapping_area_village_id";
    public static final String VILLAGE_MAPPING_AREA_DISTRICT_NAME = "village_mapping_area_district_name";
    public static final String VILLAGE_MAPPING_AREA_TALUKA_NAME = "village_mapping_area_taluka_name";
    public static final String VILLAGE_MAPPING_AREA_CIRCLE_NAME = "village_mapping_area_circle_name";
    public static final String VILLAGE_MAPPING_AREA_SAJJA_NAME = "village_mapping_area_sajja_name";
    public static final String VILLAGE_MAPPING_AREA_VILLAGE_NAME = "village_mapping_area_village_name";
    public static final String VILLAGE_MAPPING_AREA_GEO_AREA = "village_mapping_area_geo_area_name";
    public static final String VILLAGE_MAPPING_AREA_CUL_AREA = "village_mapping_area_cul_area_name";


}


