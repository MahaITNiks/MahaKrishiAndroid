package com.maha.agri.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maha.agri.R;
import com.maha.agri.activity.user_dashboard.AA.AADashboardActivity;
import com.maha.agri.preferenceconstant.PreferenceManager;
import com.maha.agri.preferenceconstant.Preference_Constant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SwitchProfileAdapter extends RecyclerView.Adapter<SwitchProfileAdapter.CustomViewHolder> {

    private Context context;
    private String[] location_list, role_list;
    private JSONArray assigned_charges;
    private JSONObject assigned_charges_json_object;
    private PreferenceManager preferencemanager;

    public SwitchProfileAdapter(Context context, PreferenceManager preferenceManager, JSONArray assigned_charges) {
        this.context = context;
        this.preferencemanager = preferenceManager;
        this.assigned_charges = assigned_charges;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        private TextView switch_profile_location_name_tv,switch_profile_role_tv;
        private LinearLayout switch_profile_ll;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            switch_profile_location_name_tv = mView.findViewById(R.id.switch_profile_location_name_tv);
            switch_profile_role_tv = mView.findViewById(R.id.switch_profile_role_tv);
            switch_profile_ll = mView.findViewById(R.id.switch_profile_ll);
        }

    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.switch_profile_single_item, viewGroup, false);
        return new SwitchProfileAdapter.CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder customViewHolder, int i) {
        try {
            assigned_charges_json_object = assigned_charges.getJSONObject(i);
            customViewHolder.switch_profile_ll.setTag(i);
            String role_officer = assigned_charges_json_object.getString("role_officer");
            String role_charge = assigned_charges_json_object.getString("role_charge");
            if(role_officer.equalsIgnoreCase("AS")&&role_charge.equalsIgnoreCase("Additional Charge")){
                customViewHolder.switch_profile_location_name_tv.setText("Circle : " + " " + assigned_charges_json_object.getString("circle_name"));
            }else{
                customViewHolder.switch_profile_location_name_tv.setText("Circle : " + " " + assigned_charges_json_object.getString("circle_name") + "||" + "Sajja : " + " " + assigned_charges_json_object.getString("sajja_name"));
            }
            customViewHolder.switch_profile_role_tv.setText(role_officer + " " + role_charge);
            customViewHolder.switch_profile_ll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int index = (Integer) v.getTag();
                        try {
                            String id = assigned_charges.getJSONObject(index).getString("role_officer_id");
                            String role_charge_id = assigned_charges.getJSONObject(index).getString("role_charge_id");
                            String circle_id = assigned_charges.getJSONObject(index).getString("circle_id");
                            String circle_name = assigned_charges.getJSONObject(index).getString("circle_name");
                            preferencemanager.putPreferenceValues(Preference_Constant.ROLE_OFFICER_ID, id);
                            preferencemanager.putPreferenceValues(Preference_Constant.ROLE_CHARGE_ID, role_charge_id);
                            preferencemanager.putPreferenceValues(Preference_Constant.CIRCLE_ID, circle_id);
                            preferencemanager.putPreferenceValues(Preference_Constant.CIRCLE_NAME, circle_name);
                            if(role_officer.equalsIgnoreCase("AA")&&role_charge.equalsIgnoreCase("Primary Charge")||role_officer.equalsIgnoreCase("AA")&&role_charge.equalsIgnoreCase("Additional Charge")){
                                String sajja_id = assigned_charges.getJSONObject(index).getString("sajja_id");
                                String sajja_name = assigned_charges.getJSONObject(index).getString("sajja_name");
                                preferencemanager.putPreferenceValues(Preference_Constant.SAJJA_ID, sajja_id);
                                preferencemanager.putPreferenceValues(Preference_Constant.SAJJA_NAME, sajja_name);
                            }
                            Intent attendance = new Intent(context, AADashboardActivity.class);
                            context.startActivity(attendance);
                            ((Activity)context).finishAffinity();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });

        }catch (Exception e) {

        }

    }

    @Override
    public int getItemCount() {
        return assigned_charges.length();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SwitchProfileAdapter.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SwitchProfileAdapter.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

}


