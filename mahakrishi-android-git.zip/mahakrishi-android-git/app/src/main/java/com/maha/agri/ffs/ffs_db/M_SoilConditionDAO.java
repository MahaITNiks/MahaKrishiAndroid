package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_SoilConditionDAO {

    @Query("SELECT * FROM M_SoilConditionEY")
    List<M_SoilConditionEY> getAll();

    @Query("SELECT * FROM M_SoilConditionEY WHERE uid IN (:userIds)")
    List<M_SoilConditionEY> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM M_SoilConditionEY WHERE uid = :id")
    List<M_SoilConditionEY> checkIdExists(int id);

    @Insert
    void insertAll(M_SoilConditionEY... m_soilCondition);

    @Insert
    void insertOnlySingle(M_SoilConditionEY m_soilConditionEY);

}
