/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.ffs.ffs_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface M_PestDAO {

    @Query("SELECT * FROM M_PestEY")
    List<M_PestEY> getAll();

    @Query("SELECT * FROM M_PestEY WHERE crop_id = :crop_id")
    List<M_PestEY> getCropPest(int crop_id);


    @Query("SELECT * FROM M_PestEY WHERE uid IN (:userIds)")
    List<M_PestEY> loadAllByIds(int[] userIds);

    @Insert
    void insertAll(M_PestEY... m_pestEYS);

    @Insert
    void insertOnlySingle(M_PestEY m_pestEY);


}
