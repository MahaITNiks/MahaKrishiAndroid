/*
 * Copyright (c) 2018. Runtime Solutions Pvt Ltd. All right reserved.
 * Web URL  http://runtime-solutions.com
 * Author Name: Vinod Vishwakarma
 * Linked In: https://www.linkedin.com/in/vvishwakarma
 * Official Email ID : vinod@runtime-solutions.com
 * Email ID: vish.vino@gmail.com
 * Last Modified : 1/12/18 3:21 PM
 */

package com.maha.agri.util;

import android.content.Context;
import android.os.Environment;

import com.maha.agri.enums.CroppingSystem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import in.co.appinventor.services_api.app_util.AppUtility;
import in.co.appinventor.services_api.settings.AppSettings;


public class AppSession {


    private Context mContext;

    public AppSession(Context mContext) {
        this.mContext = mContext;
    }


    //::TODO User Roles

    public int getPMURole() {
        return 3;
    }

    public int getPDATMARole() {
        return 4;
    }

    public int getDSAORole() {
        return 5;
    }

    public int getSDAORole() {
        return 6;
    }

    public int getKVKRole() {
        return 7;
    }

    public int getCARole() {
        return 8;
    }

    public int getAgAsstRole() {
        return 9;
    }

    public int getFFSRole() {
        return 10;
    }

    public int getFarmerRole() {
        return 11;
    }

    public int getAOSDAORole() {
        return 22;
    }

    public int getCOORDRole() {
        return 30;
    }


    public boolean isUserLoggedIn() {
        return AppSettings.getInstance().getBooleanValue(mContext, ApConstants.kIS_LOGGED_IN, false);
    }


    public int getUserId() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kUSER_ID, 0);
    }


    public String getToken() {
        return AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTOKEN);
    }


    public String getTimeStamp() {
        return String.valueOf(System.currentTimeMillis());
    }


    //::TODO Storage Dir

    public File getOnlineStorageDir() {
        File storageDir = new File(Environment.getExternalStorageDirectory().getPath(), ApConstants.kDIR + "/" + ApConstants.kVISITS_DIR + "/" + ApConstants.kVISITS_ONLINE_DIR);
        return storageDir;
    }

    public File getOfflineStorageDir() {
        File storageDir = new File(Environment.getExternalStorageDirectory().getPath(), ApConstants.kDIR + "/" + ApConstants.kVISITS_DIR + "/" + ApConstants.kVISITS_OFFLINE_DIR);
        return storageDir;
    }

    public File getOfflineStorageDirs() {
        String child = ApConstants.kDIR + "/" + ApConstants.kVISITS_DIR + "/" + ApConstants.kVISITS_OFFLINE_DIR+"/";
        File storageDir = new File(Environment.getExternalStorageDirectory().getPath(), child);
        return storageDir;
    }


    public void deleteAllFiles() {
        try {
            String childDir = ApConstants.kDIR + "/" + ApConstants.kVISITS_DIR + "/" + ApConstants.kVISITS_OFFLINE_DIR;
            File dir = new File(Environment.getExternalStorageDirectory().getPath()+"/"+childDir);
            if (dir != null && dir.isDirectory()) {
                if (dir.listFiles() != null ) {
                    if (dir.listFiles().length > 0) {
                        AppUtility.getInstance().deleteAllFileFromDirectory(dir);
                    }
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }

    }



    //TODO If flag is true means that user is offline data access else online data access
    public boolean isOfflineMode() {
        return AppSettings.getInstance().getBooleanValue(mContext, ApConstants.kOnlineOfflineMode, false);
    }

   /* public ProfileModel getProfileModel() {
        String profile = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kLOGIN_DATA);
        try {
            JSONObject jsonObject = new JSONObject(profile);

            return new ProfileModel(jsonObject);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }*/


    //:: TODO Season Related
    public int getSeasonType() {
        int season = AppSettings.getInstance().getIntValue(mContext, ApConstants.kSEASON_ID, 0);
        return season;
    }


    //:: TODO App ID For FFS APP
    public int getAppId() {
        return 1;
    }


    //:: TODO Get Deploy Build Version
    public int getServerAppBuildVer() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kAPP_BUILD_VER);
        int buildVer = 0;
        try {
            JSONObject jsonObject = new JSONObject(data);
            buildVer = jsonObject.getInt("build_version");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return buildVer;
    }




    public int getRoleId() {
        return 11; //Host farmer registration
    }

    public int getUserRoleId() {
        int role_id = AppSettings.getInstance().getIntValue(mContext, ApConstants.kROLE_ID, 0);
        return role_id; //Role Id
    }

    //::TODO Schedule Status

    public int scheduleCompleted() {
        return 1;
    }

    public int reschedule() {
        return 2;
    }

    public int scheduleMissed() {
        return 3;
    }

    public int todaySchedule() {
        return 4;
    }

    public int upcomingSchedule() {
        return 5;
    }


    //:: TODO Dashboard
    public JSONArray getSchedule() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kSCHEDULES);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kSCHEDULES)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public JSONArray getHistoryOfVisits() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kHISTORY_OF_VISITS);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kHISTORY_OF_VISITS)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }


    public JSONArray getCropAdvisory() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kCROP_ADVISORY);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kCROP_ADVISORY)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public int getPlotID() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kPLOT_ID, 0);
    }

    public int getScheduleId() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kSCHEDULE_ID, 0);
    }

    public int getVisitNumber() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kVISIT_NUM, 0);
    }

    public int getVisitCount() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kVISIT_COUNT, 0);
    }

    public String getCropName() {
        return AppSettings.getInstance().getSavedValue(mContext, ApConstants.kCROP_NAME);
    }

    public String getInterCropName() {
        return AppSettings.getInstance().getSavedValue(mContext, ApConstants.kINTER_CROP_NAME);
    }

    public int getInterVisitCropCount() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kINTER_CROP_VISIT_COUNT, 0);
    }




    public JSONArray getAttendance() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kATTENDANCE)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }


    public String getAttendanceFileName() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getAttendanceFilePath() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_PATH);
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_PATH))   {
            return "";
        }
        return AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_PATH);
    }


    public String getAttendanceFileURL() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getAttendanceFileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_FILE_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_FILE_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }

    //TODO Attendance Photo list
    public String getAttendanceListFileName() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_LIST_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_LIST_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getAttendanceListFilePath() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_LIST_PATH);
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_LIST_PATH))   {
            return "";
        }
        return AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_LIST_PATH);
    }


    public String getAttendanceListFileURL() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_LIST_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_LIST_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getAttendanceListFileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kATTENDANCE_LIST_FILE_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kATTENDANCE_LIST_FILE_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }


    public JSONArray getTechDemo() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public JSONArray getInputDemo() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kINPUT_DEMO);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kINPUT_DEMO)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public String getTechDemoFileName1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE1);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE1)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getTechDemoFileURL1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE1);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE1)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }


    public String getTechDemoFileName2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE2);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE2)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getTechDemoFileURL2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE2);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE2)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONObject dataJSON = jsonObject.getJSONObject("data");
                fileName = dataJSON.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getTechDemoFilePATH1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_PATH1);
        String filePath = null;

        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_PATH1)) {
            filePath = "";
        } else {
            filePath = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_PATH1);
        }

        return filePath;
    }

    public String getTechDemoFilePATH2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_PATH2);
        String filePath = null;

        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_PATH2)) {
            filePath = "";
        } else {
            filePath = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_PATH2);
        }

        return filePath;
    }


    public String getTechDemo1FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE1_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE1_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }

    public String getTechDemo2FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kTECH_DEMO_FILE2_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kTECH_DEMO_FILE2_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }







    //TODO FFS Plot Observations
    public String getPostServerObservations(int type) {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBSERVATIONS);
        JSONArray jsonArray = null;
        JSONObject jsonObject = new JSONObject();
        try {
            if (data.equalsIgnoreCase(ApConstants.kOBSERVATIONS)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }

            jsonObject.put("cropping_system_id", type);
            jsonObject.put("major_obs", jsonArray);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonObject.toString();
    }


    public JSONArray getObservations() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBSERVATIONS);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kOBSERVATIONS)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return jsonArray;
    }

    public JSONArray getObservationsIntercrop() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBSERVATIONS);
        JSONArray jsonArray = null;

        try {

            if (data.equalsIgnoreCase(ApConstants.kOBSERVATIONS)) {
                jsonArray = new JSONArray();

            } else {
                JSONObject jsonObject = new JSONObject(data);

                if (jsonObject.isNull("major_obs")) {
                    jsonArray = jsonObject.getJSONArray("inter_obs");
                } else {
                    JSONArray jsonArray1 = jsonObject.getJSONArray("major_obs");
                    JSONArray jsonArray2 = jsonObject.getJSONArray("inter_obs");

                    jsonArray = new JSONArray();

                    for (int j = 0; j < jsonArray1.length(); j++) {
                        JSONObject jsonObject1 = jsonArray1.getJSONObject(j);
                        jsonArray.put(jsonObject1);
                    }

                    for (int j = 0; j < jsonArray2.length(); j++) {
                        JSONObject jsonObject1 = jsonArray2.getJSONObject(j);
                        jsonArray.put(jsonObject1);
                    }
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public JSONObject getPostObservationsIntercrop() {

        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBSERVATIONS);
        JSONObject jsonObject = null;

        try {

            if (data.equalsIgnoreCase(ApConstants.kOBSERVATIONS)) {
                jsonObject = new JSONObject();

            } else {
                jsonObject = new JSONObject(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonObject;
    }


    public String getObsFileName1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE1);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE1)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }


    public String getObsFileURL1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE1);
        String fileName = "";
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE1)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }


    public String getObsFileName2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE2);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE2)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFileURL2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE2);
        String fileName = "";
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE2)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFileName3() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE3);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE3)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFileURL3() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE3);
        String fileName = "";
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE3)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFileName4() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE4);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE4)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFileURL4() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE4);
        String fileName = "";
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE4)) {
            fileName = "";
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getObsFilePATH1() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_PATH1);
        if (data.equalsIgnoreCase(ApConstants.kOBS_PATH1)) {
            return "";
        }
        return data;
    }

    public String getObsFilePATH2() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_PATH2);
        if (data.equalsIgnoreCase(ApConstants.kOBS_PATH2))   {
            return "";
        }
        return data;
    }

    public String getObsFilePATH3() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_PATH3);
        if (data.equalsIgnoreCase(ApConstants.kOBS_PATH3)) {
            return "";
        }
        return data;
    }

    public String getObsFilePATH4() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_PATH4);
        if (data.equalsIgnoreCase(ApConstants.kOBS_PATH4)) {
            return "";
        }
        return data;
    }


    public String getObs1FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE1_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE1_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }
        return latLong;
    }

    public String getObs2FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE2_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE2_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }
        return latLong;
    }

    public String getObs3FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE3_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE3_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }

    public String getObs4FileLatLon() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_FILE4_LOC);
        String latLong = null;
        if (data.equalsIgnoreCase(ApConstants.kOBS_FILE4_LOC)) {
            latLong = "0";
        } else {
            latLong = data;
        }

        return latLong;
    }

    public String getPostObservations(int cropType) {

        JSONArray jsonArray = cropType == CroppingSystem.SOLE.id() ? getObservations() : getObservationsIntercrop();


        JSONObject jsonObject = new JSONObject();

        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                if (jsonObject1.getInt("id") == 0) {
                    jsonObject.put("no_leaves", jsonObject1.getString("value"));
                }

                if (jsonObject1.getInt("id") == 1) {
                    jsonObject.put("plant_ht", jsonObject1.getString("value"));
                }

                if (jsonObject1.getInt("id") == 2) {
                    jsonObject.put("no_flowers", jsonObject1.getString("value"));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (jsonArray.length() == 0) {
            return "";

        } else {
            return jsonArray.toString();
        }

    }

    public long getDateSowing() {
        long id = AppSettings.getInstance().getLongValue(mContext, ApConstants.kOBS_DATE_SOWING, 0);
        return id;
    }

    public String getMethodSowing() {
        String String = AppSettings.getInstance().getValue(mContext, ApConstants.kOBS_METHOD_SOWING, ApConstants.kOBS_METHOD_SOWING);
        return String;
    }

    public int getCropVariety() {
        int id = AppSettings.getInstance().getIntValue(mContext, ApConstants.kOBS_CROP_VARIETY, 0);
        return id;
    }

    public int getIrrigationMethod() {
        int id = AppSettings.getInstance().getIntValue(mContext, ApConstants.kOBS_IRRIGATION_METHOD, 0);
        return id;
    }







    public int getVisitUniqueId() {
        return AppSettings.getInstance().getIntValue(mContext, ApConstants.kVISIT_UNIQUE_ID, 0);
    }

    public int getCropId() {
        int id = AppSettings.getInstance().getIntValue(mContext, ApConstants.kCROP_UNIQUE_ID, 0);
        return id;
    }




    //::TODO Soil Test Report

    public String getSoilTestReportFileName() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kSOIL_TEST_REPORT_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kSOIL_TEST_REPORT_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public String getSoilTestReportFileURL() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kSOIL_TEST_REPORT_FILE);
        String fileName = null;
        if (data.equalsIgnoreCase(ApConstants.kSOIL_TEST_REPORT_FILE)) {
            fileName = null;
        } else {
            try {
                JSONObject jsonObject = new JSONObject(data);
                fileName = jsonObject.getString("file_url");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return fileName;
    }

    public JSONArray getYieldAttendance() {
        String data = AppSettings.getInstance().getSavedValue(mContext, ApConstants.kYIELD_ATTENDANCE);
        JSONArray jsonArray = null;
        try {
            if (data.equalsIgnoreCase(ApConstants.kYIELD_ATTENDANCE)) {
                jsonArray = new JSONArray();
            } else {
                jsonArray = new JSONArray(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }



    public int getObsWeatherId() {
        int id =  AppSettings.getInstance().getIntValue(mContext, ApConstants.kOBS_WEATHER_ID, 0);
        return id;
    }

    public String getObsWeatherName() {
        String name =  AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_WEATHER_NAME);
        if (name.equalsIgnoreCase(ApConstants.kOBS_WEATHER_NAME)) {
            name = "";
        }
        return name;
    }

    public int getObsWindId() {
        int id =  AppSettings.getInstance().getIntValue(mContext, ApConstants.kOBS_WIND_ID, 0);
        return id;
    }

    public String getObsWindName() {
        String name =  AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_WIND_NAME);
        if (name.equalsIgnoreCase(ApConstants.kOBS_WIND_NAME)) {
            name = "";
        }
        return name;
    }

    public int getObsRainfallId() {
        int id =  AppSettings.getInstance().getIntValue(mContext, ApConstants.kOBS_RAINFALL_ID, 0);
        return id;
    }

    public String getObsRainfallName() {
        String name =  AppSettings.getInstance().getSavedValue(mContext, ApConstants.kOBS_RAINFALL_NAME);
        if (name.equalsIgnoreCase(ApConstants.kOBS_RAINFALL_NAME)) {
            name = "";
        }
        return name;
    }



    //::TODO Offline

    public boolean isOfflineSynced() {
        return AppSettings.getInstance().getBooleanValue(mContext, ApConstants.kIS_OFFLINE, false);
    }


    public void logoutFromApplication() {
        AppUtility.getInstance().clearAppSharedPrefData(mContext, ApConstants.kSHARED_PREF);
        AppSettings.getInstance().setValue(mContext, ApConstants.kSCHEDULES, ApConstants.kSCHEDULES);
        AppSettings.getInstance().setValue(mContext, ApConstants.kHISTORY_OF_VISITS, ApConstants.kHISTORY_OF_VISITS);
        AppSettings.getInstance().setValue(mContext, ApConstants.kCROP_ADVISORY, ApConstants.kCROP_ADVISORY);
        AppSettings.getInstance().setIntValue(mContext, ApConstants.kSEASON_ID, 0);
        AppSettings.getInstance().setBooleanValue(mContext, ApConstants.kIS_LOGGED_IN, false);

    }


    public void clearTempDataForSchedule() {

        AppSettings.getInstance().setIntValue(mContext, ApConstants.kSCHEDULE_ID, 0);

        AppSettings.getInstance().setIntValue(mContext, ApConstants.kVISIT_COUNT, 0);
        AppSettings.getInstance().setValue(mContext, ApConstants.kINTER_CROP_NAME, ApConstants.kINTER_CROP_NAME);
        AppSettings.getInstance().setValue(mContext, ApConstants.kCROP_NAME, ApConstants.kCROP_NAME);
        AppSettings.getInstance().setIntValue(mContext, ApConstants.kINTER_CROP_VISIT_COUNT, 0);

        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE_FILE_LOC, ApConstants.kATTENDANCE_FILE_LOC);

        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE1_LOC, ApConstants.kTECH_DEMO_FILE1_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE2_LOC, ApConstants.kTECH_DEMO_FILE2_LOC);

        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE, ApConstants.kATTENDANCE);
        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE_FILE, ApConstants.kATTENDANCE_FILE);

        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO, ApConstants.kTECH_DEMO);
        AppSettings.getInstance().setValue(mContext, ApConstants.kINPUT_DEMO, ApConstants.kINPUT_DEMO);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE1, ApConstants.kTECH_DEMO_FILE1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE2, ApConstants.kTECH_DEMO_FILE2);

        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_PATH1, ApConstants.kTECH_DEMO_PATH1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_PATH2, ApConstants.kTECH_DEMO_PATH2);


        AppSettings.getInstance().setIntValue(mContext, ApConstants.kCROP_UNIQUE_ID, 0);

        AppSettings.getInstance().setValue(mContext, ApConstants.kOBSERVATIONS, ApConstants.kOBSERVATIONS);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE1, ApConstants.kOBS_FILE1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE2, ApConstants.kOBS_FILE2);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE3, ApConstants.kOBS_FILE3);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE4, ApConstants.kOBS_FILE4);

        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE1_LOC, ApConstants.kOBS_FILE1_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE2_LOC, ApConstants.kOBS_FILE2_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE3_LOC, ApConstants.kOBS_FILE3_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE4_LOC, ApConstants.kOBS_FILE4_LOC);

        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_PATH1, ApConstants.kOBS_PATH1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_PATH2, ApConstants.kOBS_PATH2);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_PATH3, ApConstants.kOBS_PATH3);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_PATH4, ApConstants.kOBS_PATH4);


        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_WEATHER_NAME, ApConstants.kOBS_WEATHER_NAME);
        AppSettings.getInstance().setIntValue(mContext, ApConstants.kOBS_WEATHER_ID, 0);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_WIND_NAME, ApConstants.kOBS_WIND_NAME);
        AppSettings.getInstance().setIntValue(mContext, ApConstants.kOBS_WIND_ID, 0);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_RAINFALL_NAME, ApConstants.kOBS_RAINFALL_NAME);
        AppSettings.getInstance().setIntValue(mContext, ApConstants.kOBS_RAINFALL_ID, 0);

    }

    public void clearDataForScheduleVisits() {

        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE_FILE_LOC, ApConstants.kATTENDANCE_FILE_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE, ApConstants.kATTENDANCE);
        AppSettings.getInstance().setValue(mContext, ApConstants.kATTENDANCE_FILE, ApConstants.kATTENDANCE_FILE);

        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE1_LOC, ApConstants.kTECH_DEMO_FILE1_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE2_LOC, ApConstants.kTECH_DEMO_FILE2_LOC);

        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO, ApConstants.kTECH_DEMO);
        AppSettings.getInstance().setValue(mContext, ApConstants.kINPUT_DEMO, ApConstants.kINPUT_DEMO);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE1, ApConstants.kTECH_DEMO_FILE1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kTECH_DEMO_FILE2, ApConstants.kTECH_DEMO_FILE2);

        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE1_LOC, ApConstants.kOBS_FILE1_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE2_LOC, ApConstants.kOBS_FILE2_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE3_LOC, ApConstants.kOBS_FILE3_LOC);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE4_LOC, ApConstants.kOBS_FILE4_LOC);

        AppSettings.getInstance().setValue(mContext, ApConstants.kOBSERVATIONS, ApConstants.kOBSERVATIONS);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE1, ApConstants.kOBS_FILE1);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE2, ApConstants.kOBS_FILE2);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE3, ApConstants.kOBS_FILE3);
        AppSettings.getInstance().setValue(mContext, ApConstants.kOBS_FILE4, ApConstants.kOBS_FILE4);


    }

}
