package com.maha.agri.ochard_mapping;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.maha.agri.R;

import org.json.JSONArray;

import static android.widget.LinearLayout.HORIZONTAL;


public class OrchardSurveyListViewDialog extends Dialog implements View.OnClickListener,OrchardSurveyInterface {


    public OrchardSurveyListViewDialog(Context context, int themeResId) {
        super(context, themeResId);
    }

/*
    public OrchardSurveyListViewDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }
*/


    public Context context;
    public Dialog dialog;
    public Button yes, no;
    LinearLayout add_new_ll;
    TextView survey_count;
    RecyclerView recyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter adapter;
    private JSONArray orchardSurveyList;
    SearchView search;


    public OrchardSurveyListViewDialog(Context context, JSONArray orchardSurveyList) {
        super(context);
        this.context = context;
        this.orchardSurveyList = orchardSurveyList;
        setupLayout();
    }

    public OrchardSurveyListViewDialog(Context context) {
        super(context);
        this.context = context;

    }

    private void setupLayout() {

    }

    ///
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.orchard_surveylist_dialog);
        yes = (Button) findViewById(R.id.yes);
        no = (Button) findViewById(R.id.no);
        add_new_ll = findViewById(R.id.add_new_ll);
        survey_count = findViewById(R.id.survey_count);
        recyclerView = findViewById(R.id.recycler_view);
        search = findViewById(R.id.search);
        mLayoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(mLayoutManager);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);

        DividerItemDecoration itemDecor = new DividerItemDecoration(context, HORIZONTAL);
        recyclerView.addItemDecoration(itemDecor);


       // recyclerView.setAdapter(adapter);
        yes.setOnClickListener(this);
        no.setOnClickListener(this);
        add_new_ll.setOnClickListener(this);
        survey_count.setText(orchardSurveyList.length() + "");


        // searchview in Orchard Existing Survey List
        OrchardSurveyAdapter dataAdapter = new OrchardSurveyAdapter(orchardSurveyList,this, context);
        recyclerView.setAdapter(dataAdapter);

        // listening to search query text change
        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted

               // dataAdapter.filter(query);
               // adapter.notifyDataSetChanged();
               // dataAdapter.notifyDataSetChanged();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                dataAdapter.filter(query);
//dataAdapter.notifyDataSetChanged();
             //   adapter.notifyDataSetChanged();
                return false;
            }
        });


}


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.yes:
                //Do Something
                break;
            case R.id.no:
                dismiss();
                break;
            case R.id.add_new_ll:
                Intent intent = new Intent(context, OrchardMappingActivity.class);
                intent.putExtra("orchardSurvey_list", orchardSurveyList.toString());
                context.startActivity(intent);
                dismiss();
                break;
            default:
                break;
        }
        dismiss();
    }


    @Override
    public void getUpdatedCount(int length) {
        survey_count.setText(length + "");
    }
}